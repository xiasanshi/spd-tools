function _(_, e) {
    if (!(_ instanceof e)) throw new TypeError("Cannot call a class as a function");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.YodaServer = exports.modulesInfo = exports.closeStatus = exports.rohr = exports.rohrConfig = exports.source = exports.embedModule = exports.modules = exports.feVersion = void 0;

var e = function() {
    function _(_, e) {
        for (var I = 0; I < e.length; I++) {
            var o = e[I];
            o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
            Object.defineProperty(_, o.key, o);
        }
    }
    return function(e, I, o) {
        return I && _(e.prototype, I), o && _(e, o), e;
    };
}(), I = function(_) {
    return _ && _.__esModule ? _ : {
        default: _
    };
}(require("./rohr-1.0.1")), o = (getApp(), {
    i: 100019
}), r = function() {
    function I() {
        _(this, I), this.yodaServer = null;
    }
    return e(I, [ {
        key: "getServer",
        value: function() {
            return getApp().globalData || (getApp().globalData = {
                yodaUrl: "https://verify-test.meituan.com"
            }), getApp().globalData.yodaUrl || "https://verify-test.meituan.com";
        }
    } ], [ {
        key: "getYodaServer",
        value: function() {
            return this.yodaServer || (this.yodaServer = new I()), this.yodaServer;
        }
    } ]), I;
}(), R = {
    slider: "2.0.4",
    sms: "2.0.4",
    image: "2.0.4",
    voice: "2.0.4",
    lbs: "2.0.4",
    names: "2.0.4",
    birthday: "2.0.4",
    buying: "2.0.4"
}, t = {
    1: "图片",
    4: "短信",
    18: "支付密码",
    40: "语音",
    69: "历史购买",
    71: "滑块",
    79: "地址位置",
    87: "手机号",
    89: "生日",
    100: "姓名",
    110: "身份证",
    117: "光线人脸"
}, E = {
    1: "imageInfo",
    4: "smsInfo",
    18: "passwordInfo",
    40: "voiceInfo",
    69: "buyingInfo",
    71: "sliderInfo",
    79: "lbsInfo",
    87: "手机号",
    89: "birthdayInfo",
    100: "namesInfo",
    110: "idcardInfo",
    117: "faceInfo",
    "-1": "groupInfo"
}, S = [ 1, 4, 12, 15, 40, 71 ], n = {
    RISK_DEFAULT_ERROR: "121000",
    RISK_NO_SUCH_ACTION: "121001",
    RISK_COMMON_PARAMS_LOST: "121002",
    RISK_NO_SUCH_SCENE: "121003",
    RISK_USER_NOT_LOAD: "121004",
    RISK_PARAMS_INVALID_FORMART: "121005",
    RISK_NO_SUCH_METHOD: "121006",
    RISK_NOT_VERIFY_BY_ORDER: "121007",
    RISK_GET_VERIFYINFO_LIMIT: "121009",
    RISK_VERIFY_ERROR_TIMES_LIMIT: "121010",
    RISK_USER_NOT_BINDED: "121011",
    RISK_PARAMS_LOST: "121018",
    RISK_USER_RESETPWD_CODE_EXPIRE: "121036",
    RISK_MOBILE_NOT_EXIST: "121040",
    RISK_GET_VERIFY_INFO_ERROR: "121042",
    RISK_AUTHORIZE_CODE_FAIL: "121043",
    RISK_AUTHORIZE_CODE_EXPIRE: "121044",
    RISK_RISK_LEVEL_NOT_VALID: "121045",
    RISK_GET_VERIFY_CODE_CNT_REACH_LIMIT: "121046",
    RISK_LEVEL_DENY: "121051",
    RISK_VERIFY_REQUEST_TIME_OUT: "121052",
    RISK_FAKE_REQUEST: "121053",
    RISK_VOICE_SEND_TIMES_LIMIT_ONE_DAY: "121055",
    RISK_BOOM_PROOF_DENY: "121056",
    RISK_VERIFY_INFO_LOSE_EFFICACY: "121057",
    RISK_SLIDER_VERIFY_FAILED: "121058",
    RISK_GET_VERIFYINFO_TIMES_LIMIT_ONE_DAY: "121061",
    RISK_VERIFY_PAYPWD_USE_PAY_ERROR_LIMIT: "121064",
    RISK_VERIFY_ERROR_TIMES_LIMIT_ONE_DAY: "121065",
    RISK_KLINGON_OUT_OF_SERVICE: "121066",
    RISK_GET_VERIFY_INFO_ERROR_RETRY: "121067",
    RISK_NO_AUTH: "121999"
};

exports.feVersion = R, exports.modules = t, exports.embedModule = S, exports.source = 13, 
exports.rohrConfig = o, exports.rohr = I.default, exports.closeStatus = n, exports.modulesInfo = E, 
exports.YodaServer = r;