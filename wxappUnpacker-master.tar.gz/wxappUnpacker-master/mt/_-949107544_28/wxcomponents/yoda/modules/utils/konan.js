function r(r, t) {
    return void 0 === r || null === r || 0 === r.length ? r : (r = a(r), t = a(t), u(c(i(r, !0), h(i(t, !1))), !1));
}

function t(r, t) {
    return void 0 === r || null === r || 0 === r.length ? r : (t = a(t), n(u(f(i(r, !1), h(i(t, !1))), !0)));
}

function n(r, t) {
    return (void 0 === t || null === t || t < 0) && (t = r.length), 0 === t ? "" : /^[\x00-\x7f]*$/.test(r) || !/^[\x00-\xff]*$/.test(r) ? t === r.length ? r : r.substr(0, t) : t < 65535 ? utf8DecodeShortString(r, t) : utf8DecodeLongString(r, t);
}

function e(r) {
    return 4294967295 & r;
}

function o(r, t, n, e, o, f) {
    return (n >>> 5 ^ t << 2) + (t >>> 3 ^ n << 4) ^ (r ^ t) + (f[3 & e ^ o] ^ n);
}

function f(r, t) {
    var n, f, a, u, i, h = r.length, c = h - 1;
    for (n = r[0], a = e(Math.floor(6 + 52 / h) * l); 0 !== a; a = e(a - l)) {
        for (u = a >>> 2 & 3, i = c; i > 0; --i) f = r[i - 1], n = r[i] = e(r[i] - o(a, n, f, i, u, t));
        f = r[c], n = r[0] = e(r[0] - o(a, n, f, 0, u, t));
    }
    return r;
}

function a(r) {
    if (/^[\x00-\x7f]*$/.test(r)) return r;
    for (var t = [], n = r.length, e = 0, o = 0; e < n; ++e, ++o) {
        var f = r.charCodeAt(e);
        if (f < 128) t[o] = r.charAt(e); else if (f < 2048) t[o] = String.fromCharCode(192 | f >> 6, 128 | 63 & f); else if (f < 55296 || f > 57343) t[o] = String.fromCharCode(224 | f >> 12, 128 | f >> 6 & 63, 128 | 63 & f); else if (e + 1 < n) {
            var a = r.charCodeAt(e + 1);
            if (f < 56320 && 56320 <= a && a <= 57343) {
                var u = 65536 + ((1023 & f) << 10 | 1023 & a);
                t[o] = String.fromCharCode(240 | u >> 18 & 63, 128 | u >> 12 & 63, 128 | u >> 6 & 63, 128 | 63 & u), 
                ++e;
                continue;
            }
        }
    }
    return t.join("");
}

function u(r, t) {
    var n = r.length, e = n << 2;
    if (t) {
        var o = r[n - 1];
        if (e -= 4, o < e - 3 || o > e) return null;
        e = o;
    }
    for (var f = 0; f < n; f++) r[f] = String.fromCharCode(255 & r[f], r[f] >>> 8 & 255, r[f] >>> 16 & 255, r[f] >>> 24 & 255);
    var a = r.join("");
    return t ? a.substring(0, e) : a;
}

function i(r, t) {
    var n = r.length, e = n >> 2;
    0 != (3 & n) && ++e;
    var o;
    t ? (o = new Array(e + 1), o[e] = n) : o = new Array(e);
    for (var f = 0; f < n; ++f) o[f >> 2] |= r.charCodeAt(f) << ((3 & f) << 3);
    return o;
}

function h(r) {
    return r.length < 4 && (r.length = 4), r;
}

function c(r, t) {
    var n, e, o, f, a, u, i = r.length, h = i - 1;
    for (e = r[h], o = 0, u = 0 | Math.floor(6 + 52 / i); u > 0; --u) {
        for (f = (o = o + 2654435769 & 4294967295) >>> 2 & 3, a = 0; a < h; ++a) n = r[a + 1], 
        e = r[a] = r[a] + ((e >>> 5 ^ n << 2) + (n >>> 3 ^ e << 4) ^ (o ^ n) + (t[3 & a ^ f] ^ e)) & 4294967295;
        n = r[0], e = r[h] = r[h] + ((e >>> 5 ^ n << 2) + (n >>> 3 ^ e << 4) ^ (o ^ n) + (t[3 & h ^ f] ^ e)) & 4294967295;
    }
    return r;
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var l = 2654435769, d = function() {
    var r = [ -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, -1, -1, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -1, -1, -1, -1, -1, -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -1, -1, -1, -1, -1 ];
    return function(t) {
        var n, e, o, f, a, u, i, h, c, l;
        if ((i = t.length) % 4 != 0) return "";
        if (/[^ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789\+\/\=]/.test(t)) return "";
        for (c = i, (h = "=" == t.charAt(i - 2) ? 1 : "=" == t.charAt(i - 1) ? 2 : 0) > 0 && (c -= 4), 
        c = 3 * (c >> 2) + h, l = new Array(c), a = u = 0; a < i && -1 != (n = r[t.charCodeAt(a++)]) && -1 != (e = r[t.charCodeAt(a++)]) && (l[u++] = String.fromCharCode(n << 2 | (48 & e) >> 4), 
        -1 != (o = r[t.charCodeAt(a++)])) && (l[u++] = String.fromCharCode((15 & e) << 4 | (60 & o) >> 2), 
        -1 != (f = r[t.charCodeAt(a++)])); ) l[u++] = String.fromCharCode((3 & o) << 6 | f);
        return l.join("");
    };
}(), C = function() {
    var r = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".split("");
    return function(t) {
        var n, e, o, f, a, u, i;
        for (e = o = 0, f = t.length, u = (f -= a = f % 3) / 3 << 2, a > 0 && (u += 4), 
        n = new Array(u); e < f; ) i = t.charCodeAt(e++) << 16 | t.charCodeAt(e++) << 8 | t.charCodeAt(e++), 
        n[o++] = r[i >> 18] + r[i >> 12 & 63] + r[i >> 6 & 63] + r[63 & i];
        return 1 == a ? (i = t.charCodeAt(e++), n[o++] = r[i >> 2] + r[(3 & i) << 4] + "==") : 2 == a && (i = t.charCodeAt(e++) << 8 | t.charCodeAt(e++), 
        n[o++] = r[i >> 10] + r[i >> 4 & 63] + r[(15 & i) << 2] + "="), n.join("");
    };
}(), g = {};

g.Kaito = function(t, n) {
    return C(r(t, n));
}, g.Otiak = function(r, n) {
    return t(d(r), n);
}, exports.default = g;