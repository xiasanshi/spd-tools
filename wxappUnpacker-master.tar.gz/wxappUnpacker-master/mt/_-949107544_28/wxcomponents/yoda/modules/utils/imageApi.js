function e(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var t = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("./../../modules/utils/api")), a = require("./../../modules/utils/config"), o = new t.default();

exports.default = function t() {
    var i = this;
    e(this, t), this.initImage = function(e, t) {
        i.requestCode = e, o.getPageData(e, "image").then(function(a) {
            var o = a.status, s = a.data, n = a.error;
            0 === o && wx.showToast({
                title: "请求异常",
                content: "请求异常",
                complete: function() {
                    t.triggerEvent ? t.triggerEvent("imageEvent", {
                        status: 0,
                        code: n.code
                    }, {
                        bubbles: !0,
                        composed: !0
                    }) : t.props.imageEvent({
                        status: 0,
                        code: n.code
                    }), t.setData({
                        isShow: !1
                    });
                }
            }), t.setData({
                data: s,
                imgsrc: i.baseUrl + "/v2/captcha?request_code=" + e + "&action=" + s.action + "&captchaHash=" + Number(new Date()),
                opacity: .5,
                animationData: {},
                plain: !0,
                isShow: !0
            });
        }).catch(function() {
            t.triggerEvent ? t.triggerEvent("imageEvent", {
                status: 0,
                code: 99999
            }, {
                bubbles: !0,
                composed: !0
            }) : t.props.imageEvent({
                status: 0,
                code: 99999
            }), t.setData({
                isShow: !1
            });
        });
        var a = wx.createAnimation({
            transformOrigin: "50% 50%",
            duration: 500,
            timingFunction: "ease",
            delay: 0
        });
        t.animation = a;
    }, this.bindImgVerify = function(e, t) {
        var a = e.value, i = e.data, s = i.action, n = i.request_code, r = i.type, c = i.listIndex;
        1 === e.opacity && (wx.showLoading({
            title: "验证中...",
            mask: !0
        }), o.verify({
            request_code: n,
            type: r,
            action: s,
            options: {
                captchacode: a,
                listIndex: c
            }
        }).then(function(e) {
            if (e) {
                var a = e.status, o = e.data, i = e.error;
                if (wx.hideLoading(), 1 === a) {
                    var s = {
                        status: 1,
                        requestCode: n,
                        responseCode: o.response_code
                    }, r = {
                        bubbles: !0,
                        composed: !0
                    };
                    t.triggerEvent ? t.triggerEvent("imageEvent", s, r) : t.props.imageEvent(s), t.setData({
                        value: "",
                        opacity: .5,
                        isShow: !1
                    });
                } else {
                    var c = i.code;
                    121020 === c ? (wx.showToast({
                        title: "验证码错误",
                        content: "验证码错误",
                        mask: !0,
                        icon: "loading",
                        type: "fail",
                        complete: t.bingUpdateImg()
                    }), t.setData({
                        value: "",
                        opacity: .5
                    })) : (t.triggerEvent ? t.triggerEvent("imageEvent", {
                        status: 0,
                        code: c
                    }, {
                        bubbles: !0,
                        composed: !0
                    }) : t.props.imageEvent({
                        status: 0,
                        code: c
                    }), t.setData({
                        value: "",
                        opacity: .5,
                        isShow: !1
                    }));
                }
            }
        }).catch(function(e) {
            t.triggerEvent ? t.triggerEvent("imageEvent", {
                status: 0,
                code: 99999
            }, {
                bubbles: !0,
                composed: !0
            }) : t.props.imageEvent({
                status: 0,
                code: 99999
            }), t.setData({
                isShow: !1
            });
        }));
    }, this.changeImage = function(e) {
        var t = e.data.imgsrc, a = e.data.data;
        t = i.baseUrl + "/v2/captcha?request_code=" + a.request_code + "&action=" + a.action + "&captchaHash=" + Number(new Date()), 
        e.setData({
            imgsrc: t
        });
    }, this.bindImgCodeInput = function(e, t) {
        var a = t.data.opacity;
        a = e && 4 === e.length ? 1 : .5, t.setData({
            value: e,
            opacity: a
        });
    }, this.baseUrl = a.YodaServer.getYodaServer().getServer();
};