function e(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

var t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var o = "function" == typeof Symbol && "symbol" == t(Symbol.iterator) ? function(e) {
    return void 0 === e ? "undefined" : t(e);
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : void 0 === e ? "undefined" : t(e);
}, a = require("./config");

exports.default = function t() {
    var n = this;
    e(this, t), this.getPageData = function(e, t) {
        var o = {
            requestCode: e,
            feVersion: a.feVersion[t] || "0.1.0",
            source: a.source
        };
        return o._token = encodeURIComponent(a.rohr.r(o)), new Promise(function(e, t) {
            var n = wx.request({
                method: "POST",
                url: a.YodaServer.getYodaServer().getServer() + "/v2/ext_api/page_data",
                data: o,
                header: {
                    "content-type": "application/x-www-form-urlencoded"
                },
                headers: {
                    "content-type": "application/x-www-form-urlencoded"
                },
                success: function(o) {
                    var a = o.data, n = a.status, c = a.data, r = a.error;
                    200 === o.statusCode || 200 === o.status ? e({
                        status: n,
                        data: c,
                        error: r
                    }) : t(o);
                },
                fail: function(e) {
                    t(e);
                }
            });
            setTimeout(function() {
                n.abort();
            }, 3e3);
        }).catch(function() {
            wx.showToast({
                title: "网络状况不好,稍后再试",
                content: "getPageData失败",
                icon: "none"
            });
        });
    }, this.sendInfo = function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.request_code, n = e.type, c = e.action, r = void 0 === c ? "" : c, s = e.options, i = void 0 === s ? null : s, u = {
            request_code: t
        };
        if (i && "object" === (void 0 === i ? "undefined" : o(i))) for (var l in i) i.hasOwnProperty(l) && (u[l] = i[l]);
        return u._token = encodeURIComponent(a.rohr.r(u)), new Promise(function(e, t) {
            var o = wx.request({
                url: a.YodaServer.getYodaServer().getServer() + "/v2/ext_api/" + r + "/info?id=" + n,
                method: "POST",
                data: u,
                header: {
                    "content-type": "application/x-www-form-urlencoded"
                },
                headers: {
                    "content-type": "application/x-www-form-urlencoded"
                },
                success: function(o) {
                    var a = o.data, n = a.status, c = a.data, r = a.error;
                    200 === o.statusCode || 200 === o.status ? e({
                        status: n,
                        data: c,
                        error: r
                    }) : t("");
                },
                fail: function(e) {
                    t(e);
                }
            });
            setTimeout(function() {
                o.abort();
            }, 3e3);
        }).catch(function() {
            wx.showToast({
                title: "网络状况不好,稍后再试",
                content: "获取sendInfo失败",
                icon: "none"
            });
        });
    }, this.verify = function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.request_code, n = e.type, c = e.action, r = void 0 === c ? "" : c, s = e.options, i = void 0 === s ? null : s, u = {
            request_code: t
        };
        if (i && "object" === (void 0 === i ? "undefined" : o(i))) for (var l in i) i.hasOwnProperty(l) && (u[l] = i[l]);
        return u._token = encodeURIComponent(a.rohr.r(u)), new Promise(function(e, t) {
            var o = wx.request({
                url: a.YodaServer.getYodaServer().getServer() + "/v2/ext_api/" + r + "/verify?id=" + n,
                method: "POST",
                data: u,
                header: {
                    "content-type": "application/x-www-form-urlencoded"
                },
                headers: {
                    "content-type": "application/x-www-form-urlencoded"
                },
                success: function(o) {
                    var a = o.data, n = a.status, c = a.data, r = a.error;
                    200 === o.statusCode || 200 === o.status ? e({
                        status: n,
                        data: c,
                        error: r
                    }) : t();
                },
                fail: function(e) {
                    t(e);
                }
            });
            setTimeout(function() {
                o.abort();
            }, 3e3);
        }).catch(function() {
            wx.showToast({
                title: "网络状况不好,稍后再试",
                duration: 2e3,
                content: "获取verify失败",
                icon: "none"
            });
        });
    }, this.nextVerify = function(e, t) {
        var o = e.category;
        if (e.type = t, "GROUP" === o && (t || 0 === t)) return wx.setStorage({
            key: "yodaPageData",
            data: e
        }), wx.redirectTo({
            url: "./../../modules/index/index"
        }), !0;
    }, this.catchCallback = function(e, t, o, a, n, c) {
        if ("face" !== c) wx.showToast({
            title: e,
            content: e,
            icon: "none",
            type: "none",
            mask: !0,
            duration: 2e3,
            complete: function() {
                if ("string" == typeof n.callBackFail) {
                    var e = "status=0&code=" + t + "&msg=" + o;
                    e = n.callBackFail.indexOf("?") > 0 ? "&" + e : "?" + e, setTimeout(function() {
                        n.navigate({
                            options: a,
                            url: n.callBackFail + e
                        });
                    }, 1e3);
                }
                "function" === n.callBackFail && setTimeout(function() {
                    n.callBackFail({
                        status: 0,
                        code: t,
                        msg: o
                    });
                }, 1e3);
            }
        }); else {
            if ("string" == typeof n.callBackFail) {
                var r = "status=0&code=" + t + "&msg=" + o;
                r = n.callBackFail.indexOf("?") > 0 ? "&" + r : "?" + r, n.navigate({
                    options: a,
                    url: n.callBackFail + r
                });
            }
            "function" === n.callBackFail && n.callBackFail({
                status: 0,
                code: t,
                msg: o
            });
        }
    }, this.errorCallback = function(e, t, o, c, r) {
        var s = e.code || 0, i = e.message || "网络错误";
        switch (Object.keys(a.closeStatus).forEach(function(e) {
            Number(a.closeStatus[e]) === s && (s = "jump");
        }), s) {
          case 121008:
            wx.showToast({
                title: i,
                content: "验证错误",
                complete: o.bind(c),
                icon: "none"
            });
            break;

          case 121068:
            wx.showToast({
                title: i,
                content: "输入错误",
                complete: o.bind(c),
                icon: "none"
            });
            break;

          case 121038:
            wx.showToast({
                title: i,
                content: "操作过于频繁",
                icon: "none"
            });
            break;

          case 121044:
            n.catchCallback("授权码过期", s, i, t, c);
            break;

          case 121048:
            c.Image.showImage({
                requestCode: e.request_code
            });
            break;

          case 121060:
            c.Slider.showSlider({
                requestCode: e.request_code
            });
            break;

          case 121047:
            wx.showToast({
                title: i,
                content: "请重新发送验证",
                complete: o.bind(c),
                icon: "none"
            });
            break;

          case 121079:
          case 121084:
          case 121100:
          case 121101:
          case 121102:
          case 121063:
          case 121095:
            wx.showToast({
                title: i,
                content: "请重新操作",
                complete: o.bind(c),
                icon: "none"
            });
            break;

          case "jump":
          default:
            n.catchCallback(i, s, i, t, c, r);
        }
    }, this.successCallback = function(e, t, o, a) {
        if ("function" == typeof a.callBackSuccess && a.callBackSuccess({
            status: 1,
            requestCode: e,
            responseCode: t
        }), "string" == typeof a.callBackSuccess) {
            var n = "status=1&requestCode=" + e + "&responseCode=" + t;
            n = a.callBackSuccess.indexOf("?") > 0 ? "&" + n : "?" + n, a.navigate({
                options: o,
                url: a.callBackSuccess + n
            });
        }
    }, this.changeVerify = function(e) {
        e.type = -1, "GROUP" === e.category && (wx.setStorage({
            key: "yodaPageData",
            data: e
        }), wx.redirectTo({
            url: "./../../modules/index/index"
        }));
    };
};