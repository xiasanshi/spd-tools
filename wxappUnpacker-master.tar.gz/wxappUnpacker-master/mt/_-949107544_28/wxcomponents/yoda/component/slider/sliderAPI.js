function e(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var t = function() {
    function e(e, t) {
        for (var n = 0; n < t.length; n++) {
            var o = t[n];
            o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
            Object.defineProperty(e, o.key, o);
        }
    }
    return function(t, n, o) {
        return n && e(t.prototype, n), o && e(t, o), t;
    };
}(), n = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("./../../modules/utils/konan")), o = require("./../../modules/utils/config"), r = function() {
    function r() {
        e(this, r);
    }
    return t(r, null, [ {
        key: "getSystemInfo",
        value: function() {
            return wx.getSystemInfoSync();
        }
    }, {
        key: "getNotifyUrl",
        value: function(e, t, n) {
            var o = -1 === e.indexOf("?") ? "?" : "&";
            return new Promise(function(r) {
                wx.request({
                    url: "" + e + o + "request_code=" + t + "&response_code=" + n,
                    header: {
                        "content-type": "application/x-www-form-urlencoded"
                    },
                    headers: {
                        "content-type": "application/x-www-form-urlencoded"
                    },
                    success: function() {
                        r();
                    },
                    fail: function() {
                        r();
                    }
                });
            });
        }
    }, {
        key: "verfiySlide",
        value: function(e) {
            var t = e.action, r = e.id, i = e.requestCode, a = e.behavior, c = void 0 === a ? null : a, u = e.captchacode, s = void 0 === u ? "" : u, f = {
                id: r,
                request_code: i,
                fingerprint: ""
            }, d = this;
            return c && (f.behavior = n.default.Kaito(JSON.stringify(c), i)), s && (f.captchacode = s), 
            f._token = o.rohr.r(f), new Promise(function(e, n) {
                var i = wx.request({
                    url: o.YodaServer.getYodaServer().getServer() + "/v2/ext_api/" + t + "/verify?id=" + r,
                    method: "POST",
                    header: {
                        "content-type": "application/x-www-form-urlencoded"
                    },
                    headers: {
                        "content-type": "application/x-www-form-urlencoded"
                    },
                    data: f,
                    success: function(t) {
                        var n = getApp().$loginPage.data.pageData, o = t.data, r = o.datas, i = o.status, a = o.error;
                        if (1 === i && n.notifyUrl) {
                            var c = n.notifyUrl;
                            d.getNotifyUrl(c, n.request_code, r.response_code).then(function() {
                                e({
                                    status: i,
                                    error: a,
                                    datas: r
                                });
                            }).catch(function() {
                                wx.showToast({
                                    title: "获取notifyurl失败",
                                    content: "获取notifyurl失败",
                                    icon: "none"
                                });
                            });
                        } else e({
                            status: i,
                            error: a,
                            datas: r
                        });
                    },
                    fail: function(e) {
                        n(e);
                    }
                });
                setTimeout(function() {
                    i.abort();
                }, 3e3);
            }).catch(function() {
                wx.showToast({
                    title: "网络状况不好,稍后再试",
                    content: "获取verify失败",
                    icon: "none"
                });
            });
        }
    }, {
        key: "verfiyCode",
        value: function(e) {
            var t = e.action, n = e.id, o = e.requestCode, r = e.captchacode;
            return this.verfiySlide({
                action: t,
                id: n,
                requestCode: o,
                captchacode: r
            });
        }
    } ]), r;
}();

exports.default = r;