function e(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var t = function() {
    function e(e, t) {
        var i = [], o = !0, n = !1, r = void 0;
        try {
            for (var s, a = e[Symbol.iterator](); !(o = (s = a.next()).done) && (i.push(s.value), 
            !t || i.length !== t); o = !0) ;
        } catch (e) {
            n = !0, r = e;
        } finally {
            try {
                !o && a.return && a.return();
            } finally {
                if (n) throw r;
            }
        }
        return i;
    }
    return function(t, i) {
        if (Array.isArray(t)) return t;
        if (Symbol.iterator in Object(t)) return e(t, i);
        throw new TypeError("Invalid attempt to destructure non-iterable instance");
    };
}(), i = function() {
    function e(e, t) {
        for (var i = 0; i < t.length; i++) {
            var o = t[i];
            o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
            Object.defineProperty(e, o.key, o);
        }
    }
    return function(t, i, o) {
        return i && e(t.prototype, i), o && e(t, o), t;
    };
}(), o = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("./sliderAPI")), n = require("./../../modules/utils/config"), r = function() {
    function r(t) {
        var i = t.requestCode, n = t.pageData;
        e(this, r);
        var s = o.default.getSystemInfo() || {}, a = s.windowWidth, u = void 0 === a ? 375 : a, d = u / 375, c = u / 2 - 135 * d, l = s.windowHeight / 2 - 25 * d, h = [ 50 * d, 50 * d ], v = [ Number((270 * d).toFixed(3)), Number((52 * d).toFixed(3)) ], p = [ Number(c.toFixed(3)), Number(l.toFixed(3)) ], f = Date.now(), g = v[0] - h[0], m = this;
        Object.assign(m, {
            requestCode: i,
            windowWidth: u,
            zoom: d,
            btn: h,
            initTime: f,
            slideWidth: g,
            isDone: !1,
            zone: v,
            client: p,
            Timestamp: [ f ],
            count: 0,
            timeout: 0,
            points: null,
            trajectory: [],
            pageData: n
        });
    }
    return i(r, [ {
        key: "sliderTouchStart",
        value: function(e) {
            var t = this;
            t.Timestamp.push(Date.now()), t.count += 1, t.points = [], t.addPoint(e);
        }
    }, {
        key: "sliderTouchMove",
        value: function(e) {
            var t = this.isDone, i = this.slideWidth;
            if (t) return {
                isDone: t,
                deltaX: i,
                slideWidth: i
            };
            var o = this.addPoint(e);
            return this.getPosition(o);
        }
    }, {
        key: "sliderTouchCancel",
        value: function() {
            this.slidEnd();
        }
    }, {
        key: "sliderTouchEnd",
        value: function() {}
    }, {
        key: "getPoint",
        value: function(e) {
            var t = e.touches[0] || {};
            return [ t.clientX, t.clientY ];
        }
    }, {
        key: "addPoint",
        value: function(e) {
            var i = this.points, o = this.initTime, n = this.getPoint(e), r = t(n, 2), s = r[0], a = r[1];
            return this.points = i || [], this.points.push([ 0, s, a, Date.now() - o ]), [ s, a ];
        }
    }, {
        key: "getPosition",
        value: function(e) {
            var i = t(e, 2), o = i[0], n = (i[1], this.slideWidth), r = t(this.points, 1)[0], s = this.isDone, a = o - r[1];
            return a < 0 && (a = 0), a >= n && (a = n, this.isDone = !0, this.slidEnd()), {
                deltaX: a,
                slideWidth: n,
                isDone: s
            };
        }
    }, {
        key: "slidEnd",
        value: function() {
            var e = this, t = e.points, i = void 0 === t ? [] : t, r = e.Timestamp, s = e.pageData, a = void 0 === s ? {} : s, u = e.requestCode, d = e.trajectory;
            (d = d.slice(-3, d.length)).push({
                point: i,
                vector: {
                    orientation: "h"
                }
            }), e.trajectory = d, e.points = null, r[r.length - 1] - r[0] > 3e3 && (e.timeout += 1), 
            e.setData();
            var c = a.data, l = c.action, h = c.type, v = {
                action: l,
                id: h,
                requestCode: u,
                behavior: e.behavior
            };
            o.default.verfiySlide(v).then(function(e) {
                var t = getApp().$loginPage, i = t.data.requestCode, o = e.data, r = e.status, s = e.error;
                if (1 === r) wx.showToast({
                    title: "验证成功",
                    content: "验证成功",
                    complete: function() {
                        var e = "";
                        o && (e = o.response_code), t.triggerEvent ? t.triggerEvent("sliderEvent", {
                            status: 1,
                            requestCode: i,
                            responseCode: e
                        }, {
                            bubbles: !0,
                            composed: !0
                        }) : t.props.sliderEvent({
                            status: 1,
                            requestCode: i,
                            responseCode: e
                        }), t.setData({
                            isShow: !1
                        });
                    }
                }); else if (0 === r && 121048 === s.code) {
                    var a = s.request_code;
                    t.setData({
                        "sdk.requestCode": a
                    }), t.setData({
                        codeImage: n.YodaServer.getYodaServer().getServer() + "/v2/captcha?request_code=" + a + "&action=" + l,
                        validStep: "code"
                    });
                } else 0 === r && 121079 === s.code ? (wx.showToast({
                    title: s.message,
                    content: s.message,
                    mask: !0,
                    icon: "loading",
                    type: "fail"
                }), t.showSlider({
                    requestCode: t.data.requestCode
                })) : (t.triggerEvent ? t.triggerEvent("sliderEvent", {
                    status: 0,
                    code: s.code
                }, {
                    bubbles: !0,
                    composed: !0
                }) : t.props.sliderEvent({
                    status: 0,
                    code: s.code
                }), t.setData({
                    isShow: !1
                }));
            }).catch(function() {
                var e = getApp().$loginPage;
                e.triggerEvent ? e.triggerEvent("sliderEvent", {
                    status: 0,
                    code: 99999
                }, {
                    bubbles: !0,
                    composed: !0
                }) : e.props.sliderEvent({
                    status: 0,
                    code: 99999
                }), e.setData({
                    isShow: !1
                });
            });
        }
    }, {
        key: "setData",
        value: function() {
            var e = this.zone, t = this.client, i = this.Timestamp, o = this.count, n = this.timeout, r = this.trajectory, s = {
                env: {
                    zone: e,
                    client: t,
                    Timestamp: i.slice(0, 2),
                    count: o,
                    timeout: n
                },
                trajectory: r
            };
            this.behavior = s;
        }
    } ]), r;
}();

exports.default = r;