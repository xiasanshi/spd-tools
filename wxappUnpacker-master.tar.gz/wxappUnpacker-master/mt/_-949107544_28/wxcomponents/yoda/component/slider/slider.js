function t(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

var e = t(require("./sliderSDK")), s = t(require("./sliderAPI")), i = require("./../../modules/utils/config"), a = new (t(require("./../../modules/utils/api")).default)();

getApp();

Component({
    properties: {
        title: {
            type: String,
            value: "验证"
        },
        imgTitle: {
            type: String,
            value: "请输入图片中的内容"
        },
        imgButton: {
            type: String,
            value: "验证"
        }
    },
    props: {
        title: "验证",
        imgTitle: "请输入图片中的内容",
        imgButton: "验证",
        sliderEvent: function(t) {
            return console.log(t);
        }
    },
    data: {
        isShow: !1
    },
    methods: {
        showSlider: function(t) {
            var s = this, o = t.requestCode;
            i.rohr.i(i.rohrConfig.i);
            var n = this;
            a.getPageData(o, "slider").then(function(t) {
                var i = t.status, a = (t.data, t.error);
                0 === i && wx.showToast({
                    title: "请求异常",
                    content: "请求异常",
                    complete: function() {
                        n.triggerEvent ? n.triggerEvent("sliderEvent", {
                            status: 0,
                            code: a.code
                        }, {
                            bubbles: !0,
                            composed: !0
                        }) : n.props.sliderEvent({
                            status: 0,
                            code: a.code
                        }), n.setData({
                            isShow: !1
                        });
                    }
                });
                var r = new e.default({
                    requestCode: o,
                    pageData: t
                });
                getApp().$loginPage = s, s.setData({
                    sdk: r,
                    moveWidth: 0,
                    codeImage: "",
                    requestCode: o,
                    sliderCode: "",
                    isShow: !0,
                    validStep: "slider",
                    slideStatusClass: "",
                    animationData: {},
                    pageData: t
                });
            }).catch(function() {
                s.triggerEvent ? s.triggerEvent("sliderEvent", {
                    status: 0,
                    code: 99999
                }, {
                    bubbles: !0,
                    composed: !0
                }) : s.props.sliderEvent({
                    status: 0,
                    code: 99999
                }), s.setData({
                    isShow: !1
                });
            });
            var r = wx.createAnimation({
                transformOrigin: "50% 50%",
                duration: 500,
                timingFunction: "ease",
                delay: 0
            });
            this.animation = r;
        },
        sliderVerifySuccess: function(t) {
            var e = this, s = t ? t.response_code : "", i = e.data.requestCode;
            wx.showToast({
                title: "验证成功",
                content: "验证成功",
                complete: function() {
                    e.triggerEvent ? e.triggerEvent("sliderEvent", {
                        status: 1,
                        requestCode: i,
                        responseCode: s
                    }, {
                        bubbles: !0,
                        composed: !0
                    }) : e.props.sliderEvent({
                        status: 1,
                        requestCode: i,
                        responseCode: s
                    }), e.setData({
                        isShow: !1
                    });
                }
            });
        },
        sliderTouchStart: function(t) {
            this.data.sdk.sliderTouchStart(t);
        },
        sliderTouchMove: function(t) {
            var e = this.data.sdk.sliderTouchMove(t), s = e.deltaX, i = "";
            e.isDone && (i = "slider-boxLoading"), this.setData({
                moveWidth: s,
                slideStatusClass: i
            });
        },
        sliderTouchEnd: function(t) {
            var e = this.data.sdk;
            e.isDone ? this.setData({
                slideStatusClass: "slider-boxLoading"
            }) : (e.sliderTouchEnd(t), this.setData({
                moveWidth: 0
            }));
        },
        sliderClose: function() {
            this.setData({
                isShow: !1
            }), this.triggerEvent ? this.triggerEvent("sliderEvent", {
                status: 0,
                code: 33333
            }, {
                bubbles: !0,
                composed: !0
            }) : this.props.sliderEvent({
                status: 0,
                code: 33333
            });
        },
        sliderValideCode: function(t) {
            var e = this, i = this.data, a = i.sliderCode, o = i.pageData, n = i.sdk.requestCode;
            s.default.verfiyCode({
                captchacode: a,
                action: o.data.action,
                id: 1,
                requestCode: n
            }).then(function(t) {
                var s = t.status, i = t.error, a = t.data;
                1 === s ? e.sliderVerifySuccess(a) : 0 === s && 121020 === i.code ? (wx.showToast({
                    title: i.message,
                    content: i.message,
                    icon: "loading",
                    type: "fail"
                }), e.sliderUpdataCaptch()) : wx.showToast({
                    title: i.message,
                    content: i.message,
                    icon: "none",
                    type: "none",
                    duration: 2e3,
                    complete: function() {
                        e.triggerEvent ? e.triggerEvent("sliderEvent", {
                            status: 0,
                            code: i.code
                        }, {
                            bubbles: !0,
                            composed: !0
                        }) : e.props.sliderEvent({
                            status: 0,
                            code: i.code
                        }), e.setData({
                            isShow: !1
                        });
                    }
                });
            }, function() {
                e.triggerEvent ? e.triggerEvent("sliderEvent", {
                    status: 0,
                    code: 99999
                }, {
                    bubbles: !0,
                    composed: !0
                }) : e.props.sliderEvent({
                    status: 0,
                    code: 99999
                }), e.setData({
                    isShow: !1
                });
            });
        },
        sliderUpdataCaptch: function() {
            var t = this.data, e = t.sdk, s = t.pageData;
            this.setData({
                codeImage: i.YodaServer.getYodaServer().getServer() + "/v2/captcha?request_code=" + e.requestCode + "&action=" + s.action + "&captchaHash=" + Number(new Date()),
                sliderCode: ""
            });
        },
        sliderValideCodeInput: function(t) {
            this.setData({
                sliderCode: t.detail.value
            });
        },
        bindSliderInputFocus: function() {
            var t = this.data.animationData;
            this.animation.top(200).step(), t = this.animation.export(), this.setData({
                animationData: t
            });
        },
        bingSliderInputBlur: function() {
            var t = this.data.animationData;
            this.animation.top(300).step(), t = this.animation.export(), this.setData({
                animationData: t
            });
        },
        onTapPage: function(t) {
            i.rohr.t(t);
        },
        onTouchMovePage: function(t) {
            i.rohr.m(t);
        }
    }
});