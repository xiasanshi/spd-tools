(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/testPage/index" ], {
    "182a": function(n, t, e) {},
    "310b": function(n, t, e) {
        e.r(t);
        var o = e("8f56"), r = e.n(o);
        for (var c in o) "default" !== c && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(c);
        t.default = r.a;
    },
    3431: function(n, t, e) {
        (function(n) {
            function t(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            e("6cdc"), t(e("66fd")), n(t(e("e03d")).default);
        }).call(this, e("543d").createPage);
    },
    "393b": function(n, t, e) {
        e.d(t, "b", function() {
            return o;
        }), e.d(t, "c", function() {
            return r;
        }), e.d(t, "a", function() {});
        var o = function() {
            var n = this;
            n.$createElement;
            n._self._c;
        }, r = [];
    },
    "43a8": function(n, t, e) {
        var o = e("182a");
        e.n(o).a;
    },
    "8f56": function(n, t, e) {
        (function(n) {
            function o(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            function r(n, t, e, o, r, c, u) {
                try {
                    var i = n[c](u), a = i.value;
                } catch (n) {
                    return void e(n);
                }
                i.done ? t(a) : Promise.resolve(a).then(o, r);
            }
            function c(n) {
                return function() {
                    var t = this, e = arguments;
                    return new Promise(function(o, c) {
                        function u(n) {
                            r(a, o, c, u, i, "next", n);
                        }
                        function i(n) {
                            r(a, o, c, u, i, "throw", n);
                        }
                        var a = n.apply(t, e);
                        u(void 0);
                    });
                };
            }
            function u(n, t) {
                var e = Object.keys(n);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(n);
                    t && (o = o.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(n, t).enumerable;
                    })), e.push.apply(e, o);
                }
                return e;
            }
            function i(n, t, e) {
                return t in n ? Object.defineProperty(n, t, {
                    value: e,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : n[t] = e, n;
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = o(e("a34a")), f = e("2f62"), l = e("695d"), s = o(e("f7f5")), d = {
                data: function() {
                    return {
                        title: "Hello"
                    };
                },
                computed: function(n) {
                    for (var t = 1; t < arguments.length; t++) {
                        var e = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? u(Object(e), !0).forEach(function(t) {
                            i(n, t, e[t]);
                        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(n, Object.getOwnPropertyDescriptors(e)) : u(Object(e)).forEach(function(t) {
                            Object.defineProperty(n, t, Object.getOwnPropertyDescriptor(e, t));
                        });
                    }
                    return n;
                }({}, (0, f.mapState)([ "isLogin" ])),
                onLoad: function() {},
                methods: {
                    onLogout: function() {
                        (0, l.logout)();
                    },
                    onBtnTap: function() {
                        this.isLogin ? this.scanQrcode() : this.getLoginCode();
                    },
                    getLoginCode: function() {
                        (0, l.getLoginCode)();
                    },
                    wxMobileLoginBind: function(n) {
                        (0, l.login)(n).then(function(n) {
                            return console.log("only login", n), "succ" === n.status;
                        });
                    },
                    wxMobileLoginAndScan: function(n) {
                        var t = this;
                        (0, l.login)(n).then(function(n) {
                            console.log("login and scan", n), "succ" === n.status && t.scanQrcode();
                        });
                    },
                    scanQrcode: function() {
                        n.scanCode({
                            success: function(t) {
                                n.showModal({
                                    title: "默认提示",
                                    content: JSON.stringify(t)
                                });
                            }
                        });
                    },
                    callbackLogin: function() {
                        var t = getCurrentPages(), e = t[t.length - 1], o = e.options || {}, r = Object.keys(o).map(function(n) {
                            return "".concat(n, "=").concat(o[n]);
                        }).join("&");
                        if (e && e.route) {
                            var c = "" !== r ? "".concat(e.route, "?").concat(r) : e.route;
                            n.redirectTo({
                                url: "/pages/login/index?callback=".concat(encodeURIComponent(c))
                            });
                        }
                    },
                    onSubcribeMessage: function() {
                        return c(a.default.mark(function t() {
                            var e;
                            return a.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return t.next = 2, (0, s.default)();

                                  case 2:
                                    e = t.sent, n.showModal({
                                        content: JSON.stringify(e)
                                    });

                                  case 4:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    }
                }
            };
            t.default = d;
        }).call(this, e("543d").default);
    },
    e03d: function(n, t, e) {
        e.r(t);
        var o = e("393b"), r = e("310b");
        for (var c in r) "default" !== c && function(n) {
            e.d(t, n, function() {
                return r[n];
            });
        }(c);
        e("43a8");
        var u = e("f0c5"), i = Object(u.a)(r.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        t.default = i.exports;
    }
}, [ [ "3431", "common/runtime", "common/vendor" ] ] ]);