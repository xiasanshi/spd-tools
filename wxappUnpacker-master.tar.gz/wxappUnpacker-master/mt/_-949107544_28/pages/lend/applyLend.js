(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/lend/applyLend" ], {
    "07f2": function(e, t, n) {
        n.r(t);
        var o = n("ac38"), r = n("df4d");
        for (var a in r) "default" !== a && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(a);
        n("d31e");
        var i = n("f0c5"), s = Object(i.a)(r.default, o.b, o.c, !1, null, "ba7964cc", null, !1, o.a, void 0);
        t.default = s.exports;
    },
    "1d39": function(e, t, n) {},
    4629: function(e, t, n) {
        (function(e) {
            function t(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            n("6cdc"), t(n("66fd")), e(t(n("07f2")).default);
        }).call(this, n("543d").createPage);
    },
    ac38: function(e, t, n) {
        n.d(t, "b", function() {
            return r;
        }), n.d(t, "c", function() {
            return a;
        }), n.d(t, "a", function() {
            return o;
        });
        var o = {
            customModal: function() {
                return Promise.all([ n.e("common/vendor"), n.e("components/customModal/customModal") ]).then(n.bind(null, "4b4e"));
            }
        }, r = function() {
            var e = this, t = (e.$createElement, e._self._c, n("a0c5")), o = n("680f"), r = n("d3c0");
            e.$mp.data = Object.assign({}, {
                $root: {
                    m0: t,
                    m1: o,
                    m2: r
                }
            });
        }, a = [];
    },
    d31e: function(e, t, n) {
        var o = n("1d39");
        n.n(o).a;
    },
    df4d: function(e, t, n) {
        n.r(t);
        var o = n("ffdd"), r = n.n(o);
        for (var a in o) "default" !== a && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(a);
        t.default = r.a;
    },
    ffdd: function(e, t, n) {
        (function(e) {
            function o(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            function r(e, t, n, o, r, a, i) {
                try {
                    var s = e[a](i), u = s.value;
                } catch (e) {
                    return void n(e);
                }
                s.done ? t(u) : Promise.resolve(u).then(o, r);
            }
            function a(e) {
                return function() {
                    var t = this, n = arguments;
                    return new Promise(function(o, a) {
                        function i(e) {
                            r(u, o, a, i, s, "next", e);
                        }
                        function s(e) {
                            r(u, o, a, i, s, "throw", e);
                        }
                        var u = e.apply(t, n);
                        i(void 0);
                    });
                };
            }
            function i(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    t && (o = o.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, o);
                }
                return n;
            }
            function s(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? i(Object(n), !0).forEach(function(t) {
                        u(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : i(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }
            function u(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e;
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var c = o(n("a34a")), d = n("2f62"), l = o(n("9062")), f = o(n("08e2")), p = o(n("ff13")), h = o(n("e10e")), g = o(n("4360")), C = o(n("6b85")), b = o(n("f121")), m = o(n("0ea1")), P = n("695d"), L = o(n("e353")), S = n("4720"), T = n("c07e"), v = n("fecb"), y = o(n("91d2")), E = n("d99e"), I = o(n("beb0")), w = o(n("1773")), O = v.paymentErrCode.wxpayCancel, D = v.paymentErrCode.wxpayFail, x = v.paymentErrCode.stopLoop, _ = "https://p0.meituan.net/scarlett/e7ba25ea45947d3d61c407787a50311c56987.png", k = {
                components: {
                    couponTips: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/lend/couponTips") ]).then(function() {
                            return resolve(n("6754"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    navigationBar: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/navigationBar/navigationBar") ]).then(function() {
                            return resolve(n("3b59"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    Popping: function() {
                        Promise.all([ n.e("common/vendor"), n.e("components/popping") ]).then(function() {
                            return resolve(n("084e"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                data: function() {
                    return {
                        codeStr: "",
                        freeTimeDesc: "",
                        priceUnitDesc: "",
                        cappedPriceDesc: "",
                        createOrderAccessToken: "",
                        depositEntrance: !1,
                        isShowConfirm: !1,
                        isConfirmLend: !1,
                        defaultImgLoad: !1,
                        isGetPayInfo: !1,
                        isShowCoupon: !1,
                        isTZ1TZ2CabinSns: !0,
                        isLending: !1,
                        lendImgObj: {
                            jpg: _
                        },
                        dialogConfig: {},
                        lendType: "freeDeposit"
                    };
                },
                computed: s(s({}, (0, d.mapState)([ "currentCabinId", "isLogin", "userId", "isChooseCoupon", "freeDuration", "couponId", "isPopping", "shouldReload", "depositFee", "subCode" ])), {}, {
                    isShowContainer: function() {
                        return this.defaultImgLoad && this.isGetPayInfo && e.hideLoading(), this.defaultImgLoad && this.isGetPayInfo;
                    },
                    freeTime: function() {
                        return this.isChooseCoupon ? "前".concat(this.freeDuration, "分钟免费") : this.freeTimeDesc;
                    },
                    isTZ3CabinSns: function() {
                        return l.default.isTZ3CabinSns(this.currentCabinId);
                    }
                }),
                watch: {
                    isLogin: function(e) {
                        e && this.queryBestCoupon();
                    }
                },
                onShow: function() {
                    var t = this.currentCabinId || w.default.getParameterByKey("cid") || w.default.getParameterByKey("batteryCabId");
                    I.default.sendPV("APPLY_LEND", {
                        cab_sn: t
                    }), this.isLogin && this.queryBestCoupon(), g.default.state.shouldReload && !this.isLending && e.reLaunch({
                        url: "/pages/index/index",
                        fail: function() {
                            console.log("could not return to map page");
                        },
                        success: function() {
                            var e = getCurrentPages();
                            e.length && "pages/lend/applyLend" !== e[e.length - 1].route && g.default.commit("setShouldReload", !1);
                        }
                    }), y.default.setMetricManager("pageEntry", {
                        page: "".concat(this.codeStr ? "applyLendWx" : "applyLendMap")
                    });
                },
                onLoad: function(e) {
                    var t = this;
                    return a(c.default.mark(function n() {
                        return c.default.wrap(function(n) {
                            for (;;) switch (n.prev = n.next) {
                              case 0:
                                t.setIsPopping(!1), t.init(e);

                              case 2:
                              case "end":
                                return n.stop();
                            }
                        }, n);
                    }))();
                },
                onUnload: function() {
                    m.default.stopLoopOrderStatus();
                },
                onReady: function() {
                    this.getInfo();
                },
                methods: s(s({}, (0, d.mapMutations)([ "setPayInfo", "setFreeDuration", "setCouponId", "setIsChooseCoupon", "setIsPopping", "setCurrentCabinId", "setSubCode" ])), {}, {
                    init: function(e) {
                        e.q && (g.default.commit("setShouldReload", !1), this.codeStr = decodeURIComponent(e.q), 
                        L.default.getCabinId(this.codeStr), this.scan(this.codeStr)), this.updateGif(), 
                        this.depositEntrance = b.default.depositEntrance;
                    },
                    getInfo: function() {
                        try {
                            if (!this.currentCabinId) throw new Error("System error");
                            this.getPayInfo();
                        } catch (e) {
                            this.showSystemError(), this.closeToHomePage();
                        }
                    },
                    getPayStatus: function(t) {
                        return a(c.default.mark(function n() {
                            var o, r;
                            return c.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    if (!(o = t.tobePaidStatus) || "fail" !== o) {
                                        n.next = 6;
                                        break;
                                    }
                                    return r = t.orderId, n.next = 5, h.default.closeOrder({
                                        orderId: r
                                    });

                                  case 5:
                                    e.showToast({
                                        title: "支付失败，请稍后重试！",
                                        icon: "none",
                                        duration: 5e3
                                    });

                                  case 6:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    showSystemError: function() {
                        e.showToast({
                            title: "系统异常，暂时无法使用，请稍后再试",
                            icon: "none",
                            duration: 5e3
                        });
                    },
                    confirmOrder: function() {
                        var t = this;
                        return a(c.default.mark(function n() {
                            var o, r, a, i, s, u;
                            return c.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    return e.showLoading(), o = {
                                        isPayFree: !0,
                                        isDowngrade: !1,
                                        couponId: t.couponId,
                                        isChooseCoupon: t.isChooseCoupon,
                                        createOrderAccessToken: t.createOrderAccessToken
                                    }, t.lendType = "freeDeposit", n.next = 5, m.default.createOrder(o);

                                  case 5:
                                    if (r = n.sent, t.setSubCode(r.subCode), e.hideLoading(), t.isConfirmLend = !1, 
                                    t.isLending = !1, r.isSuccess) {
                                        n.next = 29;
                                        break;
                                    }
                                    if (r.code !== b.default.errorAlias.COUPON_EXPIRED) {
                                        n.next = 15;
                                        break;
                                    }
                                    return t.setIsChooseCoupon(!1), t.callUpCouponExpired("confirmOrder"), n.abrupt("return");

                                  case 15:
                                    if (r._code !== v.paymentErrCode.stopLoop) {
                                        n.next = 17;
                                        break;
                                    }
                                    return n.abrupt("return");

                                  case 17:
                                    if (r.code !== b.default.errorAlias.DEPOSIT_DEGRADE) {
                                        n.next = 21;
                                        break;
                                    }
                                    return t.callUpPayLend({
                                        errCode: r.code
                                    }), y.default.setMetricManager("wxPaySign", {
                                        result: "riskCtrl"
                                    }), n.abrupt("return");

                                  case 21:
                                    if (r.code !== b.default.errorAlias.PAY_TIMEOUT) {
                                        n.next = 24;
                                        break;
                                    }
                                    return t.callUpPayTimeout(), n.abrupt("return");

                                  case 24:
                                    if (r.code !== b.default.errorAlias.LEND_POP_ERROR) {
                                        n.next = 27;
                                        break;
                                    }
                                    return t.callUpPopFail(), n.abrupt("return");

                                  case 27:
                                    return t.parseErrorCodeToast(r.code), n.abrupt("return");

                                  case 29:
                                    a = r.data, i = a.orderStatus, s = a.orderId, u = i === T.ORDER_STATUS.LEND_SUCCESS, 
                                    e.reLaunch({
                                        url: "/pages/orderDetail/orderDetail?isPopSuccess=".concat(u, "&orderId=").concat(s)
                                    });

                                  case 32:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    freeDeposit: function() {
                        var t = this;
                        return a(c.default.mark(function n() {
                            var o, r;
                            return c.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    if (!t.isConfirmLend) {
                                        n.next = 2;
                                        break;
                                    }
                                    return n.abrupt("return");

                                  case 2:
                                    return n.prev = 2, I.default.sendMC("APPLY_LEND_FREE_LEND"), t.isConfirmLend = !0, 
                                    n.next = 7, t.checkCabinStatus();

                                  case 7:
                                    (o = n.sent) ? (t.isLending = !0, e.showLoading({
                                        title: "免押权益获取中",
                                        mask: !0
                                    }), r = Date.now(), C.default.init({
                                        success: function(n) {
                                            if (0 !== n.data.status) return e.hideLoading(), t.callUpPayLend({
                                                errCode: n.data.status
                                            }), t.isConfirmLend = !1, void (1 === n.data.status ? y.default.setMetricManager("wxPaySign", {
                                                result: "giveUp"
                                            }) : 2 === n.data.status ? y.default.setMetricManager("wxPaySign", {
                                                result: "signFail"
                                            }) : y.default.setMetricManager("wxPaySign", {
                                                result: "waitSign"
                                            }));
                                            y.default.setMetricManager("wxPaySignTIme", {
                                                result: "success"
                                            }, Date.now() - r), t.confirmOrder();
                                        },
                                        fail: function() {
                                            e.hideLoading(), t.callUpPayLend({
                                                errCode: "-1"
                                            }), t.isConfirmLend = !1, t.isLending = !1;
                                        }
                                    })) : (t.isShowConfirm = !0, t.isConfirmLend = !1, t.isLending = !1), n.next = 15;
                                    break;

                                  case 11:
                                    n.prev = 11, n.t0 = n.catch(2), t.isConfirmLend = !1, t.isLending = !1;

                                  case 15:
                                  case "end":
                                    return n.stop();
                                }
                            }, n, null, [ [ 2, 11 ] ]);
                        }))();
                    },
                    updateGif: function() {
                        this.isTZ1TZ2CabinSns = l.default.isTZ1TZ2CabinSns(this.currentCabinId), this.isTZ1TZ2CabinSns ? this.lendImgObj = {
                            jpg: _
                        } : this.lendImgObj = {
                            jpg: "https://p0.meituan.net/scarlett/2af8a7b0851131e0bc67e0248cb637ae517021.png"
                        };
                    },
                    lendPay: function() {
                        var t = this;
                        return a(c.default.mark(function n() {
                            var o, r, a, i;
                            return c.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    if (I.default.sendMC("APPLY_LEND_DEPOSIT_LEND"), !0 !== t.isLoading) {
                                        n.next = 3;
                                        break;
                                    }
                                    return n.abrupt("return");

                                  case 3:
                                    return n.prev = 3, t.lendType = "lendPay", t.isLending = !0, t.isLoading = !0, t.modalClose(), 
                                    n.next = 10, t.checkCabinStatus();

                                  case 10:
                                    if (!(o = n.sent)) {
                                        n.next = 41;
                                        break;
                                    }
                                    return e.showLoading({
                                        title: "加载中",
                                        mask: !0
                                    }), n.next = 15, m.default.createOrder({
                                        couponId: t.couponId,
                                        isChooseCoupon: t.isChooseCoupon,
                                        createOrderAccessToken: t.createOrderAccessToken
                                    });

                                  case 15:
                                    if (r = n.sent, t.setSubCode(r.subCode), t.isLoading = !1, e.hideLoading(), !r.isSuccess) {
                                        n.next = 25;
                                        break;
                                    }
                                    t.isLending = !1, a = r.data, i = void 0 === a ? {} : a, e.reLaunch({
                                        url: "/pages/orderDetail/orderDetail?orderId=".concat(i.orderId, "&isPopSuccess=true")
                                    }), n.next = 39;
                                    break;

                                  case 25:
                                    if (t.isLending = !1, r.code !== b.default.errorAlias.COUPON_EXPIRED) {
                                        n.next = 30;
                                        break;
                                    }
                                    return t.setIsChooseCoupon(!1), t.callUpCouponExpired("lendPay"), n.abrupt("return");

                                  case 30:
                                    if (r._code !== v.paymentErrCode.stopLoop) {
                                        n.next = 32;
                                        break;
                                    }
                                    return n.abrupt("return");

                                  case 32:
                                    if (r.code !== b.default.errorAlias.PAY_TIMEOUT) {
                                        n.next = 35;
                                        break;
                                    }
                                    return t.callUpPayTimeout(), n.abrupt("return");

                                  case 35:
                                    if (r.code !== b.default.errorAlias.LEND_POP_ERROR) {
                                        n.next = 38;
                                        break;
                                    }
                                    return t.callUpPopFail(), n.abrupt("return");

                                  case 38:
                                    [ O, D, x ].includes(r._code) || t.parseErrorCodeToast(r.code);

                                  case 39:
                                    n.next = 44;
                                    break;

                                  case 41:
                                    t.isShowConfirm = !0, t.isLending = !1, t.isLoading = !1;

                                  case 44:
                                    n.next = 50;
                                    break;

                                  case 46:
                                    n.prev = 46, n.t0 = n.catch(3), t.isLending = !1, t.isLoading = !1;

                                  case 50:
                                  case "end":
                                    return n.stop();
                                }
                            }, n, null, [ [ 3, 46 ] ]);
                        }))();
                    },
                    parseErrorCodeToast: function(t) {
                        var n = b.default.error, o = b.default.errorAlias, r = n[Object.keys(o).find(function(e) {
                            return (o[e] && o[e].toString()) === (t && t.toString());
                        }) || "UNMATCH_ERROR"].split("|")[1];
                        e.hideLoading(), e.showToast({
                            title: r + (0, E.subCodeTip)(this.subCode),
                            icon: "none",
                            duration: 5e3
                        });
                    },
                    defaultImageLoad: function() {
                        this.defaultImgLoad = !0;
                    },
                    defaultImageError: function() {
                        this.defaultImgLoad = !0;
                    },
                    getLoginCode: function() {
                        (0, P.getLoginCode)();
                    },
                    login: function(t) {
                        var n = this;
                        I.default.sendMC("APPLY_LEND_FREE_LEND"), (0, P.login)(t).then(function(t) {
                            "succ" === t.status && (n.scan(n.codeStr), e.showToast({
                                title: "登录成功",
                                icon: "none",
                                duration: 2e3
                            }));
                        });
                    },
                    handleBackAction: function() {
                        getCurrentPages().length > 1 ? e.navigateBack() : e.reLaunch({
                            url: "/pages/index/index"
                        });
                    },
                    scan: function(t) {
                        this.isLogin && (e.showLoading({
                            mask: !0,
                            title: "加载中"
                        }), L.default.init({
                            codeStr: t || "",
                            success: function(t) {
                                (0, S.redirToUnfinishedOrder)().then(function(n) {
                                    n || (e.hideLoading(), t.data.cabinStatus !== T.CABIN_STATUS_ENUM.success && e.showToast({
                                        title: t.msg,
                                        icon: "none",
                                        duration: 5e3
                                    }));
                                });
                            },
                            fail: function(t) {
                                e.hideLoading(), e.showToast({
                                    title: t.msg || "未知异常，请重试",
                                    icon: "none",
                                    duration: 5e3
                                });
                            }
                        }));
                    },
                    queryBestCoupon: function() {
                        var t = this;
                        p.default.queryBestCoupon(this.currentCabinId).then(function(e) {
                            var n = e.data;
                            n && n.couponId ? (t.setFreeDuration(n.rights.freeTime), t.setCouponId(n.couponId), 
                            t.isShowCoupon = !0) : (t.isShowCoupon = !1, t.setCouponId(""), t.setFreeDuration(0), 
                            t.setIsChooseCoupon(!1));
                        }).catch(function() {
                            e.hideLoading();
                        });
                    },
                    callUpPopFail: function() {
                        var e = "freeDeposit" === this.lendType ? "充电宝弹出失败，订单已关闭，可重试租借" : "充电宝弹出失败，押金已发起退款，可重试租借";
                        this.dialogConfig = {
                            title: "",
                            content: e + (0, E.subCodeTip)(this.subCode),
                            closeAble: !1,
                            buttons: [ {
                                title: "取消",
                                name: "closeToHomePage",
                                isDefault: !1
                            }, {
                                title: "重试",
                                name: "callUpScan",
                                isDefault: !0
                            } ]
                        }, this.isShowConfirm = !0;
                    },
                    callUpCouponExpired: function() {
                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "confirmOrder";
                        this.dialogConfig = {
                            title: "提示",
                            content: "优惠券已过期，无法享受优惠券权益，是否继续下单？".concat((0, E.subCodeTip)(this.subCode)),
                            closeAble: !1,
                            buttons: [ {
                                title: "否",
                                name: "closeToHomePage",
                                isDefault: !1
                            }, {
                                title: "是",
                                name: e,
                                isDefault: !0
                            } ]
                        }, this.isShowConfirm = !0;
                    },
                    callUpPayTimeout: function() {
                        this.dialogConfig = {
                            title: "",
                            content: b.default.error.PAY_TIMEOUT.split("|")[1] + (0, E.subCodeTip)(this.subCode),
                            closeAble: !1,
                            buttons: [ {
                                title: "取消",
                                name: "closeToHomePage",
                                isDefault: !1
                            }, {
                                title: "重试",
                                name: "callUpScan",
                                isDefault: !0
                            } ]
                        }, this.isShowConfirm = !0;
                    },
                    callUpPayLend: function(e) {
                        var t = e.errCode;
                        I.default.sendMV("APPLY_LEND_DEPOSIT_MODAL", {
                            err_code: t
                        });
                        var n = [ 0, 1, 2, 3, 4 ].indexOf(this.userId % 10) >= 0;
                        this.dialogConfig = {
                            title: "不符合免押条件",
                            content: "请使用押金租借，还宝后押金自动退回",
                            closeAble: "modalClose",
                            buttons: [ {
                                title: "充".concat(n ? "" : "".concat(this.depositFee, "元"), "押金租借"),
                                name: "lendPay",
                                isDefault: !0
                            } ],
                            comment: {
                                text: "确认支付代表已阅读",
                                html: "《使用条款》",
                                name: "toChargeProtocol"
                            }
                        }, this.isShowConfirm = !0;
                    },
                    showUserProtocol: function() {
                        e.navigateTo({
                            url: "/pages/userProtocol/userProtocol"
                        });
                    },
                    toChargeProtocol: function() {
                        e.navigateTo({
                            url: "/pages/chargeProtocol/chargeProtocol"
                        });
                    },
                    closeToHomePage: function() {
                        e.reLaunch({
                            url: "/pages/index/index?pageFromDialog=true"
                        });
                    },
                    callUpScan: function() {
                        L.default.init({
                            success: function(t) {
                                (0, S.redirToUnfinishedOrder)().then(function(n) {
                                    n || (t.data.cabinStatus === T.CABIN_STATUS_ENUM.success ? (g.default.commit("setShouldReload", !1), 
                                    g.default.commit("setCurrentCabinId", t.data.cabinId), e.navigateTo({
                                        url: "/pages/lend/applyLend"
                                    })) : e.showToast({
                                        title: t.msg,
                                        icon: "none",
                                        duration: 5e3
                                    }));
                                });
                            },
                            fail: function(t) {
                                e.showToast({
                                    title: t.msg,
                                    icon: "none",
                                    duration: 5e3
                                });
                            }
                        });
                    },
                    modalClose: function() {
                        this.isShowConfirm = !1;
                    },
                    checkCabinStatus: function() {
                        var t = this;
                        return a(c.default.mark(function n() {
                            var o, r, a, i, s, u, d;
                            return c.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    return o = b.default.error, r = b.default.errorAlias, n.prev = 1, e.showLoading({
                                        title: "加载中",
                                        mask: !0
                                    }), n.next = 5, f.default.getCabinStatus(t.currentCabinId);

                                  case 5:
                                    if (a = n.sent, t.setSubCode(a.subCode), e.hideLoading(), a.data === b.default.errorAlias.SUCCESS) {
                                        n.next = 20;
                                        break;
                                    }
                                    if (t.dialogConfig = {
                                        title: "",
                                        content: "",
                                        closeAble: !1,
                                        buttons: [ {
                                            title: "取消",
                                            name: "modalClose",
                                            isDefault: !1
                                        }, {
                                            title: "查看附近门店",
                                            name: "closeToHomePage",
                                            isDefault: !0
                                        } ]
                                    }, i = a.data || a.code, s = Object.keys(r).find(function(e) {
                                        return r[e] === i;
                                    }) || "UNMATCH_ERROR", !((u = [ "CREATE_ORDER_CABIN_ERROR_SYSERR1", "CREATE_ORDER_CABIN_ERROR_SYSERR2", "CREATE_ORDER_UNMATCH_ERROR" ]).indexOf(s) < 0)) {
                                        n.next = 17;
                                        break;
                                    }
                                    t.$set(t.dialogConfig, "content", o[s].split("|")[1] + (0, E.subCodeTip)(t.subCode)), 
                                    n.next = 19;
                                    break;

                                  case 17:
                                    return t.parseErrorCodeToast(i), n.abrupt("return", !0);

                                  case 19:
                                    return n.abrupt("return", !1);

                                  case 20:
                                    return n.abrupt("return", !0);

                                  case 23:
                                    return n.prev = 23, n.t0 = n.catch(1), e.hideLoading(), d = "UNMATCH_ERROR", t.$set(t.dialogConfig, "content", o[d].split("|")[1] + (0, 
                                    E.subCodeTip)(t.subCode)), n.abrupt("return", !1);

                                  case 29:
                                  case "end":
                                    return n.stop();
                                }
                            }, n, null, [ [ 1, 23 ] ]);
                        }))();
                    },
                    getPayInfo: function() {
                        var t = this;
                        return a(c.default.mark(function n() {
                            var o, r;
                            return c.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    return n.prev = 0, e.showLoading({
                                        title: "加载中",
                                        mask: !0
                                    }), t.modalClose(), n.next = 5, f.default.getCabinPayInfo(t.currentCabinId);

                                  case 5:
                                    if ((o = n.sent).code === T.CABIN_STATUS_ENUM.success.toString()) {
                                        n.next = 8;
                                        break;
                                    }
                                    throw new Error("定价信息获取失败，错误码".concat(o.code));

                                  case 8:
                                    return t.freeTimeDesc = o.data.freeTimeDesc, t.priceUnitDesc = o.data.priceUnitDesc, 
                                    t.cappedPriceDesc = o.data.cappedPriceDesc, t.createOrderAccessToken = o.data.createOrderAccessToken, 
                                    t.setPayInfo(o.data), t.isGetPayInfo = !0, n.next = 16, t.checkCabinStatus();

                                  case 16:
                                    return (r = n.sent) || (t.isShowConfirm = !0), n.abrupt("return", !0);

                                  case 21:
                                    return n.prev = 21, n.t0 = n.catch(0), e.hideLoading(), t.dialogConfig = {
                                        title: "",
                                        content: "价格信息获取失败，请重试",
                                        closeAble: !1,
                                        buttons: [ {
                                            title: "取消",
                                            name: "closeToHomePage",
                                            isDefault: !1
                                        }, {
                                            title: "重试",
                                            name: "getPayInfo",
                                            isDefault: !0
                                        } ]
                                    }, t.isShowConfirm = !0, n.abrupt("return", !1);

                                  case 27:
                                  case "end":
                                    return n.stop();
                                }
                            }, n, null, [ [ 0, 21 ] ]);
                        }))();
                    }
                })
            };
            t.default = k;
        }).call(this, n("543d").default);
    }
}, [ [ "4629", "common/runtime", "common/vendor" ] ] ]);