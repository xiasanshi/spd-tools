(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/navigationBar/navigationBar" ], {
    "179b": function(t, e, n) {
        n.d(e, "b", function() {
            return o;
        }), n.d(e, "c", function() {
            return a;
        }), n.d(e, "a", function() {});
        var o = function() {
            var t = this;
            t.$createElement;
            t._self._c;
        }, a = [];
    },
    "3b59": function(t, e, n) {
        n.r(e);
        var o = n("179b"), a = n("c5d8");
        for (var r in a) "default" !== r && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(r);
        n("deb4");
        var i = n("f0c5"), c = Object(i.a)(a.default, o.b, o.c, !1, null, "1828961d", null, !1, o.a, void 0);
        e.default = c.exports;
    },
    "656f": function(t, e, n) {},
    c5d8: function(t, e, n) {
        n.r(e);
        var o = n("d28e"), a = n.n(o);
        for (var r in o) "default" !== r && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(r);
        e.default = a.a;
    },
    d28e: function(t, e, n) {
        (function(t) {
            function o(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(t);
                    e && (o = o.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable;
                    })), n.push.apply(n, o);
                }
                return n;
            }
            function a(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? o(Object(n), !0).forEach(function(e) {
                        r(t, e, n[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : o(Object(n)).forEach(function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
                    });
                }
                return t;
            }
            function r(t, e, n) {
                return e in t ? Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = n, t;
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var i = n("2f62"), c = n("695d"), u = {
                props: {
                    mode: {
                        type: String,
                        default: "H5"
                    },
                    title: {
                        type: String,
                        default: ""
                    },
                    imageTitle: {
                        type: String,
                        default: ""
                    },
                    showAvatar: {
                        type: Boolean,
                        default: !1
                    },
                    showBack: {
                        type: Boolean,
                        default: !1
                    },
                    leftBtnHandle: {
                        type: Function,
                        default: function() {}
                    },
                    leftBtnImage: {
                        type: String,
                        default: ""
                    },
                    leftBtnText: {
                        type: String,
                        default: ""
                    },
                    rightBtnImage: {
                        type: String,
                        default: ""
                    },
                    rightBtnText: {
                        type: String,
                        default: ""
                    },
                    rightBtnHandle: {
                        type: Function,
                        default: function() {}
                    }
                },
                computed: a(a({}, (0, i.mapState)([ "isLogin" ])), {}, {
                    getStatusBarHeight: function() {
                        var e = t.getSystemInfoSync();
                        return "height: ".concat(e.statusBarHeight, "px");
                    },
                    showInWeixin: function() {
                        return -1 !== [ "ALL", "MP-WEIXIN" ].indexOf(this.mode);
                    }
                }),
                methods: {
                    handleGoBack: function() {
                        this.leftBtnHandle ? this.leftBtnHandle() : t.navigateBack();
                    },
                    getLoginCode: function() {
                        (0, c.getLoginCode)();
                    },
                    jumpToPersonCenter: function(e) {
                        this.isLogin ? t.navigateTo({
                            url: "/pages/personCenter/personCenter"
                        }) : (0, c.login)(e).then(function(e) {
                            "succ" === e.status && t.navigateTo({
                                url: "/pages/personCenter/personCenter"
                            });
                        });
                    }
                }
            };
            e.default = u;
        }).call(this, n("543d").default);
    },
    deb4: function(t, e, n) {
        var o = n("656f");
        n.n(o).a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/navigationBar/navigationBar-create-component", {
    "components/navigationBar/navigationBar-create-component": function(t, e, n) {
        n("543d").createComponent(n("3b59"));
    }
}, [ [ "components/navigationBar/navigationBar-create-component" ] ] ]);