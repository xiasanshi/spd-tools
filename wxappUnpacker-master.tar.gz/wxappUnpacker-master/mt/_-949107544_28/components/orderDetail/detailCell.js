(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/orderDetail/detailCell" ], {
    "0115": function(e, t, n) {},
    7562: function(e, t, n) {
        n.r(t);
        var o = n("ace8"), a = n("8693");
        for (var l in a) "default" !== l && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(l);
        n("f347");
        var r = n("f0c5"), c = Object(r.a)(a.default, o.b, o.c, !1, null, "3b2de3f0", null, !1, o.a, void 0);
        t.default = c.exports;
    },
    "7f3a": function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var o = {
            props: {
                mainTitle: {
                    type: String,
                    default: ""
                },
                subTitle: {
                    type: String,
                    default: ""
                },
                isShowBottomLine: {
                    type: Boolean,
                    default: !1
                }
            },
            data: function() {
                return {};
            }
        };
        t.default = o;
    },
    8693: function(e, t, n) {
        n.r(t);
        var o = n("7f3a"), a = n.n(o);
        for (var l in o) "default" !== l && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(l);
        t.default = a.a;
    },
    ace8: function(e, t, n) {
        n.d(t, "b", function() {
            return o;
        }), n.d(t, "c", function() {
            return a;
        }), n.d(t, "a", function() {});
        var o = function() {
            var e = this, t = (e.$createElement, e._self._c, n("d355"));
            e.$mp.data = Object.assign({}, {
                $root: {
                    m0: t
                }
            });
        }, a = [];
    },
    f347: function(e, t, n) {
        var o = n("0115");
        n.n(o).a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/orderDetail/detailCell-create-component", {
    "components/orderDetail/detailCell-create-component": function(e, t, n) {
        n("543d").createComponent(n("7562"));
    }
}, [ [ "components/orderDetail/detailCell-create-component" ] ] ]);