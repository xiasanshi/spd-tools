(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/orderDetail/detailHeader" ], {
    "1fa3": function(e, t, n) {
        n.r(t);
        var r = n("e66e"), i = n.n(r);
        for (var a in r) "default" !== a && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(a);
        t.default = i.a;
    },
    "35e1": function(e, t, n) {
        n.d(t, "b", function() {
            return r;
        }), n.d(t, "c", function() {
            return i;
        }), n.d(t, "a", function() {});
        var r = function() {
            var e = this, t = (e.$createElement, e._self._c, n("c91b")), r = n("ef4b"), i = e.getNowCabinModel(), a = (11 - e.orderDetailsInfo.lendPosition).toString(), o = e.getNowCabinModel(), u = e.orderDetailsInfo.lendPosition.toString();
            e.$mp.data = Object.assign({}, {
                $root: {
                    m0: t,
                    m1: r,
                    m2: i,
                    g0: a,
                    m3: o,
                    g1: u
                }
            });
        }, i = [];
    },
    "98a2": function(e, t, n) {},
    be05: function(e, t, n) {
        var r = n("98a2");
        n.n(r).a;
    },
    dd32: function(e, t, n) {
        n.r(t);
        var r = n("35e1"), i = n("1fa3");
        for (var a in i) "default" !== a && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(a);
        n("be05");
        var o = n("f0c5"), u = Object(o.a)(i.default, r.b, r.c, !1, null, "02224ca8", null, !1, r.a, void 0);
        t.default = u.exports;
    },
    e66e: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = n("c07e"), i = function(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }(n("9062")), a = {
            components: {
                Tz2EjectAnimation: function() {
                    n.e("components/ejectAnimation/Tz2EjectAnimation").then(function() {
                        return resolve(n("2eb6"));
                    }.bind(null, n)).catch(n.oe);
                },
                Tz3EjectAnimation: function() {
                    n.e("components/ejectAnimation/Tz3EjectAnimation").then(function() {
                        return resolve(n("a52e"));
                    }.bind(null, n)).catch(n.oe);
                }
            },
            props: {
                orderStatus: {
                    type: Number,
                    default: 0
                },
                currentCabinId: {
                    type: String,
                    default: ""
                },
                refundFee: {
                    type: Number,
                    default: 0
                },
                orderDetailsInfo: {
                    type: Object,
                    default: function() {
                        return {};
                    }
                },
                isSuspended: {
                    type: Boolean,
                    default: !1
                },
                remainDuration: {
                    type: String,
                    default: ""
                }
            },
            data: function() {
                return {
                    orderCode: r.ORDER_STATUS_GROUP,
                    statusImgObj: {
                        orderFinished: {
                            defaultUrl: "",
                            imgUrl: "",
                            mainTitle: "支付完成",
                            subTitleDefault: "充电宝已归还，感谢使用"
                        },
                        orderLending: {
                            defaultUrl: "https://p0.meituan.net/scarlett/49c430d60a9cc54fd7103749b11cb56833061.png",
                            mainTitle: "租借中",
                            subTitleDefault: "1台，"
                        },
                        orderStayPayment: {
                            defaultUrl: "",
                            imgUrl: "",
                            mainTitle: "待支付",
                            subTitle: "",
                            subTitleDefault: "请点击去支付完成订单"
                        },
                        orderLendSuccess: {
                            defaultUrl: "https://p0.meituan.net/scarlett/e592af13770dcb4a7b8bf34a7dcbd29514724.jpg",
                            mainTitle: "弹出成功",
                            subTitleDefault: "指示灯"
                        },
                        orderReturnSuccess: {
                            defaultUrl: "",
                            imgUrl: "",
                            mainTitle: "归还成功",
                            subTitleDefault: "充电宝已归还，感谢使用"
                        }
                    },
                    defaultImgUrl: "",
                    mainTitle: "",
                    orderStatusName: {
                        orderFinished: "orderFinished",
                        orderLending: "orderLending",
                        orderStayPayment: "orderStayPayment",
                        orderLendSuccess: "orderLendSuccess",
                        orderPoping: "orderPoping",
                        orderReturnSuccess: "orderReturnSuccess"
                    },
                    statusName: "",
                    currentTitle: ""
                };
            },
            watch: {
                orderStatus: function() {
                    this.currentTitle = this.getSubTitle(this.orderStatus);
                },
                isSuspended: function() {
                    this.currentTitle = this.getSubTitle(this.orderStatus);
                }
            },
            created: function() {
                i.default.isTZ3CabinSns(this.currentCabinId) ? (this.statusImgObj.orderLending = {
                    defaultUrl: "https://p0.meituan.net/scarlett/3209de31ee34b1edad0b9e2791935a7f215553.png",
                    mainTitle: "租借中",
                    subTitleDefault: "1台，"
                }, this.statusImgObj.orderLendSuccess = {
                    defaultUrl: "https://p0.meituan.net/scarlett/5cf26c75d27f3c9b209594863cd0e02239474.jpg",
                    mainTitle: "弹出成功",
                    subTitleDefault: "指示灯"
                }) : this.orderDetailsInfo && this.orderDetailsInfo.lendPosition && (this.statusImgObj.orderLendSuccess.subTitleDefault = "左数第".concat(11 - this.orderDetailsInfo.lendPosition, "个仓位")), 
                this.currentTitle = this.getSubTitle(this.orderStatus);
            },
            methods: {
                getNowCabinModel: function() {
                    return i.default.isTZ3CabinSns(this.currentCabinId) ? "tz3" : (i.default.isTZ1TZ2CabinSns(this.currentCabinId), 
                    "tz12");
                },
                getSubTitle: function(e) {
                    var t = this, n = "";
                    return Object.keys(this.orderCode).forEach(function(r) {
                        t.orderCode[r].indexOf(e) > -1 && (t.statusName = r, t.mainTitle = t.statusImgObj[r].mainTitle, 
                        t.defaultImgUrl = t.statusImgObj[r].defaultUrl, n = t.refundFee > 0 && "orderFinished" === r ? "".concat(t.refundFee, "元，") : t.statusImgObj[r].subTitleDefault, 
                        t.isSuspended && r === t.orderStatusName.orderLending && (t.mainTitle = "".concat(t.orderDetailsInfo.suspendInfo.suspendDuration, "暂停计费中")));
                    }), n;
                }
            }
        };
        t.default = a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/orderDetail/detailHeader-create-component", {
    "components/orderDetail/detailHeader-create-component": function(e, t, n) {
        n("543d").createComponent(n("dd32"));
    }
}, [ [ "components/orderDetail/detailHeader-create-component" ] ] ]);