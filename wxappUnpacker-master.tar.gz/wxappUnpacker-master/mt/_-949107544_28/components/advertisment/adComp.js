(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/advertisment/adComp" ], {
    "5c4b": function(t, n, e) {
        e.r(n);
        var o = e("9866"), a = e.n(o);
        for (var i in o) "default" !== i && function(t) {
            e.d(n, t, function() {
                return o[t];
            });
        }(i);
        n.default = a.a;
    },
    "80d8": function(t, n, e) {
        e.d(n, "b", function() {
            return o;
        }), e.d(n, "c", function() {
            return a;
        }), e.d(n, "a", function() {});
        var o = function() {
            var t = this, n = (t.$createElement, t._self._c, e("0cd1"));
            t.$mp.data = Object.assign({}, {
                $root: {
                    m0: n
                }
            });
        }, a = [];
    },
    "8c78": function(t, n, e) {
        e.r(n);
        var o = e("80d8"), a = e("5c4b");
        for (var i in a) "default" !== i && function(t) {
            e.d(n, t, function() {
                return a[t];
            });
        }(i);
        e("bb9d");
        var r = e("f0c5"), d = Object(r.a)(a.default, o.b, o.c, !1, null, "06dc5f78", null, !1, o.a, void 0);
        n.default = d.exports;
    },
    9866: function(t, n, e) {
        (function(t) {
            function o(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            function a(t, n, e, o, a, i, r) {
                try {
                    var d = t[i](r), s = d.value;
                } catch (t) {
                    return void e(t);
                }
                d.done ? n(s) : Promise.resolve(s).then(o, a);
            }
            function i(t) {
                return function() {
                    var n = this, e = arguments;
                    return new Promise(function(o, i) {
                        function r(t) {
                            a(s, o, i, r, d, "next", t);
                        }
                        function d(t) {
                            a(s, o, i, r, d, "throw", t);
                        }
                        var s = t.apply(n, e);
                        r(void 0);
                    });
                };
            }
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var r = o(e("a34a")), d = o(e("fac4")), s = o(e("91d2")), c = o(e("f121")), u = o(e("beb0")), l = e("c07e");
            var p = {
                name: "Advertisment",
                props: {
                    positionId: {
                        type: Number,
                        default: 1
                    },
                    cid: {
                        type: String,
                        default: ""
                    },
                    mode: {
                        type: String,
                        default: "banner"
                    },
                    className: {
                        type: String,
                        default: ""
                    }
                },
                data: function() {
                    return {
                        channel: 1,
                        advInfo: {
                            advId: "",
                            sourceType: 0,
                            imgUrl: "",
                            linkType: 0,
                            linkUrl: "",
                            appId: "",
                            showSeconds: 0,
                            popType: 0
                        },
                        modalVisible: !1
                    };
                },
                computed: {
                    valLab: function() {
                        return {
                            adv_id: this.advId,
                            position_id: this.positionId
                        };
                    },
                    isShowModal: function() {
                        return "modal" === this.mode && this.modalVisible && this.advInfo.popType;
                    }
                },
                created: function() {
                    this.fetchData();
                },
                methods: {
                    reportMV: function() {
                        var t = this.advInfo, n = t.imgUrl, e = t.popType;
                        (3 !== this.positionId && n || 3 === this.positionId && e && n) && u.default.sendMV("ADV_POSITION", this.valLab, {
                            cid: this.cid
                        });
                    },
                    reportMC: function() {
                        u.default.sendMC("ADV_POSITION", this.valLab, {
                            cid: this.cid
                        });
                    },
                    closeModal: function() {
                        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0, n = this;
                        setTimeout(function() {
                            n.modalVisible = !1;
                        }, 1e3 * t);
                    },
                    handleClik: function() {
                        this.advInfo.linkUrl && (this.reportMC(), this.advInfo.linkType < 3 ? this.miniProgramJump() : this.H5Jump());
                    },
                    miniProgramJump: function() {
                        var n = this.advInfo, e = n.linkType, o = n.linkUrl, a = n.appId;
                        e === l.AD_LINK_TYPE.MINI_INSIDE_PAGE ? t.navigateTo({
                            url: "/".concat(o)
                        }) : e === l.AD_LINK_TYPE.MINI_TO_H5_PAGE ? t.navigateTo({
                            url: "/pages/webView/index?viewPath=https://".concat(encodeURIComponent(o))
                        }) : e === l.AD_LINK_TYPE.MINI_TO_MINI && wx.navigateToMiniProgram({
                            appId: a,
                            path: "/".concat(o)
                        });
                    },
                    H5Jump: function() {
                        var n = this.advInfo, e = n.linkType, o = n.linkUrl;
                        e === l.AD_LINK_TYPE.H5_TO_H5 ? CKNB.openPage({
                            url: o
                        }) : e === l.AD_LINK_TYPE.H5_INSIDE_PAGE && t.navigateTo({
                            path: "/".concat(o)
                        });
                    },
                    isTriggerCloseModal: function() {
                        return this.advInfo.sourceType && this.advInfo.popType;
                    },
                    fetchData: function() {
                        var t = this;
                        return i(r.default.mark(function n() {
                            var e, o, a, i, u, l;
                            return r.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    return e = {
                                        status: "0",
                                        msg: "查询成功"
                                    }, n.prev = 1, o = {
                                        positionId: t.positionId,
                                        channel: t.channel
                                    }, n.next = 5, (0, d.default)(o);

                                  case 5:
                                    a = n.sent, i = a.code, u = a.data, l = void 0 === u ? {} : u, i === c.default.errorAlias.SUCCESS ? (e = {
                                        status: i,
                                        msg: "成功"
                                    }, t.advInfo = l, t.reportMV(), 3 === t.positionId && (t.modalVisible = !0, t.isTriggerCloseModal() && t.closeModal(l.showSeconds))) : e = {
                                        status: i,
                                        msg: ""
                                    }, n.next = 16;
                                    break;

                                  case 12:
                                    n.prev = 12, n.t0 = n.catch(1), e = {
                                        status: "-1",
                                        msg: "网络错误"
                                    }, s.default.addError({
                                        msg: e.msg,
                                        errorName: "getAdvertismentInfoError",
                                        error: {
                                            error: n.t0
                                        },
                                        errorType: "error"
                                    });

                                  case 16:
                                  case "end":
                                    return n.stop();
                                }
                            }, n, null, [ [ 1, 12 ] ]);
                        }))();
                    }
                }
            };
            n.default = p;
        }).call(this, e("543d").default);
    },
    bb9d: function(t, n, e) {
        var o = e("f013");
        e.n(o).a;
    },
    f013: function(t, n, e) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/advertisment/adComp-create-component", {
    "components/advertisment/adComp-create-component": function(t, n, e) {
        e("543d").createComponent(e("8c78"));
    }
}, [ [ "components/advertisment/adComp-create-component" ] ] ]);