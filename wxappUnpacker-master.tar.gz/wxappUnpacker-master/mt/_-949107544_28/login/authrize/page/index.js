(global.webpackJsonp = global.webpackJsonp || []).push([ [ "login/authrize/page/index" ], {
    "06e0": function(t, n, o) {
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var e, a = o("34cd"), u = o("cb4a"), i = (e = {}, e[u.AUTH_TYPE.userInfo] = {
            type: u.AUTH_TYPE.userInfo,
            text: "授权微信用户信息",
            openType: "getUserInfo"
        }, e), f = {
            data: function() {
                return {
                    AUTH_TYPE: u.AUTH_TYPE,
                    btn: {},
                    authrizePageData: a.config.pageConfig
                };
            },
            onShow: function() {
                a.state && a.state.option && a.state.option.pageOnshow && "function" == typeof a.state.option.pageOnshow && a.state.option.pageOnshow();
            },
            onLoad: function(t) {
                this.btn = i[t.type];
            },
            methods: {
                onGotUserInfoTap: function() {
                    a.state && a.state.option && a.state.option.userInfoClick && "function" == typeof a.state.option.userInfoClick && a.state.option.userInfoClick();
                },
                getuserinfoClick: function(t) {
                    var n = t.detail;
                    if (n && n.iv) return a.state && a.state.option && a.state.option.allowAuth && "function" == typeof a.state.option.allowAuth && a.state.option.allowAuth(), 
                    void (a.state && a.state.resolve(n));
                    a.state && a.state.option && a.state.option.refuseAuth && "function" == typeof a.state.option.refuseAuth && a.state.option.refuseAuth();
                }
            }
        };
        n.default = f;
    },
    "1aa2": function(t, n, o) {
        (function(t) {
            function n(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            o("6cdc"), n(o("66fd")), t(n(o("270e")).default);
        }).call(this, o("543d").createPage);
    },
    "270e": function(t, n, o) {
        o.r(n);
        var e = o("d37f"), a = o("39ba");
        for (var u in a) "default" !== u && function(t) {
            o.d(n, t, function() {
                return a[t];
            });
        }(u);
        o("4fc7");
        var i = o("f0c5"), f = Object(i.a)(a.default, e.b, e.c, !1, null, null, null, !1, e.a, void 0);
        n.default = f.exports;
    },
    "39ba": function(t, n, o) {
        o.r(n);
        var e = o("06e0"), a = o.n(e);
        for (var u in e) "default" !== u && function(t) {
            o.d(n, t, function() {
                return e[t];
            });
        }(u);
        n.default = a.a;
    },
    "4fc7": function(t, n, o) {
        var e = o("73d8");
        o.n(e).a;
    },
    "73d8": function(t, n, o) {},
    d37f: function(t, n, o) {
        o.d(n, "b", function() {
            return e;
        }), o.d(n, "c", function() {
            return a;
        }), o.d(n, "a", function() {});
        var e = function() {
            var t = this;
            t.$createElement;
            t._self._c;
        }, a = [];
    }
}, [ [ "1aa2", "common/runtime", "common/vendor" ] ] ]);