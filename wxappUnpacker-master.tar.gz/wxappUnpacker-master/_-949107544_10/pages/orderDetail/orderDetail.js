(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/orderDetail/orderDetail" ], {
    "145d": function(e, t, r) {
        r.r(t);
        var n = r("4444"), o = r.n(n);
        for (var i in n) "default" !== i && function(e) {
            r.d(t, e, function() {
                return n[e];
            });
        }(i);
        t.default = o.a;
    },
    4444: function(e, t, r) {
        (function(e) {
            function n(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            function o(e, t, r, n, o, i, a) {
                try {
                    var u = e[i](a), s = u.value;
                } catch (e) {
                    return void r(e);
                }
                u.done ? t(s) : Promise.resolve(s).then(n, o);
            }
            function i(e) {
                return function() {
                    var t = this, r = arguments;
                    return new Promise(function(n, i) {
                        function a(e) {
                            o(s, n, i, a, u, "next", e);
                        }
                        function u(e) {
                            o(s, n, i, a, u, "throw", e);
                        }
                        var s = e.apply(t, r);
                        a(void 0);
                    });
                };
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = n(r("a34a")), u = r("c07e"), s = r("fecb"), d = n(r("e10e")), c = r("55cf"), l = n(r("cafb")), f = r("75c3"), m = getApp().globalData.lx, p = "39.909604", h = "116.397228", g = {
                components: {
                    detailHeader: function() {
                        Promise.all([ r.e("common/vendor"), r.e("components/orderDetail/detailHeader") ]).then(function() {
                            return resolve(r("dd32"));
                        }.bind(null, r)).catch(r.oe);
                    },
                    detailCost: function() {
                        Promise.all([ r.e("common/vendor"), r.e("components/orderDetail/detailCost") ]).then(function() {
                            return resolve(r("dd28"));
                        }.bind(null, r)).catch(r.oe);
                    },
                    detailCell: function() {
                        Promise.all([ r.e("common/vendor"), r.e("components/orderDetail/detailCell") ]).then(function() {
                            return resolve(r("7562"));
                        }.bind(null, r)).catch(r.oe);
                    },
                    Popping: function() {
                        Promise.all([ r.e("common/vendor"), r.e("components/popping") ]).then(function() {
                            return resolve(r("084e"));
                        }.bind(null, r)).catch(r.oe);
                    }
                },
                data: function() {
                    return {
                        orderStatus: 0,
                        lendCabId: 0,
                        total: 0,
                        orderDetailsInfo: {
                            returnTime: 0,
                            lendTime: 0,
                            lendPoiName: "",
                            returnPoiName: "",
                            consumeFee: 0,
                            priceUnit: 0,
                            cappedPrice: 0,
                            depositFee: 0,
                            refundFee: 0,
                            actualPrice: 0,
                            freeDeposit: !1,
                            orderId: 0
                        },
                        isShowError: !1,
                        isShowDe: !1,
                        orderCode: u.ORDER_STATUS_GROUP,
                        orderStatusName: {
                            orderFinished: "orderFinished",
                            orderLending: "orderLending",
                            orderStayPayment: "orderStayPayment",
                            orderLendSuccess: "orderLendSuccess",
                            orderPoping: "orderPoping",
                            orderPopingFail: "orderPopingFail",
                            orderReturnSuccess: "orderReturnSuccess"
                        },
                        returnCell: {
                            mainTitle: "归还方式",
                            subTitle: "插入空仓即还，无需扫码"
                        },
                        nearbyPois: {
                            mainTitle: "附近网点"
                        },
                        contactCustomer: {
                            mainTitle: "联系客服",
                            subTitle: ""
                        },
                        commonProblem: {
                            mainTitle: "常见问题",
                            subTitle: ""
                        },
                        isPopSuccess: !1,
                        detailOrderId: 0,
                        timer: null,
                        isConfirmPay: !1,
                        orderInfoTimer: null,
                        popingTimer: null
                    };
                },
                computed: {
                    getDetailsInfoParse: function() {
                        return function(e) {
                            return parseFloat(e / 100);
                        };
                    },
                    getOrderStatus: function() {
                        var e = this, t = "";
                        return Object.keys(this.orderCode).forEach(function(r) {
                            e.orderCode[r].indexOf(e.orderStatus) > -1 && (t = r);
                        }), t;
                    }
                },
                onLoad: function(e) {
                    this.isPopSuccess = e.isPopSuccess, this.detailOrderId = e.orderId, this.getLocation();
                },
                onPullDownRefresh: function() {
                    this.isShowError = !1, this.getOrderInfo(!0);
                },
                onShow: function() {
                    m.pageView("c_power_wx_order_detail"), this.isShowError = !1, e.showLoading({
                        mask: !0,
                        title: "加载中"
                    }), this.getOrderInfo();
                },
                onHide: function() {
                    this.clearTimerAll();
                },
                onUnload: function() {
                    this.clearTimerAll(), (0, c.stopLoopOrderStatus)();
                },
                methods: {
                    getOrderInfo: function() {
                        var t = this, r = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                        d.default.getOrderDetail({
                            orderId: this.detailOrderId
                        }).then(function(n) {
                            r && e.stopPullDownRefresh(), e.hideLoading();
                            var o = n.status, i = n.data;
                            if (0 === o && i) {
                                if (t.orderDetailsInfo = i, t.lendCabId = t.orderDetailsInfo.lendCabId, "true" === t.isPopSuccess ? t.orderStatus = f.ORDER_STATUS.POP_SUCCESS : t.orderStatus = t.orderDetailsInfo.orderStatus, 
                                t.isPopSuccess = !1, t.getOrderStatus === t.orderStatusName.orderPopingFail) return void e.reLaunch({
                                    url: "/pages/error/index?errType=10088"
                                });
                                if (t.getOrderStatus === t.orderStatusName.orderPoping) return t.popingTimer && clearTimeout(t.popingTimer), 
                                void (t.popingTimer = setTimeout(function() {
                                    t.getOrderInfo();
                                }, 1e3));
                                null !== t.timer && clearTimeout(t.timer), t.timer = setTimeout(function() {
                                    t.getOrderInfo();
                                }, 6e4);
                            } else t.isShowError = !0;
                        }).catch(function(n) {
                            console.log(n), r && e.stopPullDownRefresh(), e.hideLoading(), t.isShowError = !0;
                        });
                    },
                    fetchdata: function(t) {
                        var r = this;
                        return i(a.default.mark(function n() {
                            var o;
                            return a.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    return n.prev = 0, n.next = 3, l.default.getPoiList(t);

                                  case 3:
                                    o = n.sent, r.total = o.data && o.data.total || 0, n.next = 10;
                                    break;

                                  case 7:
                                    n.prev = 7, n.t0 = n.catch(0), e.showToast({
                                        title: n.t0 ? n.t0.message : "获取附近门店失败",
                                        icon: "none"
                                    });

                                  case 10:
                                  case "end":
                                    return n.stop();
                                }
                            }, n, null, [ [ 0, 7 ] ]);
                        }))();
                    },
                    getLocation: function() {
                        var t = this;
                        e.getLocation({
                            type: "gcj02",
                            success: function() {
                                var e = i(a.default.mark(function e(r) {
                                    return a.default.wrap(function(e) {
                                        for (;;) switch (e.prev = e.next) {
                                          case 0:
                                            return e.next = 2, t.fetchdata({
                                                lat: r.latitude,
                                                lng: r.longitude,
                                                userLat: r.latitude,
                                                userLng: r.longitude
                                            });

                                          case 2:
                                          case "end":
                                            return e.stop();
                                        }
                                    }, e);
                                }));
                                return function(t) {
                                    return e.apply(this, arguments);
                                };
                            }(),
                            fail: function() {
                                var r = i(a.default.mark(function r() {
                                    return a.default.wrap(function(r) {
                                        for (;;) switch (r.prev = r.next) {
                                          case 0:
                                            return e.showToast({
                                                title: "授权定位信息失败",
                                                icon: "none",
                                                duration: 2e3
                                            }), r.next = 3, t.fetchdata({
                                                lat: p,
                                                lng: h,
                                                userLat: p,
                                                userLng: h
                                            });

                                          case 3:
                                          case "end":
                                            return r.stop();
                                        }
                                    }, r);
                                }));
                                return function() {
                                    return r.apply(this, arguments);
                                };
                            }()
                        });
                    },
                    isShowDetail: function(e) {
                        this.isShowDe = e.isShowDe;
                    },
                    goToInstructions: function() {
                        e.navigateTo({
                            url: "/pages/return/instructions"
                        });
                    },
                    goToNearby: function() {
                        0 !== this.total && (m.moduleClick("b_power_orderdetail_nearby_mc"), e.navigateTo({
                            url: "/pages/index/index"
                        }));
                    },
                    makePhoneCall: function() {
                        e.makePhoneCall({
                            phoneNumber: u.PHONENUMBER
                        });
                    },
                    goToFAQ: function() {
                        e.navigateTo({
                            url: "/pages/FAQ/FAQ"
                        });
                    },
                    lendAgain: function() {
                        e.navigateTo({
                            url: "/pages/index/index"
                        });
                    },
                    tobePaid: function() {
                        var t = this;
                        return i(a.default.mark(function r() {
                            var n, o;
                            return a.default.wrap(function(r) {
                                for (;;) switch (r.prev = r.next) {
                                  case 0:
                                    if (!t.isConfirmPay) {
                                        r.next = 2;
                                        break;
                                    }
                                    return r.abrupt("return");

                                  case 2:
                                    return e.showLoading({
                                        mask: !0,
                                        title: "加载中"
                                    }), t.isConfirmPay = !0, n = {
                                        isPayFree: !1,
                                        isDowngrade: !0,
                                        orderId: t.detailOrderId
                                    }, r.next = 7, (0, c.createOrder)(n);

                                  case 7:
                                    if ((o = r.sent).isSuccess) {
                                        r.next = 16;
                                        break;
                                    }
                                    if (o._code !== s.paymentErrCode.stopLoop) {
                                        r.next = 11;
                                        break;
                                    }
                                    return r.abrupt("return");

                                  case 11:
                                    1105 === o.status && e.showToast({
                                        title: "不可重复支付",
                                        icon: "none"
                                    }), t.orderInfoTimer && clearTimeout(t.orderInfoTimer), t.orderInfoTimer = setTimeout(function() {
                                        t.getOrderInfo();
                                    }, 1500), r.next = 17;
                                    break;

                                  case 16:
                                    t.getOrderInfo();

                                  case 17:
                                    t.isConfirmPay = !1;

                                  case 18:
                                  case "end":
                                    return r.stop();
                                }
                            }, r);
                        }))();
                    },
                    clearTimerAll: function() {
                        null !== this.timer && clearTimeout(this.timer), null !== this.popingTimer && clearTimeout(this.popingTimer), 
                        null !== this.orderInfoTimer && clearTimeout(this.orderInfoTimer);
                    }
                }
            };
            t.default = g;
        }).call(this, r("543d").default);
    },
    "877a": function(e, t, r) {
        r.d(t, "b", function() {
            return n;
        }), r.d(t, "c", function() {
            return o;
        }), r.d(t, "a", function() {});
        var n = function() {
            var e = this, t = (e.$createElement, e._self._c, e.getDetailsInfoParse(e.orderDetailsInfo.refundFee)), n = e.getDetailsInfoParse(e.orderDetailsInfo.consumeFee), o = r("f597");
            e.$mp.data = Object.assign({}, {
                $root: {
                    m0: t,
                    m1: n,
                    m2: o
                }
            });
        }, o = [];
    },
    a764: function(e, t, r) {
        (function(e) {
            function t(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            r("6cdc"), r("921b"), t(r("66fd")), e(t(r("de87")).default);
        }).call(this, r("543d").createPage);
    },
    bd33: function(e, t, r) {},
    c4de: function(e, t, r) {
        var n = r("bd33");
        r.n(n).a;
    },
    de87: function(e, t, r) {
        r.r(t);
        var n = r("877a"), o = r("145d");
        for (var i in o) "default" !== i && function(e) {
            r.d(t, e, function() {
                return o[e];
            });
        }(i);
        r("c4de");
        var a = r("f0c5"), u = Object(a.a)(o.default, n.b, n.c, !1, null, "761cb1ac", null, !1, n.a, void 0);
        t.default = u.exports;
    }
}, [ [ "a764", "common/runtime", "common/vendor" ] ] ]);