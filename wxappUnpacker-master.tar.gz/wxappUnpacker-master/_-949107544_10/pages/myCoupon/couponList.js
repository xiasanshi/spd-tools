(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/myCoupon/couponList" ], {
    "03a9": function(n, e, t) {
        function r(n) {
            return n && n.__esModule ? n : {
                default: n
            };
        }
        function a(n, e, t, r, a, o, u) {
            try {
                var c = n[o](u), i = c.value;
            } catch (n) {
                return void t(n);
            }
            c.done ? e(i) : Promise.resolve(i).then(r, a);
        }
        function o(n) {
            return function() {
                var e = this, t = arguments;
                return new Promise(function(r, o) {
                    function u(n) {
                        a(i, r, o, u, c, "next", n);
                    }
                    function c(n) {
                        a(i, r, o, u, c, "throw", n);
                    }
                    var i = n.apply(e, t);
                    u(void 0);
                });
            };
        }
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var u = r(t("a34a")), c = r(t("ff13")), i = {
            components: {
                panelCoupon: function() {
                    Promise.all([ t.e("common/vendor"), t.e("components/myCoupon/panelCoupon") ]).then(function() {
                        return resolve(t("60a5"));
                    }.bind(null, t)).catch(t.oe);
                },
                redeemCoupon: function() {
                    Promise.all([ t.e("common/vendor"), t.e("components/myCoupon/redeemCoupon") ]).then(function() {
                        return resolve(t("4368"));
                    }.bind(null, t)).catch(t.oe);
                }
            },
            data: function() {
                return {
                    couponList: [],
                    pageNum: 1,
                    isFinish: !1,
                    loading: !1,
                    pageSize: 10,
                    noData: !1,
                    hasError: !1,
                    triggered: !1
                };
            },
            onShow: function() {},
            onHide: function() {},
            computed: {
                hasException: function() {
                    return this.noData || this.hasError;
                }
            },
            mounted: function() {
                var n = this;
                return o(u.default.mark(function e() {
                    return u.default.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            return e.next = 2, n.getData();

                          case 2:
                          case "end":
                            return e.stop();
                        }
                    }, e);
                }))();
            },
            methods: {
                refresherrefresh: function() {
                    var n = this;
                    return o(u.default.mark(function e() {
                        return u.default.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                if (n.triggered = !0, !n.loading) {
                                    e.next = 3;
                                    break;
                                }
                                return e.abrupt("return");

                              case 3:
                                return e.next = 5, n.getData(!0);

                              case 5:
                                n.triggered = !1;

                              case 6:
                              case "end":
                                return e.stop();
                            }
                        }, e);
                    }))();
                },
                scrollBottom: function() {
                    var n = this;
                    return o(u.default.mark(function e() {
                        return u.default.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                if (!n.isFinish && !n.loading) {
                                    e.next = 2;
                                    break;
                                }
                                return e.abrupt("return");

                              case 2:
                                return n.pageNum = n.pageNum + 1, e.next = 5, n.getData();

                              case 5:
                              case "end":
                                return e.stop();
                            }
                        }, e);
                    }))();
                },
                getData: function() {
                    var n = arguments, e = this;
                    return o(u.default.mark(function t() {
                        var r, a, o, i, s;
                        return u.default.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                              case 0:
                                return r = n.length > 0 && void 0 !== n[0] && n[0], e.loading = !0, t.prev = 2, 
                                r && (e.pageNum = 1), t.next = 6, c.default.queryListByUserId({
                                    pageNo: e.pageNum
                                });

                              case 6:
                                a = t.sent, i = (o = a || {}).status, s = o.data, 0 === i && s && Array.isArray(s.data) ? (e.isFinish = s.data.length < e.pageSize, 
                                e.noData = !1, e.hasError = !1, e.couponList = r ? s.data : e.couponList.concat(s.data), 
                                e.couponList && 0 !== e.couponList.length || (e.noData = !0)) : e.noData = !0, t.next = 15;
                                break;

                              case 11:
                                t.prev = 11, t.t0 = t.catch(2), console.error("getData:", t.t0), e.hasError = !0;

                              case 15:
                                e.loading = !1;

                              case 16:
                              case "end":
                                return t.stop();
                            }
                        }, t, null, [ [ 2, 11 ] ]);
                    }))();
                },
                closeRedeem: function() {
                    this.pageNum = 1, this.getData(!0);
                }
            }
        };
        e.default = i;
    },
    "32cb": function(n, e, t) {
        t.r(e);
        var r = t("03a9"), a = t.n(r);
        for (var o in r) "default" !== o && function(n) {
            t.d(e, n, function() {
                return r[n];
            });
        }(o);
        e.default = a.a;
    },
    "537e": function(n, e, t) {
        var r = t("9767");
        t.n(r).a;
    },
    "79a5": function(n, e, t) {
        (function(n) {
            function e(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            t("6cdc"), t("921b"), e(t("66fd")), n(e(t("e481")).default);
        }).call(this, t("543d").createPage);
    },
    9767: function(n, e, t) {},
    e481: function(n, e, t) {
        t.r(e);
        var r = t("fac2"), a = t("32cb");
        for (var o in a) "default" !== o && function(n) {
            t.d(e, n, function() {
                return a[n];
            });
        }(o);
        t("537e");
        var u = t("f0c5"), c = Object(u.a)(a.default, r.b, r.c, !1, null, "8bbfa36e", null, !1, r.a, void 0);
        e.default = c.exports;
    },
    fac2: function(n, e, t) {
        t.d(e, "b", function() {
            return r;
        }), t.d(e, "c", function() {
            return a;
        }), t.d(e, "a", function() {});
        var r = function() {
            var n = this;
            n.$createElement;
            n._self._c;
        }, a = [];
    }
}, [ [ "79a5", "common/runtime", "common/vendor" ] ] ]);