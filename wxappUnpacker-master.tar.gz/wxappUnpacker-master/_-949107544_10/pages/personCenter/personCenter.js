(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/personCenter/personCenter" ], {
    "5cc2": function(n, e, t) {
        var o = t("8491");
        t.n(o).a;
    },
    6253: function(n, e, t) {
        t.r(e);
        var o = t("9f33"), u = t("8e7b");
        for (var a in u) "default" !== a && function(n) {
            t.d(e, n, function() {
                return u[n];
            });
        }(a);
        t("5cc2");
        var c = t("f0c5"), r = Object(c.a)(u.default, o.b, o.c, !1, null, "1000b028", null, !1, o.a, void 0);
        e.default = r.exports;
    },
    8491: function(n, e, t) {},
    "8e7b": function(n, e, t) {
        t.r(e);
        var o = t("b0bb"), u = t.n(o);
        for (var a in o) "default" !== a && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(a);
        e.default = u.a;
    },
    "9f33": function(n, e, t) {
        t.d(e, "b", function() {
            return o;
        }), t.d(e, "c", function() {
            return u;
        }), t.d(e, "a", function() {});
        var o = function() {
            var n = this;
            n.$createElement;
            n._self._c;
        }, u = [];
    },
    b0bb: function(n, e, t) {
        (function(n) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var o = t("c07e"), u = function(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }(t("f121")), a = t("90ff"), c = {
                components: {
                    DetailCell: function() {
                        Promise.all([ t.e("common/vendor"), t.e("components/orderDetail/detailCell") ]).then(function() {
                            return resolve(t("7562"));
                        }.bind(null, t)).catch(t.oe);
                    }
                },
                data: function() {
                    return {
                        env: u.default.env,
                        logoutText: "退出登录(".concat(u.default.env, ")")
                    };
                },
                methods: {
                    toMyCoupon: function() {
                        n.navigateTo({
                            url: "/pages/myCoupon/couponList"
                        });
                    },
                    toMyOrders: function() {
                        n.navigateTo({
                            url: "/pages/myOrders/myOrders"
                        });
                    },
                    toFAQ: function() {
                        n.navigateTo({
                            url: "/pages/FAQ/FAQ"
                        });
                    },
                    contactCustomerService: function() {
                        n.makePhoneCall({
                            phoneNumber: o.PHONENUMBER
                        });
                    },
                    toUserProtocol: function() {
                        n.navigateTo({
                            url: "/pages/userProtocol/userProtocol"
                        });
                    },
                    userLogout: function() {
                        (0, a.logout)().then(function(n) {
                            wx.showModal({
                                content: "已退出".concat(n)
                            });
                        });
                    },
                    navToTestPage: function() {
                        n.navigateTo({
                            url: "/pages/testPage/index"
                        });
                    }
                }
            };
            e.default = c;
        }).call(this, t("543d").default);
    },
    ebf1: function(n, e, t) {
        (function(n) {
            function e(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            t("6cdc"), t("921b"), e(t("66fd")), n(e(t("6253")).default);
        }).call(this, t("543d").createPage);
    }
}, [ [ "ebf1", "common/runtime", "common/vendor" ] ] ]);