(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/FAQ/FAQ" ], {
    "0705": function(t, n, e) {
        e.d(n, "b", function() {
            return c;
        }), e.d(n, "c", function() {
            return o;
        }), e.d(n, "a", function() {});
        var c = function() {
            var t = this, n = (t.$createElement, t._self._c, e("d355"));
            t.$mp.data = Object.assign({}, {
                $root: {
                    m0: n
                }
            });
        }, o = [];
    },
    "3be9": function(t, n, e) {
        e.r(n);
        var c = e("910d"), o = e.n(c);
        for (var a in c) "default" !== a && function(t) {
            e.d(n, t, function() {
                return c[t];
            });
        }(a);
        n.default = o.a;
    },
    "41c5": function(t, n, e) {
        (function(t) {
            function n(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            e("6cdc"), e("921b"), n(e("66fd")), t(n(e("96e4")).default);
        }).call(this, e("543d").createPage);
    },
    "910d": function(t, n, e) {
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var c = {
            data: function() {
                return {
                    activeIndex: -1,
                    QAList: [ {
                        title: "如何计费？",
                        content: [ "采取分时计费，从借出充电宝后计时，5分钟内免费，超出免费时长按小时计费。" ]
                    }, {
                        title: "押金规则？",
                        content: [ "押金充值", "需要交纳押金，具体金额以页面显示为准，账户余额充值不低于押金金额。", "押金返还", "有未归还的充电宝时，不能进行余额退还。归还充电宝完成后，余额可自动退还，无需手动提现。约0-3个工作日退还到充值账户。" ]
                    }, {
                        title: "用微信借的，怎么查退款到账？",
                        content: [ "步骤1：打开【微信】APP-进入【我的】，步骤2：点击【钱包】，进入微信钱包，步骤3：点击【右上角】四个方块，进入支付中心，步骤4：点击【账单】，查看账单明细。这里您就能看到自己的退款到账情况啦~。如还有问题，请微信留言或拨打客服电话：400-000-5658。" ]
                    }, {
                        title: "用美团借的，怎么查退款到账？",
                        content: [ "步骤1：打开【美团】APP-进入【我的】，步骤2：点击【我的钱包】，进入美团钱包，步骤3：点击【右上角】三个横杠，进入支付中心，步骤4：点击【交易记录】，查看交易明细，这里您就能看到自己的退款到账情况啦~。如还有问题，请在线客服留言或拨打客服电话：400-000-5658。" ]
                    }, {
                        title: "付了款，但充电宝没有弹出来怎么办？",
                        content: [ "请先检查是否有指示灯闪烁的弹出充电宝。如果未弹出，可能是由于网络延迟造成的，会在5分钟内自动发起押金退款，如果没有及时解决您的问题，请您拔打客服电话：400-000-5658。" ]
                    }, {
                        title: "充电宝取出后无法充电怎么办？",
                        content: [ "首先按下充电宝的按键确认充电是否正常。如果您借出的充电宝仍无法充电或者出现充电线损坏等情况，请将充电宝重新插入到充电宝底座。拔打我们的客服电话：400-000-5658。" ]
                    }, {
                        title: "归还充电宝后为什么显示归还失败？",
                        content: [ "先确认充电宝是否按照正确的方向插入。再确认充电宝是否成功插入到底座，凹槽灯光是否正常亮起。" ]
                    }, {
                        title: "充电宝归还后余额如何退还？",
                        content: [ "充电宝归还成功后，余额会自动返还给您。约0-3个工作日退还到原支付账户中，如仍未到账可咨询在线客服，直接拔打我们的客服电话：400-000-5658。" ]
                    }, {
                        title: "能否一个人借多个充电宝？",
                        content: [ "暂不支持一人同时借多个充电宝。" ]
                    }, {
                        title: "能否异地归还充电宝？",
                        content: [ "支持异地归还，您可以打开美团充电小程序，在地图页查看附近网点，或使用小程序搜索功能查看您想去的地标、城市、商圈，查看归还位置信息。" ]
                    } ]
                };
            },
            methods: {
                onClick: function(t) {
                    t === this.activeIndex ? this.activeIndex = -1 : this.activeIndex = t;
                }
            }
        };
        n.default = c;
    },
    "96e4": function(t, n, e) {
        e.r(n);
        var c = e("0705"), o = e("3be9");
        for (var a in o) "default" !== a && function(t) {
            e.d(n, t, function() {
                return o[t];
            });
        }(a);
        e("f1ad");
        var i = e("f0c5"), u = Object(i.a)(o.default, c.b, c.c, !1, null, "f38a1a08", null, !1, c.a, void 0);
        n.default = u.exports;
    },
    a4bd: function(t, n, e) {},
    f1ad: function(t, n, e) {
        var c = e("a4bd");
        e.n(c).a;
    }
}, [ [ "41c5", "common/runtime", "common/vendor" ] ] ]);