(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/login/index" ], {
    1799: function(n, e, t) {
        (function(n) {
            function e(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            t("6cdc"), t("921b"), e(t("66fd")), n(e(t("efcf")).default);
        }).call(this, t("543d").createPage);
    },
    "3d33": function(n, e, t) {
        t.r(e);
        var o = t("81f7"), c = t.n(o);
        for (var a in o) "default" !== a && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(a);
        e.default = c.a;
    },
    "4e1d": function(n, e, t) {},
    "6dc8": function(n, e, t) {
        t.d(e, "b", function() {
            return o;
        }), t.d(e, "c", function() {
            return c;
        }), t.d(e, "a", function() {});
        var o = function() {
            var n = this;
            n.$createElement;
            n._self._c;
        }, c = [];
    },
    "81f7": function(n, e, t) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var o = t("90ff"), c = {
            data: function() {
                return {
                    title: "Hello",
                    callback: ""
                };
            },
            onLoad: function(n) {
                this.callback = this.formatCallback(n.callback);
            },
            methods: {
                formatCallback: function(n) {
                    return n = decodeURIComponent(n).replace(/^pages/, "/pages"), /^\/pages/.test(n) || (n = "/pages/index/index"), 
                    n;
                },
                getLoginCode: function() {
                    (0, o.getLoginCode)();
                },
                wxMobileLoginBind: function(n) {
                    var e = this;
                    (0, o.login)(n).then(function(n) {
                        console.log("only login", n), "succ" === n.status && wx.redirectTo({
                            url: e.callback
                        });
                    });
                }
            }
        };
        e.default = c;
    },
    efcf: function(n, e, t) {
        t.r(e);
        var o = t("6dc8"), c = t("3d33");
        for (var a in c) "default" !== a && function(n) {
            t.d(e, n, function() {
                return c[n];
            });
        }(a);
        t("f47f");
        var f = t("f0c5"), u = Object(f.a)(c.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        e.default = u.exports;
    },
    f47f: function(n, e, t) {
        var o = t("4e1d");
        t.n(o).a;
    }
}, [ [ "1799", "common/runtime", "common/vendor" ] ] ]);