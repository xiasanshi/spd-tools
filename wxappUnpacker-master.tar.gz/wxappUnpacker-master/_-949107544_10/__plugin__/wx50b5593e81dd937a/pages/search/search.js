// __plugin__/wx50b5593e81dd937a/pages/search/search.js
Page({data: {}})