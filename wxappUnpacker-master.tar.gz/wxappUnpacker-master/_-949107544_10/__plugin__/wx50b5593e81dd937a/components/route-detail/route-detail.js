// __plugin__/wx50b5593e81dd937a/components/route-detail/route-detail.js
Page({data: {}})