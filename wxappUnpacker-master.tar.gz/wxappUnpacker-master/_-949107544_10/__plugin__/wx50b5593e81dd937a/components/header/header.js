// __plugin__/wx50b5593e81dd937a/components/header/header.js
Page({data: {}})