// __plugin__/wx50b5593e81dd937a/components/walk-route/walk-route.js
Page({data: {}})