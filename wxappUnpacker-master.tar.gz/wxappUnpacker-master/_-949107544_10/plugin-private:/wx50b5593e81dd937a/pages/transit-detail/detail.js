// plugin-private://wx50b5593e81dd937a/pages/transit-detail/detail.js
Page({data: {}})