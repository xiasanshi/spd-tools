// plugin-private://wx50b5593e81dd937a/pages/index/index.js
Page({data: {}})