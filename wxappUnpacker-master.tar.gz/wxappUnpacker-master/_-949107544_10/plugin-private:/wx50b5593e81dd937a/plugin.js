// plugin-private://wx50b5593e81dd937a/plugin.js
Page({data: {}})