// plugin-private://wx50b5593e81dd937a/components/route-status/status.js
Page({data: {}})