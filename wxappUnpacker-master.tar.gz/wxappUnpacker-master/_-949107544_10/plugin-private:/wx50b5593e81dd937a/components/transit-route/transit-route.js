// plugin-private://wx50b5593e81dd937a/components/transit-route/transit-route.js
Page({data: {}})