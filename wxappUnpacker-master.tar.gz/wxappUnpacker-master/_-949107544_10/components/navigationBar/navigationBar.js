(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/navigationBar/navigationBar" ], {
    "3b59": function(n, t, e) {
        e.r(t);
        var o = e("7d7e"), a = e("c5d8");
        for (var r in a) "default" !== r && function(n) {
            e.d(t, n, function() {
                return a[n];
            });
        }(r);
        e("57fb");
        var c = e("f0c5"), i = Object(c.a)(a.default, o.b, o.c, !1, null, "b8d71c24", null, !1, o.a, void 0);
        t.default = i.exports;
    },
    "3bf7": function(n, t, e) {
        (function(n) {
            function o(n, t) {
                var e = Object.keys(n);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(n);
                    t && (o = o.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(n, t).enumerable;
                    })), e.push.apply(e, o);
                }
                return e;
            }
            function a(n) {
                for (var t = 1; t < arguments.length; t++) {
                    var e = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? o(Object(e), !0).forEach(function(t) {
                        r(n, t, e[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(n, Object.getOwnPropertyDescriptors(e)) : o(Object(e)).forEach(function(t) {
                        Object.defineProperty(n, t, Object.getOwnPropertyDescriptor(e, t));
                    });
                }
                return n;
            }
            function r(n, t, e) {
                return t in n ? Object.defineProperty(n, t, {
                    value: e,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : n[t] = e, n;
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var c = e("2f62"), i = e("90ff"), u = {
                props: {
                    showBack: {
                        type: Boolean,
                        default: !0
                    },
                    showAvatar: {
                        type: Boolean,
                        default: !1
                    },
                    goBack: Function
                },
                data: function() {
                    return {
                        authStatus: !1
                    };
                },
                computed: a(a({}, (0, c.mapState)([ "isLogin" ])), {}, {
                    getStatusBarHeight: function() {
                        var n = wx.getSystemInfoSync();
                        return "height: ".concat(n.statusBarHeight, "px");
                    }
                }),
                methods: {
                    handleGoBack: function() {
                        this.goBack ? this.goBack() : n.navigateBack();
                    },
                    getLoginCode: function() {
                        (0, i.getLoginCode)();
                    },
                    jumpToPersonCenter: function(n) {
                        this.isLogin ? wx.navigateTo({
                            url: "/pages/personCenter/personCenter"
                        }) : (0, i.login)(n).then(function(n) {
                            "succ" === n.status && (0, i.checkLogin)();
                        });
                    }
                }
            };
            t.default = u;
        }).call(this, e("543d").default);
    },
    "57fb": function(n, t, e) {
        var o = e("f2d4");
        e.n(o).a;
    },
    "7d7e": function(n, t, e) {
        e.d(t, "b", function() {
            return o;
        }), e.d(t, "c", function() {
            return a;
        }), e.d(t, "a", function() {});
        var o = function() {
            var n = this;
            n.$createElement;
            n._self._c;
        }, a = [];
    },
    c5d8: function(n, t, e) {
        e.r(t);
        var o = e("3bf7"), a = e.n(o);
        for (var r in o) "default" !== r && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(r);
        t.default = a.a;
    },
    f2d4: function(n, t, e) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/navigationBar/navigationBar-create-component", {
    "components/navigationBar/navigationBar-create-component": function(n, t, e) {
        e("543d").createComponent(e("3b59"));
    }
}, [ [ "components/navigationBar/navigationBar-create-component" ] ] ]);