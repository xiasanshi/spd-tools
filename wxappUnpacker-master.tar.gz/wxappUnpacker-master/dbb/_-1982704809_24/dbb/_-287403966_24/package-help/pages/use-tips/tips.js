!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    }), exports.default = [ {
        title: "如何充电",
        steps: [ {
            title: "第一步",
            tips: [ {
                isHighLight: 0,
                content: "从图示处"
            }, {
                isHighLight: 1,
                content: "抽出充电线"
            }, {
                isHighLight: 0,
                content: "，请轻轻取出哦～"
            } ],
            image: {
                isSingle: 1,
                imgs: [ "https://images.wosaimg.com/25/bc3551aaf510c687aa91148e51f04fedd3ae15.png" ]
            }
        }, {
            title: "第二步",
            tips: [ {
                isHighLight: 1,
                content: "插上充电线"
            }, {
                isHighLight: 0,
                content: "，将手机与充电宝叠放"
            } ],
            image: {
                isSingle: 1,
                imgs: [ "https://images.wosaimg.com/56/632d63785108324b2e51c6f008ea6978ba3c8b.png" ]
            }
        }, {
            title: "第三步",
            tips: [ {
                isHighLight: 1,
                content: "按击侧面电源键"
            }, {
                isHighLight: 0,
                content: "，即刻开启充电哦~"
            } ],
            image: {
                isSingle: 1,
                imgs: [ "https://images.wosaimg.com/cc/921030a94146353785f3dd0f826913fd42f3da.png" ]
            }
        } ]
    }, {
        title: "如何归还",
        steps: [ {
            title: "第一步",
            tips: [ {
                isHighLight: 0,
                content: "进入小程序首页，查找并前往归还地点，寻找"
            }, {
                isHighLight: 1,
                content: "空卡槽"
            } ],
            image: {
                isSingle: 0,
                imgs: [ "https://images.wosaimg.com/f8/3c30d3fab151d6438b9952bbf5421d35085025.png", "https://images.wosaimg.com/6b/d24f0e2b9914554d09fcc56e2e334cd93647da.png" ]
            }
        }, {
            title: "第二步",
            tips: [ {
                isHighLight: 0,
                content: "将充电宝插入"
            }, {
                isHighLight: 1,
                content: "空卡槽"
            }, {
                isHighLight: 0,
                content: "，确认充电宝锁住且不可取出后即完成归还 (多数有语音提示“归还成功，感谢您的使用”的哦)"
            } ],
            image: {
                isSingle: 0,
                imgs: [ "https://images.wosaimg.com/cc/16befdce01ec93b2b2d08c80d1617647da8e7c.png", "https://images.wosaimg.com/2c/8bf8dc4b95dd7e2a7884d4735d786c1cd52761.png" ]
            }
        }, {
            title: "第三步",
            tips: [ {
                isHighLight: 0,
                content: "打开小程序"
            }, {
                isHighLight: 1,
                content: "手动支付费用或系统自动扣款"
            }, {
                isHighLight: 0,
                content: "，确认"
            }, {
                isHighLight: 1,
                content: "订单状态更新为已完成后"
            }, {
                isHighLight: 0,
                content: "即完成整个归还流程"
            } ],
            image: {
                isSingle: 1,
                imgs: [ "https://images.wosaimg.com/35/ee61434fdf3a9eff38a18c85a5a357ec7b89c8.png" ]
            }
        } ]
    } ];
}();