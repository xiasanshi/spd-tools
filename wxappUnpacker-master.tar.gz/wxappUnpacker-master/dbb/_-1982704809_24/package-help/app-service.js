/*v0.5vv_20200413_syb_scopedata*/global.__wcc_version__='v0.5vv_20200413_syb_scopedata';global.__wcc_version_info__={"customComponents":true,"fixZeroRpx":true,"propValueDeepCopy":false};
var $gwxc
var $gaic={}
$gwx3=function(path,global){
if(typeof global === 'undefined') global={};if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
$gwx('init', global);
function _(a,b){if(typeof(b)!='undefined')a.children.push(b);}
function _v(k){if(typeof(k)!='undefined')return {tag:'virtual','wxKey':k,children:[]};return {tag:'virtual',children:[]};}
function _n(tag){$gwxc++;if($gwxc>=16000){throw 'Dom limit exceeded, please check if there\'s any mistake you\'ve made.'};return {tag:'wx-'+tag,attr:{},children:[],n:[],raw:{},generics:{}}}
function _p(a,b){b&&a.properities.push(b);}
function _s(scope,env,key){return typeof(scope[key])!='undefined'?scope[key]:env[key]}
function _wp(m){console.warn("WXMLRT_$gwx3:"+m)}
function _wl(tname,prefix){_wp(prefix+':-1:-1:-1: Template `' + tname + '` is being called recursively, will be stop.')}
$gwn=console.warn;
$gwl=console.log;
function $gwh()
{
function x()
{
}
x.prototype = 
{
hn: function( obj, all )
{
if( typeof(obj) == 'object' )
{
var cnt=0;
var any1=false,any2=false;
for(var x in obj)
{
any1=any1|x==='__value__';
any2=any2|x==='__wxspec__';
cnt++;
if(cnt>2)break;
}
return cnt == 2 && any1 && any2 && ( all || obj.__wxspec__ !== 'm' || this.hn(obj.__value__) === 'h' ) ? "h" : "n";
}
return "n";
},
nh: function( obj, special )
{
return { __value__: obj, __wxspec__: special ? special : true }
},
rv: function( obj )
{
return this.hn(obj,true)==='n'?obj:this.rv(obj.__value__);
},
hm: function( obj )
{
if( typeof(obj) == 'object' )
{
var cnt=0;
var any1=false,any2=false;
for(var x in obj)
{
any1=any1|x==='__value__';
any2=any2|x==='__wxspec__';
cnt++;
if(cnt>2)break;
}
return cnt == 2 && any1 && any2 && (obj.__wxspec__ === 'm' || this.hm(obj.__value__) );
}
return false;
}
}
return new x;
}
wh=$gwh();
function $gstack(s){
var tmp=s.split('\n '+' '+' '+' ');
for(var i=0;i<tmp.length;++i){
if(0==i) continue;
if(")"===tmp[i][tmp[i].length-1])
tmp[i]=tmp[i].replace(/\s\(.*\)$/,"");
else
tmp[i]="at anonymous function";
}
return tmp.join('\n '+' '+' '+' ');
}
function $gwrt( should_pass_type_info )
{
function ArithmeticEv( ops, e, s, g, o )
{
var _f = false;
var rop = ops[0][1];
var _a,_b,_c,_d, _aa, _bb;
switch( rop )
{
case '?:':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? rev( ops[2], e, s, g, o, _f ) : rev( ops[3], e, s, g, o, _f );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '&&':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? rev( ops[2], e, s, g, o, _f ) : wh.rv( _a );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '||':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? wh.rv(_a) : rev( ops[2], e, s, g, o, _f );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '+':
case '*':
case '/':
case '%':
case '|':
case '^':
case '&':
case '===':
case '==':
case '!=':
case '!==':
case '>=':
case '<=':
case '>':
case '<':
case '<<':
case '>>':
_a = rev( ops[1], e, s, g, o, _f );
_b = rev( ops[2], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) === 'h' || wh.hn( _b ) === 'h');
switch( rop )
{
case '+':
_d = wh.rv( _a ) + wh.rv( _b );
break;
case '*':
_d = wh.rv( _a ) * wh.rv( _b );
break;
case '/':
_d = wh.rv( _a ) / wh.rv( _b );
break;
case '%':
_d = wh.rv( _a ) % wh.rv( _b );
break;
case '|':
_d = wh.rv( _a ) | wh.rv( _b );
break;
case '^':
_d = wh.rv( _a ) ^ wh.rv( _b );
break;
case '&':
_d = wh.rv( _a ) & wh.rv( _b );
break;
case '===':
_d = wh.rv( _a ) === wh.rv( _b );
break;
case '==':
_d = wh.rv( _a ) == wh.rv( _b );
break;
case '!=':
_d = wh.rv( _a ) != wh.rv( _b );
break;
case '!==':
_d = wh.rv( _a ) !== wh.rv( _b );
break;
case '>=':
_d = wh.rv( _a ) >= wh.rv( _b );
break;
case '<=':
_d = wh.rv( _a ) <= wh.rv( _b );
break;
case '>':
_d = wh.rv( _a ) > wh.rv( _b );
break;
case '<':
_d = wh.rv( _a ) < wh.rv( _b );
break;
case '<<':
_d = wh.rv( _a ) << wh.rv( _b );
break;
case '>>':
_d = wh.rv( _a ) >> wh.rv( _b );
break;
default:
break;
}
return _c ? wh.nh( _d, "c" ) : _d;
break;
case '-':
_a = ops.length === 3 ? rev( ops[1], e, s, g, o, _f ) : 0;
_b = ops.length === 3 ? rev( ops[2], e, s, g, o, _f ) : rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) === 'h' || wh.hn( _b ) === 'h');
_d = _c ? wh.rv( _a ) - wh.rv( _b ) : _a - _b;
return _c ? wh.nh( _d, "c" ) : _d;
break;
case '!':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) == 'h');
_d = !wh.rv(_a);
return _c ? wh.nh( _d, "c" ) : _d;
case '~':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) == 'h');
_d = ~wh.rv(_a);
return _c ? wh.nh( _d, "c" ) : _d;
default:
$gwn('unrecognized op' + rop );
}
}
function rev( ops, e, s, g, o, newap )
{
var op = ops[0];
var _f = false;
if ( typeof newap !== "undefined" ) o.ap = newap;
if( typeof(op)==='object' )
{
var vop=op[0];
var _a, _aa, _b, _bb, _c, _d, _s, _e, _ta, _tb, _td;
switch(vop)
{
case 2:
return ArithmeticEv(ops,e,s,g,o);
break;
case 4: 
return rev( ops[1], e, s, g, o, _f );
break;
case 5: 
switch( ops.length )
{
case 2: 
_a = rev( ops[1],e,s,g,o,_f );
return should_pass_type_info?[_a]:[wh.rv(_a)];
return [_a];
break;
case 1: 
return [];
break;
default:
_a = rev( ops[1],e,s,g,o,_f );
_b = rev( ops[2],e,s,g,o,_f );
_a.push( 
should_pass_type_info ?
_b :
wh.rv( _b )
);
return _a;
break;
}
break;
case 6:
_a = rev(ops[1],e,s,g,o);
var ap = o.ap;
_ta = wh.hn(_a)==='h';
_aa = _ta ? wh.rv(_a) : _a;
o.is_affected |= _ta;
if( should_pass_type_info )
{
if( _aa===null || typeof(_aa) === 'undefined' )
{
return _ta ? wh.nh(undefined, 'e') : undefined;
}
_b = rev(ops[2],e,s,g,o,_f);
_tb = wh.hn(_b) === 'h';
_bb = _tb ? wh.rv(_b) : _b;
o.ap = ap;
o.is_affected |= _tb;
if( _bb===null || typeof(_bb) === 'undefined' || 
_bb === "__proto__" || _bb === "prototype" || _bb === "caller" ) 
{
return (_ta || _tb) ? wh.nh(undefined, 'e') : undefined;
}
_d = _aa[_bb];
if ( typeof _d === 'function' && !ap ) _d = undefined;
_td = wh.hn(_d)==='h';
o.is_affected |= _td;
return (_ta || _tb) ? (_td ? _d : wh.nh(_d, 'e')) : _d;
}
else
{
if( _aa===null || typeof(_aa) === 'undefined' )
{
return undefined;
}
_b = rev(ops[2],e,s,g,o,_f);
_tb = wh.hn(_b) === 'h';
_bb = _tb ? wh.rv(_b) : _b;
o.ap = ap;
o.is_affected |= _tb;
if( _bb===null || typeof(_bb) === 'undefined' || 
_bb === "__proto__" || _bb === "prototype" || _bb === "caller" ) 
{
return undefined;
}
_d = _aa[_bb];
if ( typeof _d === 'function' && !ap ) _d = undefined;
_td = wh.hn(_d)==='h';
o.is_affected |= _td;
return _td ? wh.rv(_d) : _d;
}
case 7: 
switch(ops[1][0])
{
case 11:
o.is_affected |= wh.hn(g)==='h';
return g;
case 3:
_s = wh.rv( s );
_e = wh.rv( e );
_b = ops[1][1];
if (g && g.f && g.f.hasOwnProperty(_b) )
{
_a = g.f;
o.ap = true;
}
else
{
_a = _s && _s.hasOwnProperty(_b) ? 
s : (_e && _e.hasOwnProperty(_b) ? e : undefined );
}
if( should_pass_type_info )
{
if( _a )
{
_ta = wh.hn(_a) === 'h';
_aa = _ta ? wh.rv( _a ) : _a;
_d = _aa[_b];
_td = wh.hn(_d) === 'h';
o.is_affected |= _ta || _td;
_d = _ta && !_td ? wh.nh(_d,'e') : _d;
return _d;
}
}
else
{
if( _a )
{
_ta = wh.hn(_a) === 'h';
_aa = _ta ? wh.rv( _a ) : _a;
_d = _aa[_b];
_td = wh.hn(_d) === 'h';
o.is_affected |= _ta || _td;
return wh.rv(_d);
}
}
return undefined;
}
break;
case 8: 
_a = {};
_a[ops[1]] = rev(ops[2],e,s,g,o,_f);
return _a;
break;
case 9: 
_a = rev(ops[1],e,s,g,o,_f);
_b = rev(ops[2],e,s,g,o,_f);
function merge( _a, _b, _ow )
{
var ka, _bbk;
_ta = wh.hn(_a)==='h';
_tb = wh.hn(_b)==='h';
_aa = wh.rv(_a);
_bb = wh.rv(_b);
for(var k in _bb)
{
if ( _ow || !_aa.hasOwnProperty(k) )
{
_aa[k] = should_pass_type_info ? (_tb ? wh.nh(_bb[k],'e') : _bb[k]) : wh.rv(_bb[k]);
}
}
return _a;
}
var _c = _a
var _ow = true
if ( typeof(ops[1][0]) === "object" && ops[1][0][0] === 10 ) {
_a = _b
_b = _c
_ow = false
}
if ( typeof(ops[1][0]) === "object" && ops[1][0][0] === 10 ) {
var _r = {}
return merge( merge( _r, _a, _ow ), _b, _ow );
}
else
return merge( _a, _b, _ow );
break;
case 10:
_a = rev(ops[1],e,s,g,o,_f);
_a = should_pass_type_info ? _a : wh.rv( _a );
return _a ;
break;
case 12:
var _r;
_a = rev(ops[1],e,s,g,o);
if ( !o.ap )
{
return should_pass_type_info && wh.hn(_a)==='h' ? wh.nh( _r, 'f' ) : _r;
}
var ap = o.ap;
_b = rev(ops[2],e,s,g,o,_f);
o.ap = ap;
_ta = wh.hn(_a)==='h';
_tb = _ca(_b);
_aa = wh.rv(_a);	
_bb = wh.rv(_b); snap_bb=$gdc(_bb,"nv_");
try{
_r = typeof _aa === "function" ? $gdc(_aa.apply(null, snap_bb)) : undefined;
} catch (e){
e.message = e.message.replace(/nv_/g,"");
e.stack = e.stack.substring(0,e.stack.indexOf("\n", e.stack.lastIndexOf("at nv_")));
e.stack = e.stack.replace(/\snv_/g," "); 
e.stack = $gstack(e.stack);	
if(g.debugInfo)
{
e.stack += "\n "+" "+" "+" at "+g.debugInfo[0]+":"+g.debugInfo[1]+":"+g.debugInfo[2];
console.error(e);
}
_r = undefined;
}
return should_pass_type_info && (_tb || _ta) ? wh.nh( _r, 'f' ) : _r;
}
}
else
{
if( op === 3 || op === 1) return ops[1];
else if( op === 11 ) 
{
var _a='';
for( var i = 1 ; i < ops.length ; i++ )
{
var xp = wh.rv(rev(ops[i],e,s,g,o,_f));
_a += typeof(xp) === 'undefined' ? '' : xp;
}
return _a;
}
}
}
function wrapper( ops, e, s, g, o, newap )
{
if( ops[0] == '11182016' )
{
g.debugInfo = ops[2];
return rev( ops[1], e, s, g, o, newap );
}
else
{
g.debugInfo = null;
return rev( ops, e, s, g, o, newap );
}
}
return wrapper;
}
gra=$gwrt(true); 
grb=$gwrt(false); 
function TestTest( expr, ops, e,s,g, expect_a, expect_b, expect_affected )
{
{
var o = {is_affected:false};
var a = gra( ops, e,s,g, o );
if( JSON.stringify(a) != JSON.stringify( expect_a )
|| o.is_affected != expect_affected )
{
console.warn( "A. " + expr + " get result " + JSON.stringify(a) + ", " + o.is_affected + ", but " + JSON.stringify( expect_a ) + ", " + expect_affected + " is expected" );
}
}
{
var o = {is_affected:false};
var a = grb( ops, e,s,g, o );
if( JSON.stringify(a) != JSON.stringify( expect_b )
|| o.is_affected != expect_affected )
{
console.warn( "B. " + expr + " get result " + JSON.stringify(a) + ", " + o.is_affected + ", but " + JSON.stringify( expect_b ) + ", " + expect_affected + " is expected" );
}
}
}

function wfor( to_iter, func, env, _s, global, father, itemname, indexname, keyname )
{
var _n = wh.hn( to_iter ) === 'n'; 
var scope = wh.rv( _s ); 
var has_old_item = scope.hasOwnProperty(itemname);
var has_old_index = scope.hasOwnProperty(indexname);
var old_item = scope[itemname];
var old_index = scope[indexname];
var full = Object.prototype.toString.call(wh.rv(to_iter));
var type = full[8]; 
if( type === 'N' && full[10] === 'l' ) type = 'X'; 
var _y;
if( _n )
{
if( type === 'A' ) 
{
var r_iter_item;
for( var i = 0 ; i < to_iter.length ; i++ )
{
scope[itemname] = to_iter[i];
scope[indexname] = _n ? i : wh.nh(i, 'h');
r_iter_item = wh.rv(to_iter[i]);
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'O' ) 
{
var i = 0;
var r_iter_item;
for( var k in to_iter )
{
scope[itemname] = to_iter[k];
scope[indexname] = _n ? k : wh.nh(k, 'h');
r_iter_item = wh.rv(to_iter[k]);
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env,scope,_y,global );
i++;
}
}
else if( type === 'S' ) 
{
for( var i = 0 ; i < to_iter.length ; i++ )
{
scope[itemname] = to_iter[i];
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( to_iter[i] + i );
_(father,_y);
func( env,scope,_y,global );
}
}
else if( type === 'N' ) 
{
for( var i = 0 ; i < to_iter ; i++ )
{
scope[itemname] = i;
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( i );
_(father,_y);
func(env,scope,_y,global);
}
}
else
{
}
}
else
{
var r_to_iter = wh.rv(to_iter);
var r_iter_item, iter_item;
if( type === 'A' ) 
{
for( var i = 0 ; i < r_to_iter.length ; i++ )
{
iter_item = r_to_iter[i];
iter_item = wh.hn(iter_item)==='n' ? wh.nh(iter_item,'h') : iter_item;
r_iter_item = wh.rv( iter_item );
scope[itemname] = iter_item
scope[indexname] = _n ? i : wh.nh(i, 'h');
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'O' ) 
{
var i=0;
for( var k in r_to_iter )
{
iter_item = r_to_iter[k];
iter_item = wh.hn(iter_item)==='n'? wh.nh(iter_item,'h') : iter_item;
r_iter_item = wh.rv( iter_item );
scope[itemname] = iter_item;
scope[indexname] = _n ? k : wh.nh(k, 'h');
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y=_v(key);
_(father,_y);
func( env, scope, _y, global );
i++
}
}
else if( type === 'S' ) 
{
for( var i = 0 ; i < r_to_iter.length ; i++ )
{
iter_item = wh.nh(r_to_iter[i],'h');
scope[itemname] = iter_item;
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( to_iter[i] + i );
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'N' ) 
{
for( var i = 0 ; i < r_to_iter ; i++ )
{
iter_item = wh.nh(i,'h');
scope[itemname] = iter_item;
scope[indexname]= _n ? i : wh.nh(i,'h');
_y = _v( i );
_(father,_y);
func(env,scope,_y,global);
}
}
else
{
}
}
if(has_old_item)
{
scope[itemname]=old_item;
}
else
{
delete scope[itemname];
}
if(has_old_index)
{
scope[indexname]=old_index;
}
else
{
delete scope[indexname];
}
}

function _ca(o)
{ 
if ( wh.hn(o) == 'h' ) return true;
if ( typeof o !== "object" ) return false;
for(var i in o){ 
if ( o.hasOwnProperty(i) ){
if (_ca(o[i])) return true;
}
}
return false;
}
function _da( node, attrname, opindex, raw, o )
{
var isaffected = false;
var value = $gdc( raw, "", 2 );
if ( o.ap && value && value.constructor===Function ) 
{
attrname = "$wxs:" + attrname; 
node.attr["$gdc"] = $gdc;
}
if ( o.is_affected || _ca(raw) ) 
{
node.n.push( attrname );
node.raw[attrname] = raw;
}
node.attr[attrname] = value;
}
function _r( node, attrname, opindex, env, scope, global ) 
{
global.opindex=opindex;
var o = {}, _env;
var a = grb( z[opindex], env, scope, global, o );
_da( node, attrname, opindex, a, o );
}
function _rz( z, node, attrname, opindex, env, scope, global ) 
{
global.opindex=opindex;
var o = {}, _env;
var a = grb( z[opindex], env, scope, global, o );
_da( node, attrname, opindex, a, o );
}
function _o( opindex, env, scope, global )
{
global.opindex=opindex;
var nothing = {};
var r = grb( z[opindex], env, scope, global, nothing );
return (r&&r.constructor===Function) ? undefined : r;
}
function _oz( z, opindex, env, scope, global )
{
global.opindex=opindex;
var nothing = {};
var r = grb( z[opindex], env, scope, global, nothing );
return (r&&r.constructor===Function) ? undefined : r;
}
function _1( opindex, env, scope, global, o )
{
var o = o || {};
global.opindex=opindex;
return gra( z[opindex], env, scope, global, o );
}
function _1z( z, opindex, env, scope, global, o )
{
var o = o || {};
global.opindex=opindex;
return gra( z[opindex], env, scope, global, o );
}
function _2( opindex, func, env, scope, global, father, itemname, indexname, keyname )
{
var o = {};
var to_iter = _1( opindex, env, scope, global );
wfor( to_iter, func, env, scope, global, father, itemname, indexname, keyname );
}
function _2z( z, opindex, func, env, scope, global, father, itemname, indexname, keyname )
{
var o = {};
var to_iter = _1z( z, opindex, env, scope, global );
wfor( to_iter, func, env, scope, global, father, itemname, indexname, keyname );
}


function _m(tag,attrs,generics,env,scope,global)
{
var tmp=_n(tag);
var base=0;
for(var i = 0 ; i < attrs.length ; i+=2 )
{
if(base+attrs[i+1]<0)
{
tmp.attr[attrs[i]]=true;
}
else
{
_r(tmp,attrs[i],base+attrs[i+1],env,scope,global);
if(base===0)base=attrs[i+1];
}
}
for(var i=0;i<generics.length;i+=2)
{
if(base+generics[i+1]<0)
{
tmp.generics[generics[i]]="";
}
else
{
var $t=grb(z[base+generics[i+1]],env,scope,global);
if ($t!="") $t="wx-"+$t;
tmp.generics[generics[i]]=$t;
if(base===0)base=generics[i+1];
}
}
return tmp;
}
function _mz(z,tag,attrs,generics,env,scope,global)
{
var tmp=_n(tag);
var base=0;
for(var i = 0 ; i < attrs.length ; i+=2 )
{
if(base+attrs[i+1]<0)
{
tmp.attr[attrs[i]]=true;
}
else
{
_rz(z, tmp,attrs[i],base+attrs[i+1],env,scope,global);
if(base===0)base=attrs[i+1];
}
}
for(var i=0;i<generics.length;i+=2)
{
if(base+generics[i+1]<0)
{
tmp.generics[generics[i]]="";
}
else
{
var $t=grb(z[base+generics[i+1]],env,scope,global);
if ($t!="") $t="wx-"+$t;
tmp.generics[generics[i]]=$t;
if(base===0)base=generics[i+1];
}
}
return tmp;
}

var nf_init=function(){
if(typeof __WXML_GLOBAL__==="undefined"||undefined===__WXML_GLOBAL__.wxs_nf_init){
nf_init_Object();nf_init_Function();nf_init_Array();nf_init_String();nf_init_Boolean();nf_init_Number();nf_init_Math();nf_init_Date();nf_init_RegExp();
}
if(typeof __WXML_GLOBAL__!=="undefined") __WXML_GLOBAL__.wxs_nf_init=true;
};
var nf_init_Object=function(){
Object.defineProperty(Object.prototype,"nv_constructor",{writable:true,value:"Object"})
Object.defineProperty(Object.prototype,"nv_toString",{writable:true,value:function(){return "[object Object]"}})
}
var nf_init_Function=function(){
Object.defineProperty(Function.prototype,"nv_constructor",{writable:true,value:"Function"})
Object.defineProperty(Function.prototype,"nv_length",{get:function(){return this.length;},set:function(){}});
Object.defineProperty(Function.prototype,"nv_toString",{writable:true,value:function(){return "[function Function]"}})
}
var nf_init_Array=function(){
Object.defineProperty(Array.prototype,"nv_toString",{writable:true,value:function(){return this.nv_join();}})
Object.defineProperty(Array.prototype,"nv_join",{writable:true,value:function(s){
s=undefined==s?',':s;
var r="";
for(var i=0;i<this.length;++i){
if(0!=i) r+=s;
if(null==this[i]||undefined==this[i]) r+='';	
else if(typeof this[i]=='function') r+=this[i].nv_toString();
else if(typeof this[i]=='object'&&this[i].nv_constructor==="Array") r+=this[i].nv_join();
else r+=this[i].toString();
}
return r;
}})
Object.defineProperty(Array.prototype,"nv_constructor",{writable:true,value:"Array"})
Object.defineProperty(Array.prototype,"nv_concat",{writable:true,value:Array.prototype.concat})
Object.defineProperty(Array.prototype,"nv_pop",{writable:true,value:Array.prototype.pop})
Object.defineProperty(Array.prototype,"nv_push",{writable:true,value:Array.prototype.push})
Object.defineProperty(Array.prototype,"nv_reverse",{writable:true,value:Array.prototype.reverse})
Object.defineProperty(Array.prototype,"nv_shift",{writable:true,value:Array.prototype.shift})
Object.defineProperty(Array.prototype,"nv_slice",{writable:true,value:Array.prototype.slice})
Object.defineProperty(Array.prototype,"nv_sort",{writable:true,value:Array.prototype.sort})
Object.defineProperty(Array.prototype,"nv_splice",{writable:true,value:Array.prototype.splice})
Object.defineProperty(Array.prototype,"nv_unshift",{writable:true,value:Array.prototype.unshift})
Object.defineProperty(Array.prototype,"nv_indexOf",{writable:true,value:Array.prototype.indexOf})
Object.defineProperty(Array.prototype,"nv_lastIndexOf",{writable:true,value:Array.prototype.lastIndexOf})
Object.defineProperty(Array.prototype,"nv_every",{writable:true,value:Array.prototype.every})
Object.defineProperty(Array.prototype,"nv_some",{writable:true,value:Array.prototype.some})
Object.defineProperty(Array.prototype,"nv_forEach",{writable:true,value:Array.prototype.forEach})
Object.defineProperty(Array.prototype,"nv_map",{writable:true,value:Array.prototype.map})
Object.defineProperty(Array.prototype,"nv_filter",{writable:true,value:Array.prototype.filter})
Object.defineProperty(Array.prototype,"nv_reduce",{writable:true,value:Array.prototype.reduce})
Object.defineProperty(Array.prototype,"nv_reduceRight",{writable:true,value:Array.prototype.reduceRight})
Object.defineProperty(Array.prototype,"nv_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
}
var nf_init_String=function(){
Object.defineProperty(String.prototype,"nv_constructor",{writable:true,value:"String"})
Object.defineProperty(String.prototype,"nv_toString",{writable:true,value:String.prototype.toString})
Object.defineProperty(String.prototype,"nv_valueOf",{writable:true,value:String.prototype.valueOf})
Object.defineProperty(String.prototype,"nv_charAt",{writable:true,value:String.prototype.charAt})
Object.defineProperty(String.prototype,"nv_charCodeAt",{writable:true,value:String.prototype.charCodeAt})
Object.defineProperty(String.prototype,"nv_concat",{writable:true,value:String.prototype.concat})
Object.defineProperty(String.prototype,"nv_indexOf",{writable:true,value:String.prototype.indexOf})
Object.defineProperty(String.prototype,"nv_lastIndexOf",{writable:true,value:String.prototype.lastIndexOf})
Object.defineProperty(String.prototype,"nv_localeCompare",{writable:true,value:String.prototype.localeCompare})
Object.defineProperty(String.prototype,"nv_match",{writable:true,value:String.prototype.match})
Object.defineProperty(String.prototype,"nv_replace",{writable:true,value:String.prototype.replace})
Object.defineProperty(String.prototype,"nv_search",{writable:true,value:String.prototype.search})
Object.defineProperty(String.prototype,"nv_slice",{writable:true,value:String.prototype.slice})
Object.defineProperty(String.prototype,"nv_split",{writable:true,value:String.prototype.split})
Object.defineProperty(String.prototype,"nv_substring",{writable:true,value:String.prototype.substring})
Object.defineProperty(String.prototype,"nv_toLowerCase",{writable:true,value:String.prototype.toLowerCase})
Object.defineProperty(String.prototype,"nv_toLocaleLowerCase",{writable:true,value:String.prototype.toLocaleLowerCase})
Object.defineProperty(String.prototype,"nv_toUpperCase",{writable:true,value:String.prototype.toUpperCase})
Object.defineProperty(String.prototype,"nv_toLocaleUpperCase",{writable:true,value:String.prototype.toLocaleUpperCase})
Object.defineProperty(String.prototype,"nv_trim",{writable:true,value:String.prototype.trim})
Object.defineProperty(String.prototype,"nv_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
}
var nf_init_Boolean=function(){
Object.defineProperty(Boolean.prototype,"nv_constructor",{writable:true,value:"Boolean"})
Object.defineProperty(Boolean.prototype,"nv_toString",{writable:true,value:Boolean.prototype.toString})
Object.defineProperty(Boolean.prototype,"nv_valueOf",{writable:true,value:Boolean.prototype.valueOf})
}
var nf_init_Number=function(){
Object.defineProperty(Number,"nv_MAX_VALUE",{writable:false,value:Number.MAX_VALUE})
Object.defineProperty(Number,"nv_MIN_VALUE",{writable:false,value:Number.MIN_VALUE})
Object.defineProperty(Number,"nv_NEGATIVE_INFINITY",{writable:false,value:Number.NEGATIVE_INFINITY})
Object.defineProperty(Number,"nv_POSITIVE_INFINITY",{writable:false,value:Number.POSITIVE_INFINITY})
Object.defineProperty(Number.prototype,"nv_constructor",{writable:true,value:"Number"})
Object.defineProperty(Number.prototype,"nv_toString",{writable:true,value:Number.prototype.toString})
Object.defineProperty(Number.prototype,"nv_toLocaleString",{writable:true,value:Number.prototype.toLocaleString})
Object.defineProperty(Number.prototype,"nv_valueOf",{writable:true,value:Number.prototype.valueOf})
Object.defineProperty(Number.prototype,"nv_toFixed",{writable:true,value:Number.prototype.toFixed})
Object.defineProperty(Number.prototype,"nv_toExponential",{writable:true,value:Number.prototype.toExponential})
Object.defineProperty(Number.prototype,"nv_toPrecision",{writable:true,value:Number.prototype.toPrecision})
}
var nf_init_Math=function(){
Object.defineProperty(Math,"nv_E",{writable:false,value:Math.E})
Object.defineProperty(Math,"nv_LN10",{writable:false,value:Math.LN10})
Object.defineProperty(Math,"nv_LN2",{writable:false,value:Math.LN2})
Object.defineProperty(Math,"nv_LOG2E",{writable:false,value:Math.LOG2E})
Object.defineProperty(Math,"nv_LOG10E",{writable:false,value:Math.LOG10E})
Object.defineProperty(Math,"nv_PI",{writable:false,value:Math.PI})
Object.defineProperty(Math,"nv_SQRT1_2",{writable:false,value:Math.SQRT1_2})
Object.defineProperty(Math,"nv_SQRT2",{writable:false,value:Math.SQRT2})
Object.defineProperty(Math,"nv_abs",{writable:false,value:Math.abs})
Object.defineProperty(Math,"nv_acos",{writable:false,value:Math.acos})
Object.defineProperty(Math,"nv_asin",{writable:false,value:Math.asin})
Object.defineProperty(Math,"nv_atan",{writable:false,value:Math.atan})
Object.defineProperty(Math,"nv_atan2",{writable:false,value:Math.atan2})
Object.defineProperty(Math,"nv_ceil",{writable:false,value:Math.ceil})
Object.defineProperty(Math,"nv_cos",{writable:false,value:Math.cos})
Object.defineProperty(Math,"nv_exp",{writable:false,value:Math.exp})
Object.defineProperty(Math,"nv_floor",{writable:false,value:Math.floor})
Object.defineProperty(Math,"nv_log",{writable:false,value:Math.log})
Object.defineProperty(Math,"nv_max",{writable:false,value:Math.max})
Object.defineProperty(Math,"nv_min",{writable:false,value:Math.min})
Object.defineProperty(Math,"nv_pow",{writable:false,value:Math.pow})
Object.defineProperty(Math,"nv_random",{writable:false,value:Math.random})
Object.defineProperty(Math,"nv_round",{writable:false,value:Math.round})
Object.defineProperty(Math,"nv_sin",{writable:false,value:Math.sin})
Object.defineProperty(Math,"nv_sqrt",{writable:false,value:Math.sqrt})
Object.defineProperty(Math,"nv_tan",{writable:false,value:Math.tan})
}
var nf_init_Date=function(){
Object.defineProperty(Date.prototype,"nv_constructor",{writable:true,value:"Date"})
Object.defineProperty(Date,"nv_parse",{writable:true,value:Date.parse})
Object.defineProperty(Date,"nv_UTC",{writable:true,value:Date.UTC})
Object.defineProperty(Date,"nv_now",{writable:true,value:Date.now})
Object.defineProperty(Date.prototype,"nv_toString",{writable:true,value:Date.prototype.toString})
Object.defineProperty(Date.prototype,"nv_toDateString",{writable:true,value:Date.prototype.toDateString})
Object.defineProperty(Date.prototype,"nv_toTimeString",{writable:true,value:Date.prototype.toTimeString})
Object.defineProperty(Date.prototype,"nv_toLocaleString",{writable:true,value:Date.prototype.toLocaleString})
Object.defineProperty(Date.prototype,"nv_toLocaleDateString",{writable:true,value:Date.prototype.toLocaleDateString})
Object.defineProperty(Date.prototype,"nv_toLocaleTimeString",{writable:true,value:Date.prototype.toLocaleTimeString})
Object.defineProperty(Date.prototype,"nv_valueOf",{writable:true,value:Date.prototype.valueOf})
Object.defineProperty(Date.prototype,"nv_getTime",{writable:true,value:Date.prototype.getTime})
Object.defineProperty(Date.prototype,"nv_getFullYear",{writable:true,value:Date.prototype.getFullYear})
Object.defineProperty(Date.prototype,"nv_getUTCFullYear",{writable:true,value:Date.prototype.getUTCFullYear})
Object.defineProperty(Date.prototype,"nv_getMonth",{writable:true,value:Date.prototype.getMonth})
Object.defineProperty(Date.prototype,"nv_getUTCMonth",{writable:true,value:Date.prototype.getUTCMonth})
Object.defineProperty(Date.prototype,"nv_getDate",{writable:true,value:Date.prototype.getDate})
Object.defineProperty(Date.prototype,"nv_getUTCDate",{writable:true,value:Date.prototype.getUTCDate})
Object.defineProperty(Date.prototype,"nv_getDay",{writable:true,value:Date.prototype.getDay})
Object.defineProperty(Date.prototype,"nv_getUTCDay",{writable:true,value:Date.prototype.getUTCDay})
Object.defineProperty(Date.prototype,"nv_getHours",{writable:true,value:Date.prototype.getHours})
Object.defineProperty(Date.prototype,"nv_getUTCHours",{writable:true,value:Date.prototype.getUTCHours})
Object.defineProperty(Date.prototype,"nv_getMinutes",{writable:true,value:Date.prototype.getMinutes})
Object.defineProperty(Date.prototype,"nv_getUTCMinutes",{writable:true,value:Date.prototype.getUTCMinutes})
Object.defineProperty(Date.prototype,"nv_getSeconds",{writable:true,value:Date.prototype.getSeconds})
Object.defineProperty(Date.prototype,"nv_getUTCSeconds",{writable:true,value:Date.prototype.getUTCSeconds})
Object.defineProperty(Date.prototype,"nv_getMilliseconds",{writable:true,value:Date.prototype.getMilliseconds})
Object.defineProperty(Date.prototype,"nv_getUTCMilliseconds",{writable:true,value:Date.prototype.getUTCMilliseconds})
Object.defineProperty(Date.prototype,"nv_getTimezoneOffset",{writable:true,value:Date.prototype.getTimezoneOffset})
Object.defineProperty(Date.prototype,"nv_setTime",{writable:true,value:Date.prototype.setTime})
Object.defineProperty(Date.prototype,"nv_setMilliseconds",{writable:true,value:Date.prototype.setMilliseconds})
Object.defineProperty(Date.prototype,"nv_setUTCMilliseconds",{writable:true,value:Date.prototype.setUTCMilliseconds})
Object.defineProperty(Date.prototype,"nv_setSeconds",{writable:true,value:Date.prototype.setSeconds})
Object.defineProperty(Date.prototype,"nv_setUTCSeconds",{writable:true,value:Date.prototype.setUTCSeconds})
Object.defineProperty(Date.prototype,"nv_setMinutes",{writable:true,value:Date.prototype.setMinutes})
Object.defineProperty(Date.prototype,"nv_setUTCMinutes",{writable:true,value:Date.prototype.setUTCMinutes})
Object.defineProperty(Date.prototype,"nv_setHours",{writable:true,value:Date.prototype.setHours})
Object.defineProperty(Date.prototype,"nv_setUTCHours",{writable:true,value:Date.prototype.setUTCHours})
Object.defineProperty(Date.prototype,"nv_setDate",{writable:true,value:Date.prototype.setDate})
Object.defineProperty(Date.prototype,"nv_setUTCDate",{writable:true,value:Date.prototype.setUTCDate})
Object.defineProperty(Date.prototype,"nv_setMonth",{writable:true,value:Date.prototype.setMonth})
Object.defineProperty(Date.prototype,"nv_setUTCMonth",{writable:true,value:Date.prototype.setUTCMonth})
Object.defineProperty(Date.prototype,"nv_setFullYear",{writable:true,value:Date.prototype.setFullYear})
Object.defineProperty(Date.prototype,"nv_setUTCFullYear",{writable:true,value:Date.prototype.setUTCFullYear})
Object.defineProperty(Date.prototype,"nv_toUTCString",{writable:true,value:Date.prototype.toUTCString})
Object.defineProperty(Date.prototype,"nv_toISOString",{writable:true,value:Date.prototype.toISOString})
Object.defineProperty(Date.prototype,"nv_toJSON",{writable:true,value:Date.prototype.toJSON})
}
var nf_init_RegExp=function(){
Object.defineProperty(RegExp.prototype,"nv_constructor",{writable:true,value:"RegExp"})
Object.defineProperty(RegExp.prototype,"nv_exec",{writable:true,value:RegExp.prototype.exec})
Object.defineProperty(RegExp.prototype,"nv_test",{writable:true,value:RegExp.prototype.test})
Object.defineProperty(RegExp.prototype,"nv_toString",{writable:true,value:RegExp.prototype.toString})
Object.defineProperty(RegExp.prototype,"nv_source",{get:function(){return this.source;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_global",{get:function(){return this.global;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_ignoreCase",{get:function(){return this.ignoreCase;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_multiline",{get:function(){return this.multiline;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_lastIndex",{get:function(){return this.lastIndex;},set:function(v){this.lastIndex=v;}});
}
nf_init();
var nv_getDate=function(){var args=Array.prototype.slice.call(arguments);args.unshift(Date);return new(Function.prototype.bind.apply(Date, args));}
var nv_getRegExp=function(){var args=Array.prototype.slice.call(arguments);args.unshift(RegExp);return new(Function.prototype.bind.apply(RegExp, args));}
var nv_console={}
nv_console.nv_log=function(){var res="WXSRT:";for(var i=0;i<arguments.length;++i)res+=arguments[i]+" ";console.log(res);}
var nv_parseInt = parseInt, nv_parseFloat = parseFloat, nv_isNaN = isNaN, nv_isFinite = isFinite, nv_decodeURI = decodeURI, nv_decodeURIComponent = decodeURIComponent, nv_encodeURI = encodeURI, nv_encodeURIComponent = encodeURIComponent;
function $gdc(o,p,r) {
o=wh.rv(o);
if(o===null||o===undefined) return o;
if(o.constructor===String||o.constructor===Boolean||o.constructor===Number) return o;
if(o.constructor===Object){
var copy={};
for(var k in o)
if(o.hasOwnProperty(k))
if(undefined===p) copy[k.substring(3)]=$gdc(o[k],p,r);
else copy[p+k]=$gdc(o[k],p,r);
return copy;
}
if(o.constructor===Array){
var copy=[];
for(var i=0;i<o.length;i++) copy.push($gdc(o[i],p,r));
return copy;
}
if(o.constructor===Date){
var copy=new Date();
copy.setTime(o.getTime());
return copy;
}
if(o.constructor===RegExp){
var f="";
if(o.global) f+="g";
if(o.ignoreCase) f+="i";
if(o.multiline) f+="m";
return (new RegExp(o.source,f));
}
if(r&&o.constructor===Function){
if ( r == 1 ) return $gdc(o(),undefined, 2);
if ( r == 2 ) return o;
}
return null;
}
var nv_JSON={}
nv_JSON.nv_stringify=function(o){
JSON.stringify(o);
return JSON.stringify($gdc(o));
}
nv_JSON.nv_parse=function(o){
if(o===undefined) return undefined;
var t=JSON.parse(o);
return $gdc(t,'nv_');
}

function _af(p, a, r, c){
p.extraAttr = {"t_action": a, "t_rawid": r };
if ( typeof(c) != 'undefined' ) p.extraAttr.t_cid = c;
}

function _ai(i,p,e,me,r,c){var x=_grp(p,e,me);if(x)i.push(x);else{i.push('');_wp(me+':import:'+r+':'+c+': Path `'+p+'` not found from `'+me+'`.')}}
function _grp(p,e,me){if(p[0]!='/'){var mepart=me.split('/');mepart.pop();var ppart=p.split('/');for(var i=0;i<ppart.length;i++){if( ppart[i]=='..')mepart.pop();else if(!ppart[i]||ppart[i]=='.')continue;else mepart.push(ppart[i]);}p=mepart.join('/');}if(me[0]=='.'&&p[0]=='/')p='.'+p;if(e[p])return p;if(e[p+'.wxml'])return p+'.wxml';}
function _gd(p,c,e,d){if(!c)return;if(d[p][c])return d[p][c];for(var x=e[p].i.length-1;x>=0;x--){if(e[p].i[x]&&d[e[p].i[x]][c])return d[e[p].i[x]][c]};for(var x=e[p].ti.length-1;x>=0;x--){var q=_grp(e[p].ti[x],e,p);if(q&&d[q][c])return d[q][c]}var ii=_gapi(e,p);for(var x=0;x<ii.length;x++){if(ii[x]&&d[ii[x]][c])return d[ii[x]][c]}for(var k=e[p].j.length-1;k>=0;k--)if(e[p].j[k]){for(var q=e[e[p].j[k]].ti.length-1;q>=0;q--){var pp=_grp(e[e[p].j[k]].ti[q],e,p);if(pp&&d[pp][c]){return d[pp][c]}}}}
function _gapi(e,p){if(!p)return [];if($gaic[p]){return $gaic[p]};var ret=[],q=[],h=0,t=0,put={},visited={};q.push(p);visited[p]=true;t++;while(h<t){var a=q[h++];for(var i=0;i<e[a].ic.length;i++){var nd=e[a].ic[i];var np=_grp(nd,e,a);if(np&&!visited[np]){visited[np]=true;q.push(np);t++;}}for(var i=0;a!=p&&i<e[a].ti.length;i++){var ni=e[a].ti[i];var nm=_grp(ni,e,a);if(nm&&!put[nm]){put[nm]=true;ret.push(nm);}}}$gaic[p]=ret;return ret;}
var $ixc={};function _ic(p,ent,me,e,s,r,gg){var x=_grp(p,ent,me);ent[me].j.push(x);if(x){if($ixc[x]){_wp('-1:include:-1:-1: `'+p+'` is being included in a loop, will be stop.');return;}$ixc[x]=true;try{ent[x].f(e,s,r,gg)}catch(e){}$ixc[x]=false;}else{_wp(me+':include:-1:-1: Included path `'+p+'` not found from `'+me+'`.')}}
function _w(tn,f,line,c){_wp(f+':template:'+line+':'+c+': Template `'+tn+'` not found.');}function _ev(dom){var changed=false;delete dom.properities;delete dom.n;if(dom.children){do{changed=false;var newch = [];for(var i=0;i<dom.children.length;i++){var ch=dom.children[i];if( ch.tag=='virtual'){changed=true;for(var j=0;ch.children&&j<ch.children.length;j++){newch.push(ch.children[j]);}}else { newch.push(ch); } } dom.children = newch; }while(changed);for(var i=0;i<dom.children.length;i++){_ev(dom.children[i]);}} return dom; }
function _tsd( root )
{
if( root.tag == "wx-wx-scope" ) 
{
root.tag = "virtual";
root.wxCkey = "11";
root['wxScopeData'] = root.attr['wx:scope-data'];
delete root.n;
delete root.raw;
delete root.generics;
delete root.attr;
}
for( var i = 0 ; root.children && i < root.children.length ; i++ )
{
_tsd( root.children[i] );
}
return root;
}

var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx3 || [];
function gz$gwx3_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx3_1)return __WXML_GLOBAL__.ops_cached.$gwx3_1
__WXML_GLOBAL__.ops_cached.$gwx3_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'$taroCompReady']])
})(__WXML_GLOBAL__.ops_cached.$gwx3_1);return __WXML_GLOBAL__.ops_cached.$gwx3_1
}
function gz$gwx3_2(){
if( __WXML_GLOBAL__.ops_cached.$gwx3_2)return __WXML_GLOBAL__.ops_cached.$gwx3_2
__WXML_GLOBAL__.ops_cached.$gwx3_2=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'$taroCompReady']])
})(__WXML_GLOBAL__.ops_cached.$gwx3_2);return __WXML_GLOBAL__.ops_cached.$gwx3_2
}
function gz$gwx3_3(){
if( __WXML_GLOBAL__.ops_cached.$gwx3_3)return __WXML_GLOBAL__.ops_cached.$gwx3_3
__WXML_GLOBAL__.ops_cached.$gwx3_3=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'$taroCompReady']])
Z([[7],[3,'require']])
})(__WXML_GLOBAL__.ops_cached.$gwx3_3);return __WXML_GLOBAL__.ops_cached.$gwx3_3
}
function gz$gwx3_4(){
if( __WXML_GLOBAL__.ops_cached.$gwx3_4)return __WXML_GLOBAL__.ops_cached.$gwx3_4
__WXML_GLOBAL__.ops_cached.$gwx3_4=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'$taroCompReady']])
})(__WXML_GLOBAL__.ops_cached.$gwx3_4);return __WXML_GLOBAL__.ops_cached.$gwx3_4
}
function gz$gwx3_5(){
if( __WXML_GLOBAL__.ops_cached.$gwx3_5)return __WXML_GLOBAL__.ops_cached.$gwx3_5
__WXML_GLOBAL__.ops_cached.$gwx3_5=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'$taroCompReady']])
Z([[7],[3,'count']])
})(__WXML_GLOBAL__.ops_cached.$gwx3_5);return __WXML_GLOBAL__.ops_cached.$gwx3_5
}
function gz$gwx3_6(){
if( __WXML_GLOBAL__.ops_cached.$gwx3_6)return __WXML_GLOBAL__.ops_cached.$gwx3_6
__WXML_GLOBAL__.ops_cached.$gwx3_6=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'$taroCompReady']])
})(__WXML_GLOBAL__.ops_cached.$gwx3_6);return __WXML_GLOBAL__.ops_cached.$gwx3_6
}
function gz$gwx3_7(){
if( __WXML_GLOBAL__.ops_cached.$gwx3_7)return __WXML_GLOBAL__.ops_cached.$gwx3_7
__WXML_GLOBAL__.ops_cached.$gwx3_7=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'$taroCompReady']])
Z([3,'fault'])
Z([[7],[3,'$compid__21']])
Z([3,'form-item'])
Z([[7],[3,'$compid__22']])
Z([[7],[3,'$compid__23']])
Z(z[3])
Z([[7],[3,'$compid__24']])
Z([[7],[3,'$compid__25']])
Z(z[3])
Z([[7],[3,'$compid__26']])
Z([[7],[3,'$compid__27']])
})(__WXML_GLOBAL__.ops_cached.$gwx3_7);return __WXML_GLOBAL__.ops_cached.$gwx3_7
}
function gz$gwx3_8(){
if( __WXML_GLOBAL__.ops_cached.$gwx3_8)return __WXML_GLOBAL__.ops_cached.$gwx3_8
__WXML_GLOBAL__.ops_cached.$gwx3_8=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'$taroCompReady']])
Z([[6],[[7],[3,'userInfo']],[3,'censoredCellphone']])
})(__WXML_GLOBAL__.ops_cached.$gwx3_8);return __WXML_GLOBAL__.ops_cached.$gwx3_8
}
function gz$gwx3_9(){
if( __WXML_GLOBAL__.ops_cached.$gwx3_9)return __WXML_GLOBAL__.ops_cached.$gwx3_9
__WXML_GLOBAL__.ops_cached.$gwx3_9=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'$taroCompReady']])
Z([3,'question'])
Z([[7],[3,'$compid__18']])
Z([[6],[[6],[[7],[3,'questionList']],[[7],[3,'activeCategory']]],[3,'helps']])
Z([[7],[3,'anonymousState__temp13']])
Z([[7],[3,'$compid__19']])
Z([3,'server-btn'])
Z([[7],[3,'$compid__20']])
Z(z[6])
})(__WXML_GLOBAL__.ops_cached.$gwx3_9);return __WXML_GLOBAL__.ops_cached.$gwx3_9
}
function gz$gwx3_10(){
if( __WXML_GLOBAL__.ops_cached.$gwx3_10)return __WXML_GLOBAL__.ops_cached.$gwx3_10
__WXML_GLOBAL__.ops_cached.$gwx3_10=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'$taroCompReady']])
})(__WXML_GLOBAL__.ops_cached.$gwx3_10);return __WXML_GLOBAL__.ops_cached.$gwx3_10
}
__WXML_GLOBAL__.ops_set.$gwx3=z;
__WXML_GLOBAL__.ops_init.$gwx3=true;
var nv_require=function(){var nnm={};var nom={};return function(n){return function(){if(!nnm[n]) return undefined;try{if(!nom[n])nom[n]=nnm[n]();return nom[n];}catch(e){e.message=e.message.replace(/nv_/g,'');var tmp = e.stack.substring(0,e.stack.lastIndexOf(n));e.stack = tmp.substring(0,tmp.lastIndexOf('\n'));e.stack = e.stack.replace(/\snv_/g,' ');e.stack = $gstack(e.stack);e.stack += '\n    at ' + n.substring(2);console.error(e);}
}}}()
var x=['./package-help/components/contact/index.wxml','./package-help/components/image-picker/image-picker.wxml','./package-help/components/my-label/my-label.wxml','./package-help/components/my-picker/my-picker.wxml','./package-help/components/my-textarea/my-textarea.wxml','./package-help/pages/debug/debug.wxml','./package-help/pages/fault/fault.wxml','./package-help/pages/my/my.wxml','./package-help/pages/question/question.wxml','./package-help/pages/use-tips/use-tips.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx3_1()
var oB=_v()
_(r,oB)
if(_oz(z,0,e,s,gg)){oB.wxVkey=1
}
oB.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
d_[x[1]]={}
var m1=function(e,s,r,gg){
var z=gz$gwx3_2()
var oD=_v()
_(r,oD)
if(_oz(z,0,e,s,gg)){oD.wxVkey=1
}
oD.wxXCkey=1
return r
}
e_[x[1]]={f:m1,j:[],i:[],ti:[],ic:[]}
d_[x[2]]={}
var m2=function(e,s,r,gg){
var z=gz$gwx3_3()
var cF=_v()
_(r,cF)
if(_oz(z,0,e,s,gg)){cF.wxVkey=1
var hG=_v()
_(cF,hG)
if(_oz(z,1,e,s,gg)){hG.wxVkey=1
}
hG.wxXCkey=1
}
cF.wxXCkey=1
return r
}
e_[x[2]]={f:m2,j:[],i:[],ti:[],ic:[]}
d_[x[3]]={}
var m3=function(e,s,r,gg){
var z=gz$gwx3_4()
var cI=_v()
_(r,cI)
if(_oz(z,0,e,s,gg)){cI.wxVkey=1
}
cI.wxXCkey=1
return r
}
e_[x[3]]={f:m3,j:[],i:[],ti:[],ic:[]}
d_[x[4]]={}
var m4=function(e,s,r,gg){
var z=gz$gwx3_5()
var lK=_v()
_(r,lK)
if(_oz(z,0,e,s,gg)){lK.wxVkey=1
var aL=_v()
_(lK,aL)
if(_oz(z,1,e,s,gg)){aL.wxVkey=1
}
aL.wxXCkey=1
}
lK.wxXCkey=1
return r
}
e_[x[4]]={f:m4,j:[],i:[],ti:[],ic:[]}
d_[x[5]]={}
var m5=function(e,s,r,gg){
var z=gz$gwx3_6()
var eN=_v()
_(r,eN)
if(_oz(z,0,e,s,gg)){eN.wxVkey=1
}
eN.wxXCkey=1
return r
}
e_[x[5]]={f:m5,j:[],i:[],ti:[],ic:[]}
d_[x[6]]={}
var m6=function(e,s,r,gg){
var z=gz$gwx3_7()
var oP=_v()
_(r,oP)
if(_oz(z,0,e,s,gg)){oP.wxVkey=1
var xQ=_n('view')
_rz(z,xQ,'class',1,e,s,gg)
var oR=_n('x-label')
_rz(z,oR,'compid',2,e,s,gg)
_(xQ,oR)
var fS=_n('view')
_rz(z,fS,'class',3,e,s,gg)
var cT=_n('x-label')
_rz(z,cT,'compid',4,e,s,gg)
_(fS,cT)
var hU=_n('x-picker')
_rz(z,hU,'compid',5,e,s,gg)
_(fS,hU)
_(xQ,fS)
var oV=_n('view')
_rz(z,oV,'class',6,e,s,gg)
var cW=_n('x-label')
_rz(z,cW,'compid',7,e,s,gg)
_(oV,cW)
var oX=_n('x-textarea')
_rz(z,oX,'compid',8,e,s,gg)
_(oV,oX)
_(xQ,oV)
var lY=_n('view')
_rz(z,lY,'class',9,e,s,gg)
var aZ=_n('x-label')
_rz(z,aZ,'compid',10,e,s,gg)
_(lY,aZ)
var t1=_n('x-image-picker')
_rz(z,t1,'compid',11,e,s,gg)
_(lY,t1)
_(xQ,lY)
_(oP,xQ)
}
oP.wxXCkey=1
oP.wxXCkey=3
return r
}
e_[x[6]]={f:m6,j:[],i:[],ti:[],ic:[]}
d_[x[7]]={}
var m7=function(e,s,r,gg){
var z=gz$gwx3_8()
var b3=_v()
_(r,b3)
if(_oz(z,0,e,s,gg)){b3.wxVkey=1
var o4=_v()
_(b3,o4)
if(_oz(z,1,e,s,gg)){o4.wxVkey=1
}
o4.wxXCkey=1
}
b3.wxXCkey=1
return r
}
e_[x[7]]={f:m7,j:[],i:[],ti:[],ic:[]}
d_[x[8]]={}
var m8=function(e,s,r,gg){
var z=gz$gwx3_9()
var o6=_v()
_(r,o6)
if(_oz(z,0,e,s,gg)){o6.wxVkey=1
var f7=_n('view')
_rz(z,f7,'class',1,e,s,gg)
var h9=_n('x-title-tabs')
_rz(z,h9,'compid',2,e,s,gg)
_(f7,h9)
var c8=_v()
_(f7,c8)
if(_oz(z,3,e,s,gg)){c8.wxVkey=1
}
var o0=_n('view')
_rz(z,o0,'class',4,e,s,gg)
var cAB=_mz(z,'x-contact',['compid',5,'componentClass',1],[],e,s,gg)
_(o0,cAB)
var oBB=_mz(z,'x-contact',['compid',7,'componentClass',1],[],e,s,gg)
_(o0,oBB)
_(f7,o0)
c8.wxXCkey=1
_(o6,f7)
}
o6.wxXCkey=1
o6.wxXCkey=3
return r
}
e_[x[8]]={f:m8,j:[],i:[],ti:[],ic:[]}
d_[x[9]]={}
var m9=function(e,s,r,gg){
var z=gz$gwx3_10()
var aDB=_v()
_(r,aDB)
if(_oz(z,0,e,s,gg)){aDB.wxVkey=1
}
aDB.wxXCkey=1
return r
}
e_[x[9]]={f:m9,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
return root;
}
}
}
	__wxAppCode__['package-help/components/contact/index.json'] = {"component":true,"usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['package-help/components/contact/index.wxml'] = [$gwx3, './package-help/components/contact/index.wxml'];else __wxAppCode__['package-help/components/contact/index.wxml'] = $gwx3( './package-help/components/contact/index.wxml' );
		__wxAppCode__['package-help/components/image-picker/image-picker.json'] = {"component":true,"usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['package-help/components/image-picker/image-picker.wxml'] = [$gwx3, './package-help/components/image-picker/image-picker.wxml'];else __wxAppCode__['package-help/components/image-picker/image-picker.wxml'] = $gwx3( './package-help/components/image-picker/image-picker.wxml' );
		__wxAppCode__['package-help/components/my-label/my-label.json'] = {"component":true,"usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['package-help/components/my-label/my-label.wxml'] = [$gwx3, './package-help/components/my-label/my-label.wxml'];else __wxAppCode__['package-help/components/my-label/my-label.wxml'] = $gwx3( './package-help/components/my-label/my-label.wxml' );
		__wxAppCode__['package-help/components/my-picker/my-picker.json'] = {"component":true,"usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['package-help/components/my-picker/my-picker.wxml'] = [$gwx3, './package-help/components/my-picker/my-picker.wxml'];else __wxAppCode__['package-help/components/my-picker/my-picker.wxml'] = $gwx3( './package-help/components/my-picker/my-picker.wxml' );
		__wxAppCode__['package-help/components/my-textarea/my-textarea.json'] = {"component":true,"usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['package-help/components/my-textarea/my-textarea.wxml'] = [$gwx3, './package-help/components/my-textarea/my-textarea.wxml'];else __wxAppCode__['package-help/components/my-textarea/my-textarea.wxml'] = $gwx3( './package-help/components/my-textarea/my-textarea.wxml' );
		__wxAppCode__['package-help/pages/debug/debug.json'] = {"usingComponents":{},"navigationBarTitleText":"调试"};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['package-help/pages/debug/debug.wxml'] = [$gwx3, './package-help/pages/debug/debug.wxml'];else __wxAppCode__['package-help/pages/debug/debug.wxml'] = $gwx3( './package-help/pages/debug/debug.wxml' );
		__wxAppCode__['package-help/pages/fault/fault.json'] = {"usingComponents":{"x-label":"../../components/my-label/my-label","x-picker":"../../components/my-picker/my-picker","x-textarea":"../../components/my-textarea/my-textarea","x-image-picker":"../../components/image-picker/image-picker"},"navigationBarTitleText":"故障上报"};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['package-help/pages/fault/fault.wxml'] = [$gwx3, './package-help/pages/fault/fault.wxml'];else __wxAppCode__['package-help/pages/fault/fault.wxml'] = $gwx3( './package-help/pages/fault/fault.wxml' );
		__wxAppCode__['package-help/pages/my/my.json'] = {"usingComponents":{},"navigationBarTitleText":"个人中心"};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['package-help/pages/my/my.wxml'] = [$gwx3, './package-help/pages/my/my.wxml'];else __wxAppCode__['package-help/pages/my/my.wxml'] = $gwx3( './package-help/pages/my/my.wxml' );
		__wxAppCode__['package-help/pages/question/question.json'] = {"usingComponents":{"x-title-tabs":"../../../components/title-tabs/title-tabs","x-contact":"../../components/contact/index"},"navigationBarTitleText":"常见问题"};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['package-help/pages/question/question.wxml'] = [$gwx3, './package-help/pages/question/question.wxml'];else __wxAppCode__['package-help/pages/question/question.wxml'] = $gwx3( './package-help/pages/question/question.wxml' );
		__wxAppCode__['package-help/pages/use-tips/use-tips.json'] = {"usingComponents":{},"navigationBarTitleText":"使用技巧"};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['package-help/pages/use-tips/use-tips.wxml'] = [$gwx3, './package-help/pages/use-tips/use-tips.wxml'];else __wxAppCode__['package-help/pages/use-tips/use-tips.wxml'] = $gwx3( './package-help/pages/use-tips/use-tips.wxml' );
	
	define("package-help/pages/use-tips/tips.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
!function(){"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),exports.default=[{title:"如何充电",steps:[{title:"第一步",tips:[{isHighLight:0,content:"从图示处"},{isHighLight:1,content:"抽出充电线"},{isHighLight:0,content:"，请轻轻取出哦～"}],image:{isSingle:1,imgs:["https://images.wosaimg.com/25/bc3551aaf510c687aa91148e51f04fedd3ae15.png"]}},{title:"第二步",tips:[{isHighLight:1,content:"插上充电线"},{isHighLight:0,content:"，将手机与充电宝叠放"}],image:{isSingle:1,imgs:["https://images.wosaimg.com/56/632d63785108324b2e51c6f008ea6978ba3c8b.png"]}},{title:"第三步",tips:[{isHighLight:1,content:"按击侧面电源键"},{isHighLight:0,content:"，即刻开启充电哦~"}],image:{isSingle:1,imgs:["https://images.wosaimg.com/cc/921030a94146353785f3dd0f826913fd42f3da.png"]}}]},{title:"如何归还",steps:[{title:"第一步",tips:[{isHighLight:0,content:"进入小程序首页，查找并前往归还地点，寻找"},{isHighLight:1,content:"空卡槽"}],image:{isSingle:0,imgs:["https://images.wosaimg.com/f8/3c30d3fab151d6438b9952bbf5421d35085025.png","https://images.wosaimg.com/6b/d24f0e2b9914554d09fcc56e2e334cd93647da.png"]}},{title:"第二步",tips:[{isHighLight:0,content:"将充电宝插入"},{isHighLight:1,content:"空卡槽"},{isHighLight:0,content:"，确认充电宝锁住且不可取出后即完成归还 (多数有语音提示“归还成功，感谢您的使用”的哦)"}],image:{isSingle:0,imgs:["https://images.wosaimg.com/cc/16befdce01ec93b2b2d08c80d1617647da8e7c.png","https://images.wosaimg.com/2c/8bf8dc4b95dd7e2a7884d4735d786c1cd52761.png"]}},{title:"第三步",tips:[{isHighLight:0,content:"打开小程序"},{isHighLight:1,content:"手动支付费用或系统自动扣款"},{isHighLight:0,content:"，确认"},{isHighLight:1,content:"订单状态更新为已完成后"},{isHighLight:0,content:"即完成整个归还流程"}],image:{isSingle:1,imgs:["https://images.wosaimg.com/35/ee61434fdf3a9eff38a18c85a5a357ec7b89c8.png"]}}]}]}(); 
 			}); 
		__wxRoute = 'package-help/components/contact/index';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'package-help/components/contact/index.js';	define("package-help/components/contact/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
!function(){"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var e,t,n=function(){function e(e,t){for(var n=0;n<t.length;n++){var r=t[n];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}return function(t,n,r){return n&&e(t.prototype,n),r&&e(t,r),t}}(),r=u(require("../../../npm/@tarojs/taro-weapp/index.js")),o=u(require("../../../npm/classnames/index.js")),a=u(require("../../../components/base.js")),i=require("../../../api/index.js"),s=require("../../../utils/index.js");function u(e){return e&&e.__esModule?e:{default:e}}function c(e){return function(){var t=e.apply(this,arguments);return new Promise(function(e,n){return function r(o,a){try{var i=t[o](a),s=i.value}catch(o){return void n(o)}if(!i.done)return Promise.resolve(s).then(function(e){r("next",e)},function(e){r("throw",e)});e(s)}("next")})}}function l(e,t){if(!e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!t||"object"!=typeof t&&"function"!=typeof t?e:t}var p=(t=e=function(){function e(){var t,n,o,a,s=this;!function(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}(this,e);for(var u=arguments.length,p=Array(u),f=0;f<u;f++)p[f]=arguments[f];return(n=o=l(this,(t=e.__proto__||Object.getPrototypeOf(e)).call.apply(t,[this].concat(p)))).$usedState=["anonymousState__temp","text","type","className"],o.onBtnClick=c(regeneratorRuntime.mark(function e(){var t;return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:1===(t=o.props.type)&&o.onNavOnlineHelp(),2===t&&o.onScanCode();case 3:case"end":return e.stop()}},e,s)})),o.onNavOnlineHelp=c(regeneratorRuntime.mark(function e(){var t,n;return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return r.default.showLoading({title:"加载中",mask:!0}),e.prev=1,e.next=4,(0,i.contact)();case 4:t=e.sent,(n=t.data)&&n.url&&r.default.navigateTo({url:"/pages/webview-h5/webview-h5?url="+encodeURIComponent(n.url)}),r.default.hideLoading(),e.next=14;break;case 10:e.prev=10,e.t0=e.catch(1),r.default.hideLoading(),r.default.showToast({title:e.t0.message||"获取客服地址出错",icon:"none",duration:2e3});case 14:case"end":return e.stop()}},e,s,[[1,10]])})),o.onNavFault=(a=c(regeneratorRuntime.mark(function e(t){var n,o,a,u,c,l,p;return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return r.default.showLoading({title:"加载中",mask:!0}),e.prev=1,e.next=4,(0,i.getMasterInfo)(t.result);case 4:if(n=e.sent,o=n.code,a=n.message,u=n.data,r.default.hideLoading(),u&&200===o){e.next=12;break}return r.default.showToast({title:a,icon:"none",duration:2e3}),e.abrupt("return");case 12:u.bind?(c=u.masterSn,l=u.storeSn,p=u.storeName,r.default.navigateTo({url:"/package-help/pages/fault/fault?masterInfo="+encodeURIComponent(JSON.stringify({masterSn:c,storeSn:l,storeName:p}))})):r.default.showToast({title:"设备未绑定门店",icon:"none",duration:2e3}),e.next=19;break;case 15:e.prev=15,e.t0=e.catch(1),r.default.hideLoading(),r.default.showToast({title:e.t0.message||"无效的二维码",icon:"none",duration:2e3});case 19:case"end":return e.stop()}},e,s,[[1,15]])})),function(e){return a.apply(this,arguments)}),o.onScanCode=c(regeneratorRuntime.mark(function e(){return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return e.next=2,r.default.showModal({title:"",content:"请扫描故障机柜二维码",cancelText:"取消",confirmText:"扫码上报"});case 2:e.sent.confirm&&r.default.scanCode({success:function(e){o.onNavFault(e)}});case 4:case"end":return e.stop()}},e,s)})),o.customComponents=[],l(o,n)}return function(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function, not "+typeof t);e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),t&&(Object.setPrototypeOf?Object.setPrototypeOf(e,t):e.__proto__=t)}(e,a.default),n(e,[{key:"_constructor",value:function(t){(function e(t,n,r){null===t&&(t=Function.prototype);var o=Object.getOwnPropertyDescriptor(t,n);if(void 0===o){var a=Object.getPrototypeOf(t);return null===a?void 0:e(a,n,r)}if("value"in o)return o.value;var i=o.get;return void 0!==i?i.call(r):void 0})(e.prototype.__proto__||Object.getPrototypeOf(e.prototype),"_constructor",this).call(this,t),this.$$refs=new r.default.RefsArray}},{key:"_createData",value:function(e,t,n){this.__state=e||this.state||{},this.__props=t||this.props||{},this.$prefix;var r=this.__props,a=r.className,i=r.text,u=void 0===i?"人工客服":i,c=(0,o.default)("component-class","server","flex-row","aligin-center",a);return this.anonymousFunc0=(0,s.throttleButton)(this.onBtnClick),Object.assign(this.__state,{anonymousState__temp:c,text:u}),this.__state}},{key:"anonymousFunc0",value:function(e){}}]),e}(),e.$$events=["anonymousFunc0"],e.$$componentPath="package-help/components/contact/index",t);exports.default=p,Component(require("../../../npm/@tarojs/taro-weapp/index.js").default.createComponent(p))}(); 
 			}); 	require("package-help/components/contact/index.js");
 		__wxRoute = 'package-help/components/image-picker/image-picker';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'package-help/components/image-picker/image-picker.js';	define("package-help/components/image-picker/image-picker.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
!function(){"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var e,n,t,r=Object.assign||function(e){for(var n=1;n<arguments.length;n++){var t=arguments[n];for(var r in t)Object.prototype.hasOwnProperty.call(t,r)&&(e[r]=t[r])}return e},o=function(){function e(e,n){for(var t=0;t<n.length;t++){var r=n[t];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}return function(n,t,r){return t&&e(n.prototype,t),r&&e(n,r),n}}(),a=require("../../../npm/@tarojs/taro-weapp/index.js"),i=(t=a)&&t.__esModule?t:{default:t},u=require("../../../api/index.js");function s(e){return function(){var n=e.apply(this,arguments);return new Promise(function(e,t){return function r(o,a){try{var i=n[o](a),u=i.value}catch(o){return void t(o)}if(!i.done)return Promise.resolve(u).then(function(e){r("next",e)},function(e){r("throw",e)});e(u)}("next")})}}function c(e,n){if(!e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!n||"object"!=typeof n&&"function"!=typeof n?e:n}var p=(n=e=function(){function e(){var n,t,r;!function(e,n){if(!(e instanceof n))throw new TypeError("Cannot call a class as a function")}(this,e);for(var o=arguments.length,a=Array(o),i=0;i<o;i++)a[i]=arguments[i];return(t=r=c(this,(n=e.__proto__||Object.getPrototypeOf(e)).call.apply(n,[this].concat(a)))).$usedState=["loopArray9","fileMatrix","DeleteX","add","files","count","sizeType","sourceType"],r.anonymousFunc0Map={},r.anonymousFunc1Map={},r.anonymousFunc2Map={},r.customComponents=[],c(r,t)}return function(e,n){if("function"!=typeof n&&null!==n)throw new TypeError("Super expression must either be null or a function, not "+typeof n);e.prototype=Object.create(n&&n.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),n&&(Object.setPrototypeOf?Object.setPrototypeOf(e,n):e.__proto__=n)}(e,i.default.Component),o(e,[{key:"_constructor",value:function(n){(function e(n,t,r){null===n&&(n=Function.prototype);var o=Object.getOwnPropertyDescriptor(n,t);if(void 0===o){var a=Object.getPrototypeOf(n);return null===a?void 0:e(a,t,r)}if("value"in o)return o.value;var i=o.get;return void 0!==i?i.call(r):void 0})(e.prototype.__proto__||Object.getPrototypeOf(e.prototype),"_constructor",this).call(this,n),this.$$refs=new i.default.RefsArray}},{key:"_createData",value:function(e,n,t){var o=this;this.__state=e||this.state||{},this.__props=n||this.props||{},this.$prefix;var c,p,l=this.__props,f=l.files,y=void 0===f?[]:f,h=l.count,d=void 0===h?1:h,m=l.sizeType,v=l.sourceType,g=l.onChange,_=l.onImageClick,b=l.onFail,F=(c=s(regeneratorRuntime.mark(function e(){var n,t,a;return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return n=r({},d?{count:d-y.length}:{},v?{sourceType:v}:{},m?{sizeType:m}:{sizeType:["compressed"]}),e.prev=1,e.next=4,i.default.chooseImage(n);case 4:t=e.sent,a=t.tempFilePaths,w(a),e.next=15;break;case 9:if(e.prev=9,e.t0=e.catch(1),b)return o.__props.onFail(e.t0),e.abrupt("return");e.next=14;break;case 14:i.default.showToast({title:e.t0,icon:"none",duration:2e3});case 15:case"end":return e.stop()}},e,o,[[1,9]])})),function(){return c.apply(this,arguments)}),w=(p=s(regeneratorRuntime.mark(function e(n){var t,r;return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return i.default.showLoading({title:"上传中",mask:!0}),e.prev=1,e.next=4,Promise.all(n.map(function(e){return(0,u.uploadFile)(e)}));case 4:t=e.sent,r=t.map(function(e){if(e&&200===e.code)return{url:e.data}}).filter(Boolean),o.__props.onChange(y.concat(r),"add"),i.default.hideLoading(),e.next=14;break;case 10:e.prev=10,e.t0=e.catch(1),i.default.hideLoading(),i.default.showToast({title:e.t0.message||e.t0||"上传图片失败",icon:"none",duration:2e3});case 14:case"end":return e.stop()}},e,o,[[1,10]])})),function(e){return p.apply(this,arguments)}),x=function(e,n,t){for(var r=[],o=e.length<t,a=o?e.length+1:e.length,i=Math.ceil(a/n),u=0;u<i;u++)if(u===i-1){var s=e.slice(u*n);s.length<n&&o&&s.push({type:"add",key:"add"}),r.push(s)}else r.push(e.slice(u*n,(u+1)*n));return r}(y,4,d),$=x.map(function(e,n){return e={$original:(0,a.internal_get_original)(e)},{$loopState__temp2:n+1,$anonymousCallee__4:e.$original.map(function(e,t){e={$original:(0,a.internal_get_original)(e)};var r=4*n+t,i="fzzzz"+n+"-"+t;o.anonymousFunc0Map[i]=function(){return e=4*n+t,void(_&&o.__props.onImageClick(y,e));var e};var u="gzzzz"+n+"-"+t;o.anonymousFunc1Map[u]=function(){return e=4*n+t,void(g&&o.__props.onChange(y.filter(function(n,t){return t!==e}),"remove",e));var e};var s="hzzzz"+n+"-"+t;return o.anonymousFunc2Map[s]=F,{$loopState__temp4:r,_$indexKey:i,_$indexKey2:u,_$indexKey3:s,$original:e.$original}}),$original:e.$original}});return Object.assign(this.__state,{loopArray9:$,fileMatrix:x,DeleteX:"/package-help/images/delete.png",add:"/package-help/images/add.png"}),this.__state}},{key:"anonymousFunc0",value:function(e){for(var n,t=arguments.length,r=Array(1<t?t-1:0),o=1;o<t;o++)r[o-1]=arguments[o];return this.anonymousFunc0Map[e]&&(n=this.anonymousFunc0Map)[e].apply(n,r)}},{key:"anonymousFunc1",value:function(e){for(var n,t=arguments.length,r=Array(1<t?t-1:0),o=1;o<t;o++)r[o-1]=arguments[o];return this.anonymousFunc1Map[e]&&(n=this.anonymousFunc1Map)[e].apply(n,r)}},{key:"anonymousFunc2",value:function(e){for(var n,t=arguments.length,r=Array(1<t?t-1:0),o=1;o<t;o++)r[o-1]=arguments[o];return this.anonymousFunc2Map[e]&&(n=this.anonymousFunc2Map)[e].apply(n,r)}}]),e}(),e.$$events=["anonymousFunc0","anonymousFunc1","anonymousFunc2"],e.$$componentPath="package-help/components/image-picker/image-picker",n);exports.default=p,Component(require("../../../npm/@tarojs/taro-weapp/index.js").default.createComponent(p))}(); 
 			}); 	require("package-help/components/image-picker/image-picker.js");
 		__wxRoute = 'package-help/components/my-label/my-label';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'package-help/components/my-label/my-label.js';	define("package-help/components/my-label/my-label.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
!function(){"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var t,e,r,o=function(){function t(t,e){for(var r=0;r<e.length;r++){var o=e[r];o.enumerable=o.enumerable||!1,o.configurable=!0,"value"in o&&(o.writable=!0),Object.defineProperty(t,o.key,o)}}return function(e,r,o){return r&&t(e.prototype,r),o&&t(e,o),e}}(),n=require("../../../npm/@tarojs/taro-weapp/index.js"),a=(r=n)&&r.__esModule?r:{default:r};function i(t,e){if(!t)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!e||"object"!=typeof e&&"function"!=typeof e?t:e}var u=(e=t=function(){function t(){var e,r,o;!function(t,e){if(!(t instanceof e))throw new TypeError("Cannot call a class as a function")}(this,t);for(var n=arguments.length,a=Array(n),u=0;u<n;u++)a[u]=arguments[u];return(r=o=i(this,(e=t.__proto__||Object.getPrototypeOf(t)).call.apply(e,[this].concat(a)))).$usedState=["anonymousState__temp","require","text","style"],o.customComponents=[],i(o,r)}return function(t,e){if("function"!=typeof e&&null!==e)throw new TypeError("Super expression must either be null or a function, not "+typeof e);t.prototype=Object.create(e&&e.prototype,{constructor:{value:t,enumerable:!1,writable:!0,configurable:!0}}),e&&(Object.setPrototypeOf?Object.setPrototypeOf(t,e):t.__proto__=e)}(t,a.default.Component),o(t,[{key:"_constructor",value:function(e){(function t(e,r,o){null===e&&(e=Function.prototype);var n=Object.getOwnPropertyDescriptor(e,r);if(void 0===n){var a=Object.getPrototypeOf(e);return null===a?void 0:t(a,r,o)}if("value"in n)return n.value;var i=n.get;return void 0!==i?i.call(o):void 0})(t.prototype.__proto__||Object.getPrototypeOf(t.prototype),"_constructor",this).call(this,e),this.$$refs=new a.default.RefsArray}},{key:"_createData",value:function(t,e,r){this.__state=t||this.state||{},this.__props=e||this.props||{},this.$prefix;var o=this.__props,a=o.text,i=o.require,u=o.style,s=(0,n.internal_inline_style)(u);return Object.assign(this.__state,{anonymousState__temp:s,require:i,text:a}),this.__state}}]),t}(),t.$$events=[],t.$$componentPath="package-help/components/my-label/my-label",e);exports.default=u,Component(require("../../../npm/@tarojs/taro-weapp/index.js").default.createComponent(u))}(); 
 			}); 	require("package-help/components/my-label/my-label.js");
 		__wxRoute = 'package-help/components/my-picker/my-picker';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'package-help/components/my-picker/my-picker.js';	define("package-help/components/my-picker/my-picker.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
!function(){"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var e,t,n=function(){function e(e,t){for(var n=0;n<t.length;n++){var o=t[n];o.enumerable=o.enumerable||!1,o.configurable=!0,"value"in o&&(o.writable=!0),Object.defineProperty(e,o.key,o)}}return function(t,n,o){return n&&e(t.prototype,n),o&&e(t,o),t}}(),o=require("../../../npm/@tarojs/taro-weapp/index.js"),r=i(o),a=i(require("../../../npm/classnames/index.js"));function i(e){return e&&e.__esModule?e:{default:e}}function u(e,t){if(!e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!t||"object"!=typeof t&&"function"!=typeof t?e:t}var p=(t=e=function(){function e(){var t,n,o;!function(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}(this,e);for(var r=arguments.length,a=Array(r),i=0;i<r;i++)a[i]=arguments[i];return(n=o=u(this,(t=e.__proto__||Object.getPrototypeOf(e)).call.apply(t,[this].concat(a)))).$usedState=["anonymousState__temp","anonymousState__temp2","anonymousState__temp3","value","rangeKey","range","arrowRight","placeholder","style"],o.customComponents=[],u(o,n)}return function(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function, not "+typeof t);e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),t&&(Object.setPrototypeOf?Object.setPrototypeOf(e,t):e.__proto__=t)}(e,r.default.Component),n(e,[{key:"_constructor",value:function(t){(function e(t,n,o){null===t&&(t=Function.prototype);var r=Object.getOwnPropertyDescriptor(t,n);if(void 0===r){var a=Object.getPrototypeOf(t);return null===a?void 0:e(a,n,o)}if("value"in r)return r.value;var i=r.get;return void 0!==i?i.call(o):void 0})(e.prototype.__proto__||Object.getPrototypeOf(e.prototype),"_constructor",this).call(this,t),this.$$refs=new r.default.RefsArray}},{key:"_createData",value:function(e,t,n){var r=this;this.__state=e||this.state||{},this.__props=t||this.props||{},this.$prefix;var i=this.__props,u=i.value,p=i.range,s=void 0===p?[]:p,c=i.rangeKey,l=i.placeholder,f=void 0===l?"请选择":l,_=(i.onChange,i.style),y=(0,o.internal_inline_style)(_);this.anonymousFunc0=function(e){r.__props.onChange(e.detail.value,e)};var h=c?(0,a.default)("picker-view-field",{"picker-placeholder":!s[u]}):null,m=(0,a.default)("picker-view-field",{"picker-placeholder":!s[u]});return Object.assign(this.__state,{anonymousState__temp:y,anonymousState__temp2:h,anonymousState__temp3:m,value:u,rangeKey:c,range:s,arrowRight:"/package-help/images/arrowRight.png",placeholder:f}),this.__state}},{key:"anonymousFunc0",value:function(e){}}]),e}(),e.$$events=["anonymousFunc0"],e.$$componentPath="package-help/components/my-picker/my-picker",t);exports.default=p,Component(require("../../../npm/@tarojs/taro-weapp/index.js").default.createComponent(p))}(); 
 			}); 	require("package-help/components/my-picker/my-picker.js");
 		__wxRoute = 'package-help/components/my-textarea/my-textarea';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'package-help/components/my-textarea/my-textarea.js';	define("package-help/components/my-textarea/my-textarea.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
!function(){"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var t,e,o,n=function(){function t(t,e){for(var o=0;o<e.length;o++){var n=e[o];n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(t,n.key,n)}}return function(e,o,n){return o&&t(e.prototype,o),n&&t(e,n),e}}(),r=require("../../../npm/@tarojs/taro-weapp/index.js"),a=(o=r)&&o.__esModule?o:{default:o};function u(t,e){if(!t)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!e||"object"!=typeof e&&"function"!=typeof e?t:e}var i=(e=t=function(){function t(){var e,o,n;!function(t,e){if(!(t instanceof e))throw new TypeError("Cannot call a class as a function")}(this,t);for(var r=arguments.length,a=Array(r),i=0;i<r;i++)a[i]=arguments[i];return(o=n=u(this,(e=t.__proto__||Object.getPrototypeOf(t)).call.apply(e,[this].concat(a)))).$usedState=["anonymousState__temp","placeholder","maxlength","value","count","customStyle"],n.customComponents=[],u(n,o)}return function(t,e){if("function"!=typeof e&&null!==e)throw new TypeError("Super expression must either be null or a function, not "+typeof e);t.prototype=Object.create(e&&e.prototype,{constructor:{value:t,enumerable:!1,writable:!0,configurable:!0}}),e&&(Object.setPrototypeOf?Object.setPrototypeOf(t,e):t.__proto__=e)}(t,a.default.Component),n(t,[{key:"_constructor",value:function(e){(function t(e,o,n){null===e&&(e=Function.prototype);var r=Object.getOwnPropertyDescriptor(e,o);if(void 0===r){var a=Object.getPrototypeOf(e);return null===a?void 0:t(a,o,n)}if("value"in r)return r.value;var u=r.get;return void 0!==u?u.call(n):void 0})(t.prototype.__proto__||Object.getPrototypeOf(t.prototype),"_constructor",this).call(this,e),this.$$refs=new a.default.RefsArray}},{key:"_createData",value:function(t,e,o){var n=this;this.__state=t||this.state||{},this.__props=e||this.props||{},this.$prefix;var a=this.__props,u=a.value,i=a.maxlength,s=void 0===i?200:i,c=a.count,p=a.placeholder,l=void 0===p?"请输入":p,f=(a.onChange,a.customStyle),y=(0,r.internal_inline_style)(f);return this.anonymousFunc0=function(t){n.__props.onChange(t.target.value,t)},Object.assign(this.__state,{anonymousState__temp:y,placeholder:l,maxlength:s,value:u,count:c}),this.__state}},{key:"anonymousFunc0",value:function(t){}}]),t}(),t.$$events=["anonymousFunc0"],t.$$componentPath="package-help/components/my-textarea/my-textarea",e);exports.default=i,Component(require("../../../npm/@tarojs/taro-weapp/index.js").default.createComponent(i))}(); 
 			}); 	require("package-help/components/my-textarea/my-textarea.js");
 		__wxRoute = 'package-help/pages/my/my';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'package-help/pages/my/my.js';	define("package-help/pages/my/my.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
!function(){"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var e,t,n,o=function(){function e(e,t){for(var n=0;n<t.length;n++){var o=t[n];o.enumerable=o.enumerable||!1,o.configurable=!0,"value"in o&&(o.writable=!0),Object.defineProperty(e,o.key,o)}}return function(t,n,o){return n&&e(t.prototype,n),o&&e(t,o),t}}(),r=require("../../../npm/@tarojs/taro-weapp/index.js"),a=(n=r)&&n.__esModule?n:{default:n},i=require("../../../utils/index.js");function u(e,t){if(!e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!t||"object"!=typeof t&&"function"!=typeof t?e:t}var s=(t=e=function(){function e(){var t,n,o;!function(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}(this,e);for(var r=arguments.length,a=Array(r),i=0;i<r;i++)a[i]=arguments[i];return(n=o=u(this,(t=e.__proto__||Object.getPrototypeOf(e)).call.apply(t,[this].concat(a)))).$usedState=["userInfo","indexAvatar","myOrders","Go","myQuestion"],o.config={navigationBarTitleText:"个人中心"},o.state={userInfo:{}},o.times=0,o.timer=null,o.onAvatarClick=function(){},o.customComponents=[],u(o,n)}return function(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function, not "+typeof t);e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),t&&(Object.setPrototypeOf?Object.setPrototypeOf(e,t):e.__proto__=t)}(e,r.Component),o(e,[{key:"_constructor",value:function(t){(function e(t,n,o){null===t&&(t=Function.prototype);var r=Object.getOwnPropertyDescriptor(t,n);if(void 0===r){var a=Object.getPrototypeOf(t);return null===a?void 0:e(a,n,o)}if("value"in r)return r.value;var i=r.get;return void 0!==i?i.call(o):void 0})(e.prototype.__proto__||Object.getPrototypeOf(e.prototype),"_constructor",this).call(this,t),this.$$refs=new a.default.RefsArray}},{key:"componentWillMount",value:function(){var e=(0,i.getGlobalData)("userInfo");e&&this.setState({userInfo:e})}},{key:"componentWillUnmount",value:function(){clearTimeout(this.timer)}},{key:"goToOrders",value:function(){a.default.navigateTo({url:"/package-order/pages/orders/orders"})}},{key:"goToQuestion",value:function(){a.default.navigateTo({url:"/package-help/pages/question/question"})}},{key:"_createData",value:function(e,t,n){return this.__state=e||this.state||{},this.__props=t||this.props||{},this.$prefix,this.__state.userInfo,this.anonymousFunc0=(0,i.throttleButton)(this.goToOrders),this.anonymousFunc1=(0,i.throttleButton)(this.goToQuestion),Object.assign(this.__state,{indexAvatar:"/images/indexAvatar.png",myOrders:"/package-help/images/myOrders.png",Go:"/images/Go.png",myQuestion:"/package-help/images/myQuestion.png"}),this.__state}},{key:"anonymousFunc0",value:function(e){}},{key:"anonymousFunc1",value:function(e){}}]),e}(),e.$$events=["onAvatarClick","anonymousFunc0","anonymousFunc1"],e.$$componentPath="package-help/pages/my/my",t);exports.default=s,Component(require("../../../npm/@tarojs/taro-weapp/index.js").default.createComponent(s,!0))}(); 
 			}); 	require("package-help/pages/my/my.js");
 		__wxRoute = 'package-help/pages/debug/debug';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'package-help/pages/debug/debug.js';	define("package-help/pages/debug/debug.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
!function(){"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var t,e,n,o=function(){function t(t,e){for(var n=0;n<e.length;n++){var o=e[n];o.enumerable=o.enumerable||!1,o.configurable=!0,"value"in o&&(o.writable=!0),Object.defineProperty(t,o.key,o)}}return function(e,n,o){return n&&t(e.prototype,n),o&&t(e,o),e}}(),r=require("../../../npm/@tarojs/taro-weapp/index.js"),a=(n=r)&&n.__esModule?n:{default:n},u=require("../../../utils/index.js");function i(t,e){if(!t)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!e||"object"!=typeof e&&"function"!=typeof e?t:e}var c=(e=t=function(){function t(){var e,n,o;!function(t,e){if(!(t instanceof e))throw new TypeError("Cannot call a class as a function")}(this,t);for(var r=arguments.length,a=Array(r),u=0;u<r;u++)a[u]=arguments[u];return(n=o=i(this,(e=t.__proto__||Object.getPrototypeOf(t)).call.apply(e,[this].concat(a)))).config={navigationBarTitleText:"调试"},o.$usedState=["xEnvFlag"],o.customComponents=[],i(o,n)}return function(t,e){if("function"!=typeof e&&null!==e)throw new TypeError("Super expression must either be null or a function, not "+typeof e);t.prototype=Object.create(e&&e.prototype,{constructor:{value:t,enumerable:!1,writable:!0,configurable:!0}}),e&&(Object.setPrototypeOf?Object.setPrototypeOf(t,e):t.__proto__=e)}(t,a.default.Component),o(t,[{key:"_constructor",value:function(e){(function t(e,n,o){null===e&&(e=Function.prototype);var r=Object.getOwnPropertyDescriptor(e,n);if(void 0===r){var a=Object.getPrototypeOf(e);return null===a?void 0:t(a,n,o)}if("value"in r)return r.value;var u=r.get;return void 0!==u?u.call(o):void 0})(t.prototype.__proto__||Object.getPrototypeOf(t.prototype),"_constructor",this).call(this,e),this.$$refs=new a.default.RefsArray}},{key:"_createData",value:function(t,e,n){this.__state=t||this.state||{},this.__props=e||this.props||{},this.$prefix;var o=function(t,e){if(Array.isArray(t))return t;if(Symbol.iterator in Object(t))return function(t,e){var n=[],o=!0,r=!1,a=void 0;try{for(var u,i=t[Symbol.iterator]();!(o=(u=i.next()).done)&&(n.push(u.value),!e||n.length!==e);o=!0);}catch(t){r=!0,a=t}finally{try{!o&&i.return&&i.return()}finally{if(r)throw a}}return n}(t,e);throw new TypeError("Invalid attempt to destructure non-iterable instance")}((0,r.useState)(""),2),i=o[0],c=o[1];return(0,r.useEffect)(function(){try{var t=(0,u.getGlobalData)("x-env-flag");t&&c(t)}catch(t){console.log(t)}},[]),this.anonymousFunc0=function(t){return c(t.detail.value)},this.anonymousFunc1=function(){(0,u.setGlobalData)("x-env-flag",i||null),a.default.showToast({icon:"none",title:i+"设置成功"})},Object.assign(this.__state,{xEnvFlag:i}),this.__state}},{key:"anonymousFunc0",value:function(t){}},{key:"anonymousFunc1",value:function(t){}}]),t}(),t.$$events=["anonymousFunc0","anonymousFunc1"],t.$$componentPath="package-help/pages/debug/debug",e);c.config={navigationBarTitleText:"调试"},exports.default=c,Component(require("../../../npm/@tarojs/taro-weapp/index.js").default.createComponent(c,!0))}(); 
 			}); 	require("package-help/pages/debug/debug.js");
 		__wxRoute = 'package-help/pages/question/question';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'package-help/pages/question/question.js';	define("package-help/pages/question/question.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
!function(){"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var t,e,n=function(t,e){if(Array.isArray(t))return t;if(Symbol.iterator in Object(t))return function(t,e){var n=[],r=!0,o=!1,i=void 0;try{for(var a,s=t[Symbol.iterator]();!(r=(a=s.next()).done)&&(n.push(a.value),!e||n.length!==e);r=!0);}catch(t){o=!0,i=t}finally{try{!r&&s.return&&s.return()}finally{if(o)throw i}}return n}(t,e);throw new TypeError("Invalid attempt to destructure non-iterable instance")},r=Object.assign||function(t){for(var e=1;e<arguments.length;e++){var n=arguments[e];for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(t[r]=n[r])}return t},o=function(){function t(t,e){for(var n=0;n<e.length;n++){var r=e[n];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(t,r.key,r)}}return function(e,n,r){return n&&t(e.prototype,n),r&&t(e,r),e}}(),i=require("../../../npm/@tarojs/taro-weapp/index.js"),a=c(i),s=c(require("../../../npm/classnames/index.js")),u=c(require("../../../utils/min-lodash.js")),l=require("../../../api/index.js");function c(t){return t&&t.__esModule?t:{default:t}}function p(t,e,n){return e in t?Object.defineProperty(t,e,{value:n,enumerable:!0,configurable:!0,writable:!0}):t[e]=n,t}function f(t,e){if(!t)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!e||"object"!=typeof e&&"function"!=typeof e?t:e}var y=(e=t=function(){function t(){var e,n,o,i=this;!function(t,e){if(!(t instanceof e))throw new TypeError("Cannot call a class as a function")}(this,t);for(var s=arguments.length,u=Array(s),c=0;c<s;c++)u[c]=arguments[c];return(n=o=f(this,(e=t.__proto__||Object.getPrototypeOf(t)).call.apply(e,[this].concat(u)))).$usedState=["anonymousState__temp11","anonymousState__temp12","anonymousState__temp13","questionList","loopArray3","$compid__18","$compid__19","$compid__20","activeCategory","Go","active","visibleHeight","displayObj"],o.timer=null,o.config={navigationBarTitleText:"常见问题"},o.state={active:0,activeCategory:0,questionList:[{}],visibleHeight:0,displayObj:{}},o.toggleStatus=function(t){var e=o.state.displayObj[t];o.actionIsDisplay=!e,o.setState(r({},o.state,{displayObj:r({},o.state.displayObj,p({},t,!e))}),function(){o.timer=setTimeout(function(){o.actionIsDisplay&&a.default.pageScrollTo({selector:".target-"+t,duration:500})},400)})},o.getQuestion=function(t){return function(){var e=t.apply(this,arguments);return new Promise(function(t,n){return function r(o,i){try{var a=e[o](i),s=a.value}catch(o){return void n(o)}if(!a.done)return Promise.resolve(s).then(function(t){r("next",t)},function(t){r("throw",t)});t(s)}("next")})}}(regeneratorRuntime.mark(function t(){var e,n;return regeneratorRuntime.wrap(function(t){for(;;)switch(t.prev=t.next){case 0:return t.next=2,(0,l.getHelperQuestion)().catch(function(t){return t});case 2:if(e=t.sent,n=e.data){t.next=6;break}return t.abrupt("return");case 6:o.setState({questionList:n});case 7:case"end":return t.stop()}},t,i)})),o.customComponents=["XTitleTabs","XContact"],f(o,n)}return function(t,e){if("function"!=typeof e&&null!==e)throw new TypeError("Super expression must either be null or a function, not "+typeof e);t.prototype=Object.create(e&&e.prototype,{constructor:{value:t,enumerable:!1,writable:!0,configurable:!0}}),e&&(Object.setPrototypeOf?Object.setPrototypeOf(t,e):t.__proto__=e)}(t,i.Component),o(t,[{key:"_constructor",value:function(e){(function t(e,n,r){null===e&&(e=Function.prototype);var o=Object.getOwnPropertyDescriptor(e,n);if(void 0===o){var i=Object.getPrototypeOf(e);return null===i?void 0:t(i,n,r)}if("value"in o)return o.value;var a=o.get;return void 0!==a?a.call(r):void 0})(t.prototype.__proto__||Object.getPrototypeOf(t.prototype),"_constructor",this).call(this,e),this.$$refs=new a.default.RefsArray}},{key:"componentWillMount",value:function(){this.getQuestion()}},{key:"componentWillUnmount",value:function(){clearTimeout(this.timer)}},{key:"componentDidUpdate",value:function(){var t=this,e=this.state,n=e.questionList,r=e.activeCategory,o=u.default.get(n,r+".helps.length",0);!o||o<1||a.default.createSelectorQuery().select(".target-"+(o-1)).boundingClientRect().select(".bottom").boundingClientRect().exec(function(e){if(e&&e[0]){var n=t.state.visibleHeight,r=e[0].bottom>e[1].top-10;r&&180!==n&&t.setState({visibleHeight:180}),r||180!=n||t.setState({visibleHeight:0})}})}},{key:"switchCategory",value:function(t){this.state.activeCategory!==t&&this.setState({activeCategory:t,displayObj:{}})}},{key:"_createData",value:function(t,e,r){var o=this;this.__state=t||this.state||{},this.__props=e||this.props||{};var a=this.$prefix,u=(0,i.genCompid)(a+"$compid__18"),l=n(u,2),c=l[0],p=l[1],f=(0,i.genCompid)(a+"$compid__19"),y=n(f,2),_=y[0],m=y[1],v=(0,i.genCompid)(a+"$compid__20"),h=n(v,2),d=h[0],g=h[1],b=this.__state,j=b.questionList,w=b.activeCategory,O=b.visibleHeight,$=(0,s.default)("visible-area"),S=(0,i.internal_inline_style)({height:O+"rpx"}),C=(0,s.default)("bottom",{"bottom-top":0<O}),x=j[w].helps?j[w].helps.map(function(t,e){t={$original:(0,i.internal_get_original)(t)};var n=o.__state.displayObj[e];return{activeIndex:n,$loopState__temp2:j[w].helps?(0,s.default)("item","fake-bottom","bd-b","target-"+e,{"bd-t":0===e},{"active-item":n}):null,$loopState__temp4:j[w].helps?e+"_key":null,$loopState__temp6:j[w].helps?(0,s.default)("title","flex-row","center-between"):null,$loopState__temp8:j[w].helps?(0,s.default)("icon-wrap",{"active-wrap":n}):null,$loopState__temp10:j[w].helps?(0,s.default)("content",{"active-content":n}):null,$original:t.$original}}):[];return i.propsManager.set({titleList:j,activeCategory:w,switchCategory:this.switchCategory.bind(this)},p,c),i.propsManager.set({className:"server-btn server-btn-left",type:1},m,_),i.propsManager.set({className:"server-btn server-btn-right",text:"故障上报",type:2},g,d),Object.assign(this.__state,{anonymousState__temp11:$,anonymousState__temp12:S,anonymousState__temp13:C,loopArray3:x,$compid__18:p,$compid__19:m,$compid__20:g,Go:"/images/Go.png"}),this.__state}}]),t}(),t.$$events=["toggleStatus"],t.$$componentPath="package-help/pages/question/question",e);exports.default=y,Component(require("../../../npm/@tarojs/taro-weapp/index.js").default.createComponent(y,!0))}(); 
 			}); 	require("package-help/pages/question/question.js");
 		__wxRoute = 'package-help/pages/fault/fault';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'package-help/pages/fault/fault.js';	define("package-help/pages/fault/fault.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
!function(){"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var e,t,n,r=function(e,t){if(Array.isArray(e))return e;if(Symbol.iterator in Object(e))return function(e,t){var n=[],r=!0,o=!1,a=void 0;try{for(var i,u=e[Symbol.iterator]();!(r=(i=u.next()).done)&&(n.push(i.value),!t||n.length!==t);r=!0);}catch(e){o=!0,a=e}finally{try{!r&&u.return&&u.return()}finally{if(o)throw a}}return n}(e,t);throw new TypeError("Invalid attempt to destructure non-iterable instance")},o=function(){function e(e,t){for(var n=0;n<t.length;n++){var r=t[n];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}return function(t,n,r){return n&&e(t.prototype,n),r&&e(t,r),t}}(),a=require("../../../npm/@tarojs/taro-weapp/index.js"),i=(n=a)&&n.__esModule?n:{default:n},u=require("../../../utils/index.js"),s=require("../../../api/index.js");function c(e){return function(){var t=e.apply(this,arguments);return new Promise(function(e,n){return function r(o,a){try{var i=t[o](a),u=i.value}catch(o){return void n(o)}if(!i.done)return Promise.resolve(u).then(function(e){r("next",e)},function(e){r("throw",e)});e(u)}("next")})}}function p(e,t){if(!e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!t||"object"!=typeof t&&"function"!=typeof t?e:t}var f=(t=e=function(){function e(){var t,n,r;!function(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}(this,e);for(var o=arguments.length,a=Array(o),i=0;i<o;i++)a[i]=arguments[i];return(n=r=p(this,(t=e.__proto__||Object.getPrototypeOf(e)).call.apply(t,[this].concat(a)))).config={navigationBarTitleText:"故障上报"},r.$usedState=["$compid__21","$compid__22","$compid__23","$compid__24","$compid__25","$compid__26","$compid__27","storeName"],r.customComponents=["XLabel","XPicker","XTextarea","XImagePicker"],p(r,n)}return function(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function, not "+typeof t);e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),t&&(Object.setPrototypeOf?Object.setPrototypeOf(e,t):e.__proto__=t)}(e,i.default.Component),o(e,[{key:"_constructor",value:function(t){(function e(t,n,r){null===t&&(t=Function.prototype);var o=Object.getOwnPropertyDescriptor(t,n);if(void 0===o){var a=Object.getPrototypeOf(t);return null===a?void 0:e(a,n,r)}if("value"in o)return o.value;var i=o.get;return void 0!==i?i.call(r):void 0})(e.prototype.__proto__||Object.getPrototypeOf(e.prototype),"_constructor",this).call(this,t),this.$$refs=new i.default.RefsArray}},{key:"_createData",value:function(e,t,n){var o=this;this.__state=e||this.state||{},this.__props=t||this.props||{};var p,f=this.$prefix,l=(0,a.genCompid)(f+"$compid__21"),m=r(l,2),d=m[0],_=m[1],h=(0,a.genCompid)(f+"$compid__22"),y=r(h,2),g=y[0],v=y[1],b=(0,a.genCompid)(f+"$compid__23"),w=r(b,2),$=w[0],x=w[1],k=(0,a.genCompid)(f+"$compid__24"),T=r(k,2),j=T[0],O=T[1],C=(0,a.genCompid)(f+"$compid__25"),F=r(C,2),P=F[0],S=F[1],R=(0,a.genCompid)(f+"$compid__26"),M=r(R,2),q=M[0],I=M[1],B=(0,a.genCompid)(f+"$compid__27"),E=r(B,2),N=E[0],A=E[1],L=null,X=(0,a.useRouter)().params.masterInfo,D=JSON.parse(decodeURIComponent(X||"{}")),J=D.masterSn,K=D.storeName,U=D.storeSn,z=(0,a.useState)([]),G=r(z,2),H=G[0],Q=G[1],V=(0,a.useState)([]),W=r(V,2),Y=W[0],Z=W[1],ee=(0,a.useState)(""),te=r(ee,2),ne=te[0],re=te[1],oe=(0,a.useState)(""),ae=r(oe,2),ie=ae[0],ue=ae[1],se=(p=c(regeneratorRuntime.mark(function e(){var t,n,r,a;return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:return e.next=2,(0,s.getReportTypes)();case 2:if(t=e.sent,n=t.code,r=t.data,a=t.message,200===n&&r)return Q(r),e.abrupt("return");e.next=9;break;case 9:i.default.showToast({title:a,icon:"none",duration:2e3});case 10:case"end":return e.stop()}},e,o)})),function(){return p.apply(this,arguments)});(0,a.useEffect)(function(){return se(),function(){clearTimeout(L)}},[L]);var ce,pe=(ce=c(regeneratorRuntime.mark(function e(){var t,n,r;return regeneratorRuntime.wrap(function(e){for(;;)switch(e.prev=e.next){case 0:if(H[ie]){e.next=3;break}return i.default.showToast({title:"请选择故障类型",icon:"none",duration:2e3}),e.abrupt("return");case 3:return i.default.showLoading({title:"上报中, 请稍等",mask:!0}),e.prev=4,e.next=7,(0,s.postReport)({storeSn:U,masterSn:J,reportType:H[ie].type,remark:ne,images:Y.map(function(e){return e.url}).filter(Boolean)});case 7:if(t=e.sent,n=t.code,r=t.message,i.default.hideLoading(),200===n)return i.default.showToast({title:"上报成功,谢谢",duration:1e4}),L=setTimeout(function(){i.default.hideToast(),i.default.navigateBack()},3e3),e.abrupt("return");e.next=15;break;case 15:i.default.showToast({title:r,icon:"none",duration:2e3}),e.next=22;break;case 18:e.prev=18,e.t0=e.catch(4),i.default.hideLoading(),i.default.showToast({title:e.t0.message||"上报失败,请重新上报",icon:"none",duration:2e3});case 22:case"end":return e.stop()}},e,o,[[4,18]])})),function(){return ce.apply(this,arguments)});return this.anonymousFunc0=function(e){return ue(e)},this.anonymousFunc1=function(e){return re(e)},this.anonymousFunc2=function(e){Z(e)},this.anonymousFunc3=function(e,t){try{var n=e.map(function(e){return e.url});i.default.previewImage({urls:n,current:n[t]})}catch(e){i.default.showToast({title:e.message||e,icon:"none",duration:2e3})}},this.anonymousFunc4=(0,u.throttleButton)(pe),a.propsManager.set({text:"故障机柜所在门店",require:!0},_,d),a.propsManager.set({text:"故障类型",require:!0},v,g),a.propsManager.set({placeholder:"请选择故障类型",range:H,rangeKey:"typeName",value:ie,onChange:this.anonymousFunc0},x,$),a.propsManager.set({text:"问题描述"},O,j),a.propsManager.set({count:200,placeholder:"请输入问题",value:ne,onChange:this.anonymousFunc1},S,P),a.propsManager.set({text:"故障图片"},I,q),a.propsManager.set({files:Y,count:3,onChange:this.anonymousFunc2,onImageClick:this.anonymousFunc3},A,N),Object.assign(this.__state,{$compid__21:_,$compid__22:v,$compid__23:x,$compid__24:O,$compid__25:S,$compid__26:I,$compid__27:A,storeName:K}),this.__state}},{key:"anonymousFunc0",value:function(e){}},{key:"anonymousFunc1",value:function(e){}},{key:"anonymousFunc2",value:function(e){}},{key:"anonymousFunc3",value:function(e){}},{key:"anonymousFunc4",value:function(e){}}]),e}(),e.$$events=["anonymousFunc4"],e.$$componentPath="package-help/pages/fault/fault",t);f.config={navigationBarTitleText:"故障上报"},exports.default=f,Component(require("../../../npm/@tarojs/taro-weapp/index.js").default.createComponent(f,!0))}(); 
 			}); 	require("package-help/pages/fault/fault.js");
 		__wxRoute = 'package-help/pages/use-tips/use-tips';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'package-help/pages/use-tips/use-tips.js';	define("package-help/pages/use-tips/use-tips.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
!function(){"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var t,e,n=function(){function t(t,e){for(var n=0;n<e.length;n++){var r=e[n];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(t,r.key,r)}}return function(e,n,r){return n&&t(e.prototype,n),r&&t(e,r),e}}(),r=require("../../../npm/@tarojs/taro-weapp/index.js"),o=u(r),a=u(require("../../../npm/classnames/index.js")),i=u(require("./tips.js"));function u(t){return t&&t.__esModule?t:{default:t}}function l(t,e){if(!t)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!e||"object"!=typeof e&&"function"!=typeof e?t:e}var s=(e=t=function(){function t(){var e,n,r;!function(t,e){if(!(t instanceof e))throw new TypeError("Cannot call a class as a function")}(this,t);for(var o=arguments.length,a=Array(o),i=0;i<o;i++)a[i]=arguments[i];return(n=r=l(this,(e=t.__proto__||Object.getPrototypeOf(t)).call.apply(e,[this].concat(a)))).config={navigationBarTitleText:"使用技巧"},r.$usedState=["tips","loopArray4","loopArray5","activeTab"],r.anonymousFunc0Map={},r.customComponents=[],l(r,n)}return function(t,e){if("function"!=typeof e&&null!==e)throw new TypeError("Super expression must either be null or a function, not "+typeof e);t.prototype=Object.create(e&&e.prototype,{constructor:{value:t,enumerable:!1,writable:!0,configurable:!0}}),e&&(Object.setPrototypeOf?Object.setPrototypeOf(t,e):t.__proto__=e)}(t,o.default.Component),n(t,[{key:"_constructor",value:function(e){(function t(e,n,r){null===e&&(e=Function.prototype);var o=Object.getOwnPropertyDescriptor(e,n);if(void 0===o){var a=Object.getPrototypeOf(e);return null===a?void 0:t(a,n,r)}if("value"in o)return o.value;var i=o.get;return void 0!==i?i.call(r):void 0})(t.prototype.__proto__||Object.getPrototypeOf(t.prototype),"_constructor",this).call(this,e),this.$$refs=new o.default.RefsArray}},{key:"_createData",value:function(t,e,n){var u=this;this.__state=t||this.state||{},this.__props=e||this.props||{},this.$prefix;var l=function(t,e){if(Array.isArray(t))return t;if(Symbol.iterator in Object(t))return function(t,e){var n=[],r=!0,o=!1,a=void 0;try{for(var i,u=t[Symbol.iterator]();!(r=(i=u.next()).done)&&(n.push(i.value),!e||n.length!==e);r=!0);}catch(t){o=!0,a=t}finally{try{!r&&u.return&&u.return()}finally{if(o)throw a}}return n}(t,e);throw new TypeError("Invalid attempt to destructure non-iterable instance")}((0,r.useState)(0),2),s=l[0],p=l[1],c=i.default.map(function(t,e){t={$original:(0,r.internal_get_original)(t)};var n=(0,a.default)("use-tips-switch-text",{"active-switch":s===e}),i="dzzzz"+e;return u.anonymousFunc0Map[i]=function(){var t;(t=e)!==s&&(o.default.pageScrollTo({selector:".use-tips",scrollTop:0,duration:500}),p(t))},{$loopState__temp2:n,_$indexKey:i,$original:t.$original}}),f=i.default[s].steps.map(function(t,e){return t={$original:(0,r.internal_get_original)(t)},{$loopState__temp6:(0,r.internal_inline_style)({justifyContent:t.$original.image.isSingle?"center":"space-between"}),$anonymousCallee__1:t.$original.tips.map(function(t,e){return t={$original:(0,r.internal_get_original)(t)},{$loopState__temp4:(0,a.default)("use-tips-para-text",{"use-tips-para-btext":t.$original.isHighLight}),$original:t.$original}}),$original:t.$original}});return Object.assign(this.__state,{tips:i.default,loopArray4:c,loopArray5:f,activeTab:s}),this.__state}},{key:"anonymousFunc0",value:function(t){for(var e,n=arguments.length,r=Array(1<n?n-1:0),o=1;o<n;o++)r[o-1]=arguments[o];return this.anonymousFunc0Map[t]&&(e=this.anonymousFunc0Map)[t].apply(e,r)}}]),t}(),t.$$events=["anonymousFunc0"],t.$$componentPath="package-help/pages/use-tips/use-tips",e);s.config={navigationBarTitleText:"使用技巧"},exports.default=s,Component(require("../../../npm/@tarojs/taro-weapp/index.js").default.createComponent(s,!0))}(); 
 			}); 	require("package-help/pages/use-tips/use-tips.js");
 	