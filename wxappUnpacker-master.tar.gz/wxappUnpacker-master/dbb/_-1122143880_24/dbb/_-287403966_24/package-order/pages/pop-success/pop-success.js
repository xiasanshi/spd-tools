!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    var e, t, n = function(e, t) {
        if (Array.isArray(e)) return e;
        if (Symbol.iterator in Object(e)) return function(e, t) {
            var n = [], r = !0, o = !1, a = void 0;
            try {
                for (var i, u = e[Symbol.iterator](); !(r = (i = u.next()).done) && (n.push(i.value), 
                !t || n.length !== t); r = !0) ;
            } catch (e) {
                o = !0, a = e;
            } finally {
                try {
                    !r && u.return && u.return();
                } finally {
                    if (o) throw a;
                }
            }
            return n;
        }(e, t);
        throw new TypeError("Invalid attempt to destructure non-iterable instance");
    }, r = function() {
        function e(e, t) {
            for (var n = 0; n < t.length; n++) {
                var r = t[n];
                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
                Object.defineProperty(e, r.key, r);
            }
        }
        return function(t, n, r) {
            return n && e(t.prototype, n), r && e(t, r), t;
        };
    }(), o = require("../../../npm/@tarojs/taro-weapp/index.js"), a = s(o), i = require("../../../api/index.js"), u = s(require("../../../npm/classnames/index.js")), c = require("../../utils.js");
    function s(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }
    function p(e, t) {
        if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return !t || "object" != typeof t && "function" != typeof t ? e : t;
    }
    var l = (t = e = function() {
        function e() {
            var t, n, r;
            !function(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
            }(this, e);
            for (var o = arguments.length, a = Array(o), i = 0; i < o; i++) a[i] = arguments[i];
            return (n = r = p(this, (t = e.__proto__ || Object.getPrototypeOf(e)).call.apply(t, [ this ].concat(a)))).config = {
                navigationBarTitleText: "取宝成功"
            }, r.$usedState = [ "anonymousState__temp", "$compid__14", "orderDetailHelp", "freeTimePhrase", "iconTime", "pricingItem", "iconMoney", "icon24", "iconMoneys", "iconCharger", "maximumDailyAmount", "orderMaxPrice" ], 
            r.customComponents = [ "BuyoutModal" ], p(r, n);
        }
        return function(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
        }(e, a.default.Component), r(e, [ {
            key: "_constructor",
            value: function(t) {
                (function e(t, n, r) {
                    null === t && (t = Function.prototype);
                    var o = Object.getOwnPropertyDescriptor(t, n);
                    if (void 0 === o) {
                        var a = Object.getPrototypeOf(t);
                        return null === a ? void 0 : e(a, n, r);
                    }
                    if ("value" in o) return o.value;
                    var i = o.get;
                    return void 0 !== i ? i.call(r) : void 0;
                })(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "_constructor", this).call(this, t), 
                this.$$refs = new a.default.RefsArray();
            }
        }, {
            key: "_createData",
            value: function(e, t, r) {
                this.__state = e || this.state || {}, this.__props = t || this.props || {};
                var s = this.$prefix, p = (0, o.genCompid)(s + "$compid__14"), l = n(p, 2), f = l[0], d = l[1], y = (0, 
                o.useRouter)().params.popInfo, m = JSON.parse(decodeURIComponent(y || "{}")), g = m.orderSn, h = m.freeTimePhrase, v = m.maximumDailyAmount, _ = m.orderMaxPrice, b = m.pricingItem, j = void 0, w = null;
                wx.createInterstitialAd && (w = wx.createInterstitialAd({
                    adUnitId: "adunit-c269efde4e61fce9"
                }));
                var x = (0, o.useState)(!1), O = n(x, 2), P = O[0], T = O[1];
                (0, o.useEffect)(function() {
                    return w && setTimeout(function() {
                        w.show().catch(function(e) {
                            return console.log(e);
                        });
                    }, 250), function() {
                        "function" == typeof j && j();
                    };
                }), this.anonymousFunc0 = function() {
                    a.default.navigateTo({
                        url: "/package-help/pages/use-tips/use-tips"
                    });
                }, this.anonymousFunc1 = function() {
                    a.default.redirectTo({
                        url: "/package-order/pages/order-detail/order-detail?orderSn=" + g
                    });
                }, this.anonymousFunc2 = function() {
                    return T(!0);
                };
                var k = (0, u.default)("adContainer", "pageAd", "fade-out", {
                    "fade-in": !P
                });
                return o.propsManager.set({
                    orderSn: g,
                    showBuyoutModal: P,
                    handleBuyoutModal: T,
                    handleBuyout: function() {
                        var e = (0, c.requestPayOrder)(g, i.payForCharger, !1), t = e.payPromise, n = e.payCancel;
                        j = n, t.then(function(e) {
                            T(!1), a.default.redirectTo({
                                url: "/package-order/pages/order-detail/order-detail?orderSn=" + g
                            });
                        }).catch(function(e) {});
                    }
                }, d, f), Object.assign(this.__state, {
                    anonymousState__temp: k,
                    $compid__14: d,
                    orderDetailHelp: "/images/orderDetailHelp.png",
                    freeTimePhrase: h,
                    iconTime: "/package-order/images/iconTime.png",
                    pricingItem: b,
                    iconMoney: "/package-order/images/iconMoney.png",
                    icon24: "/package-order/images/icon24.png",
                    iconMoneys: "/package-order/images/iconMoneys.png",
                    iconCharger: "/package-order/images/iconCharger.png",
                    maximumDailyAmount: v,
                    orderMaxPrice: _
                }), this.__state;
            }
        }, {
            key: "anonymousFunc0",
            value: function(e) {}
        }, {
            key: "anonymousFunc1",
            value: function(e) {}
        }, {
            key: "anonymousFunc2",
            value: function(e) {}
        } ]), e;
    }(), e.$$events = [ "anonymousFunc0", "anonymousFunc1", "anonymousFunc2" ], e.$$componentPath = "package-order/pages/pop-success/pop-success", 
    t);
    l.config = {
        navigationBarTitleText: "取宝成功"
    }, exports.default = l, Component(require("../../../npm/@tarojs/taro-weapp/index.js").default.createComponent(l, !0));
}();