!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    var e, t, n = function(e, t) {
        if (Array.isArray(e)) return e;
        if (Symbol.iterator in Object(e)) return function(e, t) {
            var n = [], o = !0, a = !1, r = void 0;
            try {
                for (var i, s = e[Symbol.iterator](); !(o = (i = s.next()).done) && (n.push(i.value), 
                !t || n.length !== t); o = !0) ;
            } catch (e) {
                a = !0, r = e;
            } finally {
                try {
                    !o && s.return && s.return();
                } finally {
                    if (a) throw r;
                }
            }
            return n;
        }(e, t);
        throw new TypeError("Invalid attempt to destructure non-iterable instance");
    }, o = Object.assign || function(e) {
        for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var o in n) Object.prototype.hasOwnProperty.call(n, o) && (e[o] = n[o]);
        }
        return e;
    }, a = function() {
        function e(e, t) {
            for (var n = 0; n < t.length; n++) {
                var o = t[n];
                o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
                Object.defineProperty(e, o.key, o);
            }
        }
        return function(t, n, o) {
            return n && e(t.prototype, n), o && e(t, o), t;
        };
    }(), r = require("../../../npm/@tarojs/taro-weapp/index.js"), i = p(r), s = p(require("../../../npm/classnames/index.js")), u = require("../../../api/index.js"), l = require("../../../utils/index.js"), c = require("../../../constant/index.js"), m = require("../../../utils/sensors/index.js"), d = require("../../utils.js");
    function p(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }
    function h(e) {
        return function() {
            var t = e.apply(this, arguments);
            return new Promise(function(e, n) {
                return function o(a, r) {
                    try {
                        var i = t[a](r), s = i.value;
                    } catch (a) {
                        return void n(a);
                    }
                    if (!i.done) return Promise.resolve(s).then(function(e) {
                        o("next", e);
                    }, function(e) {
                        o("throw", e);
                    });
                    e(s);
                }("next");
            });
        };
    }
    function y(e, t) {
        if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return !t || "object" != typeof t && "function" != typeof t ? e : t;
    }
    var _ = "dbb-order-detail-page", f = c.ORDER_STATUS.NONE, g = c.ORDER_STATUS.RENTING, S = c.ORDER_STATUS.SUSPEND, T = c.ORDER_STATUS.WAIT_TO_PAY, v = c.ORDER_STATUS.COMPLETED, D = c.ORDER_STATUS.REFUND, O = c.ORDER_STATUS.BUY_OUT, k = (t = e = function() {
        function e() {
            var t, n, o;
            !function(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
            }(this, e);
            for (var a = arguments.length, r = Array(a), s = 0; s < a; s++) r[s] = arguments[s];
            return (n = o = y(this, (t = e.__proto__ || Object.getPrototypeOf(e)).call.apply(t, [ this ].concat(r)))).$usedState = [ "anonymousState__temp2", "anonymousState__temp3", "anonymousState__temp4", "anonymousState__temp5", "anonymousState__temp6", "anonymousState__temp7", "anonymousState__temp8", "anonymousState__temp9", "anonymousState__temp10", "anonymousState__temp11", "anonymousState__temp12", "anonymousState__temp13", "anonymousState__temp14", "anonymousState__temp15", "anonymousState__temp16", "anonymousState__temp17", "anonymousState__temp18", "anonymousState__temp19", "anonymousState__temp20", "anonymousState__temp21", "anonymousState__temp22", "anonymousState__temp23", "$compid__12", "$compid__13", "code", "CODE", "hasRequest", "PREFIX", "orderDetailHelp", "orderDetailDevider", "day", "hour", "discountTotal", "showDiscountTip", "category", "NONE", "WAIT_TO_PAY", "anonymousState__temp", "categoryPhrase", "tips", "min", "effectiveTotal", "originalTotal", "discountItem", "orderSn", "chargerSn", "rentStoreName", "backStoreName", "pricingItem", "showBuyoutModal", "checkinTime", "checkoutTime", "buyoutTime", "rentTime", "chargeSku", "model", "refType" ], 
            o.config = {
                navigationBarTitleText: "订单详情",
                enablePullDownRefresh: !0
            }, o.showPurchaseCharger = [ g, S ], o.notFinishOrder = [ g, S, T ], o.showRentDuration = [ T, v, D, O ], 
            o.showBackStoreName = [ v, T, D ], o.showTotalPrice = [ v, D, O ], o.showEffectivePrice = [ v, D, O ], 
            o.showBackTime = [ v, D ], o.showPurchaseTime = [ O ], o.state = {
                code: c.CODE.SUCCESS,
                hasRequest: !1,
                showBuyoutModal: !1,
                orderSn: "",
                chargerSn: "",
                category: "",
                categoryPhrase: "",
                rentStoreName: "",
                backStoreName: "",
                pricingItem: "",
                checkinTime: "",
                checkoutTime: "",
                discountTotal: "",
                effectiveTotal: "",
                originalTotal: "",
                buyoutTime: "",
                rentTime: "",
                tips: "",
                chargeSku: {},
                model: null,
                refType: null
            }, o.setOrderNavigationBarTitle = function(e) {
                "/package-order/pages/order-detail/order-detail".includes((0, l.getCurrentRoute)()) && i.default.setNavigationBarTitle({
                    title: 3 === e ? "微信支付分订单" : 1 === e ? "支付宝芝麻分订单" : "订单详情"
                });
            }, o.handleTouchMove = function(e) {
                e.preventDefault(), e.stopPropagation();
            }, o.customComponents = [ "XConnectFail", "BuyoutModal" ], y(o, n);
        }
        var t;
        return function(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
        }(e, r.Component), a(e, [ {
            key: "_constructor",
            value: function() {
                this.getOrderData = this.getOrderData.bind(this), this.handleBuyoutModal = this.handleBuyoutModal.bind(this), 
                this.payCharger = this.payCharger.bind(this), this.$$refs = new i.default.RefsArray();
            }
        }, {
            key: "componentWillMount",
            value: function() {
                var e = this.$router.params.orderSn;
                this.setState({
                    orderSn: e
                });
            }
        }, {
            key: "componentDidMount",
            value: function() {
                (0, m.$track)("DBB_CHECK_OrderDetailOnReady", {
                    result: "success"
                });
            }
        }, {
            key: "componentWillUnmount",
            value: function() {
                "function" == typeof this.payCancel && this.payCancel();
            }
        }, {
            key: "componentDidShow",
            value: function() {
                this.getOrderData();
            }
        }, {
            key: "onPullDownRefresh",
            value: function() {
                this.getOrderData();
            }
        }, {
            key: "getOrderData",
            value: function() {
                var e = this, t = this.state.orderSn;
                i.default.showLoading({
                    title: "加载中",
                    mask: !0
                }), (0, u.getOrderDetail)({
                    orderSn: t
                }).then(function(t) {
                    i.default.hideLoading();
                    var n = t.data, a = t.data.refType, r = t.code;
                    e.setOrderNavigationBarTitle(a), e.setState(o({}, n, {
                        code: r
                    })), e.handleBuyoutModal(!1), e.state.hasRequest || e.setState({
                        hasRequest: !0
                    }), i.default.stopPullDownRefresh();
                }).catch(function(t) {
                    i.default.hideLoading(), e.setState({
                        code: t.code
                    }), e.handleBuyoutModal(!1), i.default.stopPullDownRefresh();
                });
            }
        }, {
            key: "goToNearStore",
            value: function(e) {
                e.stopPropagation(), (0, l.tryGoToNearStore)(this, "navigateTo", null);
            }
        }, {
            key: "copySn",
            value: function() {
                var e = this.state.orderSn;
                i.default.setClipboardData({
                    data: e
                }).then(function() {
                    i.default.showToast({
                        title: "复制成功",
                        icon: "success"
                    });
                }).catch(function() {
                    i.default.showToast({
                        title: "复制失败"
                    });
                });
            }
        }, {
            key: "goToHelper",
            value: function() {
                i.default.navigateTo({
                    url: "/package-help/pages/question/question"
                });
            }
        }, {
            key: "goToDeviceChecking",
            value: function() {
                var e = this.state, t = e.orderSn, n = e.model;
                i.default.navigateTo({
                    url: "/package-order/pages/device-checking/device-checking?orderSn=" + t + "&model=" + (n || "RLB01")
                });
            }
        }, {
            key: "payOrder",
            value: (t = h(regeneratorRuntime.mark(function e() {
                var t, n, o, a, r, s, l, c, m, d, p, h;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (t = this.state, n = t.refType, o = t.orderSn, 3 === n) return i.default.showLoading({
                            title: "加载中",
                            mask: !0
                        }), e.next = 5, (0, u.getWeChatPayParms)(o).catch(function(e) {
                            return i.default.hideLoading(), e;
                        });
                        e.next = 11;
                        break;

                      case 5:
                        a = e.sent, r = a.data, i.default.hideLoading(), r && r.mchId && (s = r.mchId, l = r.nonceStr, 
                        c = r.outOrderNo, m = r.serviceId, d = r.sign, p = r.signType, h = r.timestamp, 
                        wx.openBusinessView({
                            businessType: "wxpayScoreDetail",
                            extraData: {
                                mch_id: s,
                                service_id: m,
                                out_order_no: c,
                                timestamp: h,
                                nonce_str: l,
                                sign_type: p,
                                sign: d
                            },
                            success: function(e) {
                                console.log(e);
                            },
                            fail: function(e) {
                                console.log(e);
                            },
                            complete: function() {}
                        })), e.next = 12;
                        break;

                      case 11:
                        1 === n && this.toPay(u.payForOrder, !0);

                      case 12:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            })), function() {
                return t.apply(this, arguments);
            })
        }, {
            key: "payCharger",
            value: function() {
                this.toPay(u.payForCharger, !1);
            }
        }, {
            key: "toPay",
            value: function(e, t) {
                var n = this, o = (0, d.requestPayOrder)(this.state.orderSn, e, t), a = o.payPromise, r = o.payCancel;
                this.payCancel = r, a.then(function(e) {
                    n.handleBuyoutModal(!1), n.getOrderData();
                }).catch(function(e) {});
            }
        }, {
            key: "handleBuyoutModal",
            value: function(e) {
                this.setState({
                    showBuyoutModal: e
                });
            }
        }, {
            key: "_createGenerateDisImgData",
            value: function(e) {
                var t = this;
                return function() {
                    var e = t.state, n = e.category, o = e.discountTotal;
                    return {
                        effectiveTotal: e.effectiveTotal,
                        PREFIX: _,
                        orderDetailDiscount: "/package-order/images/orderDetailDiscount.png",
                        orderDetailAllDis: "/package-order/images/orderDetailAllDis.png",
                        category: n,
                        COMPLETED: v,
                        discountTotal: o
                    };
                };
            }
        }, {
            key: "_createData",
            value: function(e, t, a) {
                var i = this;
                this.__state = e || this.state || {}, this.__props = t || this.props || {};
                var u = this.$prefix, m = (0, r.genCompid)(u + "$compid__12"), d = n(m, 2), p = d[0], h = d[1], y = (0, 
                r.genCompid)(u + "$compid__13"), g = n(y, 2), S = g[0], v = g[1], D = this.__state, O = D.code, k = D.hasRequest, E = D.orderSn, w = (D.chargerSn, 
                D.rentStoreName, D.backStoreName), x = (D.pricingItem, D.checkinTime), b = D.checkoutTime, P = D.category, R = (D.discountTotal, 
                D.effectiveTotal, D.originalTotal, D.buyoutTime), C = D.rentTime, B = (D.categoryPhrase, 
                D.tips, D.showBuyoutModal), N = (D.chargeSku, D.discountItem), F = this.showPurchaseCharger, M = this.notFinishOrder, j = this.showRentDuration, I = this.showBackStoreName, A = this.showTotalPrice, q = this.showEffectivePrice, $ = this.showBackTime, U = this.showPurchaseTime, z = (0, 
                l.timeStamp)(C, !0), L = z.day, W = z.hour, H = z.min, G = N && (0, l.isExsit)(M, P), X = k ? this._createGenerateDisImgData(u + "bzzzzzzzzz")() : null, Y = (0, 
                r.internal_inline_style)({
                    boxSizing: "border-box"
                });
                this.anonymousFunc0 = (0, l.throttleButton)(this.goToHelper);
                var K = k ? (0, s.default)(_ + "-status-area-desc") : null, V = k ? (0, r.internal_inline_style)((0, 
                l.isExsit)(M, P) ? {} : {
                    border: "none",
                    marginBottom: "10rpx",
                    padding: 0
                }) : null, J = k ? (0, r.internal_inline_style)({
                    maxWidth: "510rpx"
                }) : null, Q = (0, l.isExsit)(M, P) ? -1 != F.indexOf(P) ? "预估费用" : "费用合计" : null, Z = (0, 
                l.isExsit)(F, P) ? (0, r.internal_inline_style)(G ? {
                    marginTop: 0
                } : {}) : null, ee = (0, l.isExsit)(F, P) ? (0, s.default)("basic-btn", _ + "-status-area-option-purchase") : null;
                this.anonymousFunc1 = (0, l.throttleButton)(this.goToNearStore), this.anonymousFunc2 = (0, 
                l.throttleButton)(function() {
                    return i.handleBuyoutModal(!0);
                }), this.anonymousFunc3 = (0, l.throttleButton)(this.goToDeviceChecking), this.anonymousFunc4 = (0, 
                l.throttleButton)(this.payOrder);
                var te = k ? (0, r.internal_inline_style)({
                    alignItems: "flex-start",
                    justifyContent: "flex-start"
                }) : null, ne = (0, l.isExsit)(j, P) ? (0, l.timeStamp)(C) || "0分钟" : null, oe = k ? b && (0, 
                l.timestampToTime)(b) : null, ae = (0, l.isExsit)(I, P) && (0, l.isExsit)($, P) && w && x ? x && (0, 
                l.timestampToTime)(x) : null, re = (0, l.isExsit)(U, P) && R ? R && (0, l.timestampToTime)(R) : null, ie = k ? (0, 
                r.internal_inline_style)({
                    marginBottom: 0
                }) : null, se = k ? (0, s.default)("adContainer", "pageAd", "fade-out", {
                    "fade-in": !B
                }) : null, ue = (0, l.isExsit)(M, P), le = (0, l.isExsit)(M, P), ce = (0, l.isExsit)(F, P), me = (0, 
                l.isExsit)(j, P), de = (0, l.isExsit)(A, P), pe = (0, l.isExsit)(q, P), he = (0, 
                l.isExsit)(I, P) && (0, l.isExsit)($, P) && w && x, ye = (0, l.isExsit)(U, P) && R;
                return O === c.CODE.NETWORK_OFFLINE && r.propsManager.set(o(o({}, c.NET_ERR_CONF, {
                    onButtonClick: this.getOrderData
                })), h, p), r.propsManager.set({
                    orderSn: E,
                    showBuyoutModal: B,
                    handleBuyoutModal: this.handleBuyoutModal,
                    handleBuyout: this.payCharger
                }, v, S), Object.assign(this.__state, {
                    anonymousState__temp2: Y,
                    anonymousState__temp3: K,
                    anonymousState__temp4: V,
                    anonymousState__temp5: J,
                    anonymousState__temp6: Q,
                    anonymousState__temp7: Z,
                    anonymousState__temp8: ee,
                    anonymousState__temp9: te,
                    anonymousState__temp10: ne,
                    anonymousState__temp11: oe,
                    anonymousState__temp12: ae,
                    anonymousState__temp13: re,
                    anonymousState__temp14: ie,
                    anonymousState__temp15: se,
                    anonymousState__temp16: ue,
                    anonymousState__temp17: le,
                    anonymousState__temp18: ce,
                    anonymousState__temp19: me,
                    anonymousState__temp20: de,
                    anonymousState__temp21: pe,
                    anonymousState__temp22: he,
                    anonymousState__temp23: ye,
                    $compid__12: h,
                    $compid__13: v,
                    CODE: c.CODE,
                    PREFIX: _,
                    orderDetailHelp: "/images/orderDetailHelp.png",
                    orderDetailDevider: "/package-order/images/orderDetailDevider.png",
                    day: L,
                    hour: W,
                    showDiscountTip: G,
                    NONE: f,
                    WAIT_TO_PAY: T,
                    anonymousState__temp: X,
                    min: H,
                    discountItem: N
                }), this.__state;
            }
        }, {
            key: "anonymousFunc0",
            value: function(e) {}
        }, {
            key: "anonymousFunc1",
            value: function(e) {}
        }, {
            key: "anonymousFunc2",
            value: function(e) {}
        }, {
            key: "anonymousFunc3",
            value: function(e) {}
        }, {
            key: "anonymousFunc4",
            value: function(e) {}
        } ]), e;
    }(), e.$$events = [ "anonymousFunc0", "anonymousFunc1", "anonymousFunc2", "anonymousFunc3", "anonymousFunc4", "copySn" ], 
    e.$$componentPath = "package-order/pages/order-detail/order-detail", t);
    exports.default = k, Component(require("../../../npm/@tarojs/taro-weapp/index.js").default.createComponent(k, !0));
}();