!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    var e, t, n, o = function() {
        function e(e, t) {
            for (var n = 0; n < t.length; n++) {
                var o = t[n];
                o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
                Object.defineProperty(e, o.key, o);
            }
        }
        return function(t, n, o) {
            return n && e(t.prototype, n), o && e(t, o), t;
        };
    }(), a = require("../../../npm/@tarojs/taro-weapp/index.js"), r = (n = a) && n.__esModule ? n : {
        default: n
    }, i = require("../../../api/index.js"), c = require("../../../constant/index.js"), s = require("../../../utils/index.js"), l = require("../../../utils/sensors/index.js");
    function u(e, t) {
        if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return !t || "object" != typeof t && "function" != typeof t ? e : t;
    }
    var p = {
        RLB01: "https://images.wosaimg.com/a4/3d95de18b6b1a7471c37edd8232207bbf31c2b.gif",
        RLB02: "https://images.wosaimg.com/d4/c2ece3a02ad319a5691563efdad5ccacd07e9e.gif",
        RLBB24: "https://images.wosaimg.com/3c/55989185a3bc4351617346abae18bd62acb971.gif",
        RLBB48: "https://images.wosaimg.com/3c/55989185a3bc4351617346abae18bd62acb971.gif"
    }, d = (t = e = function() {
        function e() {
            var t, n, o;
            !function(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
            }(this, e);
            for (var a = arguments.length, l = Array(a), p = 0; p < a; p++) l[p] = arguments[p];
            return (n = o = u(this, (t = e.__proto__ || Object.getPrototypeOf(e)).call.apply(t, [ this ].concat(l)))).$usedState = [ "anonymousState__temp", "anonymousState__temp2", "deviceGif", "model", "mySeconds" ], 
            o.config = {
                navigationBarTitleText: "设备检测中"
            }, o.state = {
                mySeconds: 180
            }, o.intervaler = null, o.loopDetectPopUpStatus = function() {
                var e = o.state.orderSn, t = (0, s.loopHandler)(i.detectPopUpStatus, e, 18e4, 15e3, "status", 0), n = t.loopPromise, a = t.loopCancel;
                o.loopCancel = a, o.handleMySeconds("reset", 180), n.then(function(e) {
                    o.judgeStatus(e);
                }).catch(function(e) {});
            }, o.judgeStatus = function(e) {
                var t = e.status;
                switch (o.handleMySeconds("stop"), t) {
                  case c.POP_STATUS.SUCCESS:
                    r.default.showModal({
                        title: "弹宝成功",
                        content: "充电宝已弹出，请取走充电宝，有问题请联系客服",
                        confirmText: "确定",
                        showCancel: !1
                    }).then(function(e) {
                        e.confirm && r.default.reLaunch({
                            url: "/pages/index/index"
                        });
                    });
                    break;

                  case c.POP_STATUS.IN_POP_UP:
                    r.default.showModal({
                        title: "未检测到结果",
                        content: "请确认机柜已通电再重新检测，或联系客服人员处理",
                        confirmText: "联系客服",
                        cancelText: "重新检测",
                        cancelColor: "#576B95",
                        confirmColor: "#576B95"
                    }).then(function(e) {
                        e.confirm ? "/package-order/pages/device-checking/device-checking".includes((0, 
                        s.getCurrentRoute)()) && r.default.redirectTo({
                            url: "/package-help/pages/question/question"
                        }) : o.loopDetectPopUpStatus();
                    });
                    break;

                  case c.POP_STATUS.FAIL:
                    r.default.showModal({
                        title: "弹宝失败",
                        content: "充电宝未弹出，请重新租借",
                        confirmText: "确定",
                        showCancel: !1
                    }).then(function(e) {
                        e.confirm && r.default.reLaunch({
                            url: "/pages/index/index"
                        });
                    });
                }
            }, o.customComponents = [], u(o, n);
        }
        return function(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
        }(e, a.Component), o(e, [ {
            key: "_constructor",
            value: function(t) {
                (function e(t, n, o) {
                    null === t && (t = Function.prototype);
                    var a = Object.getOwnPropertyDescriptor(t, n);
                    if (void 0 === a) {
                        var r = Object.getPrototypeOf(t);
                        return null === r ? void 0 : e(r, n, o);
                    }
                    if ("value" in a) return a.value;
                    var i = a.get;
                    return void 0 !== i ? i.call(o) : void 0;
                })(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "_constructor", this).call(this, t), 
                this.$$refs = new r.default.RefsArray();
            }
        }, {
            key: "componentWillMount",
            value: function() {
                var e = this, t = this.$router.params, n = t.orderSn, o = t.model;
                this.setState({
                    orderSn: n,
                    model: o
                }, function() {
                    e.loopDetectPopUpStatus();
                }), (0, l.$track)("DBB_CHECK_DeviceCheckingOnReady", {
                    result: "success"
                });
            }
        }, {
            key: "componentWillUnmount",
            value: function() {
                this.loopCancel && this.loopCancel();
            }
        }, {
            key: "handleMySeconds",
            value: function(e, t) {
                switch (e) {
                  case "reset":
                    this.setState({
                        mySeconds: t || 180
                    }), this.intervalDelSec();
                    break;

                  case "resume":
                    this.intervalDelSec();
                    break;

                  case "stop":
                    clearInterval(this.intervaler);
                }
            }
        }, {
            key: "intervalDelSec",
            value: function() {
                var e = this;
                this.intervaler = setInterval(function() {
                    var t = e.state.mySeconds;
                    0 < t ? e.setState({
                        mySeconds: t - 1
                    }) : clearInterval(e.intervaler);
                }, 1e3);
            }
        }, {
            key: "_createData",
            value: function(e, t, n) {
                this.__state = e || this.state || {}, this.__props = t || this.props || {}, this.$prefix;
                var o = this.__state, r = o.model, i = (o.mySeconds, (0, a.internal_inline_style)({
                    width: "80rpx",
                    display: "inline-block"
                })), c = "RLBB24RLBB48".includes(r);
                return Object.assign(this.__state, {
                    anonymousState__temp: i,
                    anonymousState__temp2: c,
                    deviceGif: p,
                    model: r
                }), this.__state;
            }
        } ]), e;
    }(), e.$$events = [], e.$$componentPath = "package-order/pages/device-checking/device-checking", 
    t);
    exports.default = d, Component(require("../../../npm/@tarojs/taro-weapp/index.js").default.createComponent(d, !0));
}();