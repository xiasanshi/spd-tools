!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    var e, t, r = Object.assign || function(e) {
        for (var t = 1; t < arguments.length; t++) {
            var r = arguments[t];
            for (var o in r) Object.prototype.hasOwnProperty.call(r, o) && (e[o] = r[o]);
        }
        return e;
    }, o = function() {
        function e(e, t) {
            for (var r = 0; r < t.length; r++) {
                var o = t[r];
                o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
                Object.defineProperty(e, o.key, o);
            }
        }
        return function(t, r, o) {
            return r && e(t.prototype, r), o && e(t, o), t;
        };
    }(), n = require("../../../npm/@tarojs/taro-weapp/index.js"), i = p(n), a = p(require("../../../utils/min-lodash.js")), s = p(require("../../../npm/classnames/index.js")), u = require("../../../api/index.js"), c = require("../../../utils/index.js"), l = require("../../../constant/index.js");
    function p(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }
    function d(e) {
        return function() {
            var t = e.apply(this, arguments);
            return new Promise(function(e, r) {
                return function o(n, i) {
                    try {
                        var a = t[n](i), s = a.value;
                    } catch (n) {
                        return void r(n);
                    }
                    if (!a.done) return Promise.resolve(s).then(function(e) {
                        o("next", e);
                    }, function(e) {
                        o("throw", e);
                    });
                    e(s);
                }("next");
            });
        };
    }
    function f(e, t) {
        if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return !t || "object" != typeof t && "function" != typeof t ? e : t;
    }
    var g = (t = e = function() {
        function e() {
            var t, r, o;
            !function(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
            }(this, e);
            for (var n = arguments.length, i = Array(n), a = 0; a < n; a++) i[a] = arguments[a];
            return (r = o = f(this, (t = e.__proto__ || Object.getPrototypeOf(e)).call.apply(t, [ this ].concat(i)))).$usedState = [ "anonymousState__temp17", "loopArray1", "$compid__11", "PREFIX", "code", "CODE", "ordersEmpty", "orderList", "Go", "canShowFooterLoading", "hasRequest", "isRequest", "noMore", "requestConfig" ], 
            o.config = {
                navigationBarTitleText: "我的订单",
                enablePullDownRefresh: !0
            }, o.state = {
                code: l.CODE.SUCCESS,
                orderList: [],
                hasRequest: !1,
                canShowFooterLoading: !1,
                requestConfig: {
                    noMore: !1,
                    isRequest: !1,
                    ctime: "",
                    pageSize: 7
                }
            }, o.overOrder = [ l.ORDER_STATUS.BUY_OUT, l.ORDER_STATUS.REFUND, l.ORDER_STATUS.COMPLETED ], 
            o.notShowPriceOrder = [ l.ORDER_STATUS.RENTING, l.ORDER_STATUS.SUSPEND ], o.anonymousFunc0Map = {}, 
            o.customComponents = [ "XConnectFail", "XFooterLoading", "XDivider" ], f(o, r);
        }
        var t;
        return function(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
        }(e, n.Component), o(e, [ {
            key: "_constructor",
            value: function(t) {
                (function e(t, r, o) {
                    null === t && (t = Function.prototype);
                    var n = Object.getOwnPropertyDescriptor(t, r);
                    if (void 0 === n) {
                        var i = Object.getPrototypeOf(t);
                        return null === i ? void 0 : e(i, r, o);
                    }
                    if ("value" in n) return n.value;
                    var a = n.get;
                    return void 0 !== a ? a.call(o) : void 0;
                })(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "_constructor", this).call(this, t), 
                this.$$refs = new i.default.RefsArray();
            }
        }, {
            key: "componentWillMount",
            value: (t = d(regeneratorRuntime.mark(function e() {
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            })), function() {
                return t.apply(this, arguments);
            })
        }, {
            key: "componentDidMount",
            value: function() {
                this.getOrderList();
            }
        }, {
            key: "onReachBottom",
            value: function() {
                this.getOrderList();
            }
        }, {
            key: "onPullDownRefresh",
            value: function() {
                var e = this;
                this.setState({
                    requestConfig: r({}, this.state.requestConfig, {
                        noMore: !1,
                        isRequest: !1,
                        ctime: ""
                    })
                }, function() {
                    e.getOrderList(!0);
                });
            }
        }, {
            key: "judgeShowFooterLoading",
            value: function() {
                var e = this.state, t = e.orderList, r = e.requestConfig.pageSize;
                t.length >= r && this.setState({
                    canShowFooterLoading: !0
                });
            }
        }, {
            key: "getOrderList",
            value: function(e) {
                var t = this, o = 0 < arguments.length && void 0 !== e && e, n = this.state, s = n.canShowFooterLoading, c = n.requestConfig, l = c.noMore, p = c.isRequest, d = c.ctime, f = c.pageSize, g = this.state.orderList;
                if (!l && !p) {
                    var h = {
                        pageSize: f,
                        ctime: d
                    };
                    this.setState({
                        requestConfig: r({}, this.state.requestConfig, {
                            isRequest: !0
                        })
                    }), (0, u.getOrderList)(h).then(function(e) {
                        var n = e.data, u = e.code;
                        if (a.default.isArray(n)) {
                            var c = o ? n : g.concat(n);
                            t.setState({
                                code: u,
                                orderList: c,
                                hasRequest: !0,
                                requestConfig: r({}, t.state.requestConfig, {
                                    isRequest: !1,
                                    noMore: n.length < f,
                                    ctime: 0 != c.length ? a.default.last(c).ctime : ""
                                })
                            }, function() {
                                i.default.stopPullDownRefresh(), s || t.judgeShowFooterLoading();
                            });
                        }
                    }).catch(function(e) {
                        t.setState({
                            code: e.code,
                            hasRequest: !0,
                            requestConfig: r({}, t.state.requestConfig, {
                                isRequest: !1
                            })
                        }), i.default.stopPullDownRefresh();
                    });
                }
            }
        }, {
            key: "navigate2detail",
            value: function(e) {
                i.default.navigateTo({
                    url: "/package-order/pages/order-detail/order-detail?orderSn=" + e
                });
            }
        }, {
            key: "_createData",
            value: function(e, t, o) {
                var i = this;
                this.__state = e || this.state || {}, this.__props = t || this.props || {};
                var u = this.$prefix, p = function(e, t) {
                    if (Array.isArray(e)) return e;
                    if (Symbol.iterator in Object(e)) return function(e, t) {
                        var r = [], o = !0, n = !1, i = void 0;
                        try {
                            for (var a, s = e[Symbol.iterator](); !(o = (a = s.next()).done) && (r.push(a.value), 
                            !t || r.length !== t); o = !0) ;
                        } catch (e) {
                            n = !0, i = e;
                        } finally {
                            try {
                                !o && s.return && s.return();
                            } finally {
                                if (n) throw i;
                            }
                        }
                        return r;
                    }(e, t);
                    throw new TypeError("Invalid attempt to destructure non-iterable instance");
                }((0, n.genCompid)(u + "$compid__11"), 2), d = p[0], f = p[1], g = this.__state, h = g.code, m = g.orderList, y = g.hasRequest, _ = (g.canShowFooterLoading, 
                g.requestConfig), v = _.noMore, O = _.isRequest, S = this.overOrder, R = this.notShowPriceOrder, $ = y && a.default.isEmpty(m), q = $ ? [] : m.map(function(e, t) {
                    e = {
                        $original: (0, n.internal_get_original)(e)
                    };
                    var r = (0, c.timeStamp)(e.$original.rentTime, !0), o = r.day, a = r.hour, u = r.min, l = String(e.$original.orderSn), p = "azzzz" + t;
                    return i.anonymousFunc0Map[p] = (0, c.throttleButton)(function() {
                        return i.navigate2detail(e.$original.orderSn);
                    }), {
                        day: o,
                        hour: a,
                        min: u,
                        $loopState__temp2: l,
                        _$indexKey: p,
                        $loopState__temp4: (0, s.default)("dbb-orders-page-item-status"),
                        $loopState__temp6: (0, n.internal_inline_style)(-1 !== S.indexOf(e.$original.category) ? {
                            color: "#999999"
                        } : {}),
                        $loopState__temp8: -1 == R.indexOf(e.$original.category) ? -1 !== S.indexOf(e.$original.category) ? "/package-order/images/ordersAmountA.svg" : "/package-order/images/ordersAmountB.svg" : null,
                        $loopState__temp10: -1 == R.indexOf(e.$original.category) ? (0, n.internal_inline_style)(-1 !== S.indexOf(e.$original.category) ? {
                            color: "#999999"
                        } : {}) : null,
                        $loopState__temp12: -1 !== S.indexOf(e.$original.category) ? "/package-order/images/ordersRentimeA.svg" : "/package-order/images/ordersRentimeB.svg",
                        $loopState__temp14: (0, n.internal_inline_style)(-1 !== S.indexOf(e.$original.category) ? {
                            color: "#999999"
                        } : {}),
                        $loopState__temp16: (0, c.timestampToTime)(e.$original.ctime),
                        $loopState__temp19: -1 == R.indexOf(e.$original.category),
                        $original: e.$original
                    };
                });
                return h == l.CODE.NETWORK_OFFLINE && n.propsManager.set(r(r({}, l.NET_ERR_CONF, {
                    onButtonClick: this.getOrderList.bind(this)
                })), f, d), Object.assign(this.__state, {
                    anonymousState__temp17: $,
                    loopArray1: q,
                    $compid__11: f,
                    PREFIX: "dbb-orders-page",
                    CODE: l.CODE,
                    ordersEmpty: "/package-order/images/ordersEmpty.png",
                    Go: "/images/Go.png",
                    isRequest: O,
                    noMore: v
                }), this.__state;
            }
        }, {
            key: "anonymousFunc0",
            value: function(e) {
                for (var t, r = arguments.length, o = Array(1 < r ? r - 1 : 0), n = 1; n < r; n++) o[n - 1] = arguments[n];
                return this.anonymousFunc0Map[e] && (t = this.anonymousFunc0Map)[e].apply(t, o);
            }
        } ]), e;
    }(), e.$$events = [ "anonymousFunc0" ], e.$$componentPath = "package-order/pages/orders/orders", 
    t);
    exports.default = g, Component(require("../../../npm/@tarojs/taro-weapp/index.js").default.createComponent(g, !0));
}();