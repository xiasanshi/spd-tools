!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    }), exports.requestPayOrder = void 0;
    var e, n = require("../npm/@tarojs/taro-weapp/index.js"), t = (e = n) && e.__esModule ? e : {
        default: e
    }, r = require("../api/index.js"), o = require("../utils/index.js");
    exports.requestPayOrder = function(e, n, i) {
        var a, u = void 0, c = void 0, s = void 0, d = new Promise(function(e, n) {
            u = e, c = n;
        }), f = (a = function(e) {
            return function() {
                var n = e.apply(this, arguments);
                return new Promise(function(e, t) {
                    return function r(o, i) {
                        try {
                            var a = n[o](i), u = a.value;
                        } catch (o) {
                            return void t(o);
                        }
                        if (!a.done) return Promise.resolve(u).then(function(e) {
                            r("next", e);
                        }, function(e) {
                            r("throw", e);
                        });
                        e(u);
                    }("next");
                });
            };
        }(regeneratorRuntime.mark(function r() {
            var o, i;
            return regeneratorRuntime.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    return t.default.showLoading({
                        title: "支付中",
                        mask: !0
                    }), r.prev = 1, r.next = 4, n({
                        orderSn: e
                    });

                  case 4:
                    o = r.sent, i = o.data, l(i, "orderSn"), r.next = 12;
                    break;

                  case 9:
                    r.prev = 9, r.t0 = r.catch(1), v("网络错误，请稍后重试");

                  case 12:
                  case "end":
                    return r.stop();
                }
            }, r, void 0, [ [ 1, 9 ] ]);
        })), function() {
            return a.apply(this, arguments);
        }), l = function(e, n) {
            if (e) {
                var t = e.status, r = e.tsn;
                switch (t) {
                  case "FINISHED":
                    h(!0);
                    break;

                  case "FAILED":
                    h(!1, "付款失败", i ? "您的支付宝账户余额不足，充值后将自动扣款" : "请确保支付宝/微信账户资金足够再付款");
                    break;

                  case "PENDING":
                    "orderSn" === n ? p(r) : "tSn" === n && h(!1, "付款超时", "请稍后再试");
                    break;

                  default:
                    v("网络错误，请稍后重试");
                }
            } else v("网络错误，请稍后重试");
        }, p = function(e) {
            var n = (0, o.loopHandler)(r.queryTsnStatus, e, 3e4, 3e3, "status", "PENDING"), i = n.loopPromise, a = n.loopCancel;
            s = a, i.then(function(e) {
                l(e, "tSn");
            }).catch(function(e) {
                c(null), t.default.hideLoading();
            });
        }, h = function(e, n, r) {
            t.default.hideLoading(), e ? ((0, o.hideToastAftLoading)({
                title: "付款成功",
                icon: "none",
                duration: 1e3
            }), u({})) : t.default.showModal({
                title: n,
                content: r,
                confirmText: "知道了",
                cancelText: "返回首页"
            }).then(function(e) {
                e.confirm ? v() : t.default.reLaunch({
                    url: "/pages/index/index"
                });
            });
        }, v = function(e) {
            t.default.hideLoading(), e && (0, o.hideToastAftLoading)({
                title: "网络错误，请稍后重试",
                icon: "none",
                duration: 2e3
            }), c(null);
        };
        return f(), {
            payPromise: d,
            payCancel: function() {
                c(null), "function" == typeof s && s();
            }
        };
    };
}();