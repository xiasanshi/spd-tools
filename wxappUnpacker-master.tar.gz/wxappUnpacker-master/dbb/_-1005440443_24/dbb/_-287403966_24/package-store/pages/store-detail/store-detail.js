!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    var t, e, n = Object.assign || function(t) {
        for (var e = 1; e < arguments.length; e++) {
            var n = arguments[e];
            for (var a in n) Object.prototype.hasOwnProperty.call(n, a) && (t[a] = n[a]);
        }
        return t;
    }, a = function() {
        function t(t, e) {
            for (var n = 0; n < e.length; n++) {
                var a = e[n];
                a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), 
                Object.defineProperty(t, a.key, a);
            }
        }
        return function(e, n, a) {
            return n && t(e.prototype, n), a && t(e, a), e;
        };
    }(), o = require("../../../npm/@tarojs/taro-weapp/index.js"), r = u(o), s = u(require("../../../npm/classnames/index.js")), i = require("../../../utils/index.js");
    function u(t) {
        return t && t.__esModule ? t : {
            default: t
        };
    }
    function l(t, e) {
        if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return !e || "object" != typeof e && "function" != typeof e ? t : e;
    }
    var c = (e = t = function() {
        function t() {
            var e, a, o;
            !function(t, e) {
                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
            }(this, t);
            for (var s = arguments.length, u = Array(s), c = 0; c < s; c++) u[c] = arguments[c];
            return (a = o = l(this, (e = t.__proto__ || Object.getPrototypeOf(t)).call.apply(e, [ this ].concat(u)))).$usedState = [ "anonymousState__temp", "anonymousState__temp2", "anonymousState__temp3", "anonymousState__temp4", "detail", "storeDetailBusRange", "storeDetailCharger" ], 
            o.config = {
                navigationBarTitleText: "门店详情"
            }, o.interstitialAd = null, o.state = {
                detail: {}
            }, o.toMapRoute = function() {
                var t = o.state.detail;
                r.default.openLocation({
                    longitude: +t.longitude,
                    latitude: +t.latitude,
                    name: t.storeName || "-",
                    address: t.address || "-"
                });
            }, o.judgeGoToNearStore = function() {
                r.default.getCurrentPages().map(function(t) {
                    return t.route;
                }).includes("package-store/pages/near-store/near-store") ? r.default.navigateBack() : (0, 
                i.tryGoToNearStore)(o, "navigateTo", n({}, (0, i.getGlobalData)("location")));
            }, o.goToUseTips = function() {
                r.default.navigateTo({
                    url: "/package-help/pages/use-tips/use-tips"
                });
            }, o.customComponents = [], l(o, a);
        }
        return function(t, e) {
            if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
            t.prototype = Object.create(e && e.prototype, {
                constructor: {
                    value: t,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
        }(t, o.Component), a(t, [ {
            key: "_constructor",
            value: function(e) {
                (function t(e, n, a) {
                    null === e && (e = Function.prototype);
                    var o = Object.getOwnPropertyDescriptor(e, n);
                    if (void 0 === o) {
                        var r = Object.getPrototypeOf(e);
                        return null === r ? void 0 : t(r, n, a);
                    }
                    if ("value" in o) return o.value;
                    var s = o.get;
                    return void 0 !== s ? s.call(a) : void 0;
                })(t.prototype.__proto__ || Object.getPrototypeOf(t.prototype), "_constructor", this).call(this, e), 
                this.$$refs = new r.default.RefsArray();
            }
        }, {
            key: "componentWillMount",
            value: function() {
                var t = JSON.parse((0, i.getGlobalData)("currentStore") || "{}");
                t && this.setState({
                    detail: t
                }), wx.createInterstitialAd && (this.interstitialAd = wx.createInterstitialAd({
                    adUnitId: "adunit-28961433a9a310ea"
                }));
            }
        }, {
            key: "componentDidMount",
            value: function() {
                var t = this;
                this.interstitialAd && setTimeout(function() {
                    t.interstitialAd.show().catch(function(t) {
                        return console.log(t);
                    });
                }, 250);
            }
        }, {
            key: "_createData",
            value: function(t, e, n) {
                this.__state = t || this.state || {}, this.__props = e || this.props || {}, this.$prefix;
                var a = this.__state.detail, r = (0, s.default)("store-status", a.canRentNum ? "store-status-valid" : "store-status-invalid"), u = (0, 
                o.internal_inline_style)({
                    marginLeft: "46rpx"
                }), l = (0, s.default)("store-status", a.canReturnNum ? "store-status-valid" : "store-status-invalid");
                this.anonymousFunc0 = function() {
                    return (0, i.scanCode4Business)("navigateTo");
                }, this.anonymousFunc1 = (0, i.throttleButton)(this.toMapRoute);
                var c = (0, i.calcDistance)(a.distance);
                return Object.assign(this.__state, {
                    anonymousState__temp: r,
                    anonymousState__temp2: u,
                    anonymousState__temp3: l,
                    anonymousState__temp4: c,
                    storeDetailBusRange: "/package-store/images/storeDetailBusRange.png",
                    storeDetailCharger: "/package-store/images/storeDetailCharger.png"
                }), this.__state;
            }
        }, {
            key: "anonymousFunc0",
            value: function(t) {}
        }, {
            key: "anonymousFunc1",
            value: function(t) {}
        } ]), t;
    }(), t.$$events = [ "anonymousFunc0", "anonymousFunc1", "judgeGoToNearStore", "goToUseTips" ], 
    t.$$componentPath = "package-store/pages/store-detail/store-detail", e);
    exports.default = c, Component(require("../../../npm/@tarojs/taro-weapp/index.js").default.createComponent(c, !0));
}();