!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    var t, e, r = function(t, e) {
        if (Array.isArray(t)) return t;
        if (Symbol.iterator in Object(t)) return function(t, e) {
            var r = [], n = !0, o = !1, a = void 0;
            try {
                for (var i, s = t[Symbol.iterator](); !(n = (i = s.next()).done) && (r.push(i.value), 
                !e || r.length !== e); n = !0) ;
            } catch (t) {
                o = !0, a = t;
            } finally {
                try {
                    !n && s.return && s.return();
                } finally {
                    if (o) throw a;
                }
            }
            return r;
        }(t, e);
        throw new TypeError("Invalid attempt to destructure non-iterable instance");
    }, n = Object.assign || function(t) {
        for (var e = 1; e < arguments.length; e++) {
            var r = arguments[e];
            for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (t[n] = r[n]);
        }
        return t;
    }, o = function() {
        function t(t, e) {
            for (var r = 0; r < e.length; r++) {
                var n = e[r];
                n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
                Object.defineProperty(t, n.key, n);
            }
        }
        return function(e, r, n) {
            return r && t(e.prototype, r), n && t(e, n), e;
        };
    }(), a = require("../../../npm/@tarojs/taro-weapp/index.js"), i = p(a), s = p(require("../../../utils/min-lodash.js")), u = require("../../../api/index.js"), c = require("../../../constant/index.js"), l = require("../../../utils/index.js");
    function p(t) {
        return t && t.__esModule ? t : {
            default: t
        };
    }
    function f(t) {
        return function() {
            var e = t.apply(this, arguments);
            return new Promise(function(t, r) {
                return function n(o, a) {
                    try {
                        var i = e[o](a), s = i.value;
                    } catch (o) {
                        return void r(o);
                    }
                    if (!i.done) return Promise.resolve(s).then(function(t) {
                        n("next", t);
                    }, function(t) {
                        n("throw", t);
                    });
                    t(s);
                }("next");
            });
        };
    }
    function h(t, e) {
        if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return !e || "object" != typeof e && "function" != typeof e ? t : e;
    }
    var d = [ {
        title: "全部门店"
    }, {
        title: "可借门店"
    }, {
        title: "可还门店"
    } ], g = (e = t = function() {
        function t() {
            var e, r, n;
            !function(t, e) {
                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
            }(this, t);
            for (var o = arguments.length, a = Array(o), s = 0; s < o; s++) a[s] = arguments[s];
            return (r = n = h(this, (e = t.__proto__ || Object.getPrototypeOf(t)).call.apply(e, [ this ].concat(a)))).$usedState = [ "loopArray2", "$compid__16", "$compid__17", "list", "hasRequest", "nearStoreEmpty", "code", "CODE", "activeCategory" ], 
            n.config = {
                navigationBarTitleText: "附近门店"
            }, n.state = {
                list: [],
                code: c.CODE.SUCCESS,
                hasRequest: !1,
                activeCategory: 0
            }, n.goToStoreDetail = function(t) {
                var e = t.currentTarget.dataset.key, r = n.state.list[e];
                r && ((0, l.setGlobalData)("currentStore", JSON.stringify(r)), i.default.navigateTo({
                    url: "/package-store/pages/store-detail/store-detail"
                }));
            }, n.customComponents = [ "XTitleTabs", "XStoreInfo", "XDivider", "XConnectFail" ], 
            h(n, r);
        }
        var e;
        return function(t, e) {
            if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
            t.prototype = Object.create(e && e.prototype, {
                constructor: {
                    value: t,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
        }(t, a.Component), o(t, [ {
            key: "_constructor",
            value: function() {
                this.goToStoreDetail = this.goToStoreDetail.bind(this), this.$$refs = new i.default.RefsArray();
            }
        }, {
            key: "componentWillMount",
            value: function() {
                var t = this, e = this.$router.params, r = e.latitude, n = e.longitude;
                this.setState({
                    location: {
                        latitude: r,
                        longitude: n
                    }
                }, function() {
                    t.getStores();
                });
            }
        }, {
            key: "componentWillUnmount",
            value: function() {}
        }, {
            key: "getStores",
            value: (e = f(regeneratorRuntime.mark(function t() {
                var e, r, o, a, l, p, f, h;
                return regeneratorRuntime.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (e = this.state, r = e.location, o = e.activeCategory, r && r.latitude && r.longitude) {
                            t.next = 13;
                            break;
                        }
                        return t.prev = 2, t.next = 5, i.default.getLocation();

                      case 5:
                        a = t.sent, r = {
                            latitude: a.latitude,
                            longitude: a.longitude
                        }, t.next = 13;
                        break;

                      case 9:
                        return t.prev = 9, t.t0 = t.catch(2), i.default.showToast({
                            title: "请授权位置查看附近门店",
                            icon: "none",
                            duration: 1500
                        }), t.abrupt("return");

                      case 13:
                        return l = n({
                            type: o
                        }, r), t.prev = 14, i.default.showLoading({
                            title: "加载中",
                            mask: !0
                        }), t.next = 18, (0, u.getStoreList)(l).catch(function(t) {
                            return t;
                        });

                      case 18:
                        p = t.sent, f = p.data, h = p.code, s.default.isArray(f) ? this.setState({
                            code: h,
                            list: f,
                            hasRequest: !0
                        }) : this.setState({
                            code: c.CODE.NETWORK_OFFLINE,
                            hasRequest: !0
                        }), i.default.hideLoading(), t.next = 28;
                        break;

                      case 25:
                        t.prev = 25, t.t1 = t.catch(14), this.setState({
                            code: c.CODE.NETWORK_OFFLINE,
                            hasRequest: !0
                        }, i.default.hideLoading);

                      case 28:
                      case "end":
                        return t.stop();
                    }
                }, t, this, [ [ 2, 9 ], [ 14, 25 ] ]);
            })), function() {
                return e.apply(this, arguments);
            })
        }, {
            key: "switchCategory",
            value: function(t) {
                var e = this;
                this.state.activeCategory !== t && this.setState({
                    activeCategory: t,
                    hasRequest: !1,
                    list: []
                }, function() {
                    e.getStores();
                });
            }
        }, {
            key: "_createData",
            value: function(t, e, o) {
                this.__state = t || this.state || {}, this.__props = e || this.props || {};
                var i = this.$prefix, s = (0, a.genCompid)(i + "$compid__16"), u = r(s, 2), l = u[0], p = u[1], f = (0, 
                a.genCompid)(i + "$compid__17"), h = r(f, 2), g = h[0], y = h[1], v = this.__state, _ = v.code, m = v.list, b = v.hasRequest, C = v.activeCategory, S = 0 === m.length && b ? [] : m.map(function(t, e) {
                    t = {
                        $original: (0, a.internal_get_original)(t)
                    };
                    var n = String(t.$original.storeSn), o = (0, a.genCompid)(i + "czzzzzzzzz" + e, !0), s = r(o, 2), u = s[0], c = s[1];
                    return 0 === m.length && b || a.propsManager.set({
                        props: t.$original
                    }, c, u), {
                        $loopState__temp2: n,
                        $compid__15: c,
                        $original: t.$original
                    };
                });
                return a.propsManager.set({
                    titleList: d,
                    activeCategory: C,
                    switchCategory: this.switchCategory.bind(this)
                }, p, l), _ === c.CODE.NETWORK_OFFLINE && a.propsManager.set(n(n({}, c.NET_ERR_CONF, {
                    onButtonClick: this.getStores.bind(this)
                })), y, g), Object.assign(this.__state, {
                    loopArray2: S,
                    $compid__16: p,
                    $compid__17: y,
                    nearStoreEmpty: "/package-store/images/nearStoreEmpty.png",
                    CODE: c.CODE
                }), this.__state;
            }
        } ]), t;
    }(), t.$$events = [ "goToStoreDetail" ], t.$$componentPath = "package-store/pages/near-store/near-store", 
    e);
    exports.default = g, Component(require("../../../npm/@tarojs/taro-weapp/index.js").default.createComponent(g, !0));
}();