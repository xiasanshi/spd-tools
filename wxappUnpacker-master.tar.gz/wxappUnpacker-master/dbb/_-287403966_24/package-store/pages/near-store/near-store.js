// package-store/pages/near-store/near-store.js
Page({data: {}})