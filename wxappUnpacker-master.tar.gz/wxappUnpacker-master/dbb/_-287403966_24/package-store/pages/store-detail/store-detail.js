// package-store/pages/store-detail/store-detail.js
Page({data: {}})