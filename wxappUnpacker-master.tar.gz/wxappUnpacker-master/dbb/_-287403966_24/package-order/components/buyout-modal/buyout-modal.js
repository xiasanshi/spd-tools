// package-order/components/buyout-modal/buyout-modal.js
Page({data: {}})