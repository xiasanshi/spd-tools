// package-order/pages/order-detail/order-detail.js
Page({data: {}})