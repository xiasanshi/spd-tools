// package-order/pages/device-checking/device-checking.js
Page({data: {}})