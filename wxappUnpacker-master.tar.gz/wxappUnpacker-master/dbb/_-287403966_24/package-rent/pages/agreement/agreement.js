// package-rent/pages/agreement/agreement.js
Page({data: {}})