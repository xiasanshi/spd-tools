// package-rent/pages/rent-fail/rent-fail.js
Page({data: {}})