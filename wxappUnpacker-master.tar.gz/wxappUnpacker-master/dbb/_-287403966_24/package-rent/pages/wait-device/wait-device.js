// package-rent/pages/wait-device/wait-device.js
Page({data: {}})