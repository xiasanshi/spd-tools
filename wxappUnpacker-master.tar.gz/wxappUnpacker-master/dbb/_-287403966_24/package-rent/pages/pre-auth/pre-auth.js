// package-rent/pages/pre-auth/pre-auth.js
Page({data: {}})