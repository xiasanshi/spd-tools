// package-rent/components/phone-number/index.js
Page({data: {}})