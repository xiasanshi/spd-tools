// package-rent/components/rlbii/rlbii.js
Page({data: {}})