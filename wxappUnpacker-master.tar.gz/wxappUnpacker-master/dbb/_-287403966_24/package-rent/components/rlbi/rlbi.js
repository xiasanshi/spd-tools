// package-rent/components/rlbi/rlbi.js
Page({data: {}})