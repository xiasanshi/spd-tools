// package-rent/components/rlbxii/rlbxii.js
Page({data: {}})