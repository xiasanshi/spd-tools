// package-rent/components/screen-loading/screen-loading.js
Page({data: {}})