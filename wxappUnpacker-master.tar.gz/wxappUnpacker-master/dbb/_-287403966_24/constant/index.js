!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    var e = require("./order.js");
    Object.defineProperty(exports, "ORDER_STATUS", {
        enumerable: !0,
        get: function() {
            return e.ORDER_STATUS;
        }
    }), Object.defineProperty(exports, "AUTH_CODE", {
        enumerable: !0,
        get: function() {
            return e.AUTH_CODE;
        }
    }), Object.defineProperty(exports, "ALIPAY_FROZEN_CODE", {
        enumerable: !0,
        get: function() {
            return e.ALIPAY_FROZEN_CODE;
        }
    });
    var r = require("./device.js");
    Object.defineProperty(exports, "POP_STATUS", {
        enumerable: !0,
        get: function() {
            return r.POP_STATUS;
        }
    }), Object.defineProperty(exports, "CREATE_ORDER_ERROR", {
        enumerable: !0,
        get: function() {
            return r.CREATE_ORDER_ERROR;
        }
    }), Object.defineProperty(exports, "DEVICE_STATUS_REASONS", {
        enumerable: !0,
        get: function() {
            return r.DEVICE_STATUS_REASONS;
        }
    }), Object.defineProperty(exports, "POP_ORDER_RESULT", {
        enumerable: !0,
        get: function() {
            return r.POP_ORDER_RESULT;
        }
    });
    var t = require("./code.js");
    Object.defineProperty(exports, "CODE", {
        enumerable: !0,
        get: function() {
            return t.CODE;
        }
    }), Object.defineProperty(exports, "NET_ERR_CONF", {
        enumerable: !0,
        get: function() {
            return t.NET_ERR_CONF;
        }
    });
}();