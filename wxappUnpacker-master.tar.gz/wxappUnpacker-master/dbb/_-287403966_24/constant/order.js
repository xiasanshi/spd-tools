!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    exports.ORDER_STATUS = {
        NONE: 10,
        RENTING: 11,
        SUSPEND: 12,
        WAIT_TO_PAY: 13,
        COMPLETED: 14,
        REFUND: 15,
        BUY_OUT: 16
    }, exports.AUTH_CODE = {
        SUCCESS: 9e3,
        FAIL: 4e3,
        USER_CANCEL: 6001,
        IN_PROCESS: 8e3,
        NETWORK_WRONG: 6002,
        UNKNOWN: 6004,
        USER_FORGET_PW: 99
    }, exports.ALIPAY_FROZEN_CODE = {
        UNKNOWN: 1,
        SUCCESS: 2,
        FAIL: 3
    };
}();