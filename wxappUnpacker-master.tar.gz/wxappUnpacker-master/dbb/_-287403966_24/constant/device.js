!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    var e = Object.assign || function(e) {
        for (var o = 1; o < arguments.length; o++) {
            var a = arguments[o];
            for (var t in a) Object.prototype.hasOwnProperty.call(a, t) && (e[t] = a[t]);
        }
        return e;
    }, o = (exports.POP_STATUS = {
        ORDER_NOT_FOUND: -1,
        IN_POP_UP: 0,
        FAIL: 1,
        SUCCESS: 2
    }, exports.CREATE_ORDER_ERROR = {
        CREATE_SUCCESS: 0,
        UN_FINISH: 1,
        NOT_FREE_TIME: 2,
        NO_AGREE: 3,
        CREATE_FAIL: 4,
        AUTH_FAIL: 5
    }, {
        imageUrl: "https://images.wosaimg.com/38/14b00e3bcf7d72e680c4190aaf05492884ff49.png",
        desc: "建议去附近门店租借",
        buttonText: "附近可借",
        imageWidth: 394,
        imageHeight: 267
    });
    exports.DEVICE_STATUS_REASONS = {
        60000: e({
            reason: "设备异常，暂无法租借[60000]"
        }, o),
        60001: e({
            reason: "设备异常，暂无法租借[60001]"
        }, o),
        60002: e({
            reason: "该设备未绑定门店，暂无法租借[60002]"
        }, o),
        60003: e({
            reason: "网络连接异常，请稍后再试[60003]",
            imageUrl: "https://images.wosaimg.com/41/dc9e797b12020f60c478acf41c1f90160e9178.png",
            tip: "重新扫码",
            onTip: "scanCode"
        }, o),
        60004: e({
            reason: "设备维护中，请稍后再试[60004]"
        }, o),
        60005: e({
            reason: "设备异常，请稍后再试[60005]"
        }, o),
        60006: e({
            reason: "暂无可借充电宝，请稍后再试[60006]",
            imageUrl: "https://images.wosaimg.com/5e/0cd2c947255674e98a507d978e9dd08d81e43d.png",
            tip: "退出",
            onTip: "goToHome"
        }, o),
        60007: e({
            reason: "设备异常，暂无法租借[60007]"
        }, o),
        60008: e({
            reason: "暂未支持本渠道租借[60008]"
        }, o, {
            desc: "可使用支付宝APP扫码",
            buttonText: null
        }),
        60009: e({}, o, {
            reason: "充电宝正在充电中，请稍后再试",
            desc: "",
            imageUrl: "https://images.wosaimg.com/5e/45bc8a240c8e6501a3f9bbe6541f8cded48032.gif",
            tip: "退出",
            onTip: "goToHome",
            imageWidth: 345,
            imageHeight: 266
        }),
        520: e({
            reason: "未知异常，请稍后再试[520]"
        }, o, {
            buttonText: "退出"
        })
    }, exports.POP_ORDER_RESULT = {
        ORDER_NOT_EXSIT: 1,
        NOT_FREEZE: 2,
        NOT_CHARGER: 10,
        IN_THE_LINE: 11,
        POPUP_INNER_ERROR: 12,
        NOT_KNOWN: 99
    };
}();