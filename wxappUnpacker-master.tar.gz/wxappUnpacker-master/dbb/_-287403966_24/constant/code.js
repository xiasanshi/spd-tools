!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    exports.CODE = {
        NETWORK_OFFLINE: -2,
        API_ERR: -1,
        SUCCESS: 200,
        PARAMS_ERR: 400,
        AUTH_ERR: 401,
        SERVER_ERR: 520
    }, exports.NET_ERR_CONF = {
        reason: "未连接到网络",
        imageUrl: "https://images.wosaimg.com/41/dc9e797b12020f60c478acf41c1f90160e9178.png",
        desc: "",
        buttonText: "点击重连",
        imageWidth: 394,
        imageHeight: 267
    };
}();