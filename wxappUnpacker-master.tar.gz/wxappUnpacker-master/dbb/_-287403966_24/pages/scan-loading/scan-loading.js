!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    var e, t, n, r = Object.assign || function(e) {
        for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
        }
        return e;
    }, o = function() {
        function e(e, t) {
            for (var n = 0; n < t.length; n++) {
                var r = t[n];
                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
                Object.defineProperty(e, r.key, r);
            }
        }
        return function(t, n, r) {
            return n && e(t.prototype, n), r && e(t, r), t;
        };
    }(), i = require("../../npm/@tarojs/taro-weapp/index.js"), a = (n = i) && n.__esModule ? n : {
        default: n
    }, s = require("../../utils/index.js"), c = require("../../api/index.js"), u = require("../../constant/index.js"), l = require("../../utils/sensors/index.js");
    function h(e) {
        return function() {
            var t = e.apply(this, arguments);
            return new Promise(function(e, n) {
                return function r(o, i) {
                    try {
                        var a = t[o](i), s = a.value;
                    } catch (o) {
                        return void n(o);
                    }
                    if (!a.done) return Promise.resolve(s).then(function(e) {
                        r("next", e);
                    }, function(e) {
                        r("throw", e);
                    });
                    e(s);
                }("next");
            });
        };
    }
    function f(e, t) {
        if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return !t || "object" != typeof t && "function" != typeof t ? e : t;
    }
    var p = (t = e = function() {
        function e() {
            var t, n, r;
            !function(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
            }(this, e);
            for (var o = arguments.length, i = Array(o), a = 0; a < o; a++) i[a] = arguments[a];
            return (n = r = f(this, (t = e.__proto__ || Object.getPrototypeOf(e)).call.apply(t, [ this ].concat(i)))).$usedState = [ "$compid__1", "PREFIX", "failConfig", "gifUrl" ], 
            r.state = {
                failConfig: null
            }, r.config = {
                navigationBarTitleText: "连接中"
            }, r.customComponents = [ "XConnectFail" ], f(r, n);
        }
        var t;
        return function(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
        }(e, i.Component), o(e, [ {
            key: "_constructor",
            value: function() {
                this.goToHome = this.goToHome.bind(this), this.scanCode = this.scanCode.bind(this), 
                this.goToNearStore = this.goToNearStore.bind(this), this.judgeCouldRent = this.judgeCouldRent.bind(this), 
                this.checkDevice = this.checkDevice.bind(this), this.onNetErr = this.onNetErr.bind(this), 
                this.$$refs = new a.default.RefsArray();
            }
        }, {
            key: "componentWillMount",
            value: function() {
                var e = this.$router.params;
                this.qrCode = decodeURIComponent(e.qrCode || e.q || null);
            }
        }, {
            key: "componentDidMount",
            value: function() {
                this.judgeCouldRent();
            }
        }, {
            key: "scanCode",
            value: function(e) {
                e.stopPropagation(), (0, s.scanCode4Business)("redirectTo");
            }
        }, {
            key: "goToNearStore",
            value: function(e) {
                e.stopPropagation(), (0, s.tryGoToNearStore)(this, "navigateTo", null);
            }
        }, {
            key: "goToHome",
            value: function() {
                a.default.reLaunch({
                    url: "/pages/index/index"
                });
            }
        }, {
            key: "judgeCouldRent",
            value: function() {
                var e = this, t = this;
                (0, c.queryUnFinishOrder)().then(function(n) {
                    var r = n.data;
                    n.code === u.CODE.SUCCESS && r ? 0 !== r.length ? a.default.showModal({
                        title: "你有未完成订单",
                        content: "请完成后再租借",
                        showCancel: !1,
                        success: function() {
                            t.goToHome();
                        }
                    }) : e.checkDevice() : e.onNetErr(e.judgeCouldRent);
                }).catch(function(e) {
                    a.default.showToast({
                        title: e.message || "网络错误",
                        icon: "none"
                    }).then(function() {
                        a.default.redirectTo({
                            url: "/package-rent/pages/rent-fail/rent-fail"
                        });
                    });
                });
            }
        }, {
            key: "checkDevice",
            value: (t = h(regeneratorRuntime.mark(function e() {
                var t, n, r, o;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.prev = 0, e.next = 3, (0, c.checkDeviceCanRent)(this.qrCode, s.doNothing);

                      case 3:
                        t = e.sent, n = t.data, r = t.code, o = t.message, r === u.CODE.SUCCESS && n ? this.handleCheckResult(n) : (this.onNetErr(this.checkDevice), 
                        this.handleTrack("fail", r, o)), e.next = 14;
                        break;

                      case 10:
                        e.prev = 10, e.t0 = e.catch(0), this.onNetErr(this.checkDevice), this.handleTrack("fail", e.t0.code || null, "网络错误");

                      case 14:
                      case "end":
                        return e.stop();
                    }
                }, e, this, [ [ 0, 10 ] ]);
            })), function() {
                return t.apply(this, arguments);
            })
        }, {
            key: "handleCheckResult",
            value: function(e) {
                var t = e.errorCode, n = e.masterSn, o = e.storeSn, i = e.merchantSn, s = e.pricingItem;
                if (!t && n && o && i) a.default.redirectTo({
                    url: "/package-rent/pages/pre-auth/pre-auth?preAuthInfo=" + encodeURIComponent(JSON.stringify({
                        masterSn: n,
                        storeSn: o,
                        merchantSn: i,
                        pricingItem: s
                    }))
                }), this.handleTrack("success", t, "null"); else if (Object.keys(u.DEVICE_STATUS_REASONS).map(Number).includes(t)) {
                    var c = u.DEVICE_STATUS_REASONS[t];
                    this.setState({
                        failConfig: r({}, c, {
                            onButtonClick: this.goToNearStore,
                            onTip: c.onTip ? this[c.onTip] : function() {}
                        })
                    }), this.handleTrack("fail", t, c.reason);
                } else this.setState({
                    failConfig: r({}, u.DEVICE_STATUS_REASONS[520], {
                        onButtonClick: this.goToHome
                    })
                }), this.handleTrack("fail", t, "未知错误码");
            }
        }, {
            key: "handleTrack",
            value: function(e, t, n) {
                var r = (0, s.getGlobalData)("userInfo").cellphone;
                (0, l.$track)("DBB_deviceCheck", {
                    result: e,
                    resCode: t,
                    message: n,
                    cellphone: r || null
                });
            }
        }, {
            key: "onNetErr",
            value: function(e) {
                var t = this;
                this.setState({
                    failConfig: r({}, u.NET_ERR_CONF, {
                        onButtonClick: function() {
                            t.setState({
                                failConfig: null
                            }, e);
                        }
                    })
                });
            }
        }, {
            key: "_createData",
            value: function(e, t, n) {
                this.__state = e || this.state || {}, this.__props = t || this.props || {};
                var o = this.$prefix, a = function(e, t) {
                    if (Array.isArray(e)) return e;
                    if (Symbol.iterator in Object(e)) return function(e, t) {
                        var n = [], r = !0, o = !1, i = void 0;
                        try {
                            for (var a, s = e[Symbol.iterator](); !(r = (a = s.next()).done) && (n.push(a.value), 
                            !t || n.length !== t); r = !0) ;
                        } catch (e) {
                            o = !0, i = e;
                        } finally {
                            try {
                                !r && s.return && s.return();
                            } finally {
                                if (o) throw i;
                            }
                        }
                        return n;
                    }(e, t);
                    throw new TypeError("Invalid attempt to destructure non-iterable instance");
                }((0, i.genCompid)(o + "$compid__1"), 2), s = a[0], c = a[1], u = this.__state.failConfig;
                return u && i.propsManager.set(r({}, u), c, s), Object.assign(this.__state, {
                    $compid__1: c,
                    PREFIX: "dbb-scan-loading",
                    gifUrl: "https://images.wosaimg.com/e2/6dcab14a906884a1f64b06ba6868245eaf9090.gif"
                }), this.__state;
            }
        } ]), e;
    }(), e.$$events = [], e.$$componentPath = "pages/scan-loading/scan-loading", t);
    exports.default = p, Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(p, !0));
}();