!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    var t, e, o, r = function() {
        function t(t, e) {
            for (var o = 0; o < e.length; o++) {
                var r = e[o];
                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
                Object.defineProperty(t, r.key, r);
            }
        }
        return function(e, o, r) {
            return o && t(e.prototype, o), r && t(e, r), e;
        };
    }(), n = require("../../npm/@tarojs/taro-weapp/index.js"), a = (o = n) && o.__esModule ? o : {
        default: o
    };
    function i(t, e) {
        if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return !e || "object" != typeof e && "function" != typeof e ? t : e;
    }
    var u = (e = t = function() {
        function t() {
            var e, o, r;
            !function(t, e) {
                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
            }(this, t);
            for (var n = arguments.length, a = Array(n), u = 0; u < n; u++) a[u] = arguments[u];
            return (o = r = i(this, (e = t.__proto__ || Object.getPrototypeOf(t)).call.apply(e, [ this ].concat(a)))).config = {
                navigationBarTitleText: "加载中..."
            }, r.$usedState = [ "anonymousState__temp" ], r.customComponents = [], i(r, o);
        }
        return function(t, e) {
            if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
            t.prototype = Object.create(e && e.prototype, {
                constructor: {
                    value: t,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
        }(t, a.default.Component), r(t, [ {
            key: "_constructor",
            value: function(e) {
                (function t(e, o, r) {
                    null === e && (e = Function.prototype);
                    var n = Object.getOwnPropertyDescriptor(e, o);
                    if (void 0 === n) {
                        var a = Object.getPrototypeOf(e);
                        return null === a ? void 0 : t(a, o, r);
                    }
                    if ("value" in n) return n.value;
                    var i = n.get;
                    return void 0 !== i ? i.call(r) : void 0;
                })(t.prototype.__proto__ || Object.getPrototypeOf(t.prototype), "_constructor", this).call(this, e), 
                this.$$refs = new a.default.RefsArray();
            }
        }, {
            key: "_createData",
            value: function(t, e, o) {
                this.__state = t || this.state || {}, this.__props = e || this.props || {}, this.$prefix;
                var r = (0, n.useRouter)().params.url, a = decodeURIComponent(r);
                return Object.assign(this.__state, {
                    anonymousState__temp: a
                }), this.__state;
            }
        } ]), t;
    }(), t.$$events = [], t.$$componentPath = "pages/webview-h5/webview-h5", e);
    u.config = {
        navigationBarTitleText: "加载中..."
    }, exports.default = u, Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(u, !0));
}();