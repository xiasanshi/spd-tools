!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    var e, t, r, o = function() {
        function e(e, t) {
            for (var r = 0; r < t.length; r++) {
                var o = t[r];
                o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
                Object.defineProperty(e, o.key, o);
            }
        }
        return function(t, r, o) {
            return r && e(t.prototype, r), o && e(t, o), t;
        };
    }(), n = require("../../npm/@tarojs/taro-weapp/index.js"), a = (r = n) && r.__esModule ? r : {
        default: r
    };
    function i(e, t) {
        if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return !t || "object" != typeof t && "function" != typeof t ? e : t;
    }
    var u = (t = e = function() {
        function e() {
            var t, r, o;
            !function(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
            }(this, e);
            for (var n = arguments.length, a = Array(n), u = 0; u < n; u++) a[u] = arguments[u];
            return (r = o = i(this, (t = e.__proto__ || Object.getPrototypeOf(e)).call.apply(t, [ this ].concat(a)))).config = {
                navigationBarTitleText: "跳转中"
            }, o.$usedState = [ "anonymousState__temp" ], o.customComponents = [], i(o, r);
        }
        return function(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
        }(e, a.default.Component), o(e, [ {
            key: "_constructor",
            value: function(t) {
                (function e(t, r, o) {
                    null === t && (t = Function.prototype);
                    var n = Object.getOwnPropertyDescriptor(t, r);
                    if (void 0 === n) {
                        var a = Object.getPrototypeOf(t);
                        return null === a ? void 0 : e(a, r, o);
                    }
                    if ("value" in n) return n.value;
                    var i = n.get;
                    return void 0 !== i ? i.call(o) : void 0;
                })(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "_constructor", this).call(this, t), 
                this.$$refs = new a.default.RefsArray();
            }
        }, {
            key: "_createData",
            value: function(e, t, r) {
                this.__state = e || this.state || {}, this.__props = t || this.props || {}, this.$prefix;
                var o = (0, n.useRouter)().params.orderSn;
                (0, n.useDidShow)(function() {
                    a.default.redirectTo({
                        url: "/package-order/pages/order-detail/order-detail?orderSn=" + o
                    });
                });
                var i = (0, n.internal_inline_style)({
                    height: "100vh",
                    width: "100vw",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center"
                });
                return Object.assign(this.__state, {
                    anonymousState__temp: i
                }), this.__state;
            }
        } ]), e;
    }(), e.$$events = [], e.$$componentPath = "pages/order-detail/order-detail", t);
    u.config = {
        navigationBarTitleText: "跳转中"
    }, exports.default = u, Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(u, !0));
}();