!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    var e, t, n = Object.assign || function(e) {
        for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var o in n) Object.prototype.hasOwnProperty.call(n, o) && (e[o] = n[o]);
        }
        return e;
    }, o = function() {
        function e(e, t) {
            for (var n = 0; n < t.length; n++) {
                var o = t[n];
                o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
                Object.defineProperty(e, o.key, o);
            }
        }
        return function(t, n, o) {
            return n && e(t.prototype, n), o && e(t, o), t;
        };
    }(), a = require("../../npm/@tarojs/taro-weapp/index.js"), r = d(a), i = d(require("../../utils/min-lodash.js")), u = d(require("../../npm/classnames/index.js")), s = require("../../utils/index.js"), c = require("../../api/index.js"), l = require("../../constant/index.js");
    function d(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }
    function f(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e;
    }
    function p(e, t) {
        if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return !t || "object" != typeof t && "function" != typeof t ? e : t;
    }
    var g = "/images/indexMarker.png", h = (t = e = function() {
        function e() {
            var t, o, i, u, d, h = this;
            !function(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
            }(this, e);
            for (var m = arguments.length, y = Array(m), v = 0; v < m; v++) y[v] = arguments[v];
            return (i = u = p(this, (t = e.__proto__ || Object.getPrototypeOf(e)).call.apply(t, [ this ].concat(y)))).$usedState = [ "anonymousState__temp", "anonymousState__temp2", "anonymousState__temp3", "anonymousState__temp4", "anonymousState__temp5", "anonymousState__temp6", "anonymousState__temp7", "anonymousState__temp8", "$compid__0", "hasLocation", "longitude", "latitude", "markers", "userInfo", "indexAvatar", "indexNearStore", "indexCenterLocation", "markerPopState", "indexQuestion", "indexToLocate", "indexScan", "indexSearch", "hasRequestStoreInfo", "eventImg", "unFinishOrders", "indexCanRentL", "orderStateMap", "Go", "currentMarker", "currentMarkerIndex", "eventUrl" ], 
            u.config = {
                navigationBarTitleText: "电饱饱"
            }, u.orderStateMap = (f(o = {}, l.ORDER_STATUS.RENTING, "租借中"), f(o, l.ORDER_STATUS.SUSPEND, "已暂停"), 
            f(o, l.ORDER_STATUS.WAIT_TO_PAY, "待支付"), o), u.state = {
                userInfo: {},
                longitude: null,
                latitude: null,
                hasLocation: 0,
                markers: [],
                unFinishOrders: [],
                currentMarker: {},
                markerPopState: !1,
                currentMarkerIndex: null,
                hasRequestStoreInfo: !1,
                eventImg: "",
                eventUrl: ""
            }, u.initMapLocation = function(e) {
                u.findStoresDebounce(e), u.setState(n({}, e), function() {
                    u.setState({
                        hasLocation: 1
                    });
                });
            }, u.moveToLocation = function() {
                u.mapCtx.moveToLocation();
            }, u.toChooseLocation = function() {
                r.default.chooseLocation({
                    type: "gcj02"
                }).then(function(e) {
                    u.setState({
                        latitude: e.latitude,
                        longitude: e.longitude
                    });
                }).catch(function(e) {
                    e.errMsg.includes("auth deny") && r.default.showToast({
                        title: "您未授权定位权限",
                        icon: "none"
                    });
                });
            }, u.onRegionChange = function(e) {
                var t = e.type;
                if ("begin" === t) u.findStoresDebounce && u.findStoresDebounce.cancel(); else if ("end" === t) {
                    var n = u;
                    u.mapCtx.getCenterLocation({
                        success: function(e) {
                            n.findStoresDebounce({
                                longitude: e.longitude,
                                latitude: e.latitude
                            });
                        }
                    });
                }
            }, u.findStores = function(e) {
                var t = (0, s.getGlobalData)("location");
                t && t.longitude === e.longitude && t.latitude === e.latitude || ((0, s.setGlobalData)("location", n({}, e)), 
                (0, a.showLoading)({
                    title: "加载中",
                    mask: !1
                }), console.log("resLocation", e), (0, c.findStoresForMap)(e).then(function(e) {
                    u.setState({
                        markers: e.data.map(function(e, t) {
                            return n({}, e, {
                                id: t.toString(),
                                sn: e.sn,
                                latitude: +e.latitude,
                                longitude: +e.longitude,
                                width: 29,
                                height: 38,
                                iconPath: g
                            });
                        }),
                        currentMarker: {},
                        markerPopState: !1,
                        currentMarkerIndex: null,
                        hasRequestStoreInfo: !1
                    }), (0, a.hideLoading)();
                }).catch(function(e) {
                    (0, a.hideLoading)();
                }));
            }, u.onMapTap = function() {
                var e = u.state, t = e.currentMarkerIndex, o = {
                    currentMarker: {},
                    markerPopState: !1,
                    currentMarkerIndex: null,
                    markers: e.markers
                };
                null !== t && o.markers[t] && (o.markers[t].width = 29, o.markers[t].height = 38), 
                u.setState(n({}, o));
            }, u.onMarkerTap = (d = function(e) {
                return function() {
                    var t = e.apply(this, arguments);
                    return new Promise(function(e, n) {
                        return function o(a, r) {
                            try {
                                var i = t[a](r), u = i.value;
                            } catch (a) {
                                return void n(a);
                            }
                            if (!i.done) return Promise.resolve(u).then(function(e) {
                                o("next", e);
                            }, function(e) {
                                o("throw", e);
                            });
                            e(u);
                        }("next");
                    });
                };
            }(regeneratorRuntime.mark(function e(t) {
                var n, o, a, r, i, l, d, f, p, g;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (n = u.state, o = n.markers, a = n.currentMarkerIndex, r = (0, s.getGlobalData)("location"), 
                        i = r.longitude, l = r.latitude, d = t.markerId, a !== d && o && o[d]) {
                            e.next = 5;
                            break;
                        }
                        return e.abrupt("return");

                      case 5:
                        return f = o[d].storeSn, null !== a && o[a] && (o[a].width = 29, o[a].height = 38), 
                        o[d].width = 39, o[d].height = 51, u.setState({
                            markers: o,
                            hasRequestStoreInfo: !1,
                            markerPopState: !0,
                            currentMarkerIndex: d
                        }), e.next = 12, (0, c.getSingleStoreInfo)({
                            longitude: i,
                            latitude: l,
                            storeSn: f
                        }).catch(function(e) {
                            return u.onMapTap(), e;
                        });

                      case 12:
                        if (p = e.sent, g = p.data) {
                            e.next = 16;
                            break;
                        }
                        return e.abrupt("return");

                      case 16:
                        u.setState({
                            hasRequestStoreInfo: !0,
                            currentMarker: g
                        });

                      case 17:
                      case "end":
                        return e.stop();
                    }
                }, e, h);
            })), function(e) {
                return d.apply(this, arguments);
            }), u.getUserInfo = function(e) {
                var t = u, n = (0, s.getGlobalData)("userInfo");
                if (n && n.userInfoSubmitted) r.default.navigateTo({
                    url: "/package-help/pages/my/my"
                }); else {
                    var o = e.detail, a = o.encryptedData, i = o.iv, c = o.userInfo;
                    if (a && i) try {
                        t.requestSaveUserInfo(n, c);
                    } catch (e) {
                        console.log(e), t.onGetAuthFail();
                    } else t.onGetAuthFail();
                }
            }, u.requestSaveUserInfo = function(e, t) {
                r.default.navigateTo({
                    url: "/package-help/pages/my/my"
                }), (0, c.saveUserInfo)(t).then(function(t) {
                    var o = n({}, e, t.data);
                    u.setState(o), (0, s.setGlobalData)("userInfo", o);
                }).catch(function(e) {
                    console.log(e);
                });
            }, u.onGetAuthFail = function() {
                r.default.navigateTo({
                    url: "/package-help/pages/my/my"
                });
            }, u.toScan = function() {
                var e = u.state.unFinishOrders;
                0 !== e.length ? r.default.showModal({
                    title: "你有未完成的订单",
                    content: "请完成后再租借",
                    cancelText: "取消",
                    confirmText: "查看详情"
                }).then(function(t) {
                    t.confirm && r.default.navigateTo({
                        url: "/package-order/pages/order-detail/order-detail?orderSn=" + e[0].orderSn
                    });
                }) : (0, s.scanCode4Business)("navigateTo");
            }, u.goToMyPage = function(e) {
                u.toGetUserInfo(e);
            }, u.goToNearStore = function() {
                (0, s.tryGoToNearStore)(u, "navigateTo", n({}, (0, s.getGlobalData)("location")));
            }, u.goToStoreDetail = function() {
                var e = u.state.currentMarker;
                e && ((0, s.setGlobalData)("currentStore", JSON.stringify(e)), r.default.navigateTo({
                    url: "/package-store/pages/store-detail/store-detail"
                }));
            }, u.toMapRoute = function(e) {
                e.stopPropagation(), r.default.openLocation({
                    longitude: +u.state.currentMarker.longitude,
                    latitude: +u.state.currentMarker.latitude,
                    name: u.state.currentMarker.storeName || "-",
                    address: u.state.currentMarker.address || "-"
                });
            }, u.goToQuestionPage = function() {
                r.default.navigateTo({
                    url: "/package-help/pages/question/question"
                });
            }, u.goToOrderDetail = function(e) {
                return function() {
                    e && r.default.navigateTo({
                        url: "/package-order/pages/order-detail/order-detail?orderSn=" + e
                    });
                };
            }, u.goToOrdersPage = function() {
                r.default.navigateTo({
                    url: "/package-order/pages/orders/orders"
                });
            }, u.goToEventH5 = function() {
                var e = u.state.eventUrl;
                r.default.navigateTo({
                    url: "/pages/webview-h5/webview-h5?url=" + encodeURIComponent(e)
                });
            }, u.customComponents = [ "XStoreInfo", "XFooterLoading" ], p(u, i);
        }
        return function(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
        }(e, a.PureComponent), o(e, [ {
            key: "_constructor",
            value: function() {
                this.mapCtx = r.default.createMapContext("map"), this.findStoresDebounce = i.default.debounce(this.findStores, 360, {
                    trailing: !0
                }), this.$$refs = new r.default.RefsArray();
            }
        }, {
            key: "componentWillMount",
            value: function() {
                var e = this;
                (0, c.getEventImg)("index").then(function(t) {
                    var n = i.default.get(t, "data.ads[0].creative.url", null), o = i.default.get(t, "data.ads[0].landing_page", "");
                    n && e.setState({
                        eventImg: n,
                        eventUrl: o
                    });
                }).catch(function(e) {
                    console.log(e);
                });
            }
        }, {
            key: "componentDidMount",
            value: function() {
                this.getUserLocation();
            }
        }, {
            key: "componentDidShow",
            value: function() {
                this.fetchCurrentOrder();
            }
        }, {
            key: "getUserLocation",
            value: function() {
                var e = this;
                r.default.getLocation({
                    type: "gcj02"
                }).then(function(t) {
                    var n = {
                        latitude: t.latitude,
                        longitude: t.longitude
                    };
                    e.initMapLocation(n);
                }).catch(function() {
                    e.initMapLocation({
                        longitude: 121.499717,
                        latitude: 31.239702
                    });
                });
            }
        }, {
            key: "fetchCurrentOrder",
            value: function() {
                var e = this;
                (0, c.queryUnFinishOrder)().then(function(t) {
                    e.setState({
                        unFinishOrders: t.data || [],
                        userInfo: (0, s.getGlobalData)("userInfo")
                    });
                }).catch(function(e) {
                    console.log(e);
                });
            }
        }, {
            key: "_createData",
            value: function(e, t, n) {
                this.__state = e || this.state || {}, this.__props = t || this.props || {};
                var o = this.$prefix, r = this.orderStateMap, i = function(e, t) {
                    if (Array.isArray(e)) return e;
                    if (Symbol.iterator in Object(e)) return function(e, t) {
                        var n = [], o = !0, a = !1, r = void 0;
                        try {
                            for (var i, u = e[Symbol.iterator](); !(o = (i = u.next()).done) && (n.push(i.value), 
                            !t || n.length !== t); o = !0) ;
                        } catch (e) {
                            a = !0, r = e;
                        } finally {
                            try {
                                !o && u.return && u.return();
                            } finally {
                                if (a) throw r;
                            }
                        }
                        return n;
                    }(e, t);
                    throw new TypeError("Invalid attempt to destructure non-iterable instance");
                }((0, a.genCompid)(o + "$compid__0"), 2), c = i[0], l = i[1], d = this.__state, f = (d.longitude, 
                d.latitude, d.markers, d.hasLocation), p = (d.userInfo, d.currentMarker), g = d.unFinishOrders, h = d.markerPopState, m = d.hasRequestStoreInfo, y = (d.eventImg, 
                f ? {
                    tiltGesturesEnabled: 0
                } : null);
                this.anonymousFunc0 = (0, s.throttleButton)(this.goToNearStore);
                var v = h ? null : (0, u.default)("map-circle-button", "map-contact-button");
                this.anonymousFunc1 = (0, s.throttleButton)(this.goToQuestionPage);
                var S = h ? null : (0, a.internal_inline_style)({
                    width: "48rpx",
                    height: "48rpx"
                }), _ = (0, u.default)("map-circle-button", "map-location-button");
                this.anonymousFunc2 = (0, s.throttleButton)(this.moveToLocation);
                var k = (0, a.internal_inline_style)({
                    width: "52rpx",
                    height: "52rpx"
                });
                this.anonymousFunc3 = (0, s.throttleButton)(this.toScan);
                var x = (0, u.default)("map-circle-button", "map-search-button");
                this.anonymousFunc4 = (0, s.throttleButton)(this.toChooseLocation);
                var b = (0, a.internal_inline_style)({
                    width: "40rpx",
                    height: "40rpx"
                }), T = h ? (0, u.default)("map-marker-pop") : null;
                return this.anonymousFunc5 = (0, s.throttleButton)(this.goToEventH5), this.anonymousFunc6 = 1 === g.length ? (0, 
                s.throttleButton)(this.goToOrderDetail(g[0].orderSn)) : (0, s.throttleButton)(this.goToOrdersPage), 
                h && m && a.propsManager.set({
                    props: p
                }, l, c), Object.assign(this.__state, {
                    anonymousState__temp: y,
                    anonymousState__temp2: v,
                    anonymousState__temp3: S,
                    anonymousState__temp4: _,
                    anonymousState__temp5: k,
                    anonymousState__temp6: x,
                    anonymousState__temp7: b,
                    anonymousState__temp8: T,
                    $compid__0: l,
                    indexAvatar: "/images/indexAvatar.png",
                    indexNearStore: "/images/indexNearStore.png",
                    indexCenterLocation: "/images/indexCenterLocation.png",
                    indexQuestion: "/images/indexQuestion.png",
                    indexToLocate: "/images/indexToLocate.png",
                    indexScan: "/images/indexScan.png",
                    indexSearch: "/images/indexSearch.png",
                    indexCanRentL: "/images/indexCanRentL.png",
                    orderStateMap: r,
                    Go: "/images/Go.png"
                }), this.__state;
            }
        }, {
            key: "anonymousFunc0",
            value: function(e) {}
        }, {
            key: "anonymousFunc1",
            value: function(e) {}
        }, {
            key: "anonymousFunc2",
            value: function(e) {}
        }, {
            key: "anonymousFunc3",
            value: function(e) {}
        }, {
            key: "anonymousFunc4",
            value: function(e) {}
        }, {
            key: "anonymousFunc5",
            value: function(e) {}
        }, {
            key: "anonymousFunc6",
            value: function(e) {}
        } ]), e;
    }(), e.$$events = [ "onMapTap", "onRegionChange", "onMarkerTap", "getUserInfo", "onGetAuthFail", "anonymousFunc0", "anonymousFunc1", "anonymousFunc2", "anonymousFunc3", "anonymousFunc4", "goToStoreDetail", "anonymousFunc5", "anonymousFunc6" ], 
    e.$$componentPath = "pages/index/index", t);
    exports.default = h, Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(h, !0));
}();