!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    }), exports.detectPopUpStatus = exports.popInstruction = exports.chargeSpec = exports.checkDeviceCanRent = void 0;
    var e = require("../lib/request.js");
    exports.checkDeviceCanRent = function(t, r) {
        var o = "/v3/device/canRent?qrCode=" + encodeURIComponent(t);
        return (0, e.get)(o, r);
    }, exports.chargeSpec = function(t) {
        var r = "/v1/device/getSkuSalesInfo?orderSn=" + t;
        return (0, e.get)(r);
    }, exports.popInstruction = function(t, r) {
        return (0, e.post)("/v1/order/popUp", t, r);
    }, exports.detectPopUpStatus = function(t) {
        var r = "/v1/order/detectPopUpStatus?orderSn=" + t;
        return (0, e.get)(r);
    };
}();