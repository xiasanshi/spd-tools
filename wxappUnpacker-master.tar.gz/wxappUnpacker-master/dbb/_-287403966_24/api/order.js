!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    }), exports.getWeChatPayParms = exports.queryTsnStatus = exports.payForOrder = exports.getConfirmStatus = exports.payForCharger = exports.queryUnFinishOrder = exports.queryDevice = exports.preCreate = exports.getOrderList = exports.getOrderDetail = void 0;
    var r = require("../utils/index.js"), e = require("../lib/request.js");
    exports.getOrderDetail = function(r) {
        var t = "/v1/order/getOrderDetail?orderSn=" + r.orderSn;
        return (0, e.get)(t);
    }, exports.getOrderList = function(r) {
        var t = "/v1/order/getOrder?ctime=" + r.ctime + "&pageSize=" + r.pageSize;
        return (0, e.get)(t);
    }, exports.preCreate = function(r) {
        return (0, e.post)("/v1/order/preCreate", r);
    }, exports.queryDevice = function(t) {
        if (t) {
            var o = "/v2/order/getPopUpStatus?orderSn=" + t;
            return (0, e.get)(o, r.doNothing);
        }
        return Promise.reject("getPopUpStatus orderSn 为空");
    }, exports.queryUnFinishOrder = function() {
        return (0, e.get)("/v1/order/getUnFinishOrder");
    }, exports.payForCharger = function(r) {
        return (0, e.post)("/v1/order/buyout", r);
    }, exports.getConfirmStatus = function(r) {
        if (r) {
            var t = "/v1/order/getConfirmStatus?orderSn=" + r;
            return (0, e.get)(t);
        }
        return Promise.reject("getConfirmStatus orderSn 为空");
    }, exports.payForOrder = function(r) {
        return (0, e.post)("/v1/order/pay", r);
    }, exports.queryTsnStatus = function(r) {
        var t = "/v1/order/queryTsnStatus?tsn=" + r;
        return (0, e.get)(t);
    }, exports.getWeChatPayParms = function(r) {
        var t = "/v2/order/getWeChatPayJumpParameter?orderSn=" + r;
        return (0, e.get)(t);
    };
}();