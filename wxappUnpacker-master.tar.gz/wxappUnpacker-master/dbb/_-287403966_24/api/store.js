!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    }), exports.getSingleStoreInfo = exports.getStoreList = exports.findStoresForMap = void 0;
    var t = require("../lib/request.js");
    exports.findStoresForMap = function(e) {
        var r = "/v1/store/findStoresNearlyMap?longitude=" + e.longitude + "&latitude=" + e.latitude;
        return (0, t.get)(r);
    }, exports.getStoreList = function(e) {
        var r = "/v1/store/findStoresNearlyListByType?latitude=" + e.latitude + "&longitude=" + e.longitude + "&type=" + e.type;
        return (0, t.get)(r);
    }, exports.getSingleStoreInfo = function(e) {
        var r = e.longitude, o = "/v1/store/getStoreInfo?latitude=" + e.latitude + "&longitude=" + r + "&storeSn=" + e.storeSn;
        return (0, t.get)(o);
    };
}();