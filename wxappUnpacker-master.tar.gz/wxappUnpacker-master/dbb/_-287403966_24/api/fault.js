!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    }), exports.uploadFile = exports.postReport = exports.getReportTypes = exports.getMasterInfo = void 0;
    var e = require("../lib/request.js");
    exports.getMasterInfo = function(t) {
        var o = "/v2/device/getBasic?qrCode=" + encodeURIComponent(t);
        return (0, e.get)(o);
    }, exports.getReportTypes = function() {
        return (0, e.get)("/v2/device/getReportTypes");
    }, exports.postReport = function(t) {
        return (0, e.post)("/v2/device/report", t);
    }, exports.uploadFile = function(t) {
        return (0, e.upload)("/v1/oss/upload", t);
    };
}();