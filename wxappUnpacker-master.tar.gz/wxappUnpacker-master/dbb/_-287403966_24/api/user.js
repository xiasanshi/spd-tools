!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    }), exports.contact = exports.saveUserInfo = exports.getUserInfo = exports.getHelperQuestion = exports.saveFormId = exports.savePhone = void 0;
    var e, t = require("../npm/@tarojs/taro-weapp/index.js"), r = ((e = t) && e.__esModule, 
    require("../lib/request.js"));
    exports.savePhone = function(e) {
        return (0, r.post)("/v1/user/wechat/bindCellphone", e);
    }, exports.saveFormId = function(e, t) {
        return (0, r.post)("/v1/user/saveFormId", {
            formId: e
        }, t);
    }, exports.getHelperQuestion = function() {
        return (0, r.get)("/v1/help/getHelp");
    }, exports.getUserInfo = function() {
        return (0, r.get)("/v1/user/getUserInfo");
    }, exports.saveUserInfo = function(e) {
        return (0, r.post)("/v1/user/wechat/saveUserInfo", e);
    }, exports.contact = function() {
        return (0, r.get)("/v1/help/contact");
    };
}();