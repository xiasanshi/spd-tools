!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    }), exports.hasUseDiscount = exports.getEventImg = void 0;
    var e = require("../lib/request.js");
    exports.getEventImg = function(t) {
        return (0, e.request)("POST", "https://ad.wosai.cn/rpc/ads", {
            id: 0,
            rpc: "2.0",
            method: "serve",
            params: [ {
                version: 1,
                pid: {
                    index: "7c82949e-5b56-43ed-9dad-88ebaf240816",
                    preAuth: "242e8b2e-1246-4def-ae91-c4a828e2d69e"
                }[t],
                effective_payway: 3
            } ]
        }, null);
    }, exports.hasUseDiscount = function() {
        var t = "/v1/discount/usage?sn=1&timestamp=" + Date.now();
        return (0, e.get)(t);
    };
}();