!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    exports.ALIPAY_CONF = {
        CONTACT_SCENE: "SCE00112643",
        CONTACT_TNT_INST_ID: "ROEZFGCN"
    }, exports.COMMON_CONF = {
        MAX_MESSAGE_LENGTH: 40
    };
}();