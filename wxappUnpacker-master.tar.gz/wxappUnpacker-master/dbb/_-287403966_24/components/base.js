!function() {
    "use strict";
    var e, t;
    Object.defineProperty(exports, "__esModule", {
        value: !0
    }), exports.default = void 0;
    var o = require("../npm/@tarojs/taro-weapp/index.js");
    var n = (t = e = function() {
        function e() {
            return function(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
            }(this, e), function(e, t) {
                if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return !t || "object" != typeof t && "function" != typeof t ? e : t;
            }(this, (e.__proto__ || Object.getPrototypeOf(e)).apply(this, arguments));
        }
        return function(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
        }(e, o.PureComponent), e;
    }(), e.externalClasses = [ "component-class" ], e.options = {
        addGlobalClass: !0
    }, t);
    exports.default = n;
}();