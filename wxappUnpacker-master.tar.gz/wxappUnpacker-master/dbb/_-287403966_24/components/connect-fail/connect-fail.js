!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    var t, e, n = function() {
        function t(t, e) {
            for (var n = 0; n < e.length; n++) {
                var o = e[n];
                o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
                Object.defineProperty(t, o.key, o);
            }
        }
        return function(e, n, o) {
            return n && t(e.prototype, n), o && t(e, o), e;
        };
    }(), o = require("../../npm/@tarojs/taro-weapp/index.js"), r = s(o), i = s(require("../../npm/classnames/index.js")), a = require("../../utils/index.js"), u = s(require("../base.js"));
    function s(t) {
        return t && t.__esModule ? t : {
            default: t
        };
    }
    function c(t, e) {
        if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return !e || "object" != typeof e && "function" != typeof e ? t : e;
    }
    var p = (e = t = function() {
        function t() {
            var e, n, o;
            !function(t, e) {
                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
            }(this, t);
            for (var r = arguments.length, i = Array(r), a = 0; a < r; a++) i[a] = arguments[a];
            return (n = o = c(this, (e = t.__proto__ || Object.getPrototypeOf(t)).call.apply(e, [ this ].concat(i)))).$usedState = [ "anonymousState__temp", "anonymousState__temp2", "PREFIX", "imageUrl", "buttonText", "tip", "reason", "desc", "onButtonClick", "imageHeight", "imageWidth", "onTip" ], 
            o.customComponents = [], c(o, n);
        }
        return function(t, e) {
            if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
            t.prototype = Object.create(e && e.prototype, {
                constructor: {
                    value: t,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
        }(t, u.default), n(t, [ {
            key: "_constructor",
            value: function(e) {
                (function t(e, n, o) {
                    null === e && (e = Function.prototype);
                    var r = Object.getOwnPropertyDescriptor(e, n);
                    if (void 0 === r) {
                        var i = Object.getPrototypeOf(e);
                        return null === i ? void 0 : t(i, n, o);
                    }
                    if ("value" in r) return r.value;
                    var a = r.get;
                    return void 0 !== a ? a.call(o) : void 0;
                })(t.prototype.__proto__ || Object.getPrototypeOf(t.prototype), "_constructor", this).call(this, e), 
                this.$$refs = new r.default.RefsArray();
            }
        }, {
            key: "_createData",
            value: function(t, e, n) {
                this.__state = t || this.state || {}, this.__props = e || this.props || {}, this.$prefix;
                var r = this.__props, u = r.onButtonClick, s = r.imageHeight, c = r.imageWidth, p = r.imageUrl, l = r.tip, f = r.onTip, h = r.reason, y = r.desc, _ = r.buttonText, m = (0, 
                o.internal_inline_style)({
                    width: c + "rpx",
                    height: s + "rpx"
                });
                this.anonymousFunc0 = (0, a.throttleButton)(u);
                var d = _ ? (0, i.default)("btn", "connect-fail-near") : null;
                return this.anonymousFunc1 = (0, a.throttleButton)(f), Object.assign(this.__state, {
                    anonymousState__temp: m,
                    anonymousState__temp2: d,
                    PREFIX: "connect-fail",
                    imageUrl: p,
                    buttonText: _,
                    tip: l,
                    reason: h,
                    desc: y
                }), this.__state;
            }
        }, {
            key: "anonymousFunc0",
            value: function(t) {}
        }, {
            key: "anonymousFunc1",
            value: function(t) {}
        } ]), t;
    }(), t.$$events = [ "anonymousFunc0", "anonymousFunc1" ], t.$$componentPath = "components/connect-fail/connect-fail", 
    e);
    p.defaultProps = {
        imageUrl: "",
        imageWidth: 0,
        imageHeight: 0,
        tip: "",
        onTip: a.doNothing,
        onButtonClick: a.doNothing,
        desc: "",
        reason: "",
        buttonText: "附近可借"
    }, exports.default = p, Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(p));
}();