!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    var t, e, n = function() {
        function t(t, e) {
            for (var n = 0; n < e.length; n++) {
                var o = e[n];
                o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
                Object.defineProperty(t, o.key, o);
            }
        }
        return function(e, n, o) {
            return n && t(e.prototype, n), o && t(e, o), e;
        };
    }(), o = require("../../npm/@tarojs/taro-weapp/index.js"), r = i(o), a = i(require("../../npm/classnames/index.js"));
    function i(t) {
        return t && t.__esModule ? t : {
            default: t
        };
    }
    function s(t, e) {
        if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return !e || "object" != typeof e && "function" != typeof e ? t : e;
    }
    var u = (e = t = function() {
        function t() {
            var e, n, o;
            !function(t, e) {
                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
            }(this, t);
            for (var r = arguments.length, a = Array(r), i = 0; i < r; i++) a[i] = arguments[i];
            return (n = o = s(this, (e = t.__proto__ || Object.getPrototypeOf(t)).call.apply(e, [ this ].concat(a)))).$usedState = [ "loopArray8", "titleList", "activeCategory", "switchCategory" ], 
            o.anonymousFunc0Map = {}, o.customComponents = [], s(o, n);
        }
        return function(t, e) {
            if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
            t.prototype = Object.create(e && e.prototype, {
                constructor: {
                    value: t,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
        }(t, r.default.Component), n(t, [ {
            key: "_constructor",
            value: function(e) {
                (function t(e, n, o) {
                    null === e && (e = Function.prototype);
                    var r = Object.getOwnPropertyDescriptor(e, n);
                    if (void 0 === r) {
                        var a = Object.getPrototypeOf(e);
                        return null === a ? void 0 : t(a, n, o);
                    }
                    if ("value" in r) return r.value;
                    var i = r.get;
                    return void 0 !== i ? i.call(o) : void 0;
                })(t.prototype.__proto__ || Object.getPrototypeOf(t.prototype), "_constructor", this).call(this, e), 
                this.$$refs = new r.default.RefsArray();
            }
        }, {
            key: "_createData",
            value: function(t, e, n) {
                var r = this;
                this.__state = t || this.state || {}, this.__props = e || this.props || {}, this.$prefix;
                var i = this.__props, s = i.titleList, u = void 0 === s ? [] : s, l = i.activeCategory, p = i.switchCategory, c = u.map(function(t, e) {
                    t = {
                        $original: (0, o.internal_get_original)(t)
                    };
                    var n = (0, a.default)("title-tabs-title", {
                        "title-tabs-active-category": l == e
                    }, {
                        "title-tabs-sm-title": 3 < u.length
                    }), i = "title" + e, s = "ezzzz" + e;
                    return r.anonymousFunc0Map[s] = function() {
                        return p(e);
                    }, {
                        $loopState__temp2: n,
                        $loopState__temp4: i,
                        _$indexKey: s,
                        $loopState__temp6: (0, o.internal_inline_style)(function(t) {
                            var e = {
                                borderLeft: "1rpx solid transparent"
                            };
                            return 2 < u.length ? l === t || l + 1 === t || 0 === t ? e : {
                                borderLeft: "1rpx solid #d7d7d7"
                            } : e;
                        }(e)),
                        $original: t.$original
                    };
                });
                return Object.assign(this.__state, {
                    loopArray8: c,
                    titleList: u
                }), this.__state;
            }
        }, {
            key: "anonymousFunc0",
            value: function(t) {
                for (var e, n = arguments.length, o = Array(1 < n ? n - 1 : 0), r = 1; r < n; r++) o[r - 1] = arguments[r];
                return this.anonymousFunc0Map[t] && (e = this.anonymousFunc0Map)[t].apply(e, o);
            }
        } ]), t;
    }(), t.$$events = [ "anonymousFunc0" ], t.$$componentPath = "components/title-tabs/title-tabs", 
    e);
    u.options = {
        addGlobalClass: !0
    }, exports.default = u, Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(u));
}();