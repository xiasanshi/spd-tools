!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    var t, e, r = function() {
        function t(t, e) {
            for (var r = 0; r < e.length; r++) {
                var o = e[r];
                o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
                Object.defineProperty(t, o.key, o);
            }
        }
        return function(e, r, o) {
            return r && t(e.prototype, r), o && t(e, o), e;
        };
    }(), o = a(require("../../npm/@tarojs/taro-weapp/index.js")), n = a(require("../base.js"));
    function a(t) {
        return t && t.__esModule ? t : {
            default: t
        };
    }
    function i(t, e) {
        if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return !e || "object" != typeof e && "function" != typeof e ? t : e;
    }
    var u = (e = t = function() {
        function t() {
            var e, r, o;
            !function(t, e) {
                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
            }(this, t);
            for (var n = arguments.length, a = Array(n), u = 0; u < n; u++) a[u] = arguments[u];
            return (r = o = i(this, (e = t.__proto__ || Object.getPrototypeOf(t)).call.apply(e, [ this ].concat(a)))).$usedState = [], 
            o.customComponents = [], i(o, r);
        }
        return function(t, e) {
            if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
            t.prototype = Object.create(e && e.prototype, {
                constructor: {
                    value: t,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
        }(t, n.default), r(t, [ {
            key: "_constructor",
            value: function(e) {
                (function t(e, r, o) {
                    null === e && (e = Function.prototype);
                    var n = Object.getOwnPropertyDescriptor(e, r);
                    if (void 0 === n) {
                        var a = Object.getPrototypeOf(e);
                        return null === a ? void 0 : t(a, r, o);
                    }
                    if ("value" in n) return n.value;
                    var i = n.get;
                    return void 0 !== i ? i.call(o) : void 0;
                })(t.prototype.__proto__ || Object.getPrototypeOf(t.prototype), "_constructor", this).call(this, e), 
                this.$$refs = new o.default.RefsArray();
            }
        }, {
            key: "_createData",
            value: function(t, e, r) {
                return this.__state = t || this.state || {}, this.__props = e || this.props || {}, 
                this.$prefix, Object.assign(this.__state, {}), this.__state;
            }
        } ]), t;
    }(), t.$$events = [], t.$$componentPath = "components/footer-loading/footer-loading", 
    e);
    exports.default = u, Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(u));
}();