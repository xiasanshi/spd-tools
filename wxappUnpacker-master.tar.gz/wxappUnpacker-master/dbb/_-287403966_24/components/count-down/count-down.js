!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    var t, e, r, n = function() {
        function t(t, e) {
            for (var r = 0; r < e.length; r++) {
                var n = e[r];
                n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
                Object.defineProperty(t, n.key, n);
            }
        }
        return function(e, r, n) {
            return r && t(e.prototype, r), n && t(e, n), e;
        };
    }(), o = require("../../npm/@tarojs/taro-weapp/index.js"), i = (r = o) && r.__esModule ? r : {
        default: r
    };
    function a(t, e) {
        if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return !e || "object" != typeof e && "function" != typeof e ? t : e;
    }
    var u = (e = t = function() {
        function t() {
            var e, r, n;
            !function(t, e) {
                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
            }(this, t);
            for (var o = arguments.length, i = Array(o), u = 0; u < o; u++) i[u] = arguments[u];
            return (r = n = a(this, (e = t.__proto__ || Object.getPrototypeOf(t)).call.apply(e, [ this ].concat(i)))).$usedState = [ "seconds", "initSeconds" ], 
            n.customComponents = [], a(n, r);
        }
        return function(t, e) {
            if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
            t.prototype = Object.create(e && e.prototype, {
                constructor: {
                    value: t,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
        }(t, i.default.Component), n(t, [ {
            key: "_constructor",
            value: function(e) {
                (function t(e, r, n) {
                    null === e && (e = Function.prototype);
                    var o = Object.getOwnPropertyDescriptor(e, r);
                    if (void 0 === o) {
                        var i = Object.getPrototypeOf(e);
                        return null === i ? void 0 : t(i, r, n);
                    }
                    if ("value" in o) return o.value;
                    var a = o.get;
                    return void 0 !== a ? a.call(n) : void 0;
                })(t.prototype.__proto__ || Object.getPrototypeOf(t.prototype), "_constructor", this).call(this, e), 
                this.$$refs = new i.default.RefsArray();
            }
        }, {
            key: "_createData",
            value: function(t, e, r) {
                var n = this;
                this.__state = t || this.state || {}, this.__props = e || this.props || {}, this.$prefix;
                var i = this.__props, a = i.initSeconds, u = void 0 === a ? 90 : a, c = function(t, e) {
                    if (Array.isArray(t)) return t;
                    if (Symbol.iterator in Object(t)) return function(t, e) {
                        var r = [], n = !0, o = !1, i = void 0;
                        try {
                            for (var a, u = t[Symbol.iterator](); !(n = (a = u.next()).done) && (r.push(a.value), 
                            !e || r.length !== e); n = !0) ;
                        } catch (t) {
                            o = !0, i = t;
                        } finally {
                            try {
                                !n && u.return && u.return();
                            } finally {
                                if (o) throw i;
                            }
                        }
                        return r;
                    }(t, e);
                    throw new TypeError("Invalid attempt to destructure non-iterable instance");
                }((i.onStop, (0, o.useState)(parseInt(u))), 2), s = c[0], f = c[1];
                return function(t, e) {
                    var r = (0, o.useRef)();
                    (0, o.useEffect)(function() {
                        r.current = t;
                    }), (0, o.useEffect)(function() {
                        if (null !== e) {
                            var t = setInterval(function() {
                                r.current();
                            }, e);
                            return function() {
                                return clearInterval(t);
                            };
                        }
                    }, [ e ]);
                }(function() {
                    var t = s - 1;
                    t <= 0 && n.__props.onStop(), f(t);
                }, s ? 1e3 : null), Object.assign(this.__state, {
                    seconds: s
                }), this.__state;
            }
        } ]), t;
    }(), t.$$events = [], t.$$componentPath = "components/count-down/count-down", e);
    exports.default = u, Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(u));
}();