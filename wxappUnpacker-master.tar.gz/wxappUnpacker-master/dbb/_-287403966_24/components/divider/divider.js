!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    var t, e, n = function() {
        function t(t, e) {
            for (var n = 0; n < e.length; n++) {
                var o = e[n];
                o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
                Object.defineProperty(t, o.key, o);
            }
        }
        return function(e, n, o) {
            return n && t(e.prototype, n), o && t(e, o), e;
        };
    }(), o = require("../../npm/@tarojs/taro-weapp/index.js"), r = i(o), a = i(require("../base.js"));
    function i(t) {
        return t && t.__esModule ? t : {
            default: t
        };
    }
    function s(t, e) {
        if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return !e || "object" != typeof e && "function" != typeof e ? t : e;
    }
    var u = (e = t = function() {
        function t() {
            var e, n, o;
            !function(t, e) {
                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
            }(this, t);
            for (var r = arguments.length, a = Array(r), i = 0; i < r; i++) a[i] = arguments[i];
            return (n = o = s(this, (e = t.__proto__ || Object.getPrototypeOf(t)).call.apply(e, [ this ].concat(a)))).$usedState = [ "anonymousState__temp", "anonymousState__temp2", "anonymousState__temp3", "anonymousState__temp4", "anonymousState__temp5" ], 
            o.customComponents = [], s(o, n);
        }
        return function(t, e) {
            if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
            t.prototype = Object.create(e && e.prototype, {
                constructor: {
                    value: t,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
        }(t, a.default), n(t, [ {
            key: "_constructor",
            value: function(e) {
                (function t(e, n, o) {
                    null === e && (e = Function.prototype);
                    var r = Object.getOwnPropertyDescriptor(e, n);
                    if (void 0 === r) {
                        var a = Object.getPrototypeOf(e);
                        return null === a ? void 0 : t(a, n, o);
                    }
                    if ("value" in r) return r.value;
                    var i = r.get;
                    return void 0 !== i ? i.call(o) : void 0;
                })(t.prototype.__proto__ || Object.getPrototypeOf(t.prototype), "_constructor", this).call(this, e), 
                this.$$refs = new r.default.RefsArray();
            }
        }, {
            key: "_createData",
            value: function(t, e, n) {
                this.__state = t || this.state || {}, this.__props = e || this.props || {}, this.$prefix;
                var r = {
                    height: "2rpx",
                    background: "#ccc",
                    opacity: .75,
                    transform: "scaleY(.5)"
                }, a = (0, o.internal_inline_style)({
                    paddingBottom: "20rpx"
                }), i = (0, o.internal_inline_style)({
                    height: "40rpx",
                    width: "600rpx"
                }), s = (0, o.internal_inline_style)(r), u = (0, o.internal_inline_style)({
                    padding: "0 10px",
                    fontSize: "20rpx",
                    color: "#ccc"
                }), p = (0, o.internal_inline_style)(r);
                return Object.assign(this.__state, {
                    anonymousState__temp: a,
                    anonymousState__temp2: i,
                    anonymousState__temp3: s,
                    anonymousState__temp4: u,
                    anonymousState__temp5: p
                }), this.__state;
            }
        } ]), t;
    }(), t.$$events = [], t.$$componentPath = "components/divider/divider", e);
    exports.default = u, Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(u));
}();