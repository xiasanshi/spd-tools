!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    var t, e, o = function() {
        function t(t, e) {
            for (var o = 0; o < e.length; o++) {
                var n = e[o];
                n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
                Object.defineProperty(t, n.key, n);
            }
        }
        return function(e, o, n) {
            return o && t(e.prototype, o), n && t(e, n), e;
        };
    }(), n = require("../../npm/@tarojs/taro-weapp/index.js"), r = i(n), a = i(require("../../npm/classnames/index.js")), s = require("../../utils/index.js");
    function i(t) {
        return t && t.__esModule ? t : {
            default: t
        };
    }
    function u(t, e) {
        if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return !e || "object" != typeof e && "function" != typeof e ? t : e;
    }
    var p = (e = t = function() {
        function t() {
            var e, o, n;
            !function(t, e) {
                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
            }(this, t);
            for (var r = arguments.length, a = Array(r), s = 0; s < r; s++) a[s] = arguments[s];
            return (o = n = u(this, (e = t.__proto__ || Object.getPrototypeOf(t)).call.apply(e, [ this ].concat(a)))).$usedState = [ "anonymousState__temp", "anonymousState__temp2", "anonymousState__temp3", "anonymousState__temp4", "props", "indexToRoute" ], 
            n.customComponents = [], u(n, o);
        }
        return function(t, e) {
            if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
            t.prototype = Object.create(e && e.prototype, {
                constructor: {
                    value: t,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
        }(t, r.default.Component), o(t, [ {
            key: "_constructor",
            value: function(e) {
                (function t(e, o, n) {
                    null === e && (e = Function.prototype);
                    var r = Object.getOwnPropertyDescriptor(e, o);
                    if (void 0 === r) {
                        var a = Object.getPrototypeOf(e);
                        return null === a ? void 0 : t(a, o, n);
                    }
                    if ("value" in r) return r.value;
                    var s = r.get;
                    return void 0 !== s ? s.call(n) : void 0;
                })(t.prototype.__proto__ || Object.getPrototypeOf(t.prototype), "_constructor", this).call(this, e), 
                this.$$refs = new r.default.RefsArray();
            }
        }, {
            key: "_createData",
            value: function(t, e, o) {
                this.__state = t || this.state || {}, this.__props = e || this.props || {}, this.$prefix;
                var r = this.__props.props, i = void 0 === r ? {} : r, u = (0, s.calcDistance)(i.distance), p = (0, 
                a.default)("store-status", i.canRentNum ? "store-status-valid" : "store-status-invalid"), c = (0, 
                n.internal_inline_style)({
                    marginLeft: "36rpx"
                }), l = (0, a.default)("store-status", i.canReturnNum ? "store-status-valid" : "store-status-invalid");
                return Object.assign(this.__state, {
                    anonymousState__temp: u,
                    anonymousState__temp2: p,
                    anonymousState__temp3: c,
                    anonymousState__temp4: l,
                    props: i,
                    indexToRoute: "/images/indexToRoute.png"
                }), this.__state;
            }
        } ]), t;
    }(), t.$$events = [], t.$$componentPath = "components/store-info/store-info", e);
    p.options = {
        addGlobalClass: !0
    }, exports.default = p, Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(p));
}();