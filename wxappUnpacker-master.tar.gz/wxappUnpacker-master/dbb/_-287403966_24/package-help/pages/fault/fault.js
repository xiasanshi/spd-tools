// package-help/pages/fault/fault.js
Page({data: {}})