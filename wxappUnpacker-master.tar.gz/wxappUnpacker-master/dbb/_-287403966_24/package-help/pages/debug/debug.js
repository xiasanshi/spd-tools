// package-help/pages/debug/debug.js
Page({data: {}})