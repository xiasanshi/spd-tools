// package-help/pages/use-tips/use-tips.js
Page({data: {}})