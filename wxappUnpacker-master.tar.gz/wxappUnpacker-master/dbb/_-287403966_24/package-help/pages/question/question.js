// package-help/pages/question/question.js
Page({data: {}})