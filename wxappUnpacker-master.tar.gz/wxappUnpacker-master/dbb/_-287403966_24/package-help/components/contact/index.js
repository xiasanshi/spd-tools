// package-help/components/contact/index.js
Page({data: {}})