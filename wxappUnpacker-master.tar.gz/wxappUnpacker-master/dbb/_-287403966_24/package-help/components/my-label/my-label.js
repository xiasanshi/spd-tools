// package-help/components/my-label/my-label.js
Page({data: {}})