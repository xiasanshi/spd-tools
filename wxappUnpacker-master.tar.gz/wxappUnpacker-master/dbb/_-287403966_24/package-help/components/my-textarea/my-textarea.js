// package-help/components/my-textarea/my-textarea.js
Page({data: {}})