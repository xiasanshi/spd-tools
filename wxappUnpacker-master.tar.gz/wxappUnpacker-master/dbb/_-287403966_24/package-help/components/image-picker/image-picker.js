// package-help/components/image-picker/image-picker.js
Page({data: {}})