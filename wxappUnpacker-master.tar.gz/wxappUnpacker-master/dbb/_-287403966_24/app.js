!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    var e = function() {
        function e(e, a) {
            for (var t = 0; t < a.length; t++) {
                var r = a[t];
                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
                Object.defineProperty(e, r.key, r);
            }
        }
        return function(a, t, r) {
            return t && e(a.prototype, t), r && e(a, r), a;
        };
    }(), a = require("./npm/@tarojs/taro-weapp/index.js"), t = i(a);
    require("./npm/@tarojs/async-await/index.js");
    var r = require("./utils/index.js"), n = require("./utils/sensors/index.js"), o = i(require("./utils/min-lodash.js"));
    function i(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }
    function s(e, a) {
        if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return !a || "object" != typeof a && "function" != typeof a ? e : a;
    }
    var p = function() {
        function i() {
            var e, a, t;
            !function(e, a) {
                if (!(e instanceof a)) throw new TypeError("Cannot call a class as a function");
            }(this, i);
            for (var r = arguments.length, n = Array(r), o = 0; o < r; o++) n[o] = arguments[o];
            return (a = t = s(this, (e = i.__proto__ || Object.getPrototypeOf(i)).call.apply(e, [ this ].concat(n)))).config = {
                pages: [ "pages/index/index", "pages/scan-loading/scan-loading", "pages/webview-h5/webview-h5", "pages/order-detail/order-detail" ],
                subPackages: [ {
                    root: "package-rent",
                    name: "package-rent",
                    pages: [ "pages/pre-auth/pre-auth", "pages/wait-device/wait-device", "pages/agreement/agreement", "pages/rent-fail/rent-fail" ]
                }, {
                    root: "package-order",
                    name: "package-order",
                    pages: [ "pages/orders/orders", "pages/order-detail/order-detail", "pages/device-checking/device-checking", "pages/pop-success/pop-success" ]
                }, {
                    root: "package-store",
                    name: "package-store",
                    pages: [ "pages/near-store/near-store", "pages/store-detail/store-detail" ]
                }, {
                    root: "package-help",
                    name: "package-help",
                    pages: [ "pages/my/my", "pages/debug/debug", "pages/question/question", "pages/fault/fault", "pages/use-tips/use-tips" ]
                } ],
                preloadRule: {
                    "pages/index/index": {
                        network: "all",
                        packages: [ "package-order", "package-help", "package-store" ]
                    },
                    "pages/scan-loading/scan-loading": {
                        network: "all",
                        packages: [ "package-rent" ]
                    },
                    "package-rent/pages/wait-device/wait-device": {
                        network: "all",
                        packages: [ "package-order" ]
                    },
                    "package-rent/pages/rent-fail/rent-fail": {
                        network: "all",
                        packages: [ "package-help" ]
                    },
                    "package-order/pages/order-detail/order-detail": {
                        network: "all",
                        packages: [ "package-help", "package-store" ]
                    },
                    "package-order/pages/pop-success/pop-success": {
                        network: "all",
                        packages: [ "package-help" ]
                    },
                    "package-store/pages/store-detail/store-detail": {
                        network: "all",
                        packages: [ "package-help" ]
                    }
                },
                window: {
                    backgroundTextStyle: "light",
                    navigationBarBackgroundColor: "#fff",
                    navigationBarTitleText: "",
                    navigationBarTextStyle: "black"
                },
                permission: {
                    "scope.userLocation": {
                        desc: "你的位置信息将用于小程序首页地图的效果展示"
                    }
                }
            }, s(t, a);
        }
        return function(e, a) {
            if ("function" != typeof a && null !== a) throw new TypeError("Super expression must either be null or a function, not " + typeof a);
            e.prototype = Object.create(a && a.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), a && (Object.setPrototypeOf ? Object.setPrototypeOf(e, a) : e.__proto__ = a);
        }(i, a.Component), e(i, [ {
            key: "componentWillMount",
            value: function() {
                var e = ((0, r.getGlobalData)("userInfo") || {}).userId;
                e && (n.sensor.login(e), n.sensor.init()), wx.onAppShow(function(e) {
                    var a = e.scene, r = e.referrerInfo, i = void 0 === r ? {} : r, s = function(e, a) {
                        if (Array.isArray(e)) return e;
                        if (Symbol.iterator in Object(e)) return function(e, a) {
                            var t = [], r = !0, n = !1, o = void 0;
                            try {
                                for (var i, s = e[Symbol.iterator](); !(r = (i = s.next()).done) && (t.push(i.value), 
                                !a || t.length !== a); r = !0) ;
                            } catch (e) {
                                n = !0, o = e;
                            } finally {
                                try {
                                    !r && s.return && s.return();
                                } finally {
                                    if (n) throw o;
                                }
                            }
                            return t;
                        }(e, a);
                        throw new TypeError("Invalid attempt to destructure non-iterable instance");
                    }((e.path, t.default.getCurrentPages().slice(-1)), 1)[0];
                    if (s) {
                        if (1038 === a && "wxd8f3793ea3b935b8" === i.appId && "/package-rent/pages/pre-auth/pre-auth".includes(s.route)) {
                            var p = s.$component, c = p.handleQueryFreeze, l = p.handleHuabeiAuthTrack;
                            o.default.isFunction(c) && c();
                            var u = i.extraData, g = void 0 === u ? {} : u;
                            o.default.isFunction(l) && (g.query_id ? l("success", null, "用户预授权成功") : l("fail", null, "用户主动返回或取消预授权"));
                        }
                        (0, n.$track)("DBB_CHECK_AppOnShow", {
                            result: "success",
                            message: {
                                scene: a,
                                appId: i.appId || "-",
                                path: s.route
                            }
                        });
                    }
                });
            }
        }, {
            key: "componentDidMount",
            value: function() {
                (0, r.checkUpdate)(), (0, n.$track)("DBB_userAgent", {});
            }
        }, {
            key: "componentDidShow",
            value: function() {}
        }, {
            key: "componentDidHide",
            value: function() {}
        }, {
            key: "componentDidCatchError",
            value: function() {}
        }, {
            key: "_createData",
            value: function() {}
        } ]), i;
    }();
    exports.default = p, App(require("./npm/@tarojs/taro-weapp/index.js").default.createApp(p)), 
    t.default.initPxTransform({
        designWidth: 750,
        deviceRatio: {
            640: 1.17,
            750: 1,
            828: .905
        }
    });
}();