!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    }), exports.$track = exports.sensor = void 0;
    var e = Object.assign || function(e) {
        for (var r = 1; r < arguments.length; r++) {
            var t = arguments[r];
            for (var a in t) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
        }
        return e;
    }, r = require("../index.js"), t = n(require("../min-lodash.js")), a = n(require("./sa.weapp.js")), s = n(require("./sensorsdata_conf.js"));
    function n(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }
    var o = {};
    a.default.setPara(s.default);
    try {
        var i = wx.getSystemInfoSync().SDKVersion;
        o = {
            platForm: "WECHAT",
            uaOrigin: "WechatMini",
            uaFormat: "微信小程序",
            sdkVersion: i
        };
    } catch (e) {}
    var u = [], l = exports.sensor = a.default, c = exports.$track = function(a, s) {
        var n = (0, r.getGlobalData)("userInfo") || {}, i = n.userId, c = n.clientUserId, f = e({}, o, {
            timestamp: Date.now(),
            currentRoute: (0, r.getCurrentRoute)()
        });
        if (s && t.default.assign(f, s), a && u.push({
            name: a,
            properties: f
        }), i) {
            var d = !0, p = !1, v = void 0;
            try {
                for (var y, m = u[Symbol.iterator](); !(d = (y = m.next()).done); d = !0) {
                    var x = y.value, g = x.name, h = x.properties;
                    h = t.default.assign(h, {
                        userId: i,
                        clientUserId: c
                    }), h = t.default.pickOwnBy(h), l.track.call(l, g, h);
                }
            } catch (a) {
                p = !0, v = a;
            } finally {
                try {
                    !d && m.return && m.return();
                } finally {
                    if (p) throw v;
                }
            }
            u = [];
        }
    };
    exports.default = {
        sensor: l,
        $track: c
    };
}();