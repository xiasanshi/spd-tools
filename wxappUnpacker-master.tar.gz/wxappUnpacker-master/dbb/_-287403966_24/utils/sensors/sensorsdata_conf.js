!function() {
    "use strict";
    module.exports = {
        name: "sensors",
        server_url: "https://shence.wosai-inc.com:8106/sa?project=consumerana",
        autoTrack: {
            appLaunch: !1,
            appShow: !1,
            appHide: !1,
            pageShow: !1,
            pageShare: !0
        }
    };
}();