!function() {
    "use strict";
    var t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
        return typeof t;
    } : function(t) {
        return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
    }, e = {}, r = {
        para: {
            name: "sensors",
            server_url: "",
            send_timeout: 1e3,
            use_client_time: !1,
            show_log: !0,
            allow_amend_share_path: !0,
            max_string_length: 300,
            datasend_timeout: 3e3,
            source_channel: [],
            autoTrack: {
                appLaunch: !0,
                appShow: !0,
                appHide: !0,
                pageShow: !0,
                pageShare: !0
            },
            is_persistent_save: !1
        }
    }, n = "object" == (void 0 === n ? "undefined" : t(n)) ? n : {};
    n.info = function() {
        if (r.para.show_log && "object" == ("undefined" == typeof console ? "undefined" : t(console)) && console.log) try {
            return console.log.apply(console, arguments);
        } catch (t) {
            console.log(arguments[0]);
        }
    }, r.setPara = function(i) {
        r.para = e.extend2Lev(r.para, i);
        var a = [];
        if (e.isArray(r.para.source_channel)) for (var s = r.para.source_channel.length, o = 0; o < s; o++) -1 === " utm_source utm_medium utm_campaign utm_content utm_term sa_utm ".indexOf(" " + r.para.source_channel[o] + " ") && a.push(r.para.source_channel[o]);
        r.para.source_channel = a, e.isObject(r.para.register) && e.extend(e.info.properties, r.para.register), 
        r.para.openid_url || (r.para.openid_url = r.para.server_url.replace(/([^\/])\/(sa)(\.gif){0,1}/, "$1/mp_login")), 
        "number" != typeof r.para.send_timeout && (r.para.send_timeout = 1e3);
        var u = {
            send_timeout: 6e3,
            max_length: 6
        };
        !0 === r.para.batch_send ? (r.para.batch_send = e.extend({}, u), r.para.use_client_time = !0) : "object" == t(r.para.batch_send) && (r.para.use_client_time = !0, 
        r.para.batch_send = e.extend({}, u, r.para.batch_send)), r.para.server_url || n.info("请使用 setPara() 方法设置 server_url 数据接收地址,详情可查看https://www.sensorsdata.cn/manual/mp_sdk_new.html#112-%E5%BC%95%E5%85%A5%E5%B9%B6%E9%85%8D%E7%BD%AE%E5%8F%82%E6%95%B0");
    }, r.status = {};
    var i = Array.prototype, a = Function.prototype, s = Object.prototype, o = i.slice, u = s.toString, c = s.hasOwnProperty, p = [ "$latest_utm_source", "$latest_utm_medium", "$latest_utm_campaign", "$latest_utm_content", "$latest_utm_term", "latest_sa_utm" ], f = {
        1000: "其他",
        1001: "发现栏小程序主入口，「最近使用」列表（基础库2.2.4版本起包含「我的小程序」列表）",
        1005: "顶部搜索框的搜索结果页",
        1006: "发现栏小程序主入口搜索框的搜索结果页",
        1007: "单人聊天会话中的小程序消息卡片",
        1008: "群聊会话中的小程序消息卡片",
        1011: "扫描二维码",
        1012: "长按图片识别二维码",
        1013: "手机相册选取二维码",
        1014: "小程序模版消息",
        1017: "前往体验版的入口页",
        1019: "微信钱包",
        1020: "公众号 profile 页相关小程序列表",
        1022: "聊天顶部置顶小程序入口",
        1023: "安卓系统桌面图标",
        1024: "小程序 profile 页",
        1025: "扫描一维码",
        1026: "附近小程序列表",
        1027: "顶部搜索框搜索结果页“使用过的小程序”列表",
        1028: "我的卡包",
        1029: "卡券详情页",
        1030: "自动化测试下打开小程序",
        1031: "长按图片识别一维码",
        1032: "手机相册选取一维码",
        1034: "微信支付完成页",
        1035: "公众号自定义菜单",
        1036: "App 分享消息卡片",
        1037: "小程序打开小程序",
        1038: "从另一个小程序返回",
        1039: "摇电视",
        1042: "添加好友搜索框的搜索结果页",
        1043: "公众号模板消息",
        1044: "带 shareTicket 的小程序消息卡片（详情)",
        1045: "朋友圈广告",
        1046: "朋友圈广告详情页",
        1047: "扫描小程序码",
        1048: "长按图片识别小程序码",
        1049: "手机相册选取小程序码",
        1052: "卡券的适用门店列表",
        1053: "搜一搜的结果页",
        1054: "顶部搜索框小程序快捷入口",
        1056: "音乐播放器菜单",
        1057: "钱包中的银行卡详情页",
        1058: "公众号文章",
        1059: "体验版小程序绑定邀请页",
        1064: "微信连Wi-Fi状态栏",
        1067: "公众号文章广告",
        1068: "附近小程序列表广告",
        1069: "移动应用",
        1071: "钱包中的银行卡列表页",
        1072: "二维码收款页面",
        1073: "客服消息列表下发的小程序消息卡片",
        1074: "公众号会话下发的小程序消息卡片",
        1077: "摇周边",
        1078: "连Wi-Fi成功页",
        1079: "微信游戏中心",
        1081: "客服消息下发的文字链",
        1082: "公众号会话下发的文字链",
        1084: "朋友圈广告原生页",
        1088: "会话中查看系统消息，打开小程序",
        1089: "微信聊天主界面下拉",
        1090: "长按小程序右上角菜单唤出最近使用历史",
        1091: "公众号文章商品卡片",
        1092: "城市服务入口",
        1095: "小程序广告组件",
        1096: "聊天记录",
        1097: "微信支付签约页",
        1099: "页面内嵌插件",
        1102: "公众号 profile 页服务预览",
        1103: "发现栏小程序主入口，“我的小程序”列表",
        1104: "微信聊天主界面下拉，“我的小程序”栏",
        1106: "聊天主界面下拉，从顶部搜索结果页，打开小程序",
        1107: "订阅消息，打开小程序",
        1113: "安卓手机负一屏，打开小程序(三星)",
        1114: "安卓手机侧边栏，打开小程序(三星)",
        1124: "扫“一物一码”打开小程序",
        1125: "长按图片识别“一物一码”",
        1126: "扫描手机相册中选取的“一物一码”",
        1129: "微信爬虫访问",
        1131: "浮窗打开小程序",
        1146: "地理位置信息打开出行类小程序",
        1148: "卡包-交通卡，打开小程序"
    }, d = "直接打开";
    r.status.referrer = "直接打开";
    var h = null, l = 0, m = "", g = !1;
    function _(t, n, i) {
        var a = r.autoTrackCustom[i];
        if (t[n]) {
            var s = t[n];
            t[n] = function() {
                "onLaunch" === n && (this[r.para.name] = r), !r.para.autoTrackIsFirst || e.isObject(r.para.autoTrackIsFirst) && !r.para.autoTrackIsFirst[i] ? (s.apply(this, arguments), 
                a.apply(this, arguments)) : (!0 === r.para.autoTrackIsFirst || e.isObject(r.para.autoTrackIsFirst) && r.para.autoTrackIsFirst[i]) && (a.apply(this, arguments), 
                s.apply(this, arguments));
            };
        } else t[n] = function() {
            "onLaunch" === n && (this[r.para.name] = r), a.apply(this, arguments);
        };
    }
    r.lib_version = "1.13.16", function() {
        a.bind;
        var t = i.forEach, r = i.indexOf, s = Array.isArray, p = {}, f = e.each = function(e, r, n) {
            if (null == e) return !1;
            if (t && e.forEach === t) e.forEach(r, n); else if (e.length === +e.length) {
                for (var i = 0, a = e.length; i < a; i++) if (i in e && r.call(n, e[i], i, e) === p) return !1;
            } else for (var s in e) if (c.call(e, s) && r.call(n, e[s], s, e) === p) return !1;
        };
        e.logger = n, e.extend = function(t) {
            return f(o.call(arguments, 1), function(e) {
                for (var r in e) void 0 !== e[r] && (t[r] = e[r]);
            }), t;
        }, e.extend2Lev = function(t) {
            return f(o.call(arguments, 1), function(r) {
                for (var n in r) void 0 !== r[n] && (e.isObject(r[n]) && e.isObject(t[n]) ? e.extend(t[n], r[n]) : t[n] = r[n]);
            }), t;
        }, e.coverExtend = function(t) {
            return f(o.call(arguments, 1), function(e) {
                for (var r in e) void 0 !== e[r] && void 0 === t[r] && (t[r] = e[r]);
            }), t;
        }, e.isArray = s || function(t) {
            return "[object Array]" === u.call(t);
        }, e.isFunction = function(t) {
            try {
                return /^\s*\bfunction\b/.test(t);
            } catch (t) {
                return !1;
            }
        }, e.isArguments = function(t) {
            return !(!t || !c.call(t, "callee"));
        }, e.toArray = function(t) {
            return t ? t.toArray ? t.toArray() : e.isArray(t) ? o.call(t) : e.isArguments(t) ? o.call(t) : e.values(t) : [];
        }, e.values = function(t) {
            var e = [];
            return null == t || f(t, function(t) {
                e[e.length] = t;
            }), e;
        }, e.include = function(t, e) {
            var n = !1;
            return null == t ? n : r && t.indexOf === r ? -1 != t.indexOf(e) : (f(t, function(t) {
                if (n = n || t === e) return p;
            }), n);
        };
    }(), e.trim = function(t) {
        return t.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, "");
    }, e.isObject = function(t) {
        return null != t && "[object Object]" == u.call(t);
    }, e.isEmptyObject = function(t) {
        if (e.isObject(t)) {
            for (var r in t) if (c.call(t, r)) return !1;
            return !0;
        }
        return !1;
    }, e.isUndefined = function(t) {
        return void 0 === t;
    }, e.isString = function(t) {
        return "[object String]" == u.call(t);
    }, e.isDate = function(t) {
        return "[object Date]" == u.call(t);
    }, e.isBoolean = function(t) {
        return "[object Boolean]" == u.call(t);
    }, e.isNumber = function(t) {
        return "[object Number]" == u.call(t) && /[\d\.]+/.test(String(t));
    }, e.isJSONString = function(t) {
        try {
            JSON.parse(t);
        } catch (t) {
            return !1;
        }
        return !0;
    }, e.decodeURIComponent = function(t) {
        var e = "";
        try {
            e = decodeURIComponent(t);
        } catch (r) {
            e = t;
        }
        return e;
    }, e.encodeDates = function(t) {
        return e.each(t, function(r, n) {
            e.isDate(r) ? t[n] = e.formatDate(r) : e.isObject(r) && (t[n] = e.encodeDates(r));
        }), t;
    }, e.formatDate = function(t) {
        function e(t) {
            return t < 10 ? "0" + t : t;
        }
        return t.getFullYear() + "-" + e(t.getMonth() + 1) + "-" + e(t.getDate()) + " " + e(t.getHours()) + ":" + e(t.getMinutes()) + ":" + e(t.getSeconds()) + "." + e(t.getMilliseconds());
    }, e.searchObjDate = function(t) {
        e.isObject(t) && e.each(t, function(r, n) {
            e.isObject(r) ? e.searchObjDate(t[n]) : e.isDate(r) && (t[n] = e.formatDate(r));
        });
    }, e.formatString = function(t) {
        return t.length > r.para.max_string_length ? (n.info("字符串长度超过限制，已经做截取--" + t), t.slice(0, r.para.max_string_length)) : t;
    }, e.searchObjString = function(t) {
        e.isObject(t) && e.each(t, function(r, n) {
            e.isObject(r) ? e.searchObjString(t[n]) : e.isString(r) && (t[n] = e.formatString(r));
        });
    }, e.unique = function(t) {
        for (var e, r = [], n = {}, i = 0; i < t.length; i++) (e = t[i]) in n || (n[e] = !0, 
        r.push(e));
        return r;
    }, e.strip_sa_properties = function(t) {
        return e.isObject(t) && e.each(t, function(r, i) {
            if (e.isArray(r)) {
                var a = [];
                e.each(r, function(t) {
                    e.isString(t) ? a.push(t) : n.info("您的数据-", r, "的数组里的值必须是字符串,已经将其删除");
                }), 0 !== a.length ? t[i] = a : (delete t[i], n.info("已经删除空的数组"));
            }
            e.isString(r) || e.isNumber(r) || e.isDate(r) || e.isBoolean(r) || e.isArray(r) || (n.info("您的数据-", r, "-格式不满足要求，我们已经将其删除"), 
            delete t[i]);
        }), t;
    }, e.strip_empty_properties = function(t) {
        var r = {};
        return e.each(t, function(t, e) {
            null != t && (r[e] = t);
        }), r;
    }, e.utf8Encode = function(t) {
        var e, r, n, i, a = "";
        for (e = r = 0, n = (t = (t + "").replace(/\r\n/g, "\n").replace(/\r/g, "\n")).length, 
        i = 0; i < n; i++) {
            var s = t.charCodeAt(i), o = null;
            s < 128 ? r++ : o = 127 < s && s < 2048 ? String.fromCharCode(s >> 6 | 192, 63 & s | 128) : String.fromCharCode(s >> 12 | 224, s >> 6 & 63 | 128, 63 & s | 128), 
            null !== o && (e < r && (a += t.substring(e, r)), a += o, e = r = i + 1);
        }
        return e < r && (a += t.substring(e, t.length)), a;
    }, e.base64Encode = function(t) {
        var r, n, i, a, s, o = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", u = 0, c = 0, p = "", f = [];
        if (!t) return t;
        for (t = e.utf8Encode(t); r = (s = t.charCodeAt(u++) << 16 | t.charCodeAt(u++) << 8 | t.charCodeAt(u++)) >> 18 & 63, 
        n = s >> 12 & 63, i = s >> 6 & 63, a = 63 & s, f[c++] = o.charAt(r) + o.charAt(n) + o.charAt(i) + o.charAt(a), 
        u < t.length; ) ;
        switch (p = f.join(""), t.length % 3) {
          case 1:
            p = p.slice(0, -2) + "==";
            break;

          case 2:
            p = p.slice(0, -1) + "=";
        }
        return p;
    }, e.getCurrentPath = function() {
        var t = "未取到";
        try {
            var e = getCurrentPages();
            t = e[e.length - 1].route;
        } catch (t) {
            n.info(t);
        }
        return t;
    }, e.getCurrentUrl = function(t) {
        var r = e.getCurrentPath(), n = "";
        return e.isObject(t) && t.sensors_mp_encode_url_query && (n = t.sensors_mp_encode_url_query), 
        r ? n ? r + "?" + n : r : "未取到";
    }, e.getPath = function(t) {
        return "string" == typeof t ? t.replace(/^\//, "") : "取值异常";
    }, r.initialState = {
        queue: [],
        isComplete: !1,
        systemIsComplete: !1,
        storeIsComplete: !1,
        checkIsComplete: function() {
            this.systemIsComplete && this.storeIsComplete && (this.isComplete = !0, 0 < this.queue.length && (e.each(this.queue, function(t) {
                r[t[0]].apply(r, o.call(t[1]));
            }), this.queue = []));
        }
    }, e.getCustomUtmFromQuery = function(t, n, i, a) {
        if (!e.isObject(t)) return {};
        var s = {};
        if (t.sa_utm) for (var o in t) "sa_utm" !== o ? e.include(r.para.source_channel, o) && (s[i + o] = t[o]) : s[a + o] = t[o]; else for (var o in t) -1 === " utm_source utm_medium utm_campaign utm_content utm_term ".indexOf(" " + o + " ") ? e.include(r.para.source_channel, o) && (s[i + o] = t[o]) : s[n + o] = t[o];
        return s;
    }, e.getObjFromQuery = function(t) {
        var r = t.split("?"), n = [], i = {};
        return r && r[1] ? (e.each(r[1].split("&"), function(t) {
            (n = t.split("="))[0] && n[1] && (i[n[0]] = n[1]);
        }), i) : {};
    }, e.setStorageSync = function(t, e) {
        function r() {
            wx.setStorageSync(t, e);
        }
        try {
            r();
        } catch (t) {
            n.info("set Storage fail --", t);
            try {
                r();
            } catch (t) {
                n.info("set Storage fail again --", t);
            }
        }
    }, e.getStorageSync = function(t) {
        var e = "";
        try {
            e = wx.getStorageSync(t);
        } catch (r) {
            try {
                e = wx.getStorageSync(t);
            } catch (t) {
                n.info("getStorage fail");
            }
        }
        return e;
    }, e.getMPScene = function(t) {
        return "number" == typeof t || "string" == typeof t && "" !== t ? (t = String(t), 
        f[t] || t) : "未取到值";
    }, e.getShareDepth = function() {
        if ("number" != typeof l || 0 === l) return 1;
        var t = r.store.getDistinctId(), e = r.store.getFirstId();
        return !m || m !== t && m !== e ? l + 1 : l;
    }, e.setShareInfo = function(t, r) {
        var n = {};
        if (!(t && e.isObject(t.query) && t.query.sampshare)) return {};
        if (n = e.decodeURIComponent(t.query.sampshare), !e.isJSONString(n)) return {};
        var i = (n = JSON.parse(n)).d, a = n.p, s = n.i;
        "string" == typeof s ? (r.$share_distinct_id = s, m = s) : r.$share_distinct_id = "取值异常", 
        "number" == typeof i ? (r.$share_depth = i, l = i) : r.$share_depth = "-1", r.$share_url_path = "string" == typeof a ? a : "取值异常";
    }, e.getShareInfo = function() {
        return JSON.stringify({
            i: r.store.getDistinctId() || "取值异常",
            p: e.getCurrentPath(),
            d: e.getShareDepth()
        });
    }, e.detectOptionQuery = function(t) {
        if (!t || !e.isObject(t.query)) return {};
        var n, i, a, s, o = {};
        return o.query = e.extend({}, t.query), "string" == typeof o.query.scene && (n = o.query, 
        i = [ "utm_source", "utm_content", "utm_medium", "utm_campaign", "utm_term", "sa_utm" ].concat(r.para.source_channel), 
        a = new RegExp("(" + i.join("|") + ")%3D", "i"), 1 === (s = Object.keys(n)).length && "scene" === s[0] && a.test(n.scene)) && (o.scene = o.query.scene, 
        delete o.query.scene), t.query.q && t.query.scancode_time && "101" === String(t.scene).slice(0, 3) && (o.q = String(o.query.q), 
        delete o.query.q, delete o.query.scancode_time), o;
    }, e.getMixedQuery = function(t) {
        var r = e.detectOptionQuery(t), n = r.scene, i = r.q, a = r.query;
        for (var s in a) a[s] = e.decodeURIComponent(a[s]);
        return n && (n = -1 !== (n = e.decodeURIComponent(n)).indexOf("?") ? "?" + n.replace(/\?/g, "") : "?" + n, 
        e.extend(a, e.getObjFromQuery(n))), i && e.extend(a, e.getObjFromQuery(e.decodeURIComponent(i))), 
        a;
    }, e.setUtm = function(t, r) {
        var n = {}, i = e.getMixedQuery(t), a = e.getCustomUtmFromQuery(i, "$", "_", "$"), s = e.getCustomUtmFromQuery(i, "$latest_", "_latest_", "$latest_");
        return n.pre1 = a, n.pre2 = s, e.extend(r, a), n;
    }, e.wxrequest = function(t) {
        var n = wx.request(t);
        setTimeout(function() {
            e.isObject(n) && e.isFunction(n.abort) && n.abort();
        }, r.para.datasend_timeout);
    }, e.info = {
        currentProps: {},
        properties: {
            $lib: "MiniProgram",
            $lib_version: String("1.13.16")
        },
        getSystem: function() {
            var t = this.properties;
            wx.getNetworkType({
                success: function(e) {
                    t.$network_type = e.networkType;
                },
                complete: function() {
                    wx.getSystemInfo({
                        success: function(e) {
                            var r, n;
                            t.$manufacturer = e.brand, t.$model = e.model, t.$screen_width = Number(e.screenWidth), 
                            t.$screen_height = Number(e.screenHeight), t.$os = "ios" === (n = (r = e.platform).toLowerCase()) ? "iOS" : "android" === n ? "Android" : r, 
                            t.$os_version = -1 < e.system.indexOf(" ") ? e.system.split(" ")[1] : e.system;
                        },
                        complete: function() {
                            r.initialState.systemIsComplete = !0, r.initialState.checkIsComplete();
                        }
                    });
                }
            });
        }
    }, r._ = e, r.prepareData = function(i, a) {
        var s = {
            distinct_id: this.store.getDistinctId(),
            lib: {
                $lib: "MiniProgram",
                $lib_method: "code",
                $lib_version: String("1.13.16")
            },
            properties: {}
        };
        e.extend(s, this.store.getUnionId(), i), e.isObject(i.properties) && !e.isEmptyObject(i.properties) && e.extend(s.properties, i.properties), 
        i.type && "profile" === i.type.slice(0, 7) || (r.para.batch_send && (s._track_id = Number(String(Math.random()).slice(2, 5) + String(Math.random()).slice(2, 4) + String(Date.now()).slice(-4))), 
        s.properties = e.extend({}, e.info.properties, r.store.getProps(), e.info.currentProps, s.properties), 
        "object" == t(r.store._state) && "number" == typeof r.store._state.first_visit_day_time && r.store._state.first_visit_day_time > new Date().getTime() ? s.properties.$is_first_day = !0 : s.properties.$is_first_day = !1), 
        s.properties.$time && e.isDate(s.properties.$time) ? (s.time = 1 * s.properties.$time, 
        delete s.properties.$time) : r.para.use_client_time && (s.time = 1 * new Date()), 
        e.searchObjDate(s), e.searchObjString(s), n.info(s), r.sendStrategy.send(s);
    }, r.store = {
        verifyDistinctId: function(t) {
            return "number" == typeof t && (t = String(t), /^\d+$/.test(t) || (t = "unexpected_id")), 
            "string" == typeof t && "" !== t || (t = "unexpected_id"), t;
        },
        storageInfo: null,
        getUUID: function() {
            return Date.now() + "-" + Math.floor(1e7 * Math.random()) + "-" + Math.random().toString(16).replace(".", "") + "-" + String(31242 * Math.random()).replace(".", "").slice(0, 8);
        },
        getStorage: function() {
            return this.storageInfo || (this.storageInfo = r._.getStorageSync("sensorsdata2015_wechat") || ""), 
            this.storageInfo;
        },
        _state: {},
        mem: {
            mdata: [],
            getLength: function() {
                return this.mdata.length;
            },
            add: function(t) {
                this.mdata.push(t);
            },
            clear: function(t) {
                this.mdata.splice(0, t);
            }
        },
        toState: function(t) {
            var r = null;
            e.isJSONString(t) ? (r = JSON.parse(t)).distinct_id ? this._state = r : this.set("distinct_id", this.getUUID()) : e.isObject(t) && (r = t).distinct_id ? this._state = r : this.set("distinct_id", this.getUUID());
        },
        getFirstId: function() {
            return this._state.first_id;
        },
        getDistinctId: function() {
            return this._state.distinct_id;
        },
        getUnionId: function() {
            var t = {};
            return this._state.first_id && this._state.distinct_id ? (t.login_id = this._state.distinct_id, 
            t.anonymous_id = this._state.first_id) : t.anonymous_id = this._state.distinct_id, 
            t;
        },
        getProps: function() {
            return this._state.props || {};
        },
        setProps: function(t, r) {
            var n = this._state.props || {};
            r ? this.set("props", t) : (e.extend(n, t), this.set("props", n));
        },
        set: function(e, r) {
            var n = {};
            for (var i in "string" == typeof e ? n[e] = r : "object" == (void 0 === e ? "undefined" : t(e)) && (n = e), 
            this._state = this._state || {}, n) this._state[i] = n[i];
            this.save();
        },
        change: function(t, e) {
            this._state[t] = e;
        },
        save: function() {
            r._.setStorageSync("sensorsdata2015_wechat", this._state);
        },
        init: function() {
            var t = this.getStorage();
            if (t) this.toState(t); else {
                g = !0;
                var e = new Date(), n = e.getTime();
                e.setHours(23), e.setMinutes(59), e.setSeconds(60), r.setOnceProfile({
                    $first_visit_time: new Date()
                }), this.set({
                    distinct_id: this.getUUID(),
                    first_visit_time: n,
                    first_visit_day_time: e.getTime()
                });
            }
        }
    }, r.setProfile = function(t, e) {
        r.prepareData({
            type: "profile_set",
            properties: t
        }, e);
    }, r.setOnceProfile = function(t, e) {
        r.prepareData({
            type: "profile_set_once",
            properties: t
        }, e);
    }, r.appendProfile = function(t, i) {
        if (!e.isObject(t)) return !1;
        e.each(t, function(r, i) {
            e.isString(r) ? t[i] = [ r ] : e.isArray(r) || (delete t[i], n.info("appendProfile属性的值必须是字符串或者数组"));
        }), r.prepareData({
            type: "profile_append",
            properties: t
        }, i);
    }, r.incrementProfile = function(t, n) {
        if (!e.isObject(t)) return !1;
        var i = t;
        e.isString(t) && ((t = {})[i] = 1), r.prepareData({
            type: "profile_increment",
            properties: t
        }, n);
    }, r.track = function(t, e, r) {
        this.prepareData({
            type: "track",
            event: t,
            properties: e
        }, r);
    }, r.identify = function(t, e) {
        if ("string" != typeof t && "number" != typeof t) return !1;
        t = r.store.verifyDistinctId(t);
        var n = r.store.getFirstId();
        !0 === e ? n ? r.store.set("first_id", t) : r.store.set("distinct_id", t) : n ? r.store.change("first_id", t) : r.store.change("distinct_id", t);
    }, r.trackSignup = function(t, e, n, i) {
        var a = r.store.getFirstId() || r.store.getDistinctId();
        r.store.set("distinct_id", t), r.prepareData({
            original_id: a,
            distinct_id: t,
            type: "track_signup",
            event: e,
            properties: n
        }, i);
    }, r.registerApp = function(t) {
        e.isObject(t) && !e.isEmptyObject(t) && (e.info.currentProps = e.extend(e.info.currentProps, t));
    }, r.register = function(t) {
        e.isObject(t) && !e.isEmptyObject(t) && r.store.setProps(t);
    }, r.clearAllRegister = function() {
        r.store.setProps({}, !0);
    }, r.clearAllProps = function(t) {
        var n = r.store.getProps(), i = {};
        e.isArray(t) && (e.each(n, function(r, n) {
            e.include(t, n) || (i[n] = r);
        }), r.store.setProps(i, !0));
    }, r.clearAppRegister = function(t) {
        e.isArray(t) && e.each(e.info.currentProps, function(r, n) {
            e.include(t, n) && delete e.info.currentProps[n];
        });
    }, r.setLatestChannel = function(t) {
        e.isEmptyObject(t) || (function(t, e) {
            var r = !1;
            for (var n in e) t[e[n]] && (r = !0);
            return r;
        }(t, p) && (r.clearAppRegister(p), r.clearAllProps(p)), r.para.is_persistent_save ? r.register(t) : r.registerApp(t));
    }, r.login = function(t) {
        if ("string" != typeof t && "number" != typeof t) return !1;
        t = r.store.verifyDistinctId(t);
        var e = r.store.getFirstId(), n = r.store.getDistinctId();
        t !== n && (e || r.store.set("first_id", n), r.trackSignup(t, "$SignUp"));
    }, r.openid = {
        getRequest: function(t) {
            wx.login({
                success: function(n) {
                    n.code && r.para.appid && r.para.openid_url ? e.wxrequest({
                        url: r.para.openid_url + "&code=" + n.code + "&appid=" + r.para.appid,
                        method: "GET",
                        complete: function(r) {
                            e.isObject(r) && e.isObject(r.data) && r.data.openid ? t(r.data.openid) : t();
                        }
                    }) : t();
                }
            });
        },
        getWXStorage: function() {
            var t = r.store.getStorage();
            if (t && e.isObject(t)) return t.openid;
        },
        getOpenid: function(t) {
            if (!r.para.appid) return t(), !1;
            var e = this.getWXStorage();
            e ? t(e) : this.getRequest(t);
        }
    }, r.initial = function() {
        this._.info.getSystem(), this.store.init();
    }, r.init = function(t) {
        if (!0 === this.hasInit) return !1;
        this.hasInit = !0, r.setPara(t), r.para.batch_send && (wx.getStorage({
            key: "sensors_mp_prepare_data",
            complete: function(t) {
                var n = t.data && e.isArray(t.data) ? t.data : [];
                r.store.mem.mdata = n.concat(r.store.mem.mdata), r.sendStrategy.syncStorage = !0;
            }
        }), r.sendStrategy.batchInterval()), r.initialState.storeIsComplete = !0, r.initialState.checkIsComplete();
    }, r.getPresetProperties = function() {
        if (e.info && e.info.properties && e.info.properties.$lib) {
            var t = {};
            e.each(e.info.currentProps, function(e, r) {
                0 === r.indexOf("$") && (t[r] = e);
            });
            var n = e.extend(t, {
                $url_path: e.getCurrentPath()
            }, e.info.properties, r.store.getProps());
            return delete n.$lib, n;
        }
        return {};
    }, e.autoExeQueue = function() {
        return {
            items: [],
            enqueue: function(t) {
                this.items.push(t), this.start();
            },
            dequeue: function() {
                return this.items.shift();
            },
            getCurrentItem: function() {
                return this.items[0];
            },
            isRun: !1,
            start: function() {
                0 < this.items.length && !this.isRun && (this.isRun = !0, this.getCurrentItem().start());
            },
            close: function() {
                this.dequeue(), this.isRun = !1, this.start();
            }
        };
    }, r.requestQueue = function(t) {
        this.url = t.url;
    }, r.requestQueue.prototype.isEnd = function() {
        this.received || (this.received = !0, this.close());
    }, r.requestQueue.prototype.start = function() {
        var t = this;
        setTimeout(function() {
            t.isEnd();
        }, r.para.send_timeout), e.wxrequest({
            url: this.url,
            method: "GET",
            complete: function() {
                t.isEnd();
            }
        });
    }, r.dataQueue = e.autoExeQueue(), r.sendStrategy = {
        dataHasSend: !0,
        dataHasChange: !1,
        syncStorage: !1,
        onAppHide: function() {
            r.para.batch_send && this.batchSend();
        },
        send: function(t) {
            if (!r.para.server_url) return !1;
            if (r.para.batch_send) {
                if (this.dataHasChange = !0, 300 <= r.store.mem.getLength()) return n.info("数据量存储过大，有异常"), 
                !1;
                r.store.mem.add(t), r.store.mem.getLength() >= r.para.batch_send.max_length && this.batchSend();
            } else this.queueSend(t);
        },
        queueSend: function(t) {
            t = JSON.stringify(t), t = -1 !== r.para.server_url.indexOf("?") ? r.para.server_url + "&data=" + encodeURIComponent(e.base64Encode(t)) : r.para.server_url + "?data=" + encodeURIComponent(e.base64Encode(t));
            var n = new r.requestQueue({
                url: t
            });
            n.close = function() {
                r.dataQueue.close();
            }, r.dataQueue.enqueue(n);
        },
        wxrequest: function(t) {
            if (e.isArray(t.data) && 0 < t.data.length) {
                var n = Date.now();
                t.data.forEach(function(t) {
                    t._flush_time = n;
                }), t.data = JSON.stringify(t.data), e.wxrequest({
                    url: r.para.server_url,
                    method: "POST",
                    dataType: "text",
                    data: "data_list=" + encodeURIComponent(e.base64Encode(t.data)),
                    success: function() {
                        t.success(t.len);
                    },
                    fail: function() {
                        t.fail();
                    }
                });
            } else t.success(t.len);
        },
        batchSend: function() {
            if (this.dataHasSend) {
                var t = r.store.mem.mdata, e = t.length;
                0 < e && (this.dataHasSend = !1, this.wxrequest({
                    data: t,
                    len: e,
                    success: this.batchRemove.bind(this),
                    fail: this.sendFail.bind(this)
                }));
            }
        },
        sendFail: function() {
            this.dataHasSend = !0;
        },
        batchRemove: function(t) {
            r.store.mem.clear(t), this.dataHasSend = !0, this.dataHasChange = !0, this.batchWrite();
        },
        is_first_batch_write: !0,
        batchWrite: function() {
            var t = this;
            this.dataHasChange && (this.is_first_batch_write && (this.is_first_batch_write = !1, 
            setTimeout(function() {
                t.batchSend();
            }, 1e3)), this.dataHasChange = !1, this.syncStorage && r._.setStorageSync("sensors_mp_prepare_data", r.store.mem.mdata));
        },
        batchInterval: function() {
            var t = this;
            !function e() {
                setTimeout(function() {
                    t.batchWrite(), e();
                }, 500);
            }(), function e() {
                setTimeout(function() {
                    t.batchSend(), e();
                }, r.para.batch_send.send_timeout);
            }();
        }
    }, r.setOpenid = function(t, e) {
        r.store.set("openid", t), e ? r.store.set("distinct_id", t) : r.identify(t, !0);
    }, r.initWithOpenid = function(t, n) {
        (t = t || {}).appid && (r.para.appid = t.appid), r.openid.getOpenid(function(i) {
            i && r.setOpenid(i, t.isCoverLogin), n && e.isFunction(n) && n(i), r.init(t);
        });
    }, e.each([ "setProfile", "setOnceProfile", "track", "quick", "incrementProfile", "appendProfile" ], function(t) {
        var e = r[t];
        r[t] = function() {
            r.initialState.isComplete ? e.apply(r, arguments) : r.initialState.queue.push([ t, arguments ]);
        };
    }), e.setQuery = function(t, r) {
        if (t && e.isObject(t) && !e.isEmptyObject(t)) {
            var n = [];
            return e.each(t, function(t, i) {
                "q" === i && e.isString(t) && 0 === t.indexOf("http") || "scene" === i || (r ? n.push(i + "=" + t) : n.push(i + "=" + e.decodeURIComponent(t)));
            }), n.join("&");
        }
        return "";
    }, e.getUtmFromPage = function() {
        var t = {};
        try {
            var r = getCurrentPages(), i = r[r.length - 1].options;
            t = e.getCustomUtmFromQuery(i, "$", "_", "$");
        } catch (t) {
            n.info(t);
        }
        return t;
    }, r.autoTrackCustom = {
        trackCustom: function(t, n, i) {
            var a = r.para.autoTrack[t], s = "";
            r.para.autoTrack && a && ("function" == typeof a ? (s = a(), e.isObject(s) && e.extend(n, s)) : e.isObject(a) && (e.extend(n, a), 
            r.para.autoTrack[t] = !0), r.track(i, n));
        },
        appLaunch: function(n, i) {
            "object" != t(this) || this.trackCustom || (this[r.para.name] = r);
            var a = {};
            n && n.path && (a.$url_path = e.getPath(n.path)), e.setShareInfo(n, a);
            var s = e.setUtm(n, a);
            g ? (a.$is_first_time = !0, e.isEmptyObject(s.pre1) || r.setOnceProfile(s.pre1)) : a.$is_first_time = !1, 
            r.setLatestChannel(s.pre2), a.$scene = e.getMPScene(n.scene), r.registerApp({
                $latest_scene: a.$scene
            }), a.$url_query = e.setQuery(n.query), i ? (a = e.extend(a, i), r.track("$MPLaunch", a)) : r.para.autoTrack && r.para.autoTrack.appLaunch && r.autoTrackCustom.trackCustom("appLaunch", a, "$MPLaunch");
        },
        appShow: function(t, n) {
            var i = {};
            h = new Date().getTime(), t && t.path && (i.$url_path = e.getPath(t.path)), e.setShareInfo(t, i);
            var a = e.setUtm(t, i);
            r.setLatestChannel(a.pre2), i.$scene = e.getMPScene(t.scene), r.registerApp({
                $latest_scene: i.$scene
            }), i.$url_query = e.setQuery(t.query), n ? (i = e.extend(i, n), r.track("$MPShow", i)) : r.para.autoTrack && r.para.autoTrack.appShow && r.autoTrackCustom.trackCustom("appShow", i, "$MPShow");
        },
        appHide: function(t) {
            var n = new Date().getTime(), i = {};
            i.$url_path = e.getCurrentPath(), h && 0 < n - h && (n - h) / 36e5 < 24 && (i.event_duration = (n - h) / 1e3), 
            t ? (i = e.extend(i, t), r.track("$MPHide", i)) : r.para.autoTrack && r.para.autoTrack.appHide && r.autoTrackCustom.trackCustom("appHide", i, "$MPHide"), 
            r.sendStrategy.onAppHide();
        },
        pageLoad: function(t) {
            t && e.isObject(t) && (this.sensors_mp_url_query = e.setQuery(t), this.sensors_mp_encode_url_query = e.setQuery(t, !0));
        },
        pageShow: function() {
            var t = {}, n = e.getCurrentPath();
            t.$referrer = d, t.$url_path = n, r.status.last_referrer = d, t.$url_query = this.sensors_mp_url_query ? this.sensors_mp_url_query : "", 
            t = e.extend(t, e.getUtmFromPage()), r.para.onshow ? r.para.onshow(r, n, this) : r.para.autoTrack && r.para.autoTrack.pageShow && r.autoTrackCustom.trackCustom("pageShow", t, "$MPViewScreen"), 
            d = n, r.status.referrer = n;
        },
        pageShare: function(n, i) {
            var a = n.onShareAppMessage;
            n.onShareAppMessage = function() {
                var n = a.apply(this, arguments);
                return r.para.autoTrack && r.para.autoTrack.pageShare && r.autoTrackCustom.trackCustom("pageShare", {
                    $url_path: e.getCurrentPath(),
                    $share_depth: e.getShareDepth()
                }, "$MPShare"), r.para.allow_amend_share_path && ("object" != (void 0 === n ? "undefined" : t(n)) && ((n = {}).path = e.getCurrentUrl(this)), 
                "object" != (void 0 === n ? "undefined" : t(n)) || void 0 !== n.path && "" !== n.path || (n.path = e.getCurrentUrl(this)), 
                "object" == (void 0 === n ? "undefined" : t(n)) && "string" == typeof n.path && (-1 === n.path.indexOf("?") ? n.path = n.path + "?" : "&" !== n.path.slice(-1) && (n.path = n.path + "&")), 
                n.path = n.path + "sampshare=" + encodeURIComponent(e.getShareInfo())), n;
            };
        }
    }, r.quick = function() {
        var t = arguments[0], i = arguments[1], a = arguments[2], s = e.isObject(a) ? a : {};
        if ("getAnonymousID" === t) {
            if (!e.isEmptyObject(r.store._state)) return r.store._state.first_id ? r.store._state.first_id : r.store._state.distinct_id;
            n.info("请先初始化SDK");
        } else "appLaunch" === t || "appShow" === t ? i ? r.autoTrackCustom[t](i, s) : n.info("App的launch和show，在sensors.quick第二个参数必须传入App的options参数") : "appHide" === t && (s = e.isObject(i) ? i : {}, 
        r.autoTrackCustom[t](s));
    };
    var y = App;
    App = function(t) {
        _(t, "onLaunch", "appLaunch"), _(t, "onShow", "appShow"), _(t, "onHide", "appHide"), 
        y.apply(this, arguments);
    };
    var S = Page;
    Page = function(t) {
        _(t, "onLoad", "pageLoad"), _(t, "onShow", "pageShow"), "function" == typeof t.onShareAppMessage && r.autoTrackCustom.pageShare(t), 
        S.apply(this, arguments);
    };
    var b = Component;
    Component = function(t) {
        try {
            t.methods = t.methods || {}, _(t.methods, "onLoad", "pageLoad"), _(t.methods, "onShow", "pageShow"), 
            "function" == typeof t.methods.onShareAppMessage && r.autoTrackCustom.pageShare(t.methods), 
            b.apply(this, arguments);
        } catch (t) {
            b.apply(this, arguments);
        }
    }, r.initial(), module.exports = r;
}();