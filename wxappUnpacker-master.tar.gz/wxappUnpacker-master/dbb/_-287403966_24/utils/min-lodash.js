!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    var n = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(n) {
        return typeof n;
    } : function(n) {
        return n && "function" == typeof Symbol && n.constructor === Symbol && n !== Symbol.prototype ? "symbol" : typeof n;
    };
    function t(n) {
        if (Array.isArray(n)) {
            for (var t = 0, r = Array(n.length); t < n.length; t++) r[t] = n[t];
            return r;
        }
        return Array.from(n);
    }
    var r = function(n) {
        return Object.prototype.toString.call(n);
    }, e = function(t) {
        var r = void 0 === t ? "undefined" : n(t);
        return null != t && ("object" == r || "function" == r);
    }, i = function(n, t, r) {
        var i, o, u, c, a, f, l = 0, s = !1, y = !1, d = !0;
        if ("function" != typeof n) throw new TypeError("Expected a function");
        function v(t) {
            var r = i, e = o;
            return i = o = void 0, l = t, c = n.apply(e, r);
        }
        function p(n) {
            var r = n - f;
            return void 0 === f || t <= r || r < 0 || y && u <= n - l;
        }
        function m() {
            var n = Date.now();
            if (p(n)) return g(n);
            a = setTimeout(m, function(n) {
                var r = n - l, e = t - (n - f);
                return y ? Math.min(e, u - r) : e;
            }(n));
        }
        function g(n) {
            return a = void 0, d && i ? v(n) : (i = o = void 0, c);
        }
        function b() {
            var n = Date.now(), r = p(n);
            if (i = arguments, o = this, f = n, r) {
                if (void 0 === a) return function(n) {
                    return l = n, a = setTimeout(m, t), s ? v(n) : c;
                }(f);
                if (y) return a = setTimeout(m, t), v(f);
            }
            return void 0 === a && (a = setTimeout(m, t)), c;
        }
        return t = +t || 0, e(r) && (s = !!r.leading, u = (y = "maxWait" in r) ? Math.max(+r.maxWait || 0, t) : u, 
        d = "trailing" in r ? !!r.trailing : d), b.cancel = function() {
            void 0 !== a && clearTimeout(a), i = f = o = a = void (l = 0);
        }, b.flush = function() {
            return void 0 === a ? c : g(Date.now());
        }, b;
    };
    exports.default = {
        isFunction: function(n) {
            return "[object Function]" === r(n);
        },
        isArray: function(n) {
            return "[object Array]" === r(n);
        },
        isEmpty: function(n) {
            return [ Object, Array ].includes((n || {}).constructor) && !function(n) {
                return Object.entries ? Object.entries(n) : function(n) {
                    for (var t = Object.keys(n), r = t.length, e = new Array(r); r--; ) e[r] = [ t[r], n[t[r]] ];
                    return e;
                }(n);
            }(n || {}).length;
        },
        get: function(n, t, r) {
            function e(r) {
                return String.prototype.split.call(t, r).filter(Boolean).reduce(function(n, t) {
                    return null != n ? n[t] : n;
                }, n);
            }
            var i = 2 < arguments.length && void 0 !== r ? r : void 0, o = e(/[,[\]]+?/) || e(/[,[\].]+?/);
            return void 0 === o || o === n ? i : o;
        },
        last: function(n) {
            return n.slice(-1)[0];
        },
        chunk: function(n, r) {
            return n.reduce(function(n, e, i) {
                return i % r == 0 ? [].concat(t(n), [ [ e ] ]) : [].concat(t(n.slice(0, -1)), [ [].concat(t(n.slice(-1)[0]), [ e ]) ]);
            }, []);
        },
        debounce: i,
        throttle: function(n, t, r) {
            var o = !0, u = !0;
            if ("function" != typeof n) throw new TypeError("Expected a function");
            return e(r) && (o = "leading" in r ? !!r.leading : o, u = "trailing" in r ? !!r.trailing : u), 
            i(n, t, {
                leading: o,
                maxWait: t,
                trailing: u
            });
        },
        isFinite: function(n) {
            return Number.isFinite(n);
        },
        inRange: function(n, t, r) {
            var e = 2 < arguments.length && void 0 !== r ? r : 0;
            return Math.min(t, e) <= n && n < Math.max(t, e);
        },
        indexOf: function(n, t) {
            return n.indexOf(t);
        },
        isNil: function(n) {
            return null == n;
        },
        assign: function() {
            return Object.assign.apply(Object, arguments);
        },
        pickOwnBy: function(n) {
            var t = {};
            for (var r in n) n[r] && n.hasOwnProperty(r) && (t[r] = n[r]);
            return t;
        }
    };
}();