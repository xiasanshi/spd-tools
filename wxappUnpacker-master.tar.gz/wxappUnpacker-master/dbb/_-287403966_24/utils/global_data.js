!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    }), exports.setGlobalData = function(e, t) {
        a.default.setStorage({
            key: e,
            data: t
        });
    }, exports.getGlobalData = function(e) {
        return a.default.getStorageSync(e);
    };
    var e, t = require("../npm/@tarojs/taro-weapp/index.js"), a = (e = t) && e.__esModule ? e : {
        default: e
    };
}();