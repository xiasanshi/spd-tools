!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    }), exports.snakeCase = exports.camelCase = void 0;
    var e, r = require("../npm/@tarojs/taro-weapp/index.js");
    (e = r) && e.__esModule;
    exports.camelCase = function(e, r) {
        var t = 1 < arguments.length && void 0 !== r ? r : "_";
        return e.replace(new RegExp(t + "([a-z])", "g"), function() {
            for (var e = arguments.length, r = Array(e), t = 0; t < e; t++) r[t] = arguments[t];
            return r[1].toUpperCase();
        });
    }, exports.snakeCase = function(e, r) {
        var t = 1 < arguments.length && void 0 !== r ? r : "_";
        return e.replace(/([A-Z])/g, function() {
            for (var e = arguments.length, r = Array(e), a = 0; a < e; a++) r[a] = arguments[a];
            return "" + t + r[1].toLowerCase();
        });
    };
}();