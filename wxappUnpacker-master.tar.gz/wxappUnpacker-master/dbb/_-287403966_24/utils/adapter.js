!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    }), exports.throttleButton = exports.hideToastAftLoading = exports.loopHandler = exports.getCurrentRoute = exports.getFormId = exports.doNothing = exports.scanCode4Business = exports.isExsit = exports.calcDistance = exports.timeStamp = exports.checkUpdate = exports.tryGoToNearStore = exports.requestPayment = exports.promisely = void 0;
    var t = Object.assign || function(t) {
        for (var e = 1; e < arguments.length; e++) {
            var n = arguments[e];
            for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (t[r] = n[r]);
        }
        return t;
    }, e = o(require("../npm/@tarojs/taro-weapp/index.js")), n = o(require("./min-lodash.js")), r = require("./index.js");
    function o(t) {
        return t && t.__esModule ? t : {
            default: t
        };
    }
    function i(t) {
        return function() {
            var e = t.apply(this, arguments);
            return new Promise(function(t, n) {
                return function r(o, i) {
                    try {
                        var a = e[o](i), u = a.value;
                    } catch (o) {
                        return void n(o);
                    }
                    if (!a.done) return Promise.resolve(u).then(function(t) {
                        r("next", t);
                    }, function(t) {
                        r("throw", t);
                    });
                    t(u);
                }("next");
            });
        };
    }
    var a, u, s = exports.promisely = function(e, n) {
        return new Promise(function(r, o) {
            e(t({}, n, {
                success: function() {
                    r.apply(void 0, arguments);
                },
                fail: function() {
                    o.apply(void 0, arguments);
                },
                complete: function() {
                    r.apply(void 0, arguments);
                }
            }));
        });
    };
    exports.requestPayment = (u = i(regeneratorRuntime.mark(function t(e) {
        return regeneratorRuntime.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", new Promise(function() {
                    var t = i(regeneratorRuntime.mark(function t(n, r) {
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                              case 0:
                                s(my.tradePay, e).then(function(t) {
                                    9e3 == ~~t.resultCode ? n(t) : r(t);
                                }).catch(function(t) {
                                    return r(t);
                                });

                              case 1:
                              case "end":
                                return t.stop();
                            }
                        }, t, void 0);
                    }));
                    return function(e, n) {
                        return t.apply(this, arguments);
                    };
                }()));

              case 1:
              case "end":
                return t.stop();
            }
        }, t, void 0);
    })), function(t) {
        return u.apply(this, arguments);
    }), exports.tryGoToNearStore = (a = i(regeneratorRuntime.mark(function t(n, o, i) {
        var a;
        return regeneratorRuntime.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                if (t.prev = 0, t.t0 = i || (0, r.getGlobalData)("location"), t.t0) {
                    t.next = 6;
                    break;
                }
                return t.next = 5, e.default.getLocation();

              case 5:
                t.t0 = t.sent;

              case 6:
                (a = t.t0) && a.latitude && a.longitude && e.default[o]({
                    url: "/package-store/pages/near-store/near-store?latitude=" + a.latitude + "&longitude=" + a.longitude
                }), t.next = 15;
                break;

              case 10:
                return t.prev = 10, t.t1 = t.catch(0), console.log("getLocation", t.t1), e.default.showToast({
                    title: "请授权位置以查看附近门店",
                    icon: "none",
                    duration: 1500
                }), t.abrupt("return");

              case 15:
              case "end":
                return t.stop();
            }
        }, t, void 0, [ [ 0, 10 ] ]);
    })), function(t, e, n) {
        return a.apply(this, arguments);
    }), exports.checkUpdate = function() {
        var t = e.default.getUpdateManager();
        t.onCheckForUpdate(function(t) {
            t.hasUpdate && console.log("发现新的版本！");
        }), t.onUpdateReady(function() {
            e.default.showModal({
                title: "更新提示",
                content: "新版本已准备就绪，是否重启小程序？",
                cancelText: "取消",
                confirmText: "确认"
            }).then(function(e) {
                e.confirm && t.applyUpdate();
            }), t.onUpdateFailed(function() {});
        });
    }, exports.timeStamp = function(t, e) {
        var n = {};
        if (n.day = parseInt(t / 60 / 24), n.hour = parseInt(t / 60 % 24), n.min = parseInt(t % 60), 
        e) return n;
        var r = "", o = n.day, i = n.hour, a = n.min;
        return 0 < o && (r = o + "天"), 0 < i && (r += i + "小时"), 0 < a && (r += parseFloat(a) + "分钟"), 
        r;
    }, exports.calcDistance = function(t) {
        if (!n.default.isFinite(t)) return "";
        switch (!0) {
          case n.default.inRange(t, 0, 1e3):
            return t + "m";

          default:
            return (t / 1e3).toFixed(2) + "km";
        }
    }, exports.isExsit = function(t, e) {
        return !!n.default.isArray(t) && -1 != n.default.indexOf(t, e);
    }, exports.scanCode4Business = function(t) {
        e.default.scanCode({
            success: function(n) {
                e.default[t]({
                    url: "/pages/scan-loading/scan-loading?qrCode=" + n.result
                });
            }
        });
    }, exports.doNothing = function() {}, exports.getFormId = function(t) {}, exports.getCurrentRoute = function() {
        var t = function(t, e) {
            if (Array.isArray(t)) return t;
            if (Symbol.iterator in Object(t)) return function(t, e) {
                var n = [], r = !0, o = !1, i = void 0;
                try {
                    for (var a, u = t[Symbol.iterator](); !(r = (a = u.next()).done) && (n.push(a.value), 
                    !e || n.length !== e); r = !0) ;
                } catch (t) {
                    o = !0, i = t;
                } finally {
                    try {
                        !r && u.return && u.return();
                    } finally {
                        if (o) throw i;
                    }
                }
                return n;
            }(t, e);
            throw new TypeError("Invalid attempt to destructure non-iterable instance");
        }(e.default.getCurrentPages().slice(-1), 1)[0];
        return t && t.route || null;
    }, exports.loopHandler = function(t, e, r, o, i, a) {
        function u() {
            p = !0, t(e).then(function(t) {
                d = t.data, g(d);
            }, function(t) {
                x = t, g(null);
            });
        }
        var s = void 0, c = void 0, l = void 0, f = void 0, p = void 0, d = void 0, x = void 0, m = void 0, v = void 0, h = new Promise(function(t, e) {
            m = t, v = e;
        }), g = function(t) {
            p = !1, f ? f = l = null : l ? (l = null, y()) : n.default.isNil(t) ? c = setTimeout(u, o) : (i ? t[i] : t) === a ? c = setTimeout(u, o) : y();
        }, y = function() {
            d ? m(d) : v(x), w();
        }, w = function() {
            c && clearTimeout(c), s && clearTimeout(s), s = c = p = d = x = null;
        };
        return s = setTimeout(function() {
            p ? l = !0 : y();
        }, r), u(), {
            loopPromise: h,
            loopCancel: function() {
                p && (f = !0), v(null), w();
            }
        };
    }, exports.hideToastAftLoading = function(t) {
        setTimeout(function() {
            return e.default.showToast(t);
        });
    }, exports.throttleButton = function(t) {
        return "[object Function]" === Object.prototype.toString.call(t) ? n.default.throttle(t, 1500, {
            leading: !0,
            trailing: !1
        }) : function() {};
    };
}();