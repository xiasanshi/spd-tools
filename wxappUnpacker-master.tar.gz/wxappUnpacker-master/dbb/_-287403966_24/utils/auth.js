!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    }), exports.login = exports.getAuthCode = void 0;
    r(require("../npm/@tarojs/taro-weapp/index.js")), r(require("./min-lodash.js"));
    var e = require("./index.js"), t = require("./sensors/index.js"), n = require("../lib/request.js");
    function r(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }
    var o = exports.getAuthCode = function() {
        for (var e = arguments.length, t = Array(e), n = 0; n < e; n++) t[n] = arguments[n];
        return new Promise(function(e, t) {
            wx.login({
                success: function(t) {
                    var n = t.code, r = t.authCode;
                    e(void 0 === r ? n : r);
                }
            });
        });
    };
    exports.login = function() {
        return new Promise((r = regeneratorRuntime.mark(function r(a, u) {
            var s, i, c;
            return regeneratorRuntime.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    return r.next = 2, o("auth_base");

                  case 2:
                    s = r.sent, i = (0, e.getGlobalData)("userInfo") || {}, c = i.userId, (0, n.post)("/v1/user/login", {
                        authCode: s
                    }).then(function(n) {
                        n.data && n.data.token && ((0, e.setGlobalData)("userInfo", n.data), (0, e.setGlobalData)("token", n.data.token), 
                        c || (t.sensor.login(n.data.userId), t.sensor.init(), (0, t.$track)())), a(n.data);
                    }).catch(function(e) {
                        u(e);
                    });

                  case 5:
                  case "end":
                    return r.stop();
                }
            }, r, void 0);
        }), a = function() {
            var e = r.apply(this, arguments);
            return new Promise(function(t, n) {
                return function r(o, a) {
                    try {
                        var u = e[o](a), s = u.value;
                    } catch (o) {
                        return void n(o);
                    }
                    if (!u.done) return Promise.resolve(s).then(function(e) {
                        r("next", e);
                    }, function(e) {
                        r("throw", e);
                    });
                    t(s);
                }("next");
            });
        }, function(e, t) {
            return a.apply(this, arguments);
        }));
        var r, a;
    };
}();