!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    var e = require("./global_data.js");
    Object.defineProperty(exports, "setGlobalData", {
        enumerable: !0,
        get: function() {
            return e.setGlobalData;
        }
    }), Object.defineProperty(exports, "getGlobalData", {
        enumerable: !0,
        get: function() {
            return e.getGlobalData;
        }
    }), Object.defineProperty(exports, "clearGlobalData", {
        enumerable: !0,
        get: function() {
            return e.clearGlobalData;
        }
    });
    var t = require("./string.js");
    Object.defineProperty(exports, "camelCase", {
        enumerable: !0,
        get: function() {
            return t.camelCase;
        }
    }), Object.defineProperty(exports, "snakeCase", {
        enumerable: !0,
        get: function() {
            return t.snakeCase;
        }
    });
    var r = require("./auth.js");
    Object.defineProperty(exports, "getAuthCode", {
        enumerable: !0,
        get: function() {
            return r.getAuthCode;
        }
    }), Object.defineProperty(exports, "login", {
        enumerable: !0,
        get: function() {
            return r.login;
        }
    });
    var n = require("./date.js");
    Object.defineProperty(exports, "timestampToTime", {
        enumerable: !0,
        get: function() {
            return n.timestampToTime;
        }
    });
    var o = require("./adapter.js");
    Object.defineProperty(exports, "promisely", {
        enumerable: !0,
        get: function() {
            return o.promisely;
        }
    }), Object.defineProperty(exports, "requestPayment", {
        enumerable: !0,
        get: function() {
            return o.requestPayment;
        }
    }), Object.defineProperty(exports, "tryGoToNearStore", {
        enumerable: !0,
        get: function() {
            return o.tryGoToNearStore;
        }
    }), Object.defineProperty(exports, "timeStamp", {
        enumerable: !0,
        get: function() {
            return o.timeStamp;
        }
    }), Object.defineProperty(exports, "calcDistance", {
        enumerable: !0,
        get: function() {
            return o.calcDistance;
        }
    }), Object.defineProperty(exports, "isExsit", {
        enumerable: !0,
        get: function() {
            return o.isExsit;
        }
    }), Object.defineProperty(exports, "doNothing", {
        enumerable: !0,
        get: function() {
            return o.doNothing;
        }
    }), Object.defineProperty(exports, "scanCode4Business", {
        enumerable: !0,
        get: function() {
            return o.scanCode4Business;
        }
    }), Object.defineProperty(exports, "checkUpdate", {
        enumerable: !0,
        get: function() {
            return o.checkUpdate;
        }
    }), Object.defineProperty(exports, "getFormId", {
        enumerable: !0,
        get: function() {
            return o.getFormId;
        }
    }), Object.defineProperty(exports, "getCurrentRoute", {
        enumerable: !0,
        get: function() {
            return o.getCurrentRoute;
        }
    }), Object.defineProperty(exports, "loopHandler", {
        enumerable: !0,
        get: function() {
            return o.loopHandler;
        }
    }), Object.defineProperty(exports, "hideToastAftLoading", {
        enumerable: !0,
        get: function() {
            return o.hideToastAftLoading;
        }
    }), Object.defineProperty(exports, "throttleButton", {
        enumerable: !0,
        get: function() {
            return o.throttleButton;
        }
    });
}();