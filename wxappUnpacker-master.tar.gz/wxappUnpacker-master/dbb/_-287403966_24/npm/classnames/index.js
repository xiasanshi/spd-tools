!function() {
    "use strict";
    var e = {}.hasOwnProperty;
    function n() {
        for (var r = [], t = 0; t < arguments.length; t++) {
            var f = arguments[t];
            if (f) {
                var o = typeof f;
                if ("string" == o || "number" == o) r.push(f); else if (Array.isArray(f) && f.length) {
                    var i = n.apply(null, f);
                    i && r.push(i);
                } else if ("object" == o) for (var a in f) e.call(f, a) && f[a] && r.push(a);
            }
        }
        return r.join(" ");
    }
    "undefined" != typeof module && module.exports ? (n.default = n, module.exports = n) : "function" == typeof define && "object" == typeof define.amd && define.amd ? define("classnames", [], function() {
        return n;
    }) : window.classNames = n;
}();