!function() {
    var e = "undefined" != typeof window && window.Math === Math ? window : "object" == typeof global ? global : this;
    e.Promise || (e.Promise = require("../../promise-polyfill/lib/index.js")), e.regeneratorRuntime || (e.regeneratorRuntime = require("../../regenerator-runtime/runtime.js"));
}();