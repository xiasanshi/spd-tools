var n = getApp();

Page({
    data: {},
    onLoad: function() {
        this.openingMember();
    },
    onReady: function() {},
    onShow: function() {},
    openingMember: function() {
        var e = this;
        wx.request({
            url: n.configObj.productDetail,
            data: {
                session: n.globalData.session,
                version: "1.0"
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(n) {
                if (0 == n.data.code) {
                    var o = n.data.data.signing_code, t = n.data.data.deduction_price;
                    e.setData({
                        deduction_price: t,
                        signing_code: o
                    });
                }
            },
            fail: function() {},
            complete: function() {}
        });
    },
    manageRenew: function() {
        var n = this.data.deduction_price;
        wx.redirectTo({
            url: "/pages/index/member/runRenew/runRenew?backRoot=false&deduction_price=" + n
        });
    },
    toaboutUs: function() {
        wx.navigateTo({
            url: "/packageuser/user/aboutUs/aboutUs"
        });
    },
    handleCall: function(n) {
        var e = n.target.dataset.phone;
        wx.makePhoneCall({
            phoneNumber: e
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});