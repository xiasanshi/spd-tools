var e = getApp();

Page({
    clickableNot: !0,
    data: {
        usablemoney: 0,
        advertisingflag: !1,
        Unopened: !1,
        isconnection: !1
    },
    onLoad: function(e) {
        var a = this;
        a.numIsPhone(), a.setData({
            usablemoney: e.usablemoney
        });
    },
    onShow: function() {
        getApp().http_post({
            bhv_type: "view",
            obj_type: "Page",
            title: "提现",
            act_obj: 10042
        });
    },
    numIsPhone: function() {
        var a = this;
        wx.request({
            url: e.configObj.IsPhoneNum,
            data: {
                session: e.globalData.session
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(e) {
                0 == e.data.code ? a.setData({
                    datacode: 0
                }) : 1 == e.data.code && a.setData({
                    datacode: 1
                });
            }
        });
    },
    goHomeTap: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    resultTap: function() {
        var a = this;
        getApp().http_post({
            bhv_type: "click",
            obj_type: "Control",
            title: "提现",
            control_name: "提现_申请提现",
            act_obj: 10043
        }), 1 == a.clickableNot && (a.clickableNot = !1, wx.requestSubscribeMessage ? wx.requestSubscribeMessage({
            tmplIds: [ e.configObj.newsID.withdrawID ],
            success: function(e) {},
            fail: function(e) {},
            complete: function(e) {
                a.setData({
                    isconnection: !0,
                    advertisingflag: !0
                }), a.clickableNot = !0;
            }
        }) : (a.setData({
            isconnection: !0,
            advertisingflag: !0
        }), a.clickableNot = !0));
    },
    cancel: function() {
        this.setData({
            isconnection: !1,
            advertisingflag: !1
        });
    },
    withdrawal: function() {
        var a = this, o = a.data.usablemoney;
        wx.showLoading({
            title: "请稍后",
            mask: !0
        }), wx.request({
            url: e.configObj.refundUrl,
            data: {
                session: e.globalData.session
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(e) {
                0 == e.data.errcode || 3 == e.data.errcode || 5 == e.data.errcode ? (a.requestUserInfo(), 
                wx.redirectTo({
                    url: "/packageuser/user/mywallet/refund/refund?refund=" + o
                })) : 1 == e.data.errcode ? wx.showModal({
                    content: "账户余额不足!",
                    confirmText: "确定",
                    success: function(e) {
                        e.confirm;
                    }
                }) : 2 == e.data.errcode ? wx.showModal({
                    content: "提现申请中,请耐心等待",
                    confirmText: "确定",
                    success: function(e) {
                        e.confirm && a.requestUserInfo();
                    }
                }) : wx.showToast({
                    title: "提现申请失败",
                    icon: "fail",
                    duration: 2e3
                });
            },
            fail: function() {
                wx.showModal({
                    content: res.data.msg,
                    showCancel: !1,
                    confirmText: "确定",
                    success: function(e) {}
                });
            },
            complete: function() {
                wx.hideLoading();
            }
        });
    },
    getPhoneNumber: function(a) {
        var o = this, t = a.detail.iv, n = a.detail.encryptedData, s = e.globalData.authCode, c = e.globalData.trdSessionId;
        "getPhoneNumber:fail 用户未绑定手机，请先在微信客户端进行绑定后重试" == a.detail.errMsg || "getPhoneNumber:fail user deny" == a.detail.errMsg || "getPhoneNumber:ok" == a.detail.errMsg && o.loginServerPhoneNumber(s, t, n, c, o);
    },
    loginServerPhoneNumber: function(a, o, t, n, s) {
        wx.request({
            url: e.configObj.loginPhoneNumber,
            data: {
                code: a,
                encryptedData: t,
                iv: o,
                trdSessionId: n
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(a) {
                var o = a.data.data.purePhoneNumber;
                wx.request({
                    url: e.configObj.bindingPhoneNum,
                    data: {
                        session: e.globalData.session,
                        mobile: o,
                        code: "weChatPhoneNumberCode"
                    },
                    header: {
                        "Content-Type": "application/x-www-form-urlencoded"
                    },
                    method: "POST",
                    success: function(e) {
                        1 == e.data.code ? (s.setData({
                            advertisingflag: !0,
                            Unopened: !0
                        }), s.numIsPhone()) : wx.showModal({
                            content: e.data.msg,
                            showCancel: !1,
                            confirmText: "确定",
                            success: function(e) {
                                e.confirm && wx.navigateBack({
                                    delta: 1
                                });
                            }
                        });
                    }
                });
            }
        });
    },
    Close: function() {
        this.setData({
            advertisingflag: !1,
            Unopened: !1
        });
    },
    requestUserInfo: function() {
        var a = this;
        e.globalData.session && wx.request({
            url: e.configObj.userInfoUrl,
            data: {
                session: e.globalData.session
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(o) {
                var t = !1;
                if ((o.data.data.user_info.usablemoney <= 0 || 0 != o.data.code) && (t = !0), a.setData({
                    adisabled: t
                }), 0 == o.data.code) {
                    if (null != o.data.data.phone_num) n = o.data.data.phone_num.replace(/(\d{3})\d{4}(\d{4})/, "$1****$2"); else var n = null;
                    a.setData({
                        userInfo: o.data.data.user_info,
                        phonenum: n
                    });
                } else 1 == o.data.code ? console.log("缺少必要参数") : 2 == o.data.code ? (console.log("session有误"), 
                e.globalData.session = null, e.login()) : 3 == o.data.code ? console.log("登录code不合法") : 4 == o.data.code ? console.log("用户加密数据解密错误") : 5 == o.data.code && (console.log("session 过期"), 
                e.globalData.session = null, e.login());
            },
            fail: function() {
                wx.showModal({
                    content: "当前网络不佳,请切换网络重新进入该页面",
                    showCancel: !1,
                    confirmText: "我知道了",
                    success: function(e) {
                        e.confirm && wx.navigateBack({
                            delta: 1
                        });
                    }
                });
            },
            complete: function() {}
        });
    }
});