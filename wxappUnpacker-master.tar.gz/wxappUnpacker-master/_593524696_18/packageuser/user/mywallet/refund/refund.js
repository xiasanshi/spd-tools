var t = require("../../../../utils/util.js"), e = getApp();

Page({
    data: {
        request_time: "",
        status: 0,
        usablemoney: 0
    },
    onLoad: function(t) {
        t.request_time ? this.setData({
            request_time: t.request_time,
            status: t.status
        }) : this.getWithdrawRecods(), this.setData({
            refund: t.refund
        });
    },
    onShow: function() {
        getApp().http_post({
            bhv_type: "view",
            obj_type: "Page",
            title: "提现进度",
            act_obj: 10044
        });
    },
    getWithdrawRecods: function() {
        var s = this;
        wx.request({
            url: e.configObj.withdrawRecodsUrl,
            data: {
                session: e.globalData.session
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(e) {
                var a = e.data.data.refund_logs[0], i = t.toDate(a.request_time);
                s.setData({
                    request_time: i,
                    status: a.status
                });
            },
            fail: function() {},
            complete: function() {}
        });
    },
    gohome: function() {
        wx.reLaunch({
            url: "/pages/index/index"
        });
    }
});