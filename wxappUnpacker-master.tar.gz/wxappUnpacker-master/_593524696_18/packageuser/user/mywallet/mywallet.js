var t = getApp();

Page({
    adv_objStr: {},
    data: {
        adisabled: !0,
        showModalAdv: !0
    },
    setUpData: function() {
        var a = t.globalData.userInfo;
        if (a) {
            var e;
            e = !(a.usablemoney > 0), this.setData({
                userInfo: a,
                adisabled: e
            }), wx.hideLoading();
        }
    },
    onLoad: function() {
        wx.showLoading({
            title: "正在加载"
        }), this.setUpData(), t.userInfoRequest(this.setUpData);
    },
    onShow: function() {
        var a = this;
        getApp().http_post({
            bhv_type: "view",
            obj_type: "Page",
            title: "我的钱包",
            act_obj: 10045
        });
        var e = wx.getStorageSync("adv_obj");
        e && (a.adv_objStr = JSON.parse(e), a.adv_objStr.wechat_wt && (a.data.showModalAdv && t.advExposure(a.adv_objStr.wechat_wt, "300015"), 
        a.setData({
            checkUrl_wechat_wt: a.adv_objStr.wechat_wt.checkUrl,
            materialUrl_wechat_wt: t.configObj.advImgAdd + a.adv_objStr.wechat_wt.materialUrl
        })), a.adv_objStr.wechat_wdb && (t.advExposure(a.adv_objStr.wechat_wdb, "300014"), 
        a.setData({
            checkUrl_wechat_wdb: a.adv_objStr.wechat_wdb.checkUrl,
            materialUrl_wechat_wdb: t.configObj.advImgAdd + a.adv_objStr.wechat_wdb.materialUrl
        })));
    },
    onPullDownRefresh: function() {
        wx.showLoading({
            title: "正在加载"
        }), t.userInfoRequest(this.setUpData), wx.stopPullDownRefresh();
    },
    noTitlemodalTap: function(t) {
        var a = this;
        getApp().http_post({
            bhv_type: "click",
            obj_type: "Control",
            title: "我的钱包",
            control_name: "我的钱包_提现",
            act_obj: 10041
        });
        var e = a.data.userInfo.usablemoney;
        wx.navigateTo({
            url: "/packageuser/user/mywallet/withdraw/withdraw?usablemoney=" + e
        });
    },
    catchAd: function() {
        t.pushAdv(this.adv_objStr.wechat_wdb, "300014");
    },
    onbinddoumob: function() {
        t.pushAdv(this.adv_objStr.wechat_wt, "300015"), this.adv_objStr.wechat_wt.checkUrl && this.setData({
            showModalAdv: !1
        });
    },
    hideModal: function() {
        this.setData({
            showModalAdv: !1
        });
    },
    transactionDetails: function() {
        wx.navigateTo({
            url: "/packageuser/user/mywallet/transaction/transaction"
        });
    }
});