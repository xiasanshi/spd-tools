var t = require("../../../../utils/util.js"), a = getApp();

Page({
    toolItemW: 0,
    data: {
        width: 0,
        height: 0,
        currentTab: 0,
        status: 0,
        request_time: "",
        refund_time: ""
    },
    onLoad: function() {
        var t = this;
        wx.showLoading({
            title: "正在加载"
        }), wx.getSystemInfo({
            success: function(a) {
                t.setData({
                    width: a.windowWidth,
                    height: a.windowHeight
                });
            }
        }), t.recharge(), t.deductions(), t.getWithdrawRecods(), t.paidMember(), this.toolItemW = wx.getSystemInfoSync().windowWidth / 4;
        var a = (this.toolItemW - 50) / 2;
        t.setData({
            lineX: a
        });
    },
    onPullDownRefresh: function() {
        wx.showLoading({
            title: "正在加载"
        }), this.recharge(), this.deductions(), this.getWithdrawRecods(), this.paidMember(), 
        wx.stopPullDownRefresh();
    },
    scheTap: function(t) {
        var a = this, e = t.currentTarget.dataset.ind, d = a.data.refund_logs[e].request_time, n = a.data.refund_logs[e].status, o = a.data.refund_logs[e].refund;
        wx.navigateTo({
            url: "/packageuser/user/mywallet/refund/refund?request_time=" + d + "&status=" + n + "&refund=" + o
        });
    },
    bindChange: function(t) {
        var a = this;
        if ("touch" == t.detail.source) {
            var e = t.detail.current, d = this.toolItemW * e + (this.toolItemW - 50) / 2;
            a.setData({
                currentTab: e,
                lineX: d
            });
        }
    },
    swichNav: function(t) {
        var a = this;
        if (this.data.currentTab === t.target.dataset.current) return !1;
        var e = t.target.dataset.current, d = this.toolItemW * e + (this.toolItemW - 50) / 2;
        a.setData({
            currentTab: e,
            lineX: d
        });
    },
    objSort: function(t) {
        return function(a) {
            return 1 == a[t] ? -1 : 0;
        };
    },
    getWithdrawRecods: function() {
        var e = this;
        wx.request({
            url: a.configObj.withdrawRecodsUrl,
            data: {
                session: a.globalData.session
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(a) {
                if (0 == a.data.code && a.data.data.refund_logs.length > 0) {
                    for (var d = 0; d < a.data.data.refund_logs.length; d++) a.data.data.refund_logs[d].request_time = t.toDate(a.data.data.refund_logs[d].request_time), 
                    a.data.data.refund_logs[d].refund_time = t.toDate(a.data.data.refund_logs[d].refund_time);
                    e.setData({
                        refund_logs: a.data.data.refund_logs
                    });
                }
            },
            fail: function() {},
            complete: function() {
                wx.hideLoading();
            }
        });
    },
    look: function(t) {
        this.data.refund_logs[t.currentTarget.dataset.ind].look = "查看" === this.data.refund_logs[t.currentTarget.dataset.ind].look ? "收起" : "查看", 
        this.data.refund_logs[t.currentTarget.dataset.ind].open = !this.data.refund_logs[t.currentTarget.dataset.ind].open, 
        this.setData({
            refund_logs: this.data.refund_logs
        });
    },
    refundHelp: function() {
        wx.navigateTo({
            url: "/pages/deposit/refundHelp/refundHelp"
        });
    },
    recharge: function() {
        var e = this;
        wx.request({
            url: a.configObj.getUserPaidLogs,
            data: {
                session: a.globalData.session
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(a) {
                if (0 == a.data.code && a.data.data.userPaidLogs.length > 0) for (var d = 0; d < a.data.data.userPaidLogs.length; d++) {
                    a.data.data.userPaidLogs[d].created_date = t.toDate(a.data.data.userPaidLogs[d].created_date / 1e3);
                    a.data.data.userPaidLogs[d].created_date, a.data.data.userPaidLogs[d].paid;
                    e.setData({
                        userPaidLogs: a.data.data.userPaidLogs
                    });
                }
            },
            fail: function() {},
            complete: function() {
                wx.hideLoading();
            }
        });
    },
    deductions: function() {
        var e = this;
        wx.request({
            url: a.configObj.getUseFeeOrderList,
            data: {
                session: a.globalData.session,
                page: 0
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(a) {
                if (0 == a.data.code && a.data.data.length > 0) {
                    for (var d = 0; d < a.data.data.length; d++) a.data.data[d].returnTime = t.toDate(a.data.data[d].returnTime / 1e3);
                    e.setData({
                        OrderList: a.data.data
                    });
                }
            },
            fail: function() {},
            complete: function() {
                wx.hideLoading();
            }
        });
    },
    paidMember: function() {
        var e = this;
        wx.request({
            url: a.configObj.memberPaidOrder,
            data: {
                session: a.globalData.session
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(a) {
                if (0 == a.data.code && a.data.data.length > 0) {
                    for (var d = 0; d < a.data.data.length; d++) a.data.data[d].pay_time = t.toDate(a.data.data[d].pay_time / 1e3);
                    e.setData({
                        paymember: a.data.data
                    });
                }
            },
            fail: function() {},
            complete: function() {
                wx.hideLoading();
            }
        });
    }
});