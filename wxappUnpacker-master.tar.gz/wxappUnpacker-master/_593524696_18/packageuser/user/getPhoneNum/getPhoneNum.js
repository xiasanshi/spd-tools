var t = getApp(), o = /^(((13[0-9]{1})|(14[0-9]{1})|(15[0-9]{1})|(16[0-9]{1})|(17[0-9]{1})|(18[0-9]{1})|(19[0-9]{1}))+\d{8})$/;

Page({
    countdown: 60,
    data: {
        advertisingflag: !1,
        issucsCode: !1,
        binded: !1,
        isopen: !1,
        issucopen: !1,
        isHistoryData: !1,
        isgray: !0,
        isgreen: !1,
        isnobut: !0,
        isyesbut: !1,
        last_time: "",
        is_show: !0,
        isimg_show: !1,
        data_phone: "",
        data_verify: "",
        datacode: 2
    },
    onLoad: function(t) {
        var o = this;
        "null" == t.phonenum ? o.setData({
            isBinded: !1
        }) : o.setData({
            isBinded: !0,
            phonenum: t.phonenum
        });
    },
    onShow: function() {},
    settime: function(t) {
        if (0 == t.countdown) return t.setData({
            is_show: !0,
            isHistoryData: !0
        }), void (t.countdown = 60);
        t.setData({
            is_show: !1,
            last_time: t.countdown,
            isHistoryData: !0
        }), t.countdown--, setTimeout(function() {
            t.settime(t);
        }, 1e3);
    },
    input_phoneNum: function(t) {
        this.setData({
            data_phone: t.detail.value
        }), 11 == this.data.data_phone.length ? this.setData({
            isgray: !1,
            isgreen: !0,
            isimg_show: !0
        }) : 60 == this.countdown ? this.setData({
            isgray: !0,
            isgreen: !1,
            isimg_show: !1
        }) : this.countdown > 0 && this.countdown < 60 && this.setData({
            isgray: !1,
            isgreen: !1,
            isimg_show: !1,
            is_show: !1
        });
    },
    clear_phoneNum: function() {
        this.countdown > 0 && this.countdown < 60 ? this.setData({
            inputValue: "",
            isimg_show: !1,
            isgreen: !1,
            isgray: !1,
            data_phone: "",
            is_show: !1
        }) : this.setData({
            inputValue: "",
            isimg_show: !1,
            isgreen: !1,
            isgray: !0,
            data_phone: ""
        });
    },
    input_identifyCode: function(t) {
        this.setData({
            data_verify: t.detail.value
        }), 4 != this.data.data_verify.length && 6 != this.data.data_verify.length || 11 != this.data.data_phone.length ? this.setData({
            isnobut: !0,
            isyesbut: !1
        }) : this.setData({
            isnobut: !1,
            isyesbut: !0
        });
    },
    clickVerify: function() {
        var n = this, s = n.data.data_phone;
        return 0 == s.length ? (wx.showModal({
            content: "手机号不能为空",
            confirmText: "确定",
            confirmColor: "#23C788",
            showCancel: !1,
            success: function(t) {}
        }), !1) : s.length < 11 ? (wx.showModal({
            content: "手机号长度有误",
            confirmText: "确定",
            confirmColor: "#23C788",
            showCancel: !1,
            success: function(t) {}
        }), !1) : o.test(s) ? (wx.showLoading({
            title: "加载中",
            mask: !0
        }), void wx.request({
            url: t.configObj.verification,
            data: {
                session: t.globalData.session,
                mobile: s
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(t) {
                wx.hideLoading(), 1 == t.data.code ? (n.setData({
                    issucsCode: !0,
                    advertisingflag: !0
                }), n.setData({
                    is_show: !n.data.is_show
                }), n.settime(n)) : wx.showToast({
                    title: "发送失败,请稍后再试",
                    icon: "none"
                });
            },
            fail: function() {
                wx.hideLoading(), wx.showToast({
                    title: "发送失败,请稍后再试",
                    icon: "none"
                });
            }
        })) : (wx.showModal({
            content: "手机号有误",
            confirmText: "确定",
            confirmColor: "#23C788",
            showCancel: !1,
            success: function(t) {}
        }), !1);
    },
    nextStep: function() {
        var n = this, s = n.data.data_phone, e = (n.data.isBinded, n.data.datacode, n.data.data_verify);
        return 0 == s.length ? (wx.showModal({
            content: "手机号不能为空",
            confirmText: "确定",
            confirmColor: "#23C788",
            showCancel: !1,
            success: function(t) {}
        }), !1) : s.length < 11 ? (wx.showModal({
            content: "手机号长度有误",
            confirmText: "确定",
            confirmColor: "#23C788",
            showCancel: !1,
            success: function(t) {}
        }), !1) : o.test(s) ? 0 == e.length ? (wx.showModal({
            content: "验证码不能为空",
            confirmText: "确定",
            confirmColor: "#23C788",
            showCancel: !1,
            success: function(t) {}
        }), !1) : void wx.request({
            url: t.configObj.checkMobileIsBinded,
            data: {
                session: t.globalData.session,
                code: e,
                mobile: s
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(o) {
                0 == o.data.code || 2 == o.data.code ? wx.request({
                    url: t.configObj.bindingPhoneNum,
                    data: {
                        session: t.globalData.session,
                        mobile: s
                    },
                    header: {
                        "Content-Type": "application/x-www-form-urlencoded"
                    },
                    method: "POST",
                    success: function(t) {
                        0 == t.data.code ? n.setData({
                            advertisingflag: !0,
                            binded: !0
                        }) : 3 == t.data.code && n.setData({
                            advertisingflag: !0,
                            issucopen: !0
                        });
                    },
                    fail: function(t) {
                        wx.showModal({
                            content: "当前网络延迟，请稍后再试",
                            confirmText: "确定",
                            success: function(t) {
                                t.confirm && wx.navigateBack({
                                    delta: 1
                                });
                            }
                        });
                    }
                }) : 1 == o.data.code ? n.setData({
                    advertisingflag: !0,
                    isopen: !0
                }) : wx.showModal({
                    content: o.data.msg,
                    confirmText: "确定",
                    confirmColor: "#23C788",
                    showCancel: !1,
                    success: function(t) {}
                });
            }
        }) : (wx.showModal({
            content: "手机号有误",
            confirmText: "确定",
            confirmColor: "#23C788",
            showCancel: !1,
            success: function(t) {}
        }), !1);
    },
    Sure: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    sucsCode: function() {
        this.setData({
            issucsCode: !1,
            advertisingflag: !1
        });
    }
});