Page({
    onLoad: function() {
        var e = getApp().dataObj.pg_version;
        this.setData({
            version: e
        });
    },
    agreement: function() {
        wx.navigateTo({
            url: "/packageuser/user/aboutUs/agreement/agreement"
        });
    }
});