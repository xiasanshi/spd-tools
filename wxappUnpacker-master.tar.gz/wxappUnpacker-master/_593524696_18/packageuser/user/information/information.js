var o = getApp();

Page({
    onLoad: function() {},
    onShow: function() {
        var a = this;
        wx.showLoading({
            title: "正在加载"
        });
        var e = setInterval(function() {
            o.globalData.session && (a.requestUserInfo(), a.numIsPhone(), clearInterval(e));
        }, 500);
    },
    requestUserInfo: function() {
        var a = this;
        o.globalData.session && wx.request({
            url: o.configObj.userInfoUrl,
            data: {
                session: o.globalData.session
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(e) {
                var n = !1;
                if ((e.data.data.user_info.usablemoney <= 0 || 0 != e.data.code) && (n = !0), a.setData({
                    adisabled: n,
                    isbinding: 1
                }), 0 == e.data.code) {
                    if (null != e.data.data.phone_num) s = e.data.data.phone_num.replace(/(\d{3})\d{4}(\d{4})/, "$1****$2"); else var s = null;
                    a.setData({
                        userInfo: e.data.data.user_info,
                        phonenum: s
                    }), wx.hideLoading();
                } else 1 == e.data.code ? console.log("缺少必要参数") : 2 == e.data.code ? (console.log("session有误"), 
                o.globalData.session = null, o.login()) : 3 == e.data.code ? console.log("登录code不合法") : 4 == e.data.code ? console.log("用户加密数据解密错误") : 5 == e.data.code && (console.log("session 过期"), 
                o.globalData.session = null, o.login());
            },
            fail: function() {
                wx.showModal({
                    content: "当前网络不佳,请切换网络重新进入该页面",
                    showCancel: !1,
                    confirmText: "我知道了",
                    success: function(o) {
                        o.confirm && wx.navigateBack({
                            delta: 1
                        });
                    }
                });
            },
            complete: function() {}
        });
    },
    onPullDownRefresh: function() {
        wx.showLoading({
            title: "正在加载"
        }), this.requestUserInfo(), this.numIsPhone(), wx.stopPullDownRefresh();
    },
    numIsPhone: function() {
        var a = this;
        o.globalData.session && wx.request({
            url: o.configObj.IsPhoneNum,
            data: {
                session: o.globalData.session
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(o) {
                0 == o.data.code ? a.setData({
                    datacode: 0
                }) : 1 == o.data.code && a.setData({
                    datacode: 1
                });
            }
        });
    }
});