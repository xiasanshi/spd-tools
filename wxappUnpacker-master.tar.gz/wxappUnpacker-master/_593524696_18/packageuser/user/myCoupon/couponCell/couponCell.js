require("../../../../utils/util.js");

Component({
    properties: {
        couponData: {
            type: Map,
            value: {},
            observer: "onCouponData"
        }
    },
    data: {},
    methods: {
        onCouponData: function(e) {
            e.endTime = e.end_time.replace(/\./g, "-"), this.setData({
                couponData: e
            });
        }
    }
});