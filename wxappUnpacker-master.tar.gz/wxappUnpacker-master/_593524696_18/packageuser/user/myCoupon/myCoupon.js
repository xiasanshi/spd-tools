var t, a = require("../../../utils/weapp-qrcode.js"), o = getApp();

Page({
    isHistoryData: !1,
    dataArray1: [],
    dataArray2: [],
    data: {
        code_num: "",
        lineX: 0,
        widWidth: 0,
        optionSel: 0
    },
    onLoad: function(o) {
        var e = this;
        void 0 != o.isHistoryData && (e.isHistoryData = "true" == o.isHistoryData), e.isHistoryData && wx.setNavigationBarTitle({
            title: "历史优惠券"
        }), wx.getSystemInfo({
            success: function(t) {
                e.setData({
                    width: t.windowWidth,
                    height: t.windowHeight
                });
            }
        }), e.setData({
            isHistoryData: e.isHistoryData,
            lineX: e.data.width / 6,
            widWidth: e.data.width / 6
        }), t = new a("canvas", {
            text: "code=00000000",
            width: 200,
            height: 200,
            colorDark: "#000000",
            colorLight: "#ffffff",
            correctLevel: a.CorrectLevel.H
        }), wx.showLoading({
            title: "请稍候..."
        }), this.onPullDownRefresh();
    },
    optionBtnTouch: function(t) {
        console.log(t);
        var a = t.currentTarget.dataset.index;
        if (0 == a) o = this.data.width / 6; else var o = this.data.width / 6 * 4;
        this.setData({
            lineX: o,
            optionSel: a
        }), this.setUpListData();
    },
    toHistory: function() {
        wx.navigateTo({
            url: "myCoupon?isHistoryData=true"
        });
    },
    toExplain: function() {
        wx.navigateTo({
            url: "/packageuser/user/myCoupon/Instructions/Instructions"
        });
    },
    getCouponRequest: function(t) {
        var a = this, e = t;
        wx.request({
            url: o.configObj.getTickets,
            data: {
                session: o.globalData.session,
                status: t
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(t) {
                if (0 == t.data.code) {
                    a.isHistoryData ? "1" == e ? a.dataArray1 = [] : a.dataArray2 = [] : a.dataArray1 = [];
                    for (var o = 0; o < t.data.data.length; o++) {
                        var i = t.data.data[o], s = i.status;
                        a.isHistoryData ? (i.isHistoryData = !0, 1 == s ? a.dataArray1.push(i) : 2 == s && a.dataArray2.push(i)) : 0 != s && 3 != s || a.dataArray1.push(i);
                    }
                    a.setUpListData();
                }
            },
            complete: function() {
                wx.stopPullDownRefresh(), wx.hideLoading();
            }
        });
    },
    setUpListData: function() {
        0 == this.data.optionSel ? this.setData({
            listData: this.dataArray1
        }) : 1 == this.data.optionSel && this.setData({
            listData: this.dataArray2
        });
    },
    couponcode: function(t) {
        this.setData({
            code_num: t.detail.value
        });
    },
    exchange: function() {
        var t = this, a = t.data.code_num;
        return 0 == a.length ? (wx.showToast({
            title: "券码不能为空",
            icon: "none",
            duration: 1500
        }), !1) : 8 != a.length ? (wx.showToast({
            title: "券码长度有误",
            icon: "none",
            duration: 1500
        }), !1) : void wx.request({
            url: o.configObj.exchangeTicket,
            data: {
                session: o.globalData.session,
                ticketNo: a
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(a) {
                wx.showToast({
                    title: a.data.msg,
                    icon: "none",
                    duration: 1500
                }), t.setData({
                    code_num: ""
                }), setTimeout(function() {
                    t.getCouponRequest("0");
                }, 1e3);
            }
        });
    },
    QRTouch: function(a) {
        var o = a.detail;
        console.log(o), t.makeCode("code=" + o.user_coupons_no), this.setData({
            showQR: !0
        });
    },
    advertisinghide: function() {
        this.setData({
            showQR: !1
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.isHistoryData ? (this.getCouponRequest("1"), this.getCouponRequest("2"), this.setData({
            notdataMsg: "暂无优惠券"
        })) : this.getCouponRequest("0");
    },
    onReachBottom: function() {}
});