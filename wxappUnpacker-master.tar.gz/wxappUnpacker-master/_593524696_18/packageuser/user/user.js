var e = require("../../utils/util.js"), t = getApp();

Page({
    adv_objStr: {},
    data: {
        showModalAdv: !0,
        listData: [ {
            title: "我的订单",
            image: "order"
        }, {
            title: "我的钱包",
            image: "wallet"
        }, {
            title: "我的卡券",
            image: "ticket"
        }, {
            title: "使用帮助",
            image: "help"
        }, {
            title: "设置",
            image: "set"
        } ]
    },
    onLoad: function() {
        wx.showLoading({
            title: "正在加载"
        });
    },
    onShow: function() {
        var e = this;
        t.globalData.session && e.requestUserInfo(), getApp().userLoginSuccessCallback = function() {
            e.requestUserInfo();
        }, wx.getSetting({
            success: function(e) {
                e.authSetting["scope.userInfo"] ? wx.getUserInfo({
                    success: function(e) {}
                }) : (wx.hideLoading(), t.globalData.authToUrl = "/packageuser/user/user", wx.redirectTo({
                    url: "/pages/index/authorization/authorization"
                }));
            }
        });
        var a = wx.getStorageSync("adv_obj");
        a && (e.adv_objStr = JSON.parse(a), e.adv_objStr.wechat_yt ? (e.data.showModalAdv && t.advExposure(e.adv_objStr.wechat_yt, "300006"), 
        e.setData({
            checkUrl_wechat_yt: e.adv_objStr.wechat_yt.checkUrl,
            materialUrl_wechat_yt: t.configObj.advImgAdd + e.adv_objStr.wechat_yt.materialUrl
        })) : wx.createInterstitialAd && !e.adShowed && (e.adShowed = !0, wx.createInterstitialAd({
            adUnitId: "adunit-0c12f0abf1522eab"
        }).show()), e.adv_objStr.wechat_ydb && (t.advExposure(e.adv_objStr.wechat_ydb, "300005"), 
        e.setData({
            checkUrl_wechat_ydb: e.adv_objStr.wechat_ydb.checkUrl,
            materialUrl_wechat_ydb: t.configObj.advImgAdd + e.adv_objStr.wechat_ydb.materialUrl
        })));
    },
    requestUserInfo: function() {
        var a = this;
        wx.request({
            url: t.configObj.userInfoUrl,
            data: {
                session: t.globalData.session
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(o) {
                if (5 == o.data.code) getApp().globalData.session = null, getApp().login(); else if (0 == o.data.code) {
                    var n = o.data.data;
                    t.globalData.userInfo = n.user_info, t.globalData.userInfo.phone_num = n.phone_num;
                    var i, r = null;
                    n.phone_num && (getApp().dataObj.phone_num = i = n.phone_num, r = i.replace(/(\d{3})\d{4}(\d{4})/, "$1****$2"));
                    var s = {
                        isVip: n.user_info.is_vip,
                        phone: i,
                        phonenum: r,
                        showmember: !0
                    };
                    if (n.member_info) {
                        var c = e.toDate(n.member_info.end_time / 1e3).trim().split(/\s+/)[0];
                        Object.assign(s, {
                            show_member_info: !0,
                            fee_strategy: n.fee_strategy,
                            end_time: c
                        }), t.memberObj.is_vip = 1;
                    } else {
                        Object.assign(s, {
                            show_member_info: !1
                        });
                        var d = wx.getStorageSync("memberStatus");
                        t.memberObj.is_vip = "02" == d || "03" == d ? 1 : 0;
                    }
                    a.setData(s), wx.hideLoading();
                } else wx.hideLoading(), wx.showModal({
                    content: o.data.msg,
                    confirmText: "确定",
                    showCancel: !1,
                    success: function(e) {
                        e.confirm && wx.reLaunch({
                            url: "/pages/index/index"
                        });
                    }
                });
            },
            fail: function() {
                wx.hideLoading(), wx.showModal({
                    content: "当前网络不佳,请切换网络重新进入该页面",
                    showCancel: !1,
                    confirmText: "我知道了",
                    success: function(e) {
                        e.confirm && wx.navigateBack({
                            delta: 1
                        });
                    }
                });
            },
            complete: function() {
                getApp().http_post({
                    bhv_type: "view",
                    obj_type: "Page",
                    title: "首页",
                    other: {},
                    act_obj: 10080
                });
            }
        });
    },
    onPullDownRefresh: function() {
        wx.showLoading({
            title: "正在加载"
        }), this.requestUserInfo(), wx.stopPullDownRefresh();
    },
    listTouch: function(e) {
        var t = e.currentTarget.dataset.title;
        "我的钱包" == t ? wx.navigateTo({
            url: "/packageuser/user/mywallet/mywallet"
        }) : "我的订单" == t ? wx.navigateTo({
            url: "/pages/ordering/ordering"
        }) : "我的卡券" == t ? wx.navigateTo({
            url: "/packageuser/user/myCoupon/myCoupon"
        }) : "会员兑换" == t ? wx.navigateTo({
            url: "/pages/index/member/memberExchange/memberExchange"
        }) : "使用帮助" == t ? this.helpBtnTouch() : "设置" == t && wx.navigateTo({
            url: "/packageuser/user/setUp/setUp"
        });
    },
    openingMember: function() {
        getApp().http_post({
            bhv_type: "click",
            obj_type: "Control",
            title: "个人中心",
            control_name: "个人中心_会员按钮",
            other: {},
            act_obj: 10081
        }), wx.navigateTo({
            url: "/pages/index/member/member?backRoot=true&referrer_title=个人中心"
        });
    },
    userinfoBut: function() {
        wx.navigateTo({
            url: "/packageuser/user/information/information"
        });
    },
    todeposit: function() {
        wx.navigateTo({
            url: "/pages/deposit/deposit"
        });
    },
    changePhone: function() {
        var e = this.data.phone;
        wx.navigateTo({
            url: "/packageuser/user/getPhoneNum/getPhoneNum?phonenum=" + e
        });
    },
    toCoiling: function() {
        wx.navigateTo({
            url: "/packageuser/user/myCoupon/myCoupon"
        });
    },
    downloadApp: function() {
        wx.showModal({
            title: "温馨提示",
            showCancel: !1,
            content: "请于各大应用市场下载速绿充电APP",
            success: function(e) {}
        });
    },
    getPhoneNumber: function(e) {
        var a = this, o = (a.data.phone, e.detail.iv), n = e.detail.encryptedData, i = t.globalData.authCode, r = t.globalData.trdSessionId;
        "getPhoneNumber:fail 用户未绑定手机，请先在微信客户端进行绑定后重试" == e.detail.errMsg || "getPhoneNumber:fail user deny" == e.detail.errMsg || "getPhoneNumber:ok" == e.detail.errMsg && a.loginServerPhoneNumber(i, o, n, r, a);
    },
    loginServerPhoneNumber: function(e, a, o, n, i) {
        wx.request({
            url: t.configObj.loginPhoneNumber,
            data: {
                code: e,
                encryptedData: o,
                iv: a,
                trdSessionId: n
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(e) {
                var a = e.data.data.purePhoneNumber;
                wx.request({
                    url: t.configObj.bindingPhoneNum,
                    data: {
                        session: t.globalData.session,
                        mobile: a,
                        code: "weChatPhoneNumberCode"
                    },
                    header: {
                        "Content-Type": "application/x-www-form-urlencoded"
                    },
                    method: "POST",
                    success: function(e) {
                        1 == e.data.code ? (i.setData({
                            advertisingflag: !0,
                            Unopened: !0
                        }), i.requestUserInfo()) : wx.showModal({
                            content: e.data.msg,
                            showCancel: !1,
                            confirmText: "确定",
                            success: function(e) {
                                e.confirm && wx.navigateBack({
                                    delta: 1
                                });
                            }
                        });
                    },
                    fail: function() {
                        wx.showToast({
                            title: "失败",
                            icon: "none"
                        });
                    }
                });
            }
        });
    },
    catchAd: function() {
        t.pushAdv(this.adv_objStr.wechat_ydb, "300005");
    },
    onbinddoumob: function() {
        t.pushAdv(this.adv_objStr.wechat_yt, "300006"), this.adv_objStr.wechat_yt.checkUrl && this.setData({
            showModalAdv: !1
        });
    },
    hideModal: function() {
        this.setData({
            showModalAdv: !1
        });
    },
    helpBtnTouch: function() {
        wx.navigateTo({
            url: "/pages/helpCenter/helpCenter?orderid=&csEntryType=3"
        });
    },
    adLoadFinish_banner: function(e) {
        this.setData({
            showAd_banner: !0
        });
    }
});