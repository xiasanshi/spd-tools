// packageB/Bluetooth/payforSuccess/payforSuccess.js
Page({data: {}})