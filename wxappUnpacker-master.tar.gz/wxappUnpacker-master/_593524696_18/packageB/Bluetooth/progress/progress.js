// packageB/Bluetooth/progress/progress.js
Page({data: {}})