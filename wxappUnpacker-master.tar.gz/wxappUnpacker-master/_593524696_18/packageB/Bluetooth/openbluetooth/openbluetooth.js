// packageB/Bluetooth/openbluetooth/openbluetooth.js
Page({data: {}})