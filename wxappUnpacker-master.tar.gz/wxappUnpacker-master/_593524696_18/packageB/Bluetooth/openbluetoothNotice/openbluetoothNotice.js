// packageB/Bluetooth/openbluetoothNotice/openbluetoothNotice.js
Page({data: {}})