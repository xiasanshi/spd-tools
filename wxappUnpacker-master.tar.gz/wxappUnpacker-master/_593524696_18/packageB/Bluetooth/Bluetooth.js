// packageB/Bluetooth/Bluetooth.js
Page({data: {}})