function t(t) {
    return (t = t.toString())[1] ? t : "0" + t;
}

function e(t) {
    var e = new Date(t), n = e.getFullYear(), r = e.getMonth() + 1, i = e.getDate();
    return n + "-" + (r < 10 ? "0" + r : r) + "-" + (i < 10 ? "0" + i : i);
}

function n(t) {
    var n = new Date(t), r = e(t), i = n.getHours(), a = n.getMinutes(), o = n.getSeconds();
    return r + " " + (i < 10 ? "0" + i : i) + ":" + (a < 10 ? "0" + a : a) + ":" + (o < 10 ? "0" + o : o);
}

var r = [ [ 1, 2, 4, 5, 6, 7, 11, 12, 24, 83, 87 ], [ 25, 69, 84 ], [ 37, 71 ], [ 13, 14, 15, 16, 18 ], [ 65, 86 ], [ 19, 20, 21, 23, 28, 29, 35, 42, 60, 73, 89 ], [ 26, 46, 75, 85 ], [ 39, 40, 76, 68 ], [ 67 ], [ 32, 33, 34, 77, 78 ], [ 43, 44, 45 ], [ 36, 56, 57, 66, 79, 80, 90 ], [ 63, 64, 81, 82 ] ];

module.exports = {
    timerFormat: function(e) {
        var n, r, i;
        if (e.indexOf("小时") > -1) {
            var a = e.split("小时")[0], o = e.split("小时")[1].split("分")[0], u = e.split("小时")[1].split("分")[1].split("秒")[0];
            Number(3600 * a), Number(60 * o), Number(u), n = a, r = o, i = u;
        } else if (e.indexOf("分") > -1) {
            var o = e.split("分")[0], u = e.split("分")[1].split("秒")[0];
            Number(60 * o), Number(u), n = 0, r = o, i = u;
        } else u = e.split("秒")[0], Number(u), n = 0, r = 0, i = u;
        return [ n, r, i ].map(t).join(":");
    },
    formatTime: function(e) {
        var n = e.getFullYear(), r = e.getMonth() + 1, i = e.getDate(), a = e.getHours(), o = e.getMinutes(), u = e.getSeconds();
        return [ n, r, i ].map(t).join("/") + " " + [ a, o, u ].map(t).join(":");
    },
    getDistance: function(t, e, n, r) {
        t = t || 0, e = e || 0, n = n || 0, r = r || 0;
        var i = t * Math.PI / 180, a = n * Math.PI / 180, o = i - a, u = e * Math.PI / 180 - r * Math.PI / 180;
        return 12756274 * Math.asin(Math.sqrt(Math.pow(Math.sin(o / 2), 2) + Math.cos(i) * Math.cos(a) * Math.pow(Math.sin(u / 2), 2)));
    },
    repeatRemove: function(t) {
        var e = [];
        e = t.split("市");
        for (var n = [], r = 0; r < e.length; r++) -1 == n.indexOf(e[r]) && n.push(e[r]);
        var i = [];
        i = n.join("市").split("市");
        for (var a = [], r = 0; r < i.length; r++) -1 == a.indexOf(i[r]) && a.push(i[r]);
        var o = a[0].toString(), u = (a.shift(), []);
        u = a.join("市").split("区");
        for (var s = [], r = 0; r < u.length; r++) -1 == s.indexOf(u[r]) && s.push(u[r]);
        return o + "市" + s.join("区");
    },
    toDate: function(t) {
        return 0 == t ? 0 : n(1e3 * t);
    },
    formatDate: e,
    formatDateAndTime: n,
    EmptyToZero: function(t) {
        return void 0 == t ? 0 : null == t ? 0 : "undefined" == t ? 0 : "null" == t ? 0 : parseInt(t);
    },
    getNotNullVal: function(t, e) {
        return t || e || "";
    },
    getShopType: function(t) {
        for (var e = 0; e < r.length; e++) if (-1 != r[e].indexOf(t)) return e + 1;
        return 14;
    }
};