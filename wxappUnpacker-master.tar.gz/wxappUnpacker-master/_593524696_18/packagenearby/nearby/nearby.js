// packagenearby/nearby/nearby.js
Page({data: {}})