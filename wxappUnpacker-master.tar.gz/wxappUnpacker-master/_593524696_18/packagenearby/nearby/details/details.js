// packagenearby/nearby/details/details.js
Page({data: {}})