	var __wxAppData = __wxAppData || {}; 	var __wxRoute = __wxRoute || ""; 	var __wxRouteBegin = __wxRouteBegin || ""; 	var __wxAppCode__ = __wxAppCode__ || {};	var global = global || {};	var __WXML_GLOBAL__=__WXML_GLOBAL__ || {};	var __wxAppCurrentFile__=__wxAppCurrentFile__||""; 	var Component = Component || function(){};	var definePlugin = definePlugin || function(){};	var requirePlugin = requirePlugin || function(){};	var Behavior = Behavior || function(){};	var __vd_version_info__ = __vd_version_info__ || {};
	/*v0.5vv_20200413_syb_scopedata*/global.__wcc_version__='v0.5vv_20200413_syb_scopedata';global.__wcc_version_info__={"customComponents":true,"fixZeroRpx":true,"propValueDeepCopy":false};
var $gwxc
var $gaic={}
$gwx=function(path,global){
if(typeof global === 'undefined') global={};if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
function _(a,b){if(typeof(b)!='undefined')a.children.push(b);}
function _v(k){if(typeof(k)!='undefined')return {tag:'virtual','wxKey':k,children:[]};return {tag:'virtual',children:[]};}
function _n(tag){$gwxc++;if($gwxc>=16000){throw 'Dom limit exceeded, please check if there\'s any mistake you\'ve made.'};return {tag:'wx-'+tag,attr:{},children:[],n:[],raw:{},generics:{}}}
function _p(a,b){b&&a.properities.push(b);}
function _s(scope,env,key){return typeof(scope[key])!='undefined'?scope[key]:env[key]}
function _wp(m){console.warn("WXMLRT_$gwx:"+m)}
function _wl(tname,prefix){_wp(prefix+':-1:-1:-1: Template `' + tname + '` is being called recursively, will be stop.')}
$gwn=console.warn;
$gwl=console.log;
function $gwh()
{
function x()
{
}
x.prototype = 
{
hn: function( obj, all )
{
if( typeof(obj) == 'object' )
{
var cnt=0;
var any1=false,any2=false;
for(var x in obj)
{
any1=any1|x==='__value__';
any2=any2|x==='__wxspec__';
cnt++;
if(cnt>2)break;
}
return cnt == 2 && any1 && any2 && ( all || obj.__wxspec__ !== 'm' || this.hn(obj.__value__) === 'h' ) ? "h" : "n";
}
return "n";
},
nh: function( obj, special )
{
return { __value__: obj, __wxspec__: special ? special : true }
},
rv: function( obj )
{
return this.hn(obj,true)==='n'?obj:this.rv(obj.__value__);
},
hm: function( obj )
{
if( typeof(obj) == 'object' )
{
var cnt=0;
var any1=false,any2=false;
for(var x in obj)
{
any1=any1|x==='__value__';
any2=any2|x==='__wxspec__';
cnt++;
if(cnt>2)break;
}
return cnt == 2 && any1 && any2 && (obj.__wxspec__ === 'm' || this.hm(obj.__value__) );
}
return false;
}
}
return new x;
}
wh=$gwh();
function $gstack(s){
var tmp=s.split('\n '+' '+' '+' ');
for(var i=0;i<tmp.length;++i){
if(0==i) continue;
if(")"===tmp[i][tmp[i].length-1])
tmp[i]=tmp[i].replace(/\s\(.*\)$/,"");
else
tmp[i]="at anonymous function";
}
return tmp.join('\n '+' '+' '+' ');
}
function $gwrt( should_pass_type_info )
{
function ArithmeticEv( ops, e, s, g, o )
{
var _f = false;
var rop = ops[0][1];
var _a,_b,_c,_d, _aa, _bb;
switch( rop )
{
case '?:':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? rev( ops[2], e, s, g, o, _f ) : rev( ops[3], e, s, g, o, _f );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '&&':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? rev( ops[2], e, s, g, o, _f ) : wh.rv( _a );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '||':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? wh.rv(_a) : rev( ops[2], e, s, g, o, _f );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '+':
case '*':
case '/':
case '%':
case '|':
case '^':
case '&':
case '===':
case '==':
case '!=':
case '!==':
case '>=':
case '<=':
case '>':
case '<':
case '<<':
case '>>':
_a = rev( ops[1], e, s, g, o, _f );
_b = rev( ops[2], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) === 'h' || wh.hn( _b ) === 'h');
switch( rop )
{
case '+':
_d = wh.rv( _a ) + wh.rv( _b );
break;
case '*':
_d = wh.rv( _a ) * wh.rv( _b );
break;
case '/':
_d = wh.rv( _a ) / wh.rv( _b );
break;
case '%':
_d = wh.rv( _a ) % wh.rv( _b );
break;
case '|':
_d = wh.rv( _a ) | wh.rv( _b );
break;
case '^':
_d = wh.rv( _a ) ^ wh.rv( _b );
break;
case '&':
_d = wh.rv( _a ) & wh.rv( _b );
break;
case '===':
_d = wh.rv( _a ) === wh.rv( _b );
break;
case '==':
_d = wh.rv( _a ) == wh.rv( _b );
break;
case '!=':
_d = wh.rv( _a ) != wh.rv( _b );
break;
case '!==':
_d = wh.rv( _a ) !== wh.rv( _b );
break;
case '>=':
_d = wh.rv( _a ) >= wh.rv( _b );
break;
case '<=':
_d = wh.rv( _a ) <= wh.rv( _b );
break;
case '>':
_d = wh.rv( _a ) > wh.rv( _b );
break;
case '<':
_d = wh.rv( _a ) < wh.rv( _b );
break;
case '<<':
_d = wh.rv( _a ) << wh.rv( _b );
break;
case '>>':
_d = wh.rv( _a ) >> wh.rv( _b );
break;
default:
break;
}
return _c ? wh.nh( _d, "c" ) : _d;
break;
case '-':
_a = ops.length === 3 ? rev( ops[1], e, s, g, o, _f ) : 0;
_b = ops.length === 3 ? rev( ops[2], e, s, g, o, _f ) : rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) === 'h' || wh.hn( _b ) === 'h');
_d = _c ? wh.rv( _a ) - wh.rv( _b ) : _a - _b;
return _c ? wh.nh( _d, "c" ) : _d;
break;
case '!':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) == 'h');
_d = !wh.rv(_a);
return _c ? wh.nh( _d, "c" ) : _d;
case '~':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) == 'h');
_d = ~wh.rv(_a);
return _c ? wh.nh( _d, "c" ) : _d;
default:
$gwn('unrecognized op' + rop );
}
}
function rev( ops, e, s, g, o, newap )
{
var op = ops[0];
var _f = false;
if ( typeof newap !== "undefined" ) o.ap = newap;
if( typeof(op)==='object' )
{
var vop=op[0];
var _a, _aa, _b, _bb, _c, _d, _s, _e, _ta, _tb, _td;
switch(vop)
{
case 2:
return ArithmeticEv(ops,e,s,g,o);
break;
case 4: 
return rev( ops[1], e, s, g, o, _f );
break;
case 5: 
switch( ops.length )
{
case 2: 
_a = rev( ops[1],e,s,g,o,_f );
return should_pass_type_info?[_a]:[wh.rv(_a)];
return [_a];
break;
case 1: 
return [];
break;
default:
_a = rev( ops[1],e,s,g,o,_f );
_b = rev( ops[2],e,s,g,o,_f );
_a.push( 
should_pass_type_info ?
_b :
wh.rv( _b )
);
return _a;
break;
}
break;
case 6:
_a = rev(ops[1],e,s,g,o);
var ap = o.ap;
_ta = wh.hn(_a)==='h';
_aa = _ta ? wh.rv(_a) : _a;
o.is_affected |= _ta;
if( should_pass_type_info )
{
if( _aa===null || typeof(_aa) === 'undefined' )
{
return _ta ? wh.nh(undefined, 'e') : undefined;
}
_b = rev(ops[2],e,s,g,o,_f);
_tb = wh.hn(_b) === 'h';
_bb = _tb ? wh.rv(_b) : _b;
o.ap = ap;
o.is_affected |= _tb;
if( _bb===null || typeof(_bb) === 'undefined' || 
_bb === "__proto__" || _bb === "prototype" || _bb === "caller" ) 
{
return (_ta || _tb) ? wh.nh(undefined, 'e') : undefined;
}
_d = _aa[_bb];
if ( typeof _d === 'function' && !ap ) _d = undefined;
_td = wh.hn(_d)==='h';
o.is_affected |= _td;
return (_ta || _tb) ? (_td ? _d : wh.nh(_d, 'e')) : _d;
}
else
{
if( _aa===null || typeof(_aa) === 'undefined' )
{
return undefined;
}
_b = rev(ops[2],e,s,g,o,_f);
_tb = wh.hn(_b) === 'h';
_bb = _tb ? wh.rv(_b) : _b;
o.ap = ap;
o.is_affected |= _tb;
if( _bb===null || typeof(_bb) === 'undefined' || 
_bb === "__proto__" || _bb === "prototype" || _bb === "caller" ) 
{
return undefined;
}
_d = _aa[_bb];
if ( typeof _d === 'function' && !ap ) _d = undefined;
_td = wh.hn(_d)==='h';
o.is_affected |= _td;
return _td ? wh.rv(_d) : _d;
}
case 7: 
switch(ops[1][0])
{
case 11:
o.is_affected |= wh.hn(g)==='h';
return g;
case 3:
_s = wh.rv( s );
_e = wh.rv( e );
_b = ops[1][1];
if (g && g.f && g.f.hasOwnProperty(_b) )
{
_a = g.f;
o.ap = true;
}
else
{
_a = _s && _s.hasOwnProperty(_b) ? 
s : (_e && _e.hasOwnProperty(_b) ? e : undefined );
}
if( should_pass_type_info )
{
if( _a )
{
_ta = wh.hn(_a) === 'h';
_aa = _ta ? wh.rv( _a ) : _a;
_d = _aa[_b];
_td = wh.hn(_d) === 'h';
o.is_affected |= _ta || _td;
_d = _ta && !_td ? wh.nh(_d,'e') : _d;
return _d;
}
}
else
{
if( _a )
{
_ta = wh.hn(_a) === 'h';
_aa = _ta ? wh.rv( _a ) : _a;
_d = _aa[_b];
_td = wh.hn(_d) === 'h';
o.is_affected |= _ta || _td;
return wh.rv(_d);
}
}
return undefined;
}
break;
case 8: 
_a = {};
_a[ops[1]] = rev(ops[2],e,s,g,o,_f);
return _a;
break;
case 9: 
_a = rev(ops[1],e,s,g,o,_f);
_b = rev(ops[2],e,s,g,o,_f);
function merge( _a, _b, _ow )
{
var ka, _bbk;
_ta = wh.hn(_a)==='h';
_tb = wh.hn(_b)==='h';
_aa = wh.rv(_a);
_bb = wh.rv(_b);
for(var k in _bb)
{
if ( _ow || !_aa.hasOwnProperty(k) )
{
_aa[k] = should_pass_type_info ? (_tb ? wh.nh(_bb[k],'e') : _bb[k]) : wh.rv(_bb[k]);
}
}
return _a;
}
var _c = _a
var _ow = true
if ( typeof(ops[1][0]) === "object" && ops[1][0][0] === 10 ) {
_a = _b
_b = _c
_ow = false
}
if ( typeof(ops[1][0]) === "object" && ops[1][0][0] === 10 ) {
var _r = {}
return merge( merge( _r, _a, _ow ), _b, _ow );
}
else
return merge( _a, _b, _ow );
break;
case 10:
_a = rev(ops[1],e,s,g,o,_f);
_a = should_pass_type_info ? _a : wh.rv( _a );
return _a ;
break;
case 12:
var _r;
_a = rev(ops[1],e,s,g,o);
if ( !o.ap )
{
return should_pass_type_info && wh.hn(_a)==='h' ? wh.nh( _r, 'f' ) : _r;
}
var ap = o.ap;
_b = rev(ops[2],e,s,g,o,_f);
o.ap = ap;
_ta = wh.hn(_a)==='h';
_tb = _ca(_b);
_aa = wh.rv(_a);	
_bb = wh.rv(_b); snap_bb=$gdc(_bb,"nv_");
try{
_r = typeof _aa === "function" ? $gdc(_aa.apply(null, snap_bb)) : undefined;
} catch (e){
e.message = e.message.replace(/nv_/g,"");
e.stack = e.stack.substring(0,e.stack.indexOf("\n", e.stack.lastIndexOf("at nv_")));
e.stack = e.stack.replace(/\snv_/g," "); 
e.stack = $gstack(e.stack);	
if(g.debugInfo)
{
e.stack += "\n "+" "+" "+" at "+g.debugInfo[0]+":"+g.debugInfo[1]+":"+g.debugInfo[2];
console.error(e);
}
_r = undefined;
}
return should_pass_type_info && (_tb || _ta) ? wh.nh( _r, 'f' ) : _r;
}
}
else
{
if( op === 3 || op === 1) return ops[1];
else if( op === 11 ) 
{
var _a='';
for( var i = 1 ; i < ops.length ; i++ )
{
var xp = wh.rv(rev(ops[i],e,s,g,o,_f));
_a += typeof(xp) === 'undefined' ? '' : xp;
}
return _a;
}
}
}
function wrapper( ops, e, s, g, o, newap )
{
if( ops[0] == '11182016' )
{
g.debugInfo = ops[2];
return rev( ops[1], e, s, g, o, newap );
}
else
{
g.debugInfo = null;
return rev( ops, e, s, g, o, newap );
}
}
return wrapper;
}
gra=$gwrt(true); 
grb=$gwrt(false); 
function TestTest( expr, ops, e,s,g, expect_a, expect_b, expect_affected )
{
{
var o = {is_affected:false};
var a = gra( ops, e,s,g, o );
if( JSON.stringify(a) != JSON.stringify( expect_a )
|| o.is_affected != expect_affected )
{
console.warn( "A. " + expr + " get result " + JSON.stringify(a) + ", " + o.is_affected + ", but " + JSON.stringify( expect_a ) + ", " + expect_affected + " is expected" );
}
}
{
var o = {is_affected:false};
var a = grb( ops, e,s,g, o );
if( JSON.stringify(a) != JSON.stringify( expect_b )
|| o.is_affected != expect_affected )
{
console.warn( "B. " + expr + " get result " + JSON.stringify(a) + ", " + o.is_affected + ", but " + JSON.stringify( expect_b ) + ", " + expect_affected + " is expected" );
}
}
}

function wfor( to_iter, func, env, _s, global, father, itemname, indexname, keyname )
{
var _n = wh.hn( to_iter ) === 'n'; 
var scope = wh.rv( _s ); 
var has_old_item = scope.hasOwnProperty(itemname);
var has_old_index = scope.hasOwnProperty(indexname);
var old_item = scope[itemname];
var old_index = scope[indexname];
var full = Object.prototype.toString.call(wh.rv(to_iter));
var type = full[8]; 
if( type === 'N' && full[10] === 'l' ) type = 'X'; 
var _y;
if( _n )
{
if( type === 'A' ) 
{
var r_iter_item;
for( var i = 0 ; i < to_iter.length ; i++ )
{
scope[itemname] = to_iter[i];
scope[indexname] = _n ? i : wh.nh(i, 'h');
r_iter_item = wh.rv(to_iter[i]);
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'O' ) 
{
var i = 0;
var r_iter_item;
for( var k in to_iter )
{
scope[itemname] = to_iter[k];
scope[indexname] = _n ? k : wh.nh(k, 'h');
r_iter_item = wh.rv(to_iter[k]);
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env,scope,_y,global );
i++;
}
}
else if( type === 'S' ) 
{
for( var i = 0 ; i < to_iter.length ; i++ )
{
scope[itemname] = to_iter[i];
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( to_iter[i] + i );
_(father,_y);
func( env,scope,_y,global );
}
}
else if( type === 'N' ) 
{
for( var i = 0 ; i < to_iter ; i++ )
{
scope[itemname] = i;
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( i );
_(father,_y);
func(env,scope,_y,global);
}
}
else
{
}
}
else
{
var r_to_iter = wh.rv(to_iter);
var r_iter_item, iter_item;
if( type === 'A' ) 
{
for( var i = 0 ; i < r_to_iter.length ; i++ )
{
iter_item = r_to_iter[i];
iter_item = wh.hn(iter_item)==='n' ? wh.nh(iter_item,'h') : iter_item;
r_iter_item = wh.rv( iter_item );
scope[itemname] = iter_item
scope[indexname] = _n ? i : wh.nh(i, 'h');
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'O' ) 
{
var i=0;
for( var k in r_to_iter )
{
iter_item = r_to_iter[k];
iter_item = wh.hn(iter_item)==='n'? wh.nh(iter_item,'h') : iter_item;
r_iter_item = wh.rv( iter_item );
scope[itemname] = iter_item;
scope[indexname] = _n ? k : wh.nh(k, 'h');
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y=_v(key);
_(father,_y);
func( env, scope, _y, global );
i++
}
}
else if( type === 'S' ) 
{
for( var i = 0 ; i < r_to_iter.length ; i++ )
{
iter_item = wh.nh(r_to_iter[i],'h');
scope[itemname] = iter_item;
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( to_iter[i] + i );
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'N' ) 
{
for( var i = 0 ; i < r_to_iter ; i++ )
{
iter_item = wh.nh(i,'h');
scope[itemname] = iter_item;
scope[indexname]= _n ? i : wh.nh(i,'h');
_y = _v( i );
_(father,_y);
func(env,scope,_y,global);
}
}
else
{
}
}
if(has_old_item)
{
scope[itemname]=old_item;
}
else
{
delete scope[itemname];
}
if(has_old_index)
{
scope[indexname]=old_index;
}
else
{
delete scope[indexname];
}
}

function _ca(o)
{ 
if ( wh.hn(o) == 'h' ) return true;
if ( typeof o !== "object" ) return false;
for(var i in o){ 
if ( o.hasOwnProperty(i) ){
if (_ca(o[i])) return true;
}
}
return false;
}
function _da( node, attrname, opindex, raw, o )
{
var isaffected = false;
var value = $gdc( raw, "", 2 );
if ( o.ap && value && value.constructor===Function ) 
{
attrname = "$wxs:" + attrname; 
node.attr["$gdc"] = $gdc;
}
if ( o.is_affected || _ca(raw) ) 
{
node.n.push( attrname );
node.raw[attrname] = raw;
}
node.attr[attrname] = value;
}
function _r( node, attrname, opindex, env, scope, global ) 
{
global.opindex=opindex;
var o = {}, _env;
var a = grb( z[opindex], env, scope, global, o );
_da( node, attrname, opindex, a, o );
}
function _rz( z, node, attrname, opindex, env, scope, global ) 
{
global.opindex=opindex;
var o = {}, _env;
var a = grb( z[opindex], env, scope, global, o );
_da( node, attrname, opindex, a, o );
}
function _o( opindex, env, scope, global )
{
global.opindex=opindex;
var nothing = {};
var r = grb( z[opindex], env, scope, global, nothing );
return (r&&r.constructor===Function) ? undefined : r;
}
function _oz( z, opindex, env, scope, global )
{
global.opindex=opindex;
var nothing = {};
var r = grb( z[opindex], env, scope, global, nothing );
return (r&&r.constructor===Function) ? undefined : r;
}
function _1( opindex, env, scope, global, o )
{
var o = o || {};
global.opindex=opindex;
return gra( z[opindex], env, scope, global, o );
}
function _1z( z, opindex, env, scope, global, o )
{
var o = o || {};
global.opindex=opindex;
return gra( z[opindex], env, scope, global, o );
}
function _2( opindex, func, env, scope, global, father, itemname, indexname, keyname )
{
var o = {};
var to_iter = _1( opindex, env, scope, global );
wfor( to_iter, func, env, scope, global, father, itemname, indexname, keyname );
}
function _2z( z, opindex, func, env, scope, global, father, itemname, indexname, keyname )
{
var o = {};
var to_iter = _1z( z, opindex, env, scope, global );
wfor( to_iter, func, env, scope, global, father, itemname, indexname, keyname );
}


function _m(tag,attrs,generics,env,scope,global)
{
var tmp=_n(tag);
var base=0;
for(var i = 0 ; i < attrs.length ; i+=2 )
{
if(base+attrs[i+1]<0)
{
tmp.attr[attrs[i]]=true;
}
else
{
_r(tmp,attrs[i],base+attrs[i+1],env,scope,global);
if(base===0)base=attrs[i+1];
}
}
for(var i=0;i<generics.length;i+=2)
{
if(base+generics[i+1]<0)
{
tmp.generics[generics[i]]="";
}
else
{
var $t=grb(z[base+generics[i+1]],env,scope,global);
if ($t!="") $t="wx-"+$t;
tmp.generics[generics[i]]=$t;
if(base===0)base=generics[i+1];
}
}
return tmp;
}
function _mz(z,tag,attrs,generics,env,scope,global)
{
var tmp=_n(tag);
var base=0;
for(var i = 0 ; i < attrs.length ; i+=2 )
{
if(base+attrs[i+1]<0)
{
tmp.attr[attrs[i]]=true;
}
else
{
_rz(z, tmp,attrs[i],base+attrs[i+1],env,scope,global);
if(base===0)base=attrs[i+1];
}
}
for(var i=0;i<generics.length;i+=2)
{
if(base+generics[i+1]<0)
{
tmp.generics[generics[i]]="";
}
else
{
var $t=grb(z[base+generics[i+1]],env,scope,global);
if ($t!="") $t="wx-"+$t;
tmp.generics[generics[i]]=$t;
if(base===0)base=generics[i+1];
}
}
return tmp;
}

var nf_init=function(){
if(typeof __WXML_GLOBAL__==="undefined"||undefined===__WXML_GLOBAL__.wxs_nf_init){
nf_init_Object();nf_init_Function();nf_init_Array();nf_init_String();nf_init_Boolean();nf_init_Number();nf_init_Math();nf_init_Date();nf_init_RegExp();
}
if(typeof __WXML_GLOBAL__!=="undefined") __WXML_GLOBAL__.wxs_nf_init=true;
};
var nf_init_Object=function(){
Object.defineProperty(Object.prototype,"nv_constructor",{writable:true,value:"Object"})
Object.defineProperty(Object.prototype,"nv_toString",{writable:true,value:function(){return "[object Object]"}})
}
var nf_init_Function=function(){
Object.defineProperty(Function.prototype,"nv_constructor",{writable:true,value:"Function"})
Object.defineProperty(Function.prototype,"nv_length",{get:function(){return this.length;},set:function(){}});
Object.defineProperty(Function.prototype,"nv_toString",{writable:true,value:function(){return "[function Function]"}})
}
var nf_init_Array=function(){
Object.defineProperty(Array.prototype,"nv_toString",{writable:true,value:function(){return this.nv_join();}})
Object.defineProperty(Array.prototype,"nv_join",{writable:true,value:function(s){
s=undefined==s?',':s;
var r="";
for(var i=0;i<this.length;++i){
if(0!=i) r+=s;
if(null==this[i]||undefined==this[i]) r+='';	
else if(typeof this[i]=='function') r+=this[i].nv_toString();
else if(typeof this[i]=='object'&&this[i].nv_constructor==="Array") r+=this[i].nv_join();
else r+=this[i].toString();
}
return r;
}})
Object.defineProperty(Array.prototype,"nv_constructor",{writable:true,value:"Array"})
Object.defineProperty(Array.prototype,"nv_concat",{writable:true,value:Array.prototype.concat})
Object.defineProperty(Array.prototype,"nv_pop",{writable:true,value:Array.prototype.pop})
Object.defineProperty(Array.prototype,"nv_push",{writable:true,value:Array.prototype.push})
Object.defineProperty(Array.prototype,"nv_reverse",{writable:true,value:Array.prototype.reverse})
Object.defineProperty(Array.prototype,"nv_shift",{writable:true,value:Array.prototype.shift})
Object.defineProperty(Array.prototype,"nv_slice",{writable:true,value:Array.prototype.slice})
Object.defineProperty(Array.prototype,"nv_sort",{writable:true,value:Array.prototype.sort})
Object.defineProperty(Array.prototype,"nv_splice",{writable:true,value:Array.prototype.splice})
Object.defineProperty(Array.prototype,"nv_unshift",{writable:true,value:Array.prototype.unshift})
Object.defineProperty(Array.prototype,"nv_indexOf",{writable:true,value:Array.prototype.indexOf})
Object.defineProperty(Array.prototype,"nv_lastIndexOf",{writable:true,value:Array.prototype.lastIndexOf})
Object.defineProperty(Array.prototype,"nv_every",{writable:true,value:Array.prototype.every})
Object.defineProperty(Array.prototype,"nv_some",{writable:true,value:Array.prototype.some})
Object.defineProperty(Array.prototype,"nv_forEach",{writable:true,value:Array.prototype.forEach})
Object.defineProperty(Array.prototype,"nv_map",{writable:true,value:Array.prototype.map})
Object.defineProperty(Array.prototype,"nv_filter",{writable:true,value:Array.prototype.filter})
Object.defineProperty(Array.prototype,"nv_reduce",{writable:true,value:Array.prototype.reduce})
Object.defineProperty(Array.prototype,"nv_reduceRight",{writable:true,value:Array.prototype.reduceRight})
Object.defineProperty(Array.prototype,"nv_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
}
var nf_init_String=function(){
Object.defineProperty(String.prototype,"nv_constructor",{writable:true,value:"String"})
Object.defineProperty(String.prototype,"nv_toString",{writable:true,value:String.prototype.toString})
Object.defineProperty(String.prototype,"nv_valueOf",{writable:true,value:String.prototype.valueOf})
Object.defineProperty(String.prototype,"nv_charAt",{writable:true,value:String.prototype.charAt})
Object.defineProperty(String.prototype,"nv_charCodeAt",{writable:true,value:String.prototype.charCodeAt})
Object.defineProperty(String.prototype,"nv_concat",{writable:true,value:String.prototype.concat})
Object.defineProperty(String.prototype,"nv_indexOf",{writable:true,value:String.prototype.indexOf})
Object.defineProperty(String.prototype,"nv_lastIndexOf",{writable:true,value:String.prototype.lastIndexOf})
Object.defineProperty(String.prototype,"nv_localeCompare",{writable:true,value:String.prototype.localeCompare})
Object.defineProperty(String.prototype,"nv_match",{writable:true,value:String.prototype.match})
Object.defineProperty(String.prototype,"nv_replace",{writable:true,value:String.prototype.replace})
Object.defineProperty(String.prototype,"nv_search",{writable:true,value:String.prototype.search})
Object.defineProperty(String.prototype,"nv_slice",{writable:true,value:String.prototype.slice})
Object.defineProperty(String.prototype,"nv_split",{writable:true,value:String.prototype.split})
Object.defineProperty(String.prototype,"nv_substring",{writable:true,value:String.prototype.substring})
Object.defineProperty(String.prototype,"nv_toLowerCase",{writable:true,value:String.prototype.toLowerCase})
Object.defineProperty(String.prototype,"nv_toLocaleLowerCase",{writable:true,value:String.prototype.toLocaleLowerCase})
Object.defineProperty(String.prototype,"nv_toUpperCase",{writable:true,value:String.prototype.toUpperCase})
Object.defineProperty(String.prototype,"nv_toLocaleUpperCase",{writable:true,value:String.prototype.toLocaleUpperCase})
Object.defineProperty(String.prototype,"nv_trim",{writable:true,value:String.prototype.trim})
Object.defineProperty(String.prototype,"nv_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
}
var nf_init_Boolean=function(){
Object.defineProperty(Boolean.prototype,"nv_constructor",{writable:true,value:"Boolean"})
Object.defineProperty(Boolean.prototype,"nv_toString",{writable:true,value:Boolean.prototype.toString})
Object.defineProperty(Boolean.prototype,"nv_valueOf",{writable:true,value:Boolean.prototype.valueOf})
}
var nf_init_Number=function(){
Object.defineProperty(Number,"nv_MAX_VALUE",{writable:false,value:Number.MAX_VALUE})
Object.defineProperty(Number,"nv_MIN_VALUE",{writable:false,value:Number.MIN_VALUE})
Object.defineProperty(Number,"nv_NEGATIVE_INFINITY",{writable:false,value:Number.NEGATIVE_INFINITY})
Object.defineProperty(Number,"nv_POSITIVE_INFINITY",{writable:false,value:Number.POSITIVE_INFINITY})
Object.defineProperty(Number.prototype,"nv_constructor",{writable:true,value:"Number"})
Object.defineProperty(Number.prototype,"nv_toString",{writable:true,value:Number.prototype.toString})
Object.defineProperty(Number.prototype,"nv_toLocaleString",{writable:true,value:Number.prototype.toLocaleString})
Object.defineProperty(Number.prototype,"nv_valueOf",{writable:true,value:Number.prototype.valueOf})
Object.defineProperty(Number.prototype,"nv_toFixed",{writable:true,value:Number.prototype.toFixed})
Object.defineProperty(Number.prototype,"nv_toExponential",{writable:true,value:Number.prototype.toExponential})
Object.defineProperty(Number.prototype,"nv_toPrecision",{writable:true,value:Number.prototype.toPrecision})
}
var nf_init_Math=function(){
Object.defineProperty(Math,"nv_E",{writable:false,value:Math.E})
Object.defineProperty(Math,"nv_LN10",{writable:false,value:Math.LN10})
Object.defineProperty(Math,"nv_LN2",{writable:false,value:Math.LN2})
Object.defineProperty(Math,"nv_LOG2E",{writable:false,value:Math.LOG2E})
Object.defineProperty(Math,"nv_LOG10E",{writable:false,value:Math.LOG10E})
Object.defineProperty(Math,"nv_PI",{writable:false,value:Math.PI})
Object.defineProperty(Math,"nv_SQRT1_2",{writable:false,value:Math.SQRT1_2})
Object.defineProperty(Math,"nv_SQRT2",{writable:false,value:Math.SQRT2})
Object.defineProperty(Math,"nv_abs",{writable:false,value:Math.abs})
Object.defineProperty(Math,"nv_acos",{writable:false,value:Math.acos})
Object.defineProperty(Math,"nv_asin",{writable:false,value:Math.asin})
Object.defineProperty(Math,"nv_atan",{writable:false,value:Math.atan})
Object.defineProperty(Math,"nv_atan2",{writable:false,value:Math.atan2})
Object.defineProperty(Math,"nv_ceil",{writable:false,value:Math.ceil})
Object.defineProperty(Math,"nv_cos",{writable:false,value:Math.cos})
Object.defineProperty(Math,"nv_exp",{writable:false,value:Math.exp})
Object.defineProperty(Math,"nv_floor",{writable:false,value:Math.floor})
Object.defineProperty(Math,"nv_log",{writable:false,value:Math.log})
Object.defineProperty(Math,"nv_max",{writable:false,value:Math.max})
Object.defineProperty(Math,"nv_min",{writable:false,value:Math.min})
Object.defineProperty(Math,"nv_pow",{writable:false,value:Math.pow})
Object.defineProperty(Math,"nv_random",{writable:false,value:Math.random})
Object.defineProperty(Math,"nv_round",{writable:false,value:Math.round})
Object.defineProperty(Math,"nv_sin",{writable:false,value:Math.sin})
Object.defineProperty(Math,"nv_sqrt",{writable:false,value:Math.sqrt})
Object.defineProperty(Math,"nv_tan",{writable:false,value:Math.tan})
}
var nf_init_Date=function(){
Object.defineProperty(Date.prototype,"nv_constructor",{writable:true,value:"Date"})
Object.defineProperty(Date,"nv_parse",{writable:true,value:Date.parse})
Object.defineProperty(Date,"nv_UTC",{writable:true,value:Date.UTC})
Object.defineProperty(Date,"nv_now",{writable:true,value:Date.now})
Object.defineProperty(Date.prototype,"nv_toString",{writable:true,value:Date.prototype.toString})
Object.defineProperty(Date.prototype,"nv_toDateString",{writable:true,value:Date.prototype.toDateString})
Object.defineProperty(Date.prototype,"nv_toTimeString",{writable:true,value:Date.prototype.toTimeString})
Object.defineProperty(Date.prototype,"nv_toLocaleString",{writable:true,value:Date.prototype.toLocaleString})
Object.defineProperty(Date.prototype,"nv_toLocaleDateString",{writable:true,value:Date.prototype.toLocaleDateString})
Object.defineProperty(Date.prototype,"nv_toLocaleTimeString",{writable:true,value:Date.prototype.toLocaleTimeString})
Object.defineProperty(Date.prototype,"nv_valueOf",{writable:true,value:Date.prototype.valueOf})
Object.defineProperty(Date.prototype,"nv_getTime",{writable:true,value:Date.prototype.getTime})
Object.defineProperty(Date.prototype,"nv_getFullYear",{writable:true,value:Date.prototype.getFullYear})
Object.defineProperty(Date.prototype,"nv_getUTCFullYear",{writable:true,value:Date.prototype.getUTCFullYear})
Object.defineProperty(Date.prototype,"nv_getMonth",{writable:true,value:Date.prototype.getMonth})
Object.defineProperty(Date.prototype,"nv_getUTCMonth",{writable:true,value:Date.prototype.getUTCMonth})
Object.defineProperty(Date.prototype,"nv_getDate",{writable:true,value:Date.prototype.getDate})
Object.defineProperty(Date.prototype,"nv_getUTCDate",{writable:true,value:Date.prototype.getUTCDate})
Object.defineProperty(Date.prototype,"nv_getDay",{writable:true,value:Date.prototype.getDay})
Object.defineProperty(Date.prototype,"nv_getUTCDay",{writable:true,value:Date.prototype.getUTCDay})
Object.defineProperty(Date.prototype,"nv_getHours",{writable:true,value:Date.prototype.getHours})
Object.defineProperty(Date.prototype,"nv_getUTCHours",{writable:true,value:Date.prototype.getUTCHours})
Object.defineProperty(Date.prototype,"nv_getMinutes",{writable:true,value:Date.prototype.getMinutes})
Object.defineProperty(Date.prototype,"nv_getUTCMinutes",{writable:true,value:Date.prototype.getUTCMinutes})
Object.defineProperty(Date.prototype,"nv_getSeconds",{writable:true,value:Date.prototype.getSeconds})
Object.defineProperty(Date.prototype,"nv_getUTCSeconds",{writable:true,value:Date.prototype.getUTCSeconds})
Object.defineProperty(Date.prototype,"nv_getMilliseconds",{writable:true,value:Date.prototype.getMilliseconds})
Object.defineProperty(Date.prototype,"nv_getUTCMilliseconds",{writable:true,value:Date.prototype.getUTCMilliseconds})
Object.defineProperty(Date.prototype,"nv_getTimezoneOffset",{writable:true,value:Date.prototype.getTimezoneOffset})
Object.defineProperty(Date.prototype,"nv_setTime",{writable:true,value:Date.prototype.setTime})
Object.defineProperty(Date.prototype,"nv_setMilliseconds",{writable:true,value:Date.prototype.setMilliseconds})
Object.defineProperty(Date.prototype,"nv_setUTCMilliseconds",{writable:true,value:Date.prototype.setUTCMilliseconds})
Object.defineProperty(Date.prototype,"nv_setSeconds",{writable:true,value:Date.prototype.setSeconds})
Object.defineProperty(Date.prototype,"nv_setUTCSeconds",{writable:true,value:Date.prototype.setUTCSeconds})
Object.defineProperty(Date.prototype,"nv_setMinutes",{writable:true,value:Date.prototype.setMinutes})
Object.defineProperty(Date.prototype,"nv_setUTCMinutes",{writable:true,value:Date.prototype.setUTCMinutes})
Object.defineProperty(Date.prototype,"nv_setHours",{writable:true,value:Date.prototype.setHours})
Object.defineProperty(Date.prototype,"nv_setUTCHours",{writable:true,value:Date.prototype.setUTCHours})
Object.defineProperty(Date.prototype,"nv_setDate",{writable:true,value:Date.prototype.setDate})
Object.defineProperty(Date.prototype,"nv_setUTCDate",{writable:true,value:Date.prototype.setUTCDate})
Object.defineProperty(Date.prototype,"nv_setMonth",{writable:true,value:Date.prototype.setMonth})
Object.defineProperty(Date.prototype,"nv_setUTCMonth",{writable:true,value:Date.prototype.setUTCMonth})
Object.defineProperty(Date.prototype,"nv_setFullYear",{writable:true,value:Date.prototype.setFullYear})
Object.defineProperty(Date.prototype,"nv_setUTCFullYear",{writable:true,value:Date.prototype.setUTCFullYear})
Object.defineProperty(Date.prototype,"nv_toUTCString",{writable:true,value:Date.prototype.toUTCString})
Object.defineProperty(Date.prototype,"nv_toISOString",{writable:true,value:Date.prototype.toISOString})
Object.defineProperty(Date.prototype,"nv_toJSON",{writable:true,value:Date.prototype.toJSON})
}
var nf_init_RegExp=function(){
Object.defineProperty(RegExp.prototype,"nv_constructor",{writable:true,value:"RegExp"})
Object.defineProperty(RegExp.prototype,"nv_exec",{writable:true,value:RegExp.prototype.exec})
Object.defineProperty(RegExp.prototype,"nv_test",{writable:true,value:RegExp.prototype.test})
Object.defineProperty(RegExp.prototype,"nv_toString",{writable:true,value:RegExp.prototype.toString})
Object.defineProperty(RegExp.prototype,"nv_source",{get:function(){return this.source;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_global",{get:function(){return this.global;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_ignoreCase",{get:function(){return this.ignoreCase;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_multiline",{get:function(){return this.multiline;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_lastIndex",{get:function(){return this.lastIndex;},set:function(v){this.lastIndex=v;}});
}
nf_init();
var nv_getDate=function(){var args=Array.prototype.slice.call(arguments);args.unshift(Date);return new(Function.prototype.bind.apply(Date, args));}
var nv_getRegExp=function(){var args=Array.prototype.slice.call(arguments);args.unshift(RegExp);return new(Function.prototype.bind.apply(RegExp, args));}
var nv_console={}
nv_console.nv_log=function(){var res="WXSRT:";for(var i=0;i<arguments.length;++i)res+=arguments[i]+" ";console.log(res);}
var nv_parseInt = parseInt, nv_parseFloat = parseFloat, nv_isNaN = isNaN, nv_isFinite = isFinite, nv_decodeURI = decodeURI, nv_decodeURIComponent = decodeURIComponent, nv_encodeURI = encodeURI, nv_encodeURIComponent = encodeURIComponent;
function $gdc(o,p,r) {
o=wh.rv(o);
if(o===null||o===undefined) return o;
if(o.constructor===String||o.constructor===Boolean||o.constructor===Number) return o;
if(o.constructor===Object){
var copy={};
for(var k in o)
if(o.hasOwnProperty(k))
if(undefined===p) copy[k.substring(3)]=$gdc(o[k],p,r);
else copy[p+k]=$gdc(o[k],p,r);
return copy;
}
if(o.constructor===Array){
var copy=[];
for(var i=0;i<o.length;i++) copy.push($gdc(o[i],p,r));
return copy;
}
if(o.constructor===Date){
var copy=new Date();
copy.setTime(o.getTime());
return copy;
}
if(o.constructor===RegExp){
var f="";
if(o.global) f+="g";
if(o.ignoreCase) f+="i";
if(o.multiline) f+="m";
return (new RegExp(o.source,f));
}
if(r&&o.constructor===Function){
if ( r == 1 ) return $gdc(o(),undefined, 2);
if ( r == 2 ) return o;
}
return null;
}
var nv_JSON={}
nv_JSON.nv_stringify=function(o){
JSON.stringify(o);
return JSON.stringify($gdc(o));
}
nv_JSON.nv_parse=function(o){
if(o===undefined) return undefined;
var t=JSON.parse(o);
return $gdc(t,'nv_');
}

function _af(p, a, r, c){
p.extraAttr = {"t_action": a, "t_rawid": r };
if ( typeof(c) != 'undefined' ) p.extraAttr.t_cid = c;
}

function _ai(i,p,e,me,r,c){var x=_grp(p,e,me);if(x)i.push(x);else{i.push('');_wp(me+':import:'+r+':'+c+': Path `'+p+'` not found from `'+me+'`.')}}
function _grp(p,e,me){if(p[0]!='/'){var mepart=me.split('/');mepart.pop();var ppart=p.split('/');for(var i=0;i<ppart.length;i++){if( ppart[i]=='..')mepart.pop();else if(!ppart[i]||ppart[i]=='.')continue;else mepart.push(ppart[i]);}p=mepart.join('/');}if(me[0]=='.'&&p[0]=='/')p='.'+p;if(e[p])return p;if(e[p+'.wxml'])return p+'.wxml';}
function _gd(p,c,e,d){if(!c)return;if(d[p][c])return d[p][c];for(var x=e[p].i.length-1;x>=0;x--){if(e[p].i[x]&&d[e[p].i[x]][c])return d[e[p].i[x]][c]};for(var x=e[p].ti.length-1;x>=0;x--){var q=_grp(e[p].ti[x],e,p);if(q&&d[q][c])return d[q][c]}var ii=_gapi(e,p);for(var x=0;x<ii.length;x++){if(ii[x]&&d[ii[x]][c])return d[ii[x]][c]}for(var k=e[p].j.length-1;k>=0;k--)if(e[p].j[k]){for(var q=e[e[p].j[k]].ti.length-1;q>=0;q--){var pp=_grp(e[e[p].j[k]].ti[q],e,p);if(pp&&d[pp][c]){return d[pp][c]}}}}
function _gapi(e,p){if(!p)return [];if($gaic[p]){return $gaic[p]};var ret=[],q=[],h=0,t=0,put={},visited={};q.push(p);visited[p]=true;t++;while(h<t){var a=q[h++];for(var i=0;i<e[a].ic.length;i++){var nd=e[a].ic[i];var np=_grp(nd,e,a);if(np&&!visited[np]){visited[np]=true;q.push(np);t++;}}for(var i=0;a!=p&&i<e[a].ti.length;i++){var ni=e[a].ti[i];var nm=_grp(ni,e,a);if(nm&&!put[nm]){put[nm]=true;ret.push(nm);}}}$gaic[p]=ret;return ret;}
var $ixc={};function _ic(p,ent,me,e,s,r,gg){var x=_grp(p,ent,me);ent[me].j.push(x);if(x){if($ixc[x]){_wp('-1:include:-1:-1: `'+p+'` is being included in a loop, will be stop.');return;}$ixc[x]=true;try{ent[x].f(e,s,r,gg)}catch(e){}$ixc[x]=false;}else{_wp(me+':include:-1:-1: Included path `'+p+'` not found from `'+me+'`.')}}
function _w(tn,f,line,c){_wp(f+':template:'+line+':'+c+': Template `'+tn+'` not found.');}function _ev(dom){var changed=false;delete dom.properities;delete dom.n;if(dom.children){do{changed=false;var newch = [];for(var i=0;i<dom.children.length;i++){var ch=dom.children[i];if( ch.tag=='virtual'){changed=true;for(var j=0;ch.children&&j<ch.children.length;j++){newch.push(ch.children[j]);}}else { newch.push(ch); } } dom.children = newch; }while(changed);for(var i=0;i<dom.children.length;i++){_ev(dom.children[i]);}} return dom; }
function _tsd( root )
{
if( root.tag == "wx-wx-scope" ) 
{
root.tag = "virtual";
root.wxCkey = "11";
root['wxScopeData'] = root.attr['wx:scope-data'];
delete root.n;
delete root.raw;
delete root.generics;
delete root.attr;
}
for( var i = 0 ; root.children && i < root.children.length ; i++ )
{
_tsd( root.children[i] );
}
return root;
}

var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx || [];
function gz$gwx_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_1)return __WXML_GLOBAL__.ops_cached.$gwx_1
__WXML_GLOBAL__.ops_cached.$gwx_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'showboxhide']])
Z([[7],[3,'showmodalhide']])
Z([[7],[3,'showpopupboxhide']])
Z([[7],[3,'canPrizeNumhide']])
})(__WXML_GLOBAL__.ops_cached.$gwx_1);return __WXML_GLOBAL__.ops_cached.$gwx_1
}
function gz$gwx_2(){
if( __WXML_GLOBAL__.ops_cached.$gwx_2)return __WXML_GLOBAL__.ops_cached.$gwx_2
__WXML_GLOBAL__.ops_cached.$gwx_2=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_2);return __WXML_GLOBAL__.ops_cached.$gwx_2
}
function gz$gwx_3(){
if( __WXML_GLOBAL__.ops_cached.$gwx_3)return __WXML_GLOBAL__.ops_cached.$gwx_3
__WXML_GLOBAL__.ops_cached.$gwx_3=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_3);return __WXML_GLOBAL__.ops_cached.$gwx_3
}
function gz$gwx_4(){
if( __WXML_GLOBAL__.ops_cached.$gwx_4)return __WXML_GLOBAL__.ops_cached.$gwx_4
__WXML_GLOBAL__.ops_cached.$gwx_4=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'formSubmit'])
Z([3,'true'])
Z([[7],[3,'isimg_show']])
Z([3,'container-code'])
Z([[7],[3,'isgray']])
Z([[7],[3,'isgreen']])
Z([[7],[3,'isnobut']])
Z([[7],[3,'isyesbut']])
Z([[7],[3,'advertisingflag']])
Z([[7],[3,'isopen']])
Z([[7],[3,'binded']])
Z([[7],[3,'issucopen']])
Z([[7],[3,'issucsCode']])
})(__WXML_GLOBAL__.ops_cached.$gwx_4);return __WXML_GLOBAL__.ops_cached.$gwx_4
}
function gz$gwx_5(){
if( __WXML_GLOBAL__.ops_cached.$gwx_5)return __WXML_GLOBAL__.ops_cached.$gwx_5
__WXML_GLOBAL__.ops_cached.$gwx_5=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_5);return __WXML_GLOBAL__.ops_cached.$gwx_5
}
function gz$gwx_6(){
if( __WXML_GLOBAL__.ops_cached.$gwx_6)return __WXML_GLOBAL__.ops_cached.$gwx_6
__WXML_GLOBAL__.ops_cached.$gwx_6=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_6);return __WXML_GLOBAL__.ops_cached.$gwx_6
}
function gz$gwx_7(){
if( __WXML_GLOBAL__.ops_cached.$gwx_7)return __WXML_GLOBAL__.ops_cached.$gwx_7
__WXML_GLOBAL__.ops_cached.$gwx_7=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'||'],[[2,'=='],[[6],[[7],[3,'couponData']],[3,'status']],[1,1]],[[2,'=='],[[6],[[7],[3,'couponData']],[3,'status']],[1,2]]])
})(__WXML_GLOBAL__.ops_cached.$gwx_7);return __WXML_GLOBAL__.ops_cached.$gwx_7
}
function gz$gwx_8(){
if( __WXML_GLOBAL__.ops_cached.$gwx_8)return __WXML_GLOBAL__.ops_cached.$gwx_8
__WXML_GLOBAL__.ops_cached.$gwx_8=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'rootView'])
Z([3,'headerView'])
Z([[2,'!'],[[7],[3,'isHistoryData']]])
Z([[7],[3,'isHistoryData']])
Z([3,'true'])
Z(z[4])
Z([a,[3,'height: calc(100% - '],[[2,'?:'],[[7],[3,'isHistoryData']],[1,'50px'],[1,'108px']],[3,');']])
Z([[7],[3,'listData']])
Z([3,'couponList'])
Z([3,'QRTouch'])
Z([[7],[3,'item']])
Z([[2,'?:'],[[2,'&&'],[[2,'!='],[[7],[3,'listData']],[1,undefined]],[[2,'=='],[[6],[[7],[3,'listData']],[3,'length']],[1,0]]],[1,true],[[7],[3,'flase']]])
Z(z[2])
Z([[7],[3,'showQR']])
})(__WXML_GLOBAL__.ops_cached.$gwx_8);return __WXML_GLOBAL__.ops_cached.$gwx_8
}
function gz$gwx_9(){
if( __WXML_GLOBAL__.ops_cached.$gwx_9)return __WXML_GLOBAL__.ops_cached.$gwx_9
__WXML_GLOBAL__.ops_cached.$gwx_9=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'box'])
Z([[2,'>'],[[6],[[7],[3,'userInfo']],[3,'deposit']],[1,0]])
Z([[2,'=='],[[6],[[7],[3,'userInfo']],[3,'deposit']],[1,0]])
Z([[7],[3,'materialUrl_wechat_wdb']])
Z([[2,'&&'],[[7],[3,'showModalAdv']],[[7],[3,'materialUrl_wechat_wt']]])
Z(z[4])
})(__WXML_GLOBAL__.ops_cached.$gwx_9);return __WXML_GLOBAL__.ops_cached.$gwx_9
}
function gz$gwx_10(){
if( __WXML_GLOBAL__.ops_cached.$gwx_10)return __WXML_GLOBAL__.ops_cached.$gwx_10
__WXML_GLOBAL__.ops_cached.$gwx_10=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'refund_progress'])
Z([[2,'=='],[[7],[3,'status']],[1,1]])
Z([[2,'=='],[[7],[3,'status']],[1,2]])
})(__WXML_GLOBAL__.ops_cached.$gwx_10);return __WXML_GLOBAL__.ops_cached.$gwx_10
}
function gz$gwx_11(){
if( __WXML_GLOBAL__.ops_cached.$gwx_11)return __WXML_GLOBAL__.ops_cached.$gwx_11
__WXML_GLOBAL__.ops_cached.$gwx_11=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_11);return __WXML_GLOBAL__.ops_cached.$gwx_11
}
function gz$gwx_12(){
if( __WXML_GLOBAL__.ops_cached.$gwx_12)return __WXML_GLOBAL__.ops_cached.$gwx_12
__WXML_GLOBAL__.ops_cached.$gwx_12=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'advertisingflag']])
Z([[7],[3,'Unopened']])
Z([[7],[3,'isconnection']])
})(__WXML_GLOBAL__.ops_cached.$gwx_12);return __WXML_GLOBAL__.ops_cached.$gwx_12
}
function gz$gwx_13(){
if( __WXML_GLOBAL__.ops_cached.$gwx_13)return __WXML_GLOBAL__.ops_cached.$gwx_13
__WXML_GLOBAL__.ops_cached.$gwx_13=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'signing_code']])
})(__WXML_GLOBAL__.ops_cached.$gwx_13);return __WXML_GLOBAL__.ops_cached.$gwx_13
}
function gz$gwx_14(){
if( __WXML_GLOBAL__.ops_cached.$gwx_14)return __WXML_GLOBAL__.ops_cached.$gwx_14
__WXML_GLOBAL__.ops_cached.$gwx_14=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'=='],[[7],[3,'showmember']],[1,true]])
Z([[2,'&&'],[[7],[3,'showModalAdv']],[[7],[3,'materialUrl_wechat_yt']]])
Z(z[1])
})(__WXML_GLOBAL__.ops_cached.$gwx_14);return __WXML_GLOBAL__.ops_cached.$gwx_14
}
function gz$gwx_15(){
if( __WXML_GLOBAL__.ops_cached.$gwx_15)return __WXML_GLOBAL__.ops_cached.$gwx_15
__WXML_GLOBAL__.ops_cached.$gwx_15=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_15);return __WXML_GLOBAL__.ops_cached.$gwx_15
}
function gz$gwx_16(){
if( __WXML_GLOBAL__.ops_cached.$gwx_16)return __WXML_GLOBAL__.ops_cached.$gwx_16
__WXML_GLOBAL__.ops_cached.$gwx_16=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_16);return __WXML_GLOBAL__.ops_cached.$gwx_16
}
function gz$gwx_17(){
if( __WXML_GLOBAL__.ops_cached.$gwx_17)return __WXML_GLOBAL__.ops_cached.$gwx_17
__WXML_GLOBAL__.ops_cached.$gwx_17=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_17);return __WXML_GLOBAL__.ops_cached.$gwx_17
}
function gz$gwx_18(){
if( __WXML_GLOBAL__.ops_cached.$gwx_18)return __WXML_GLOBAL__.ops_cached.$gwx_18
__WXML_GLOBAL__.ops_cached.$gwx_18=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_18);return __WXML_GLOBAL__.ops_cached.$gwx_18
}
function gz$gwx_19(){
if( __WXML_GLOBAL__.ops_cached.$gwx_19)return __WXML_GLOBAL__.ops_cached.$gwx_19
__WXML_GLOBAL__.ops_cached.$gwx_19=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'body'])
Z([3,'headerTab'])
Z([[7],[3,'hiddenTab']])
Z([3,'bindheaderTab'])
Z([3,'headerTabBtn'])
Z([3,'-1'])
Z([a,[3,'color:'],[[2,'?:'],[[2,'=='],[[7],[3,'tabIndex']],[[2,'-'],[1,1]]],[1,'#2FAC65'],[1,'#434343']],[3,';']])
Z([[2,'=='],[[7],[3,'tabIndex']],[[2,'-'],[1,1]]])
Z([[7],[3,'tabList']])
Z([3,'id'])
Z(z[3])
Z(z[4])
Z([[7],[3,'index']])
Z([a,z[6][1],[[2,'?:'],[[2,'=='],[[7],[3,'tabIndex']],[[7],[3,'index']]],[1,'#2FAC65'],[1,'#434343']],z[6][3]])
Z([[2,'=='],[[7],[3,'tabIndex']],[[7],[3,'index']]])
Z([3,'bindcontroltap'])
Z([3,'bindmarkertap'])
Z([3,'bindregionchange'])
Z([3,'uncheckMark'])
Z([3,'ycbmap'])
Z([[7],[3,'latitude']])
Z([[7],[3,'longitude']])
Z([[7],[3,'markers']])
Z([3,'16'])
Z([3,'true'])
Z([a,[3,'height: calc(100% - '],[[2,'?:'],[[2,'=='],[[7],[3,'hiddenTab']],[1,true]],[1,'0rpx'],[1,'90rpx']],[3,'); top:'],[[2,'?:'],[[2,'=='],[[7],[3,'hiddenTab']],[1,true]],[1,'0rpx'],[1,'90rpx']]])
Z([3,'search toolRightItem'])
Z([[2,'=='],[[7],[3,'userLocation']],[1,false]])
Z([[2,'=='],[[7],[3,'userLocation']],[1,true]])
Z([[7],[3,'materialUrl_wechat_dsb']])
Z([[7],[3,'showAd_banner_before']])
Z([3,'popView'])
Z([[7],[3,'showShopInfo']])
Z([[2,'>'],[[7],[3,'orderIngNum']],[1,0]])
Z([[7],[3,'materialUrl_wechat_df']])
Z([[2,'&&'],[[7],[3,'showAd']],[[7],[3,'returnAd']]])
Z(z[35])
})(__WXML_GLOBAL__.ops_cached.$gwx_19);return __WXML_GLOBAL__.ops_cached.$gwx_19
}
function gz$gwx_20(){
if( __WXML_GLOBAL__.ops_cached.$gwx_20)return __WXML_GLOBAL__.ops_cached.$gwx_20
__WXML_GLOBAL__.ops_cached.$gwx_20=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'memberObjs']])
Z([3,'head_Member'])
Z(z[0])
Z([3,'type'])
Z([3,'menberItemTouch'])
Z([3,'memberBtnBg'])
Z([[7],[3,'index']])
Z([3,'memberBtn'])
Z([[2,'&&'],[[2,'=='],[[6],[[7],[3,'item']],[3,'type']],[1,'02']],[[2,'>'],[[6],[[7],[3,'item']],[3,'frist_price']],[1,0]]])
Z([[2,'=='],[[6],[[7],[3,'item']],[3,'type']],[1,'02']])
Z([[2,'!='],[[6],[[7],[3,'item']],[3,'type']],[1,'02']])
Z(z[0])
Z([[7],[3,'modalNeedKnow']])
Z(z[12])
Z([[7],[3,'modalmember']])
Z(z[14])
Z([3,'twoleasingbox'])
Z([[2,'!'],[[7],[3,'signing_code']]])
Z([3,'twoleasing'])
Z([[7],[3,'signing_code']])
Z(z[17])
Z([[7],[3,'modalfail']])
Z(z[21])
})(__WXML_GLOBAL__.ops_cached.$gwx_20);return __WXML_GLOBAL__.ops_cached.$gwx_20
}
function gz$gwx_21(){
if( __WXML_GLOBAL__.ops_cached.$gwx_21)return __WXML_GLOBAL__.ops_cached.$gwx_21
__WXML_GLOBAL__.ops_cached.$gwx_21=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'showMsg']])
Z([[7],[3,'showAle']])
Z([3,'aleView'])
Z([[2,'!'],[[7],[3,'aleSuccess']]])
Z([[7],[3,'aleSuccess']])
Z(z[3])
})(__WXML_GLOBAL__.ops_cached.$gwx_21);return __WXML_GLOBAL__.ops_cached.$gwx_21
}
function gz$gwx_22(){
if( __WXML_GLOBAL__.ops_cached.$gwx_22)return __WXML_GLOBAL__.ops_cached.$gwx_22
__WXML_GLOBAL__.ops_cached.$gwx_22=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'modalmember']])
Z(z[0])
})(__WXML_GLOBAL__.ops_cached.$gwx_22);return __WXML_GLOBAL__.ops_cached.$gwx_22
}
function gz$gwx_23(){
if( __WXML_GLOBAL__.ops_cached.$gwx_23)return __WXML_GLOBAL__.ops_cached.$gwx_23
__WXML_GLOBAL__.ops_cached.$gwx_23=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_23);return __WXML_GLOBAL__.ops_cached.$gwx_23
}
function gz$gwx_24(){
if( __WXML_GLOBAL__.ops_cached.$gwx_24)return __WXML_GLOBAL__.ops_cached.$gwx_24
__WXML_GLOBAL__.ops_cached.$gwx_24=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_24);return __WXML_GLOBAL__.ops_cached.$gwx_24
}
function gz$gwx_25(){
if( __WXML_GLOBAL__.ops_cached.$gwx_25)return __WXML_GLOBAL__.ops_cached.$gwx_25
__WXML_GLOBAL__.ops_cached.$gwx_25=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'box'])
Z([[2,'!'],[[7],[3,'showSlotBox']]])
Z([3,'contentSuccess'])
Z([[7],[3,'showMemberBtn']])
Z([[2,'=='],[[6],[[7],[3,'leaseResult']],[3,'status']],[1,'租借成功']])
Z([3,'bannerAdvBox'])
Z([[7],[3,'materialUrl_wechat_zbo']])
Z([[7],[3,'materialUrl_wechat_zbt']])
Z([[7],[3,'materialUrl_wechat_zbth']])
Z([[7],[3,'showAbBanner']])
Z([[7],[3,'showSlotBox']])
Z([3,'slotBox'])
Z([[2,'=='],[[7],[3,'deviceType']],[1,'H3_C']])
Z([[2,'!'],[[7],[3,'borrowSlot']]])
Z([[2,'||'],[[2,'=='],[[7],[3,'deviceType']],[1,'H2']],[[2,'=='],[[7],[3,'deviceType']],[1,'H3']]])
Z(z[13])
Z([[2,'=='],[[7],[3,'deviceType']],[1,'Big_20']])
Z([3,'listItem'])
Z([[4],[[5],[[5],[1,0]],[1,1]]])
Z([3,'id'])
Z([3,'everyItem'])
Z([[4],[[5],[[5],[[5],[[5],[[5],[[5],[[5],[[5],[[5],[[5],[1,1]],[1,2]],[1,3]],[1,4]],[1,5]],[1,6]],[1,7]],[1,8]],[1,9]],[1,10]]])
Z(z[19])
Z([[2,'=='],[[7],[3,'borrowSlot']],[[2,'+'],[[2,'*'],[[7],[3,'listItem']],[1,10]],[[7],[3,'everyItem']]]])
Z([[2,'=='],[[7],[3,'deviceType']],[1,'Big_40']])
Z(z[17])
Z([[4],[[5],[[5],[[5],[[5],[1,0]],[1,1]],[1,2]],[1,3]]])
Z(z[19])
Z(z[20])
Z(z[21])
Z(z[19])
Z(z[23])
Z([[2,'=='],[[7],[3,'deviceType']],[1,'Big_80']])
Z([3,'middlebox'])
Z(z[17])
Z(z[26])
Z(z[19])
Z(z[20])
Z(z[21])
Z(z[19])
Z(z[23])
Z(z[17])
Z([[4],[[5],[[5],[[5],[[5],[1,4]],[1,5]],[1,6]],[1,7]]])
Z(z[19])
Z(z[20])
Z(z[21])
Z(z[19])
Z(z[23])
Z([[2,'&&'],[[2,'||'],[[2,'||'],[[2,'=='],[[7],[3,'deviceType']],[1,'Big_20']],[[2,'=='],[[7],[3,'deviceType']],[1,'Big_40']]],[[2,'=='],[[7],[3,'deviceType']],[1,'Big_80']]],[[2,'!'],[[7],[3,'borrowSlot']]]])
Z(z[13])
Z([[7],[3,'borrowSlot']])
Z(z[13])
Z([[7],[3,'advertisingflag']])
Z([[7],[3,'showOpenBluetooth']])
Z([[2,'&&'],[[2,'&&'],[[2,'!'],[[7],[3,'showMemberBtn']]],[[7],[3,'showModal']]],[[7],[3,'materialUrl_wechat_zt']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_25);return __WXML_GLOBAL__.ops_cached.$gwx_25
}
function gz$gwx_26(){
if( __WXML_GLOBAL__.ops_cached.$gwx_26)return __WXML_GLOBAL__.ops_cached.$gwx_26
__WXML_GLOBAL__.ops_cached.$gwx_26=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_26);return __WXML_GLOBAL__.ops_cached.$gwx_26
}
function gz$gwx_27(){
if( __WXML_GLOBAL__.ops_cached.$gwx_27)return __WXML_GLOBAL__.ops_cached.$gwx_27
__WXML_GLOBAL__.ops_cached.$gwx_27=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'formSubmit'])
Z([3,'true'])
Z([[7],[3,'showBorrowInfo']])
Z([3,'middleBgView'])
Z([3,'middle'])
Z([[7],[3,'bindStatus']])
Z([[7],[3,'isDepositPay']])
Z([[2,'=='],[[7],[3,'isBindMobile']],[1,false]])
Z([3,'leasebuttonbox'])
Z([[2,'=='],[[7],[3,'isDepositPay']],[1,true]])
Z([[2,'=='],[[7],[3,'isDepositPay']],[1,false]])
Z([[7],[3,'memberBtnShow']])
Z(z[10])
Z([[7],[3,'showPopBg']])
Z([[7],[3,'showModal']])
Z([[7],[3,'showBatteryLowpower']])
Z([[2,'!'],[[7],[3,'notBattery']]])
Z([[7],[3,'toBepaidModa']])
Z([[7],[3,'numleasingbox']])
Z([[7],[3,'momentBusybox']])
Z([[7],[3,'showDepositBorrow']])
})(__WXML_GLOBAL__.ops_cached.$gwx_27);return __WXML_GLOBAL__.ops_cached.$gwx_27
}
function gz$gwx_28(){
if( __WXML_GLOBAL__.ops_cached.$gwx_28)return __WXML_GLOBAL__.ops_cached.$gwx_28
__WXML_GLOBAL__.ops_cached.$gwx_28=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'formSubmit'])
Z([3,'true'])
Z([[6],[[7],[3,'fee_strategy']],[3,'length']])
Z([[2,'=='],[[7],[3,'isDepositPay']],[1,false]])
Z([3,'leasebuttonbox'])
Z([a,[3,'background-color:'],[[7],[3,'backgroundColor']],[3,';']])
Z([[2,'||'],[[2,'=='],[[7],[3,'isDepositPay']],[1,true]],[[2,'&&'],[[2,'=='],[[7],[3,'isDepositPay']],[1,false]],[[2,'=='],[[7],[3,'backindex']],[1,1]]]])
Z(z[3])
Z([[7],[3,'advertisingflag']])
Z([[7],[3,'showModal']])
Z([[7],[3,'insufficientFive']])
Z([[7],[3,'toBepaidModa']])
Z([[7],[3,'toBepaidbox']])
Z([[7],[3,'numleasingbox']])
Z([[7],[3,'momentBusybox']])
})(__WXML_GLOBAL__.ops_cached.$gwx_28);return __WXML_GLOBAL__.ops_cached.$gwx_28
}
function gz$gwx_29(){
if( __WXML_GLOBAL__.ops_cached.$gwx_29)return __WXML_GLOBAL__.ops_cached.$gwx_29
__WXML_GLOBAL__.ops_cached.$gwx_29=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'formSubmit'])
Z([[7],[3,'id']])
Z([[7],[3,'orderid']])
Z([3,'true'])
Z([3,'phtotocontent'])
Z([[2,'||'],[[2,'=='],[[7],[3,'phonenum']],[1,0]],[[2,'=='],[[7],[3,'phonenum']],[1,1]]])
Z([[2,'=='],[[7],[3,'phonenum']],[1,0]])
Z([[7],[3,'advertisingflag']])
Z([[7],[3,'Unopened']])
})(__WXML_GLOBAL__.ops_cached.$gwx_29);return __WXML_GLOBAL__.ops_cached.$gwx_29
}
function gz$gwx_30(){
if( __WXML_GLOBAL__.ops_cached.$gwx_30)return __WXML_GLOBAL__.ops_cached.$gwx_30
__WXML_GLOBAL__.ops_cached.$gwx_30=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'advertisingflag']])
Z([[7],[3,'isconnection']])
Z([[7],[3,'Unopened']])
})(__WXML_GLOBAL__.ops_cached.$gwx_30);return __WXML_GLOBAL__.ops_cached.$gwx_30
}
function gz$gwx_31(){
if( __WXML_GLOBAL__.ops_cached.$gwx_31)return __WXML_GLOBAL__.ops_cached.$gwx_31
__WXML_GLOBAL__.ops_cached.$gwx_31=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'itemb'])
Z([a,[3,'width:'],[[7],[3,'width']],[3,'px;height:'],[[7],[3,'height']],[3,'px;backgroud:#f3f4f8;']])
Z([[2,'=='],[[7],[3,'orders']],[1,0]])
Z([[7],[3,'orders']])
Z([3,'orderid'])
Z([3,'toOrderInfo'])
Z([3,'orderingbox'])
Z([[6],[[7],[3,'item']],[3,'orderid']])
Z([3,'usingview'])
Z([[7],[3,'index']])
Z([[2,'&&'],[[2,'!='],[[6],[[7],[3,'item']],[3,'status']],[1,'租借失败']],[[2,'!='],[[6],[[7],[3,'item']],[3,'status']],[1,'订单处理中']]])
Z(z[10])
})(__WXML_GLOBAL__.ops_cached.$gwx_31);return __WXML_GLOBAL__.ops_cached.$gwx_31
}
function gz$gwx_32(){
if( __WXML_GLOBAL__.ops_cached.$gwx_32)return __WXML_GLOBAL__.ops_cached.$gwx_32
__WXML_GLOBAL__.ops_cached.$gwx_32=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'page'])
Z([3,'headerView'])
Z([[2,'!'],[[7],[3,'showBluetoothTimeCount']]])
Z([[2,'&&'],[[2,'&&'],[[2,'!'],[[7],[3,'showBluetoothTimeCount']]],[[6],[[7],[3,'orderInfo']],[3,'toolBtn']]],[[2,'?:'],[[2,'=='],[[6],[[7],[3,'orderInfo']],[3,'toolBtn']],[1,'去支付']],[[2,'>='],[[7],[3,'timeRange']],[1,30]],[1,'true']]])
Z([[7],[3,'showBluetoothTimeCount']])
Z([[2,'=='],[[6],[[7],[3,'orderInfo']],[3,'status']],[1,'订单处理中']])
Z([[7],[3,'orderData']])
Z([3,'order'])
Z([3,'orderData'])
Z([[7],[3,'item']])
Z(z[8])
Z([[6],[[7],[3,'orderData']],[3,'value']])
Z([[2,'=='],[[6],[[7],[3,'orderData']],[3,'title']],[1,'订单编号']])
Z([[6],[[7],[3,'shops']],[3,'length']])
Z(z[4])
})(__WXML_GLOBAL__.ops_cached.$gwx_32);return __WXML_GLOBAL__.ops_cached.$gwx_32
}
function gz$gwx_33(){
if( __WXML_GLOBAL__.ops_cached.$gwx_33)return __WXML_GLOBAL__.ops_cached.$gwx_33
__WXML_GLOBAL__.ops_cached.$gwx_33=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'materialUrl_wechat_gdb']])
})(__WXML_GLOBAL__.ops_cached.$gwx_33);return __WXML_GLOBAL__.ops_cached.$gwx_33
}
function gz$gwx_34(){
if( __WXML_GLOBAL__.ops_cached.$gwx_34)return __WXML_GLOBAL__.ops_cached.$gwx_34
__WXML_GLOBAL__.ops_cached.$gwx_34=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'box'])
Z([[2,'!='],[[7],[3,'isTesting']],[1,1]])
Z([[2,'=='],[[7],[3,'isTesting']],[1,1]])
})(__WXML_GLOBAL__.ops_cached.$gwx_34);return __WXML_GLOBAL__.ops_cached.$gwx_34
}
__WXML_GLOBAL__.ops_set.$gwx=z;
__WXML_GLOBAL__.ops_init.$gwx=true;
var nv_require=function(){var nnm={};var nom={};return function(n){return function(){if(!nnm[n]) return undefined;try{if(!nom[n])nom[n]=nnm[n]();return nom[n];}catch(e){e.message=e.message.replace(/nv_/g,'');var tmp = e.stack.substring(0,e.stack.lastIndexOf(n));e.stack = tmp.substring(0,tmp.lastIndexOf('\n'));e.stack = e.stack.replace(/\snv_/g,' ');e.stack = $gstack(e.stack);e.stack += '\n    at ' + n.substring(2);console.error(e);}
}}}()
var x=['./packageLuckdraw/luckdraw/luckdraw.wxml','./packageuser/user/aboutUs/aboutUs.wxml','./packageuser/user/aboutUs/agreement/agreement.wxml','./packageuser/user/getPhoneNum/getPhoneNum.wxml','./packageuser/user/information/information.wxml','./packageuser/user/myCoupon/Instructions/Instructions.wxml','./packageuser/user/myCoupon/couponCell/couponCell.wxml','./packageuser/user/myCoupon/myCoupon.wxml','./packageuser/user/mywallet/mywallet.wxml','./packageuser/user/mywallet/refund/refund.wxml','./packageuser/user/mywallet/transaction/transaction.wxml','./packageuser/user/mywallet/withdraw/withdraw.wxml','./packageuser/user/setUp/setUp.wxml','./packageuser/user/user.wxml','./pages/advertising-h5/advertising-h5.wxml','./pages/helpCenter/helpCenter.wxml','./pages/helpCenter/issueInfo.wxml','./pages/index/authorization/authorization.wxml','./pages/index/index.wxml','./pages/index/member/member.wxml','./pages/index/member/memberExchange/memberExchange.wxml','./pages/index/member/runRenew/runRenew.wxml','./pages/index/sweep/deviceAbnormal/deviceAbnormal.wxml','./pages/index/sweep/entrustbox/entrustbox.wxml','./pages/index/sweep/leaseSuccess/leaseSuccess.wxml','./pages/index/sweep/protocol/protocol.wxml','./pages/index/sweep/sweep.wxml','./pages/index/sweepMade/sweepMade.wxml','./pages/ordering/feedback/feedback.wxml','./pages/ordering/lost-powerback/lost-powerback.wxml','./pages/ordering/ordering.wxml','./pages/ordering/orderingend/orderingend.wxml','./pages/ordering/returnsuccess/returnsuccess.wxml','./pages/ordering/testing/testing.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_1()
var oB=_v()
_(r,oB)
if(_oz(z,0,e,s,gg)){oB.wxVkey=1
}
var xC=_v()
_(r,xC)
if(_oz(z,1,e,s,gg)){xC.wxVkey=1
}
var oD=_v()
_(r,oD)
if(_oz(z,2,e,s,gg)){oD.wxVkey=1
}
var fE=_v()
_(r,fE)
if(_oz(z,3,e,s,gg)){fE.wxVkey=1
}
oB.wxXCkey=1
xC.wxXCkey=1
oD.wxXCkey=1
fE.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
d_[x[1]]={}
var m1=function(e,s,r,gg){
var z=gz$gwx_2()
return r
}
e_[x[1]]={f:m1,j:[],i:[],ti:[],ic:[]}
d_[x[2]]={}
var m2=function(e,s,r,gg){
var z=gz$gwx_3()
return r
}
e_[x[2]]={f:m2,j:[],i:[],ti:[],ic:[]}
d_[x[3]]={}
var m3=function(e,s,r,gg){
var z=gz$gwx_4()
var eN=_mz(z,'form',['bindsubmit',0,'reportSubmit',1],[],e,s,gg)
var bO=_v()
_(eN,bO)
if(_oz(z,2,e,s,gg)){bO.wxVkey=1
}
var oR=_n('view')
_rz(z,oR,'class',3,e,s,gg)
var fS=_v()
_(oR,fS)
if(_oz(z,4,e,s,gg)){fS.wxVkey=1
}
var cT=_v()
_(oR,cT)
if(_oz(z,5,e,s,gg)){cT.wxVkey=1
}
fS.wxXCkey=1
cT.wxXCkey=1
_(eN,oR)
var oP=_v()
_(eN,oP)
if(_oz(z,6,e,s,gg)){oP.wxVkey=1
}
var xQ=_v()
_(eN,xQ)
if(_oz(z,7,e,s,gg)){xQ.wxVkey=1
}
bO.wxXCkey=1
oP.wxXCkey=1
xQ.wxXCkey=1
_(r,eN)
var cI=_v()
_(r,cI)
if(_oz(z,8,e,s,gg)){cI.wxVkey=1
}
var oJ=_v()
_(r,oJ)
if(_oz(z,9,e,s,gg)){oJ.wxVkey=1
}
var lK=_v()
_(r,lK)
if(_oz(z,10,e,s,gg)){lK.wxVkey=1
}
var aL=_v()
_(r,aL)
if(_oz(z,11,e,s,gg)){aL.wxVkey=1
}
var tM=_v()
_(r,tM)
if(_oz(z,12,e,s,gg)){tM.wxVkey=1
}
cI.wxXCkey=1
oJ.wxXCkey=1
lK.wxXCkey=1
aL.wxXCkey=1
tM.wxXCkey=1
return r
}
e_[x[3]]={f:m3,j:[],i:[],ti:[],ic:[]}
d_[x[4]]={}
var m4=function(e,s,r,gg){
var z=gz$gwx_5()
return r
}
e_[x[4]]={f:m4,j:[],i:[],ti:[],ic:[]}
d_[x[5]]={}
var m5=function(e,s,r,gg){
var z=gz$gwx_6()
return r
}
e_[x[5]]={f:m5,j:[],i:[],ti:[],ic:[]}
d_[x[6]]={}
var m6=function(e,s,r,gg){
var z=gz$gwx_7()
var oX=_v()
_(r,oX)
if(_oz(z,0,e,s,gg)){oX.wxVkey=1
}
oX.wxXCkey=1
return r
}
e_[x[6]]={f:m6,j:[],i:[],ti:[],ic:[]}
d_[x[7]]={}
var m7=function(e,s,r,gg){
var z=gz$gwx_8()
var t1=_n('view')
_rz(z,t1,'class',0,e,s,gg)
var e2=_n('view')
_rz(z,e2,'class',1,e,s,gg)
var b3=_v()
_(e2,b3)
if(_oz(z,2,e,s,gg)){b3.wxVkey=1
}
var o4=_v()
_(e2,o4)
if(_oz(z,3,e,s,gg)){o4.wxVkey=1
}
b3.wxXCkey=1
o4.wxXCkey=1
_(t1,e2)
var x5=_mz(z,'scroll-view',['enableBackToTop',4,'scrollY',1,'style',2],[],e,s,gg)
var c8=_v()
_(x5,c8)
var h9=function(cAB,o0,oBB,gg){
var aDB=_mz(z,'couponCell',['bindQRTouch',9,'couponData',1],[],cAB,o0,gg)
_(oBB,aDB)
return oBB
}
c8.wxXCkey=4
_2z(z,7,h9,e,s,gg,c8,'item','index','couponList')
var o6=_v()
_(x5,o6)
if(_oz(z,11,e,s,gg)){o6.wxVkey=1
}
var f7=_v()
_(x5,f7)
if(_oz(z,12,e,s,gg)){f7.wxVkey=1
}
o6.wxXCkey=1
f7.wxXCkey=1
_(t1,x5)
_(r,t1)
var aZ=_v()
_(r,aZ)
if(_oz(z,13,e,s,gg)){aZ.wxVkey=1
}
aZ.wxXCkey=1
return r
}
e_[x[7]]={f:m7,j:[],i:[],ti:[],ic:[]}
d_[x[8]]={}
var m8=function(e,s,r,gg){
var z=gz$gwx_9()
var oHB=_n('view')
_rz(z,oHB,'class',0,e,s,gg)
var oJB=_n('view')
var fKB=_v()
_(oJB,fKB)
if(_oz(z,1,e,s,gg)){fKB.wxVkey=1
}
var cLB=_v()
_(oJB,cLB)
if(_oz(z,2,e,s,gg)){cLB.wxVkey=1
}
fKB.wxXCkey=1
cLB.wxXCkey=1
_(oHB,oJB)
var xIB=_v()
_(oHB,xIB)
if(_oz(z,3,e,s,gg)){xIB.wxVkey=1
}
xIB.wxXCkey=1
_(r,oHB)
var eFB=_v()
_(r,eFB)
if(_oz(z,4,e,s,gg)){eFB.wxVkey=1
}
var bGB=_v()
_(r,bGB)
if(_oz(z,5,e,s,gg)){bGB.wxVkey=1
}
eFB.wxXCkey=1
bGB.wxXCkey=1
return r
}
e_[x[8]]={f:m8,j:[],i:[],ti:[],ic:[]}
d_[x[9]]={}
var m9=function(e,s,r,gg){
var z=gz$gwx_10()
var oNB=_n('view')
_rz(z,oNB,'class',0,e,s,gg)
var cOB=_v()
_(oNB,cOB)
if(_oz(z,1,e,s,gg)){cOB.wxVkey=1
}
var oPB=_v()
_(oNB,oPB)
if(_oz(z,2,e,s,gg)){oPB.wxVkey=1
}
cOB.wxXCkey=1
oPB.wxXCkey=1
_(r,oNB)
return r
}
e_[x[9]]={f:m9,j:[],i:[],ti:[],ic:[]}
d_[x[10]]={}
var m10=function(e,s,r,gg){
var z=gz$gwx_11()
return r
}
e_[x[10]]={f:m10,j:[],i:[],ti:[],ic:[]}
d_[x[11]]={}
var m11=function(e,s,r,gg){
var z=gz$gwx_12()
var tSB=_v()
_(r,tSB)
if(_oz(z,0,e,s,gg)){tSB.wxVkey=1
}
var eTB=_v()
_(r,eTB)
if(_oz(z,1,e,s,gg)){eTB.wxVkey=1
}
var bUB=_v()
_(r,bUB)
if(_oz(z,2,e,s,gg)){bUB.wxVkey=1
}
tSB.wxXCkey=1
eTB.wxXCkey=1
bUB.wxXCkey=1
return r
}
e_[x[11]]={f:m11,j:[],i:[],ti:[],ic:[]}
d_[x[12]]={}
var m12=function(e,s,r,gg){
var z=gz$gwx_13()
var xWB=_v()
_(r,xWB)
if(_oz(z,0,e,s,gg)){xWB.wxVkey=1
}
xWB.wxXCkey=1
return r
}
e_[x[12]]={f:m12,j:[],i:[],ti:[],ic:[]}
d_[x[13]]={}
var m13=function(e,s,r,gg){
var z=gz$gwx_14()
var fYB=_v()
_(r,fYB)
if(_oz(z,0,e,s,gg)){fYB.wxVkey=1
}
var cZB=_v()
_(r,cZB)
if(_oz(z,1,e,s,gg)){cZB.wxVkey=1
}
var h1B=_v()
_(r,h1B)
if(_oz(z,2,e,s,gg)){h1B.wxVkey=1
}
fYB.wxXCkey=1
cZB.wxXCkey=1
h1B.wxXCkey=1
return r
}
e_[x[13]]={f:m13,j:[],i:[],ti:[],ic:[]}
d_[x[14]]={}
var m14=function(e,s,r,gg){
var z=gz$gwx_15()
return r
}
e_[x[14]]={f:m14,j:[],i:[],ti:[],ic:[]}
d_[x[15]]={}
var m15=function(e,s,r,gg){
var z=gz$gwx_16()
return r
}
e_[x[15]]={f:m15,j:[],i:[],ti:[],ic:[]}
d_[x[16]]={}
var m16=function(e,s,r,gg){
var z=gz$gwx_17()
return r
}
e_[x[16]]={f:m16,j:[],i:[],ti:[],ic:[]}
d_[x[17]]={}
var m17=function(e,s,r,gg){
var z=gz$gwx_18()
return r
}
e_[x[17]]={f:m17,j:[],i:[],ti:[],ic:[]}
d_[x[18]]={}
var m18=function(e,s,r,gg){
var z=gz$gwx_19()
var t7B=_n('view')
_rz(z,t7B,'class',0,e,s,gg)
var o0B=_mz(z,'view',['class',1,'hidden',1],[],e,s,gg)
var xAC=_mz(z,'view',['bindtap',3,'class',1,'data-index',2,'style',3],[],e,s,gg)
var oBC=_v()
_(xAC,oBC)
if(_oz(z,7,e,s,gg)){oBC.wxVkey=1
}
oBC.wxXCkey=1
_(o0B,xAC)
var fCC=_v()
_(o0B,fCC)
var cDC=function(oFC,hEC,cGC,gg){
var lIC=_mz(z,'view',['bindtap',10,'class',1,'data-index',2,'style',3],[],oFC,hEC,gg)
var aJC=_v()
_(lIC,aJC)
if(_oz(z,14,oFC,hEC,gg)){aJC.wxVkey=1
}
aJC.wxXCkey=1
_(cGC,lIC)
return cGC
}
fCC.wxXCkey=2
_2z(z,8,cDC,e,s,gg,fCC,'item','index','id')
_(t7B,o0B)
var tKC=_mz(z,'map',['bindcontroltap',15,'bindmarkertap',1,'bindregionchange',2,'bindtap',3,'id',4,'latitude',5,'longitude',6,'markers',7,'scale',8,'showLocation',9,'style',10],[],e,s,gg)
var xOC=_n('cover-view')
_rz(z,xOC,'class',26,e,s,gg)
var oPC=_v()
_(xOC,oPC)
if(_oz(z,27,e,s,gg)){oPC.wxVkey=1
}
var fQC=_v()
_(xOC,fQC)
if(_oz(z,28,e,s,gg)){fQC.wxVkey=1
}
oPC.wxXCkey=1
fQC.wxXCkey=1
_(tKC,xOC)
var eLC=_v()
_(tKC,eLC)
if(_oz(z,29,e,s,gg)){eLC.wxVkey=1
}
var bMC=_v()
_(tKC,bMC)
if(_oz(z,30,e,s,gg)){bMC.wxVkey=1
}
var cRC=_n('cover-view')
_rz(z,cRC,'class',31,e,s,gg)
var hSC=_v()
_(cRC,hSC)
if(_oz(z,32,e,s,gg)){hSC.wxVkey=1
}
var oTC=_v()
_(cRC,oTC)
if(_oz(z,33,e,s,gg)){oTC.wxVkey=1
}
hSC.wxXCkey=1
oTC.wxXCkey=1
_(tKC,cRC)
var oNC=_v()
_(tKC,oNC)
if(_oz(z,34,e,s,gg)){oNC.wxVkey=1
}
eLC.wxXCkey=1
bMC.wxXCkey=1
oNC.wxXCkey=1
_(t7B,tKC)
var e8B=_v()
_(t7B,e8B)
if(_oz(z,35,e,s,gg)){e8B.wxVkey=1
}
var b9B=_v()
_(t7B,b9B)
if(_oz(z,36,e,s,gg)){b9B.wxVkey=1
}
e8B.wxXCkey=1
b9B.wxXCkey=1
_(r,t7B)
return r
}
e_[x[18]]={f:m18,j:[],i:[],ti:[],ic:[]}
d_[x[19]]={}
var m19=function(e,s,r,gg){
var z=gz$gwx_20()
var o2C=_n('view')
var x3C=_v()
_(o2C,x3C)
if(_oz(z,0,e,s,gg)){x3C.wxVkey=1
}
var o4C=_n('view')
_rz(z,o4C,'class',1,e,s,gg)
var c6C=_v()
_(o4C,c6C)
var h7C=function(c9C,o8C,o0C,gg){
var aBD=_mz(z,'view',['catchtap',4,'class',1,'data-index',2],[],c9C,o8C,gg)
var tCD=_n('view')
_rz(z,tCD,'class',7,c9C,o8C,gg)
var eDD=_v()
_(tCD,eDD)
if(_oz(z,8,c9C,o8C,gg)){eDD.wxVkey=1
}
var bED=_v()
_(tCD,bED)
if(_oz(z,9,c9C,o8C,gg)){bED.wxVkey=1
}
var oFD=_v()
_(tCD,oFD)
if(_oz(z,10,c9C,o8C,gg)){oFD.wxVkey=1
}
eDD.wxXCkey=1
bED.wxXCkey=1
oFD.wxXCkey=1
_(aBD,tCD)
_(o0C,aBD)
return o0C
}
c6C.wxXCkey=2
_2z(z,2,h7C,e,s,gg,c6C,'item','index','type')
var f5C=_v()
_(o4C,f5C)
if(_oz(z,11,e,s,gg)){f5C.wxVkey=1
}
f5C.wxXCkey=1
_(o2C,o4C)
x3C.wxXCkey=1
_(r,o2C)
var oVC=_v()
_(r,oVC)
if(_oz(z,12,e,s,gg)){oVC.wxVkey=1
}
var lWC=_v()
_(r,lWC)
if(_oz(z,13,e,s,gg)){lWC.wxVkey=1
}
var aXC=_v()
_(r,aXC)
if(_oz(z,14,e,s,gg)){aXC.wxVkey=1
}
var tYC=_v()
_(r,tYC)
if(_oz(z,15,e,s,gg)){tYC.wxVkey=1
var xGD=_n('view')
_rz(z,xGD,'class',16,e,s,gg)
var oHD=_v()
_(xGD,oHD)
if(_oz(z,17,e,s,gg)){oHD.wxVkey=1
}
var fID=_n('view')
_rz(z,fID,'class',18,e,s,gg)
var cJD=_v()
_(fID,cJD)
if(_oz(z,19,e,s,gg)){cJD.wxVkey=1
}
var hKD=_v()
_(fID,hKD)
if(_oz(z,20,e,s,gg)){hKD.wxVkey=1
}
cJD.wxXCkey=1
hKD.wxXCkey=1
_(xGD,fID)
oHD.wxXCkey=1
_(tYC,xGD)
}
var eZC=_v()
_(r,eZC)
if(_oz(z,21,e,s,gg)){eZC.wxVkey=1
}
var b1C=_v()
_(r,b1C)
if(_oz(z,22,e,s,gg)){b1C.wxVkey=1
}
oVC.wxXCkey=1
lWC.wxXCkey=1
aXC.wxXCkey=1
tYC.wxXCkey=1
eZC.wxXCkey=1
b1C.wxXCkey=1
return r
}
e_[x[19]]={f:m19,j:[],i:[],ti:[],ic:[]}
d_[x[20]]={}
var m20=function(e,s,r,gg){
var z=gz$gwx_21()
var cMD=_v()
_(r,cMD)
if(_oz(z,0,e,s,gg)){cMD.wxVkey=1
}
var oND=_v()
_(r,oND)
if(_oz(z,1,e,s,gg)){oND.wxVkey=1
var lOD=_n('view')
_rz(z,lOD,'class',2,e,s,gg)
var aPD=_v()
_(lOD,aPD)
if(_oz(z,3,e,s,gg)){aPD.wxVkey=1
}
var tQD=_v()
_(lOD,tQD)
if(_oz(z,4,e,s,gg)){tQD.wxVkey=1
}
var eRD=_v()
_(lOD,eRD)
if(_oz(z,5,e,s,gg)){eRD.wxVkey=1
}
aPD.wxXCkey=1
tQD.wxXCkey=1
eRD.wxXCkey=1
_(oND,lOD)
}
cMD.wxXCkey=1
oND.wxXCkey=1
return r
}
e_[x[20]]={f:m20,j:[],i:[],ti:[],ic:[]}
d_[x[21]]={}
var m21=function(e,s,r,gg){
var z=gz$gwx_22()
var oTD=_v()
_(r,oTD)
if(_oz(z,0,e,s,gg)){oTD.wxVkey=1
}
var xUD=_v()
_(r,xUD)
if(_oz(z,1,e,s,gg)){xUD.wxVkey=1
}
oTD.wxXCkey=1
xUD.wxXCkey=1
return r
}
e_[x[21]]={f:m21,j:[],i:[],ti:[],ic:[]}
d_[x[22]]={}
var m22=function(e,s,r,gg){
var z=gz$gwx_23()
return r
}
e_[x[22]]={f:m22,j:[],i:[],ti:[],ic:[]}
d_[x[23]]={}
var m23=function(e,s,r,gg){
var z=gz$gwx_24()
return r
}
e_[x[23]]={f:m23,j:[],i:[],ti:[],ic:[]}
d_[x[24]]={}
var m24=function(e,s,r,gg){
var z=gz$gwx_25()
var l3D=_n('view')
_rz(z,l3D,'class',0,e,s,gg)
var a4D=_v()
_(l3D,a4D)
if(_oz(z,1,e,s,gg)){a4D.wxVkey=1
var t5D=_n('view')
_rz(z,t5D,'class',2,e,s,gg)
var e6D=_v()
_(t5D,e6D)
if(_oz(z,3,e,s,gg)){e6D.wxVkey=1
}
var b7D=_v()
_(t5D,b7D)
if(_oz(z,4,e,s,gg)){b7D.wxVkey=1
}
e6D.wxXCkey=1
b7D.wxXCkey=1
_(a4D,t5D)
}
var o8D=_n('view')
_rz(z,o8D,'class',5,e,s,gg)
var x9D=_v()
_(o8D,x9D)
if(_oz(z,6,e,s,gg)){x9D.wxVkey=1
}
var o0D=_v()
_(o8D,o0D)
if(_oz(z,7,e,s,gg)){o0D.wxVkey=1
}
var fAE=_v()
_(o8D,fAE)
if(_oz(z,8,e,s,gg)){fAE.wxVkey=1
}
var cBE=_v()
_(o8D,cBE)
if(_oz(z,9,e,s,gg)){cBE.wxVkey=1
}
x9D.wxXCkey=1
o0D.wxXCkey=1
fAE.wxXCkey=1
cBE.wxXCkey=1
_(l3D,o8D)
a4D.wxXCkey=1
_(r,l3D)
var hYD=_v()
_(r,hYD)
if(_oz(z,10,e,s,gg)){hYD.wxVkey=1
var hCE=_n('view')
_rz(z,hCE,'class',11,e,s,gg)
var oDE=_v()
_(hCE,oDE)
if(_oz(z,12,e,s,gg)){oDE.wxVkey=1
var xME=_v()
_(oDE,xME)
if(_oz(z,13,e,s,gg)){xME.wxVkey=1
}
xME.wxXCkey=1
}
var cEE=_v()
_(hCE,cEE)
if(_oz(z,14,e,s,gg)){cEE.wxVkey=1
var oNE=_v()
_(cEE,oNE)
if(_oz(z,15,e,s,gg)){oNE.wxVkey=1
}
oNE.wxXCkey=1
}
var oFE=_v()
_(hCE,oFE)
if(_oz(z,16,e,s,gg)){oFE.wxVkey=1
var fOE=_v()
_(oFE,fOE)
var cPE=function(oRE,hQE,cSE,gg){
var lUE=_v()
_(cSE,lUE)
var aVE=function(eXE,tWE,bYE,gg){
var x1E=_v()
_(bYE,x1E)
if(_oz(z,23,eXE,tWE,gg)){x1E.wxVkey=1
}
x1E.wxXCkey=1
return bYE
}
lUE.wxXCkey=2
_2z(z,21,aVE,oRE,hQE,gg,lUE,'everyItem','index','id')
return cSE
}
fOE.wxXCkey=2
_2z(z,18,cPE,e,s,gg,fOE,'listItem','index','id')
}
var lGE=_v()
_(hCE,lGE)
if(_oz(z,24,e,s,gg)){lGE.wxVkey=1
var o2E=_v()
_(lGE,o2E)
var f3E=function(h5E,c4E,o6E,gg){
var o8E=_v()
_(o6E,o8E)
var l9E=function(tAF,a0E,eBF,gg){
var oDF=_v()
_(eBF,oDF)
if(_oz(z,31,tAF,a0E,gg)){oDF.wxVkey=1
}
oDF.wxXCkey=1
return eBF
}
o8E.wxXCkey=2
_2z(z,29,l9E,h5E,c4E,gg,o8E,'everyItem','index','id')
return o6E
}
o2E.wxXCkey=2
_2z(z,26,f3E,e,s,gg,o2E,'listItem','index','id')
}
var aHE=_v()
_(hCE,aHE)
if(_oz(z,32,e,s,gg)){aHE.wxVkey=1
var xEF=_n('view')
_rz(z,xEF,'class',33,e,s,gg)
var oFF=_v()
_(xEF,oFF)
var fGF=function(hIF,cHF,oJF,gg){
var oLF=_v()
_(oJF,oLF)
var lMF=function(tOF,aNF,ePF,gg){
var oRF=_v()
_(ePF,oRF)
if(_oz(z,40,tOF,aNF,gg)){oRF.wxVkey=1
}
oRF.wxXCkey=1
return ePF
}
oLF.wxXCkey=2
_2z(z,38,lMF,hIF,cHF,gg,oLF,'everyItem','index','id')
return oJF
}
oFF.wxXCkey=2
_2z(z,35,fGF,e,s,gg,oFF,'listItem','index','id')
var xSF=_v()
_(xEF,xSF)
var oTF=function(cVF,fUF,hWF,gg){
var cYF=_v()
_(hWF,cYF)
var oZF=function(a2F,l1F,t3F,gg){
var b5F=_v()
_(t3F,b5F)
if(_oz(z,47,a2F,l1F,gg)){b5F.wxVkey=1
}
b5F.wxXCkey=1
return t3F
}
cYF.wxXCkey=2
_2z(z,45,oZF,cVF,fUF,gg,cYF,'everyItem','index','id')
return hWF
}
xSF.wxXCkey=2
_2z(z,42,oTF,e,s,gg,xSF,'listItem','index','id')
_(aHE,xEF)
}
var tIE=_v()
_(hCE,tIE)
if(_oz(z,48,e,s,gg)){tIE.wxVkey=1
}
var eJE=_v()
_(hCE,eJE)
if(_oz(z,49,e,s,gg)){eJE.wxVkey=1
}
var bKE=_v()
_(hCE,bKE)
if(_oz(z,50,e,s,gg)){bKE.wxVkey=1
}
var oLE=_v()
_(hCE,oLE)
if(_oz(z,51,e,s,gg)){oLE.wxVkey=1
}
oDE.wxXCkey=1
cEE.wxXCkey=1
oFE.wxXCkey=1
lGE.wxXCkey=1
aHE.wxXCkey=1
tIE.wxXCkey=1
eJE.wxXCkey=1
bKE.wxXCkey=1
oLE.wxXCkey=1
_(hYD,hCE)
}
var oZD=_v()
_(r,oZD)
if(_oz(z,52,e,s,gg)){oZD.wxVkey=1
}
var c1D=_v()
_(r,c1D)
if(_oz(z,53,e,s,gg)){c1D.wxVkey=1
}
var o2D=_v()
_(r,o2D)
if(_oz(z,54,e,s,gg)){o2D.wxVkey=1
}
hYD.wxXCkey=1
oZD.wxXCkey=1
c1D.wxXCkey=1
o2D.wxXCkey=1
return r
}
e_[x[24]]={f:m24,j:[],i:[],ti:[],ic:[]}
d_[x[25]]={}
var m25=function(e,s,r,gg){
var z=gz$gwx_26()
return r
}
e_[x[25]]={f:m25,j:[],i:[],ti:[],ic:[]}
d_[x[26]]={}
var m26=function(e,s,r,gg){
var z=gz$gwx_27()
var lEG=_mz(z,'form',['bindsubmit',0,'reportSubmit',1],[],e,s,gg)
var aFG=_v()
_(lEG,aFG)
if(_oz(z,2,e,s,gg)){aFG.wxVkey=1
var tGG=_n('view')
_rz(z,tGG,'class',3,e,s,gg)
var bIG=_n('view')
_rz(z,bIG,'class',4,e,s,gg)
var oJG=_v()
_(bIG,oJG)
if(_oz(z,5,e,s,gg)){oJG.wxVkey=1
}
var xKG=_v()
_(bIG,xKG)
if(_oz(z,6,e,s,gg)){xKG.wxVkey=1
}
var oLG=_v()
_(bIG,oLG)
if(_oz(z,7,e,s,gg)){oLG.wxVkey=1
}
oJG.wxXCkey=1
xKG.wxXCkey=1
oLG.wxXCkey=1
_(tGG,bIG)
var fMG=_n('view')
_rz(z,fMG,'class',8,e,s,gg)
var cNG=_v()
_(fMG,cNG)
if(_oz(z,9,e,s,gg)){cNG.wxVkey=1
}
var hOG=_v()
_(fMG,hOG)
if(_oz(z,10,e,s,gg)){hOG.wxVkey=1
}
var oPG=_v()
_(fMG,oPG)
if(_oz(z,11,e,s,gg)){oPG.wxVkey=1
}
cNG.wxXCkey=1
hOG.wxXCkey=1
oPG.wxXCkey=1
_(tGG,fMG)
var eHG=_v()
_(tGG,eHG)
if(_oz(z,12,e,s,gg)){eHG.wxVkey=1
}
eHG.wxXCkey=1
_(aFG,tGG)
}
aFG.wxXCkey=1
_(r,lEG)
var o8F=_v()
_(r,o8F)
if(_oz(z,13,e,s,gg)){o8F.wxVkey=1
}
var f9F=_v()
_(r,f9F)
if(_oz(z,14,e,s,gg)){f9F.wxVkey=1
}
var c0F=_v()
_(r,c0F)
if(_oz(z,15,e,s,gg)){c0F.wxVkey=1
var cQG=_v()
_(c0F,cQG)
if(_oz(z,16,e,s,gg)){cQG.wxVkey=1
}
cQG.wxXCkey=1
}
var hAG=_v()
_(r,hAG)
if(_oz(z,17,e,s,gg)){hAG.wxVkey=1
}
var oBG=_v()
_(r,oBG)
if(_oz(z,18,e,s,gg)){oBG.wxVkey=1
}
var cCG=_v()
_(r,cCG)
if(_oz(z,19,e,s,gg)){cCG.wxVkey=1
}
var oDG=_v()
_(r,oDG)
if(_oz(z,20,e,s,gg)){oDG.wxVkey=1
}
o8F.wxXCkey=1
f9F.wxXCkey=1
c0F.wxXCkey=1
hAG.wxXCkey=1
oBG.wxXCkey=1
cCG.wxXCkey=1
oDG.wxXCkey=1
return r
}
e_[x[26]]={f:m26,j:[],i:[],ti:[],ic:[]}
d_[x[27]]={}
var m27=function(e,s,r,gg){
var z=gz$gwx_28()
var oZG=_mz(z,'form',['bindsubmit',0,'reportSubmit',1],[],e,s,gg)
var f1G=_v()
_(oZG,f1G)
if(_oz(z,2,e,s,gg)){f1G.wxVkey=1
}
var c2G=_v()
_(oZG,c2G)
if(_oz(z,3,e,s,gg)){c2G.wxVkey=1
}
var h3G=_mz(z,'view',['class',4,'style',1],[],e,s,gg)
var o4G=_v()
_(h3G,o4G)
if(_oz(z,6,e,s,gg)){o4G.wxVkey=1
}
var c5G=_v()
_(h3G,c5G)
if(_oz(z,7,e,s,gg)){c5G.wxVkey=1
}
o4G.wxXCkey=1
c5G.wxXCkey=1
_(oZG,h3G)
f1G.wxXCkey=1
c2G.wxXCkey=1
_(r,oZG)
var lSG=_v()
_(r,lSG)
if(_oz(z,8,e,s,gg)){lSG.wxVkey=1
}
var aTG=_v()
_(r,aTG)
if(_oz(z,9,e,s,gg)){aTG.wxVkey=1
}
var tUG=_v()
_(r,tUG)
if(_oz(z,10,e,s,gg)){tUG.wxVkey=1
}
var eVG=_v()
_(r,eVG)
if(_oz(z,11,e,s,gg)){eVG.wxVkey=1
}
var bWG=_v()
_(r,bWG)
if(_oz(z,12,e,s,gg)){bWG.wxVkey=1
}
var oXG=_v()
_(r,oXG)
if(_oz(z,13,e,s,gg)){oXG.wxVkey=1
}
var xYG=_v()
_(r,xYG)
if(_oz(z,14,e,s,gg)){xYG.wxVkey=1
}
lSG.wxXCkey=1
aTG.wxXCkey=1
tUG.wxXCkey=1
eVG.wxXCkey=1
bWG.wxXCkey=1
oXG.wxXCkey=1
xYG.wxXCkey=1
return r
}
e_[x[27]]={f:m27,j:[],i:[],ti:[],ic:[]}
d_[x[28]]={}
var m28=function(e,s,r,gg){
var z=gz$gwx_29()
var t9G=_mz(z,'form',['bindsubmit',0,'data-id',1,'data-orderid',1,'reportSubmit',2],[],e,s,gg)
var e0G=_n('view')
_rz(z,e0G,'class',4,e,s,gg)
var bAH=_v()
_(e0G,bAH)
if(_oz(z,5,e,s,gg)){bAH.wxVkey=1
}
var oBH=_v()
_(e0G,oBH)
if(_oz(z,6,e,s,gg)){oBH.wxVkey=1
}
bAH.wxXCkey=1
oBH.wxXCkey=1
_(t9G,e0G)
_(r,t9G)
var l7G=_v()
_(r,l7G)
if(_oz(z,7,e,s,gg)){l7G.wxVkey=1
}
var a8G=_v()
_(r,a8G)
if(_oz(z,8,e,s,gg)){a8G.wxVkey=1
}
l7G.wxXCkey=1
a8G.wxXCkey=1
return r
}
e_[x[28]]={f:m28,j:[],i:[],ti:[],ic:[]}
d_[x[29]]={}
var m29=function(e,s,r,gg){
var z=gz$gwx_30()
var oDH=_v()
_(r,oDH)
if(_oz(z,0,e,s,gg)){oDH.wxVkey=1
}
var fEH=_v()
_(r,fEH)
if(_oz(z,1,e,s,gg)){fEH.wxVkey=1
}
var cFH=_v()
_(r,cFH)
if(_oz(z,2,e,s,gg)){cFH.wxVkey=1
}
oDH.wxXCkey=1
fEH.wxXCkey=1
cFH.wxXCkey=1
return r
}
e_[x[29]]={f:m29,j:[],i:[],ti:[],ic:[]}
d_[x[30]]={}
var m30=function(e,s,r,gg){
var z=gz$gwx_31()
var oHH=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var cIH=_v()
_(oHH,cIH)
if(_oz(z,2,e,s,gg)){cIH.wxVkey=1
}
else{cIH.wxVkey=2
var oJH=_v()
_(cIH,oJH)
var lKH=function(tMH,aLH,eNH,gg){
var oPH=_mz(z,'view',['bindtap',5,'class',1,'data-id',2],[],tMH,aLH,gg)
var xQH=_mz(z,'view',['class',8,'data-ind',1],[],tMH,aLH,gg)
var oRH=_v()
_(xQH,oRH)
if(_oz(z,10,tMH,aLH,gg)){oRH.wxVkey=1
}
var fSH=_v()
_(xQH,fSH)
if(_oz(z,11,tMH,aLH,gg)){fSH.wxVkey=1
}
oRH.wxXCkey=1
fSH.wxXCkey=1
_(oPH,xQH)
_(eNH,oPH)
return eNH
}
oJH.wxXCkey=2
_2z(z,3,lKH,e,s,gg,oJH,'item','index','orderid')
}
cIH.wxXCkey=1
_(r,oHH)
return r
}
e_[x[30]]={f:m30,j:[],i:[],ti:[],ic:[]}
d_[x[31]]={}
var m31=function(e,s,r,gg){
var z=gz$gwx_32()
var hUH=_n('view')
_rz(z,hUH,'class',0,e,s,gg)
var lYH=_n('view')
_rz(z,lYH,'class',1,e,s,gg)
var aZH=_v()
_(lYH,aZH)
if(_oz(z,2,e,s,gg)){aZH.wxVkey=1
}
var t1H=_v()
_(lYH,t1H)
if(_oz(z,3,e,s,gg)){t1H.wxVkey=1
}
var e2H=_v()
_(lYH,e2H)
if(_oz(z,4,e,s,gg)){e2H.wxVkey=1
}
aZH.wxXCkey=1
t1H.wxXCkey=1
e2H.wxXCkey=1
_(hUH,lYH)
var oVH=_v()
_(hUH,oVH)
if(_oz(z,5,e,s,gg)){oVH.wxVkey=1
}
var b3H=_v()
_(hUH,b3H)
var o4H=function(o6H,x5H,f7H,gg){
var h9H=_v()
_(f7H,h9H)
var o0H=function(oBI,cAI,lCI,gg){
var tEI=_v()
_(lCI,tEI)
if(_oz(z,11,oBI,cAI,gg)){tEI.wxVkey=1
var eFI=_v()
_(tEI,eFI)
if(_oz(z,12,oBI,cAI,gg)){eFI.wxVkey=1
}
eFI.wxXCkey=1
}
tEI.wxXCkey=1
return lCI
}
h9H.wxXCkey=2
_2z(z,9,o0H,o6H,x5H,gg,h9H,'orderData','index','orderData')
return f7H
}
b3H.wxXCkey=2
_2z(z,6,o4H,e,s,gg,b3H,'item','index','order')
var cWH=_v()
_(hUH,cWH)
if(_oz(z,13,e,s,gg)){cWH.wxVkey=1
}
var oXH=_v()
_(hUH,oXH)
if(_oz(z,14,e,s,gg)){oXH.wxVkey=1
}
oVH.wxXCkey=1
cWH.wxXCkey=1
oXH.wxXCkey=1
_(r,hUH)
return r
}
e_[x[31]]={f:m31,j:[],i:[],ti:[],ic:[]}
d_[x[32]]={}
var m32=function(e,s,r,gg){
var z=gz$gwx_33()
var oHI=_v()
_(r,oHI)
if(_oz(z,0,e,s,gg)){oHI.wxVkey=1
}
oHI.wxXCkey=1
return r
}
e_[x[32]]={f:m32,j:[],i:[],ti:[],ic:[]}
d_[x[33]]={}
var m33=function(e,s,r,gg){
var z=gz$gwx_34()
var oJI=_n('view')
_rz(z,oJI,'class',0,e,s,gg)
var fKI=_v()
_(oJI,fKI)
if(_oz(z,1,e,s,gg)){fKI.wxVkey=1
}
var cLI=_v()
_(oJI,cLI)
if(_oz(z,2,e,s,gg)){cLI.wxVkey=1
}
fKI.wxXCkey=1
cLI.wxXCkey=1
_(r,oJI)
return r
}
e_[x[33]]={f:m33,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
return root;
}
}
}
	__wxAppCode__['packageLuckdraw/luckdraw/luckdraw.json'] = {"backgroundTextStyle":"dark","navigationBarTitleText":"九宝箱","enablePullDownRefresh":true,"usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['packageLuckdraw/luckdraw/luckdraw.wxml'] = [$gwx, './packageLuckdraw/luckdraw/luckdraw.wxml'];else __wxAppCode__['packageLuckdraw/luckdraw/luckdraw.wxml'] = $gwx( './packageLuckdraw/luckdraw/luckdraw.wxml' );
		__wxAppCode__['packageuser/user/aboutUs/aboutUs.json'] = {"backgroundTextStyle":"dark","navigationBarTitleText":"关于我们","usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['packageuser/user/aboutUs/aboutUs.wxml'] = [$gwx, './packageuser/user/aboutUs/aboutUs.wxml'];else __wxAppCode__['packageuser/user/aboutUs/aboutUs.wxml'] = $gwx( './packageuser/user/aboutUs/aboutUs.wxml' );
		__wxAppCode__['packageuser/user/aboutUs/agreement/agreement.json'] = {"backgroundTextStyle":"dark","navigationBarTitleText":"服务协议","usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['packageuser/user/aboutUs/agreement/agreement.wxml'] = [$gwx, './packageuser/user/aboutUs/agreement/agreement.wxml'];else __wxAppCode__['packageuser/user/aboutUs/agreement/agreement.wxml'] = $gwx( './packageuser/user/aboutUs/agreement/agreement.wxml' );
		__wxAppCode__['packageuser/user/getPhoneNum/getPhoneNum.json'] = {"backgroundTextStyle":"dark","navigationBarTitleText":"更改手机号","usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['packageuser/user/getPhoneNum/getPhoneNum.wxml'] = [$gwx, './packageuser/user/getPhoneNum/getPhoneNum.wxml'];else __wxAppCode__['packageuser/user/getPhoneNum/getPhoneNum.wxml'] = $gwx( './packageuser/user/getPhoneNum/getPhoneNum.wxml' );
		__wxAppCode__['packageuser/user/information/information.json'] = {"backgroundTextStyle":"dark","navigationBarTitleText":"个人信息","enablePullDownRefresh":true,"usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['packageuser/user/information/information.wxml'] = [$gwx, './packageuser/user/information/information.wxml'];else __wxAppCode__['packageuser/user/information/information.wxml'] = $gwx( './packageuser/user/information/information.wxml' );
		__wxAppCode__['packageuser/user/myCoupon/Instructions/Instructions.json'] = {"backgroundTextStyle":"dark","navigationBarTitleText":"使用说明","usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['packageuser/user/myCoupon/Instructions/Instructions.wxml'] = [$gwx, './packageuser/user/myCoupon/Instructions/Instructions.wxml'];else __wxAppCode__['packageuser/user/myCoupon/Instructions/Instructions.wxml'] = $gwx( './packageuser/user/myCoupon/Instructions/Instructions.wxml' );
		__wxAppCode__['packageuser/user/myCoupon/couponCell/couponCell.json'] = {"component":true,"usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['packageuser/user/myCoupon/couponCell/couponCell.wxml'] = [$gwx, './packageuser/user/myCoupon/couponCell/couponCell.wxml'];else __wxAppCode__['packageuser/user/myCoupon/couponCell/couponCell.wxml'] = $gwx( './packageuser/user/myCoupon/couponCell/couponCell.wxml' );
		__wxAppCode__['packageuser/user/myCoupon/myCoupon.json'] = {"usingComponents":{"couponCell":"./couponCell/couponCell"},"navigationBarTitleText":"我的卡券","enablePullDownRefresh":true,"backgroundTextStyle":"dark"};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['packageuser/user/myCoupon/myCoupon.wxml'] = [$gwx, './packageuser/user/myCoupon/myCoupon.wxml'];else __wxAppCode__['packageuser/user/myCoupon/myCoupon.wxml'] = $gwx( './packageuser/user/myCoupon/myCoupon.wxml' );
		__wxAppCode__['packageuser/user/mywallet/mywallet.json'] = {"backgroundTextStyle":"dark","navigationBarTitleText":"我的钱包","enablePullDownRefresh":true,"usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['packageuser/user/mywallet/mywallet.wxml'] = [$gwx, './packageuser/user/mywallet/mywallet.wxml'];else __wxAppCode__['packageuser/user/mywallet/mywallet.wxml'] = $gwx( './packageuser/user/mywallet/mywallet.wxml' );
		__wxAppCode__['packageuser/user/mywallet/refund/refund.json'] = {"navigationBarTitleText":"提现进度","usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['packageuser/user/mywallet/refund/refund.wxml'] = [$gwx, './packageuser/user/mywallet/refund/refund.wxml'];else __wxAppCode__['packageuser/user/mywallet/refund/refund.wxml'] = $gwx( './packageuser/user/mywallet/refund/refund.wxml' );
		__wxAppCode__['packageuser/user/mywallet/transaction/transaction.json'] = {"backgroundTextStyle":"dark","navigationBarTitleText":"交易明细","enablePullDownRefresh":true,"usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['packageuser/user/mywallet/transaction/transaction.wxml'] = [$gwx, './packageuser/user/mywallet/transaction/transaction.wxml'];else __wxAppCode__['packageuser/user/mywallet/transaction/transaction.wxml'] = $gwx( './packageuser/user/mywallet/transaction/transaction.wxml' );
		__wxAppCode__['packageuser/user/mywallet/withdraw/withdraw.json'] = {"backgroundTextStyle":"dark","navigationBarTitleText":"申请提现","usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['packageuser/user/mywallet/withdraw/withdraw.wxml'] = [$gwx, './packageuser/user/mywallet/withdraw/withdraw.wxml'];else __wxAppCode__['packageuser/user/mywallet/withdraw/withdraw.wxml'] = $gwx( './packageuser/user/mywallet/withdraw/withdraw.wxml' );
		__wxAppCode__['packageuser/user/setUp/setUp.json'] = {"backgroundTextStyle":"dark","navigationBarTitleText":"设置","usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['packageuser/user/setUp/setUp.wxml'] = [$gwx, './packageuser/user/setUp/setUp.wxml'];else __wxAppCode__['packageuser/user/setUp/setUp.wxml'] = $gwx( './packageuser/user/setUp/setUp.wxml' );
		__wxAppCode__['packageuser/user/user.json'] = {"backgroundTextStyle":"dark","navigationBarTitleText":"个人中心","enablePullDownRefresh":true,"usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['packageuser/user/user.wxml'] = [$gwx, './packageuser/user/user.wxml'];else __wxAppCode__['packageuser/user/user.wxml'] = $gwx( './packageuser/user/user.wxml' );
		__wxAppCode__['pages/advertising-h5/advertising-h5.json'] = {"usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/advertising-h5/advertising-h5.wxml'] = [$gwx, './pages/advertising-h5/advertising-h5.wxml'];else __wxAppCode__['pages/advertising-h5/advertising-h5.wxml'] = $gwx( './pages/advertising-h5/advertising-h5.wxml' );
		__wxAppCode__['pages/helpCenter/helpCenter.json'] = {"backgroundTextStyle":"dark","navigationBarTitleText":"使用帮助","usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/helpCenter/helpCenter.wxml'] = [$gwx, './pages/helpCenter/helpCenter.wxml'];else __wxAppCode__['pages/helpCenter/helpCenter.wxml'] = $gwx( './pages/helpCenter/helpCenter.wxml' );
		__wxAppCode__['pages/helpCenter/issueInfo.json'] = {"navigationBarTitleText":"问题详情","usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/helpCenter/issueInfo.wxml'] = [$gwx, './pages/helpCenter/issueInfo.wxml'];else __wxAppCode__['pages/helpCenter/issueInfo.wxml'] = $gwx( './pages/helpCenter/issueInfo.wxml' );
		__wxAppCode__['pages/index/authorization/authorization.json'] = {"backgroundTextStyle":"dark","navigationBarTitleText":"速绿充电","usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/index/authorization/authorization.wxml'] = [$gwx, './pages/index/authorization/authorization.wxml'];else __wxAppCode__['pages/index/authorization/authorization.wxml'] = $gwx( './pages/index/authorization/authorization.wxml' );
		__wxAppCode__['pages/index/index.json'] = {"backgroundTextStyle":"dark","navigationBarTitleText":"速绿充电","usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/index/index.wxml'] = [$gwx, './pages/index/index.wxml'];else __wxAppCode__['pages/index/index.wxml'] = $gwx( './pages/index/index.wxml' );
		__wxAppCode__['pages/index/member/member.json'] = {"backgroundTextStyle":"light","navigationBarTextStyle":"white","navigationBarTitleText":"会员中心","navigationBarBackgroundColor":"#292C33","backgroundColor":"#F8F9FA","usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/index/member/member.wxml'] = [$gwx, './pages/index/member/member.wxml'];else __wxAppCode__['pages/index/member/member.wxml'] = $gwx( './pages/index/member/member.wxml' );
		__wxAppCode__['pages/index/member/memberExchange/memberExchange.json'] = {"navigationBarTitleText":"会员兑换","backgroundColor":"#F5F5F5","disableScroll":true,"usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/index/member/memberExchange/memberExchange.wxml'] = [$gwx, './pages/index/member/memberExchange/memberExchange.wxml'];else __wxAppCode__['pages/index/member/memberExchange/memberExchange.wxml'] = $gwx( './pages/index/member/memberExchange/memberExchange.wxml' );
		__wxAppCode__['pages/index/member/runRenew/runRenew.json'] = {"backgroundTextStyle":"dark","navigationBarTitleText":"管理续费","usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/index/member/runRenew/runRenew.wxml'] = [$gwx, './pages/index/member/runRenew/runRenew.wxml'];else __wxAppCode__['pages/index/member/runRenew/runRenew.wxml'] = $gwx( './pages/index/member/runRenew/runRenew.wxml' );
		__wxAppCode__['pages/index/sweep/deviceAbnormal/deviceAbnormal.json'] = {"backgroundTextStyle":"dark","navigationBarTitleText":"设备网络异常","usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/index/sweep/deviceAbnormal/deviceAbnormal.wxml'] = [$gwx, './pages/index/sweep/deviceAbnormal/deviceAbnormal.wxml'];else __wxAppCode__['pages/index/sweep/deviceAbnormal/deviceAbnormal.wxml'] = $gwx( './pages/index/sweep/deviceAbnormal/deviceAbnormal.wxml' );
		__wxAppCode__['pages/index/sweep/entrustbox/entrustbox.json'] = {"backgroundTextStyle":"dark","navigationBarTitleText":"委托扣款授权书","usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/index/sweep/entrustbox/entrustbox.wxml'] = [$gwx, './pages/index/sweep/entrustbox/entrustbox.wxml'];else __wxAppCode__['pages/index/sweep/entrustbox/entrustbox.wxml'] = $gwx( './pages/index/sweep/entrustbox/entrustbox.wxml' );
		__wxAppCode__['pages/index/sweep/leaseSuccess/leaseSuccess.json'] = {"backgroundTextStyle":"dark","usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/index/sweep/leaseSuccess/leaseSuccess.wxml'] = [$gwx, './pages/index/sweep/leaseSuccess/leaseSuccess.wxml'];else __wxAppCode__['pages/index/sweep/leaseSuccess/leaseSuccess.wxml'] = $gwx( './pages/index/sweep/leaseSuccess/leaseSuccess.wxml' );
		__wxAppCode__['pages/index/sweep/protocol/protocol.json'] = {"backgroundTextStyle":"dark","navigationBarTitleText":"充值协议","enablePullDownRefresh":true,"usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/index/sweep/protocol/protocol.wxml'] = [$gwx, './pages/index/sweep/protocol/protocol.wxml'];else __wxAppCode__['pages/index/sweep/protocol/protocol.wxml'] = $gwx( './pages/index/sweep/protocol/protocol.wxml' );
		__wxAppCode__['pages/index/sweep/sweep.json'] = {"backgroundTextStyle":"dark","navigationBarBackgroundColor":"#E9FFF0","backgroundColor":"#E9FFF0","usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/index/sweep/sweep.wxml'] = [$gwx, './pages/index/sweep/sweep.wxml'];else __wxAppCode__['pages/index/sweep/sweep.wxml'] = $gwx( './pages/index/sweep/sweep.wxml' );
		__wxAppCode__['pages/index/sweepMade/sweepMade.json'] = {"backgroundTextStyle":"dark","usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/index/sweepMade/sweepMade.wxml'] = [$gwx, './pages/index/sweepMade/sweepMade.wxml'];else __wxAppCode__['pages/index/sweepMade/sweepMade.wxml'] = $gwx( './pages/index/sweepMade/sweepMade.wxml' );
		__wxAppCode__['pages/ordering/feedback/feedback.json'] = {"backgroundTextStyle":"dark","navigationBarTitleText":"订单反馈","usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/ordering/feedback/feedback.wxml'] = [$gwx, './pages/ordering/feedback/feedback.wxml'];else __wxAppCode__['pages/ordering/feedback/feedback.wxml'] = $gwx( './pages/ordering/feedback/feedback.wxml' );
		__wxAppCode__['pages/ordering/lost-powerback/lost-powerback.json'] = {"backgroundTextStyle":"dark","navigationBarTitleText":"丢失处理","usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/ordering/lost-powerback/lost-powerback.wxml'] = [$gwx, './pages/ordering/lost-powerback/lost-powerback.wxml'];else __wxAppCode__['pages/ordering/lost-powerback/lost-powerback.wxml'] = $gwx( './pages/ordering/lost-powerback/lost-powerback.wxml' );
		__wxAppCode__['pages/ordering/ordering.json'] = {"backgroundTextStyle":"dark","navigationBarTitleText":"我的订单","enablePullDownRefresh":true,"usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/ordering/ordering.wxml'] = [$gwx, './pages/ordering/ordering.wxml'];else __wxAppCode__['pages/ordering/ordering.wxml'] = $gwx( './pages/ordering/ordering.wxml' );
		__wxAppCode__['pages/ordering/orderingend/orderingend.json'] = {"backgroundTextStyle":"dark","navigationBarTitleText":"订单详情","enablePullDownRefresh":true,"usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/ordering/orderingend/orderingend.wxml'] = [$gwx, './pages/ordering/orderingend/orderingend.wxml'];else __wxAppCode__['pages/ordering/orderingend/orderingend.wxml'] = $gwx( './pages/ordering/orderingend/orderingend.wxml' );
		__wxAppCode__['pages/ordering/returnsuccess/returnsuccess.json'] = {"backgroundTextStyle":"dark","navigationBarTitleText":"归还成功","usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/ordering/returnsuccess/returnsuccess.wxml'] = [$gwx, './pages/ordering/returnsuccess/returnsuccess.wxml'];else __wxAppCode__['pages/ordering/returnsuccess/returnsuccess.wxml'] = $gwx( './pages/ordering/returnsuccess/returnsuccess.wxml' );
		__wxAppCode__['pages/ordering/testing/testing.json'] = {"backgroundTextStyle":"dark","navigationBarTitleText":"系统检测","usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/ordering/testing/testing.wxml'] = [$gwx, './pages/ordering/testing/testing.wxml'];else __wxAppCode__['pages/ordering/testing/testing.wxml'] = $gwx( './pages/ordering/testing/testing.wxml' );
	
	define("config.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e,r,i,o,t,p,d,n,a,s,c={settingType:1,host:e="https://wx.vsulv.com",newsID:a={borrowID:"ABh2SHMrsVwB9cFVTQM7ipvvE7Xo7CS5PFwQcESz4ZA",returnID:"_Xfe3nL5Re4zLgLdYyItRC1AQq4BgqwRkDOatrwaSzY",activityID:"nGdXX2E_xkFWrhQUVLI-UFbwTqbfTKpRFlXddfVoW9k",withdrawID:"SH8Ct3_3kXR1CnRAy5ImHeCLL4OoPMFux_MsOuVFwzA",memberOpeningID:"u2NmQkzKqrHnD2RtorReylnK0ftxuV1E9UvLqSL3sJY",memberExpireID:"_M7UJyuEpW-E7IfY7L9mKWG9EUnL8A2ZT-Bspx_DWAc"},advImgAdd:o="http://adv-img.vsulv.com/",loginUrl:e+"/provider/user/login",borrowUrl:e+"/provider/borrow/getMachineInfo",paymentUrl:e+"/provider/wxpay/payment",wxCreditPay:e+"/provider/wxpay/wxxcxCreditPay",paycreditUrl:e+"/provider/initiative/completeOrder",wxCreditNotify:e+"/provider/wxpay/wxxcxCreditNotify",nearbyShopsUrl:e+"/provider/shop/getNewShopList",getShopListPagingUrl:e+"/provider/shop/getShopListPaging",shopInfoUrl:e+"/provider/shop/getNewShopInfo",rentedRecordsUrl:e+"/provider/order/getOrderList",productDetail:e+"/provider/memberInfo/productDetail",createMemberOrder:e+"/provider/memberInfo/createMemberOrder",applySign:e+"/provider/wxpay/applySign",pappayapply:e+"/provider/wxpay/pappayapply",applyRecission:e+"/provider/wxpay/withhold/apply-recission",memberStatus:e+"/provider/memberInfo/memberStatus",userInfoUrl:e+"/provider/user/userInfo",memberPaidOrder:e+"/provider/memberInfo/memberPaidOrder",memberExchange:e+"/provider/memberInfo/exchange",refundUrl:e+"/provider/refund/doRefund",withdrawRecodsUrl:e+"/provider/refund/getRefundList",reportLossUrl:e+"/index.php?mod=api&act=weapp&opt=orders",getOrderInfo:e+"/provider/order/getOrderInfo",stateUrl:e+"/provider/order/getOrderStatus",progressBarOverPageSkip:e+"/provider/order/progressBarOverPageSkip",fileImgUrl:e+"/provider/upload/uploadFeedbackdImg",ProblemUrl:e+"/provider/problem/orderProblem",loseDisposeUrl:e+"/provider/order/orderLoseDispose",loginPhoneNumber:e+"/provider/bindMobile/decryptPhoneNumber",IsPhoneNum:e+"/provider/bindMobile/checkBindMobile",verification:e+"/provider/bindMobile/sendSMS",bindingPhoneNum:e+"/provider/bindMobile/bindMobile",untiePhoneNum:e+"/provider/bindMobile/unbindMobile",checkMobileIsBinded:e+"/provider/bindMobile/checkMobileIsBinded",confirmReturn:e+"/provider/borrow/confirmReturn",returnBackBut:e+"/provider/borrow/returnBack",getPrizeList:e+"/provider/prize/getPrizeList",getUsablePrizeNum:e+"/provider/prize/getUsablePrizeNum",prizePayMent:e+"/provider/wxpay/prizePayMent",getUserPrizes:e+"/provider/prize/getUserPrizes",getTickets:e+"/provider/ticket/getTicketsNew",exchangeTicket:e+"/provider/ticket/exchangeTicket",doLottery:e+"/provider/prize/doLottery",getUserPaidLogs:e+"/provider/user/getUserPaidLogs",getUseFeeOrderList:e+"/provider/order/getUseFeeOrderList",aiqiyipriceList:e+"/provider/activitiesPrice/priceList",newMembershipPrice:e+"/provider/activitiesPrice/newMembershipPrice",aiqiyiPayment:e+"/provider/wxpay/aiqiyiPayment",newAiqiyiPayment:e+"/provider/wxpay/newAiqiyiPayment",getPrizeAwards:e+"/provider/prize/getPrizeAwards",savePrizeLog:e+"/provider/prize/savePrizeLog",checkChangeAdv:(i="https://adcache.vsulv.com")+"/api/cache/checkChange",getAdvertiseInfo:i+"/api/cache/getAdvertiseInfo",vipcheckDateTime:e+"/provider/shopVip/checkDateTime",vipIscheckVip:e+"/provider/shopVip/checkVip",vipforminsertVip:e+"/provider/shopVip/insertVip",getBluetoothMachineInfo:e+"/provider/borrow/getBluetoothMachineInfo",bluetoothPayment:e+"/provider/wxpay/bluetoothPayment",bluetoothOrderRefund:e+"/provider/order/bluetoothOrderRefund",returnConfirm:e+"/provider/borrow/returnConfirm",noticeinsert:(r="https://wm.vsulv.com")+"/wprovider/errorNotify/insert",getRepair:r+"/wprovider/stationRepair/stationRepair",seversLogs:e+"/provider/order/zffBorrowOrderLogs",returnOrderMd5:e+"/provider/borrow/returnOrderMd5",overtimeConfirm:e+"/wxpay.php?submit=rent_overtime_confirm",lotteryPre:e+"/provider/lotteryPre",lotteryAfter:e+"/provider/lotteryAfter",helpH5:e+"/customapi/encrypt",buryingView:t="https://online-data-buriedlog.cn-shanghai.log.aliyuncs.com/logstores/client_js_pagepath"+(s="")+"/track",buryingClick:p="https://online-data-buriedlog.cn-shanghai.log.aliyuncs.com/logstores/client_js_clickevent"+s+"/track",advBuryingView:d="https://online-data-dsp-logs.cn-shanghai.log.aliyuncs.com/logstores/ad_mini_pagepath"+s+"/track",advBuryingClick:n="https://online-data-dsp-logs.cn-shanghai.log.aliyuncs.com/logstores/ad_mini_clickevent"+s+"/track"};module.exports=c; 
 			}); 
		define("utils/WSCoordinate.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function t(t,a){return a<72.004||a>137.8347||t<.8293||t>55.8271}function a(a,n){var e=.006693421622965943,r=6378245,o=3.141592653589793;if(t(a,n))a,n;else{var s=i(n-105,a-35),h=u(n-105,a-35),M=a/180*o,d=Math.sin(M);d=1-e*d*d;var l=Math.sqrt(d);a+=s=180*s/(r*(1-e)/(d*l)*o),n+=h=180*h/(r/l*Math.cos(M)*o)}return{latitude:a,longitude:n}}function n(t,a,n){return t.latitude>=Math.min(a.latitude,n.latitude)&&t.latitude<=Math.max(a.latitude,n.latitude)&&t.longitude>=Math.min(a.longitude,n.longitude)&&t.longitude<=Math.max(a.longitude,n.longitude)}function i(t,a){var n=3.141592653589793,i=2*t-100+3*a+.2*a*a+.1*t*a+.2*Math.sqrt(Math.abs(t));return i+=2*(20*Math.sin(6*t*n)+20*Math.sin(2*t*n))/3,i+=2*(20*Math.sin(a*n)+40*Math.sin(a/3*n))/3,i+=2*(160*Math.sin(a/12*n)+320*Math.sin(a*n/30))/3}function u(t,a){var n=3.141592653589793,i=300+t+2*a+.1*t*t+.1*t*a+.1*Math.sqrt(Math.abs(t));return i+=2*(20*Math.sin(6*t*n)+20*Math.sin(2*t*n))/3,i+=2*(20*Math.sin(t*n)+40*Math.sin(t/3*n))/3,i+=2*(150*Math.sin(t/12*n)+300*Math.sin(t/30*n))/3}module.exports={isLocationOutOfChina:t,transformFromWGSToGCJ:a,transformFromGCJToBaidu:function(t,a){var n=3.141592653589793,i=Math.sqrt(a*a+t*t)+2e-5*Math.sqrt(t*n),u=Math.atan2(t,a)+3e-6*Math.cos(a*n);return{latitude:i*Math.sin(u)+.006,longitude:i*Math.cos(u)+.0065}},transformFromBaiduToGCJ:function(t,a){var n=52.35987755982988,i=a-.0065,u=t-.006,e=Math.sqrt(i*i+u*u)-2e-5*Math.sin(u*n),r=Math.atan2(u,i)-3e-6*Math.cos(i*n);return{latitude:e*Math.sin(r),longitude:e*Math.cos(r)}},transformFromGCJToWGS:function(t,i){for(var u=t-.5,e=t+.5,r=i-.5,o=i+.5,s=1,h=30;;){var M=a(u,r),d=a(u,o),l=a(e,r),f=a((u+e)/2,(r+o)/2);if(s=Math.abs(f.latitude-t)+Math.abs(f.longitude-i),h--<=0||s<=1e-5)return{latitude:(u+e)/2,longitude:(r+o)/2};n({latitude:t,longitude:i},M,f)?(e=(u+e)/2,o=(r+o)/2):n({latitude:t,longitude:i},d,f)?(e=(u+e)/2,r=(r+o)/2):n({latitude:t,longitude:i},l,f)?(u=(u+e)/2,o=(r+o)/2):(u=(u+e)/2,r=(r+o)/2)}}}; 
 			}); 
		define("utils/hmac.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=t||function(t,e){var r={},n=r.lib={},i=n.Base=function(){function t(){}return{extend:function(e){t.prototype=this;var r=new t;return e&&r.mixIn(e),r.$super=this,r},create:function(){var t=this.extend();return t.init.apply(t,arguments),t},init:function(){},mixIn:function(t){for(var e in t)t.hasOwnProperty(e)&&(this[e]=t[e]);t.hasOwnProperty("toString")&&(this.toString=t.toString)},clone:function(){return this.$super.extend(this)}}}(),s=n.WordArray=i.extend({init:function(t,e){t=this.words=t||[],this.sigBytes=void 0!=e?e:4*t.length},toString:function(t){return(t||a).stringify(this)},concat:function(t){var e=this.words,r=t.words,n=this.sigBytes,t=t.sigBytes;if(this.clamp(),n%4)for(var i=0;i<t;i++)e[n+i>>>2]|=(r[i>>>2]>>>24-i%4*8&255)<<24-(n+i)%4*8;else if(65535<r.length)for(i=0;i<t;i+=4)e[n+i>>>2]=r[i>>>2];else e.push.apply(e,r);return this.sigBytes+=t,this},clamp:function(){var e=this.words,r=this.sigBytes;e[r>>>2]&=4294967295<<32-r%4*8,e.length=t.ceil(r/4)},clone:function(){var t=i.clone.call(this);return t.words=this.words.slice(0),t},random:function(e){for(var r=[],n=0;n<e;n+=4)r.push(4294967296*t.random()|0);return s.create(r,e)}}),o=r.enc={},a=o.Hex={stringify:function(t){for(var e=t.words,t=t.sigBytes,r=[],n=0;n<t;n++){var i=e[n>>>2]>>>24-n%4*8&255;r.push((i>>>4).toString(16)),r.push((15&i).toString(16))}return r.join("")},parse:function(t){for(var e=t.length,r=[],n=0;n<e;n+=2)r[n>>>3]|=parseInt(t.substr(n,2),16)<<24-n%8*4;return s.create(r,e/2)}},c=o.Latin1={stringify:function(t){for(var e=t.words,t=t.sigBytes,r=[],n=0;n<t;n++)r.push(String.fromCharCode(e[n>>>2]>>>24-n%4*8&255));return r.join("")},parse:function(t){for(var e=t.length,r=[],n=0;n<e;n++)r[n>>>2]|=(255&t.charCodeAt(n))<<24-n%4*8;return s.create(r,e)}},h=o.Utf8={stringify:function(t){try{return decodeURIComponent(escape(c.stringify(t)))}catch(t){throw Error("Malformed UTF-8 data")}},parse:function(t){return c.parse(unescape(encodeURIComponent(t)))}},u=n.BufferedBlockAlgorithm=i.extend({reset:function(){this._data=s.create(),this._nDataBytes=0},_append:function(t){"string"==typeof t&&(t=h.parse(t)),this._data.concat(t),this._nDataBytes+=t.sigBytes},_process:function(e){var r=this._data,n=r.words,i=r.sigBytes,o=this.blockSize,a=i/(4*o),e=(a=e?t.ceil(a):t.max((0|a)-this._minBufferSize,0))*o,i=t.min(4*e,i);if(e){for(var c=0;c<e;c+=o)this._doProcessBlock(n,c);c=n.splice(0,e),r.sigBytes-=i}return s.create(c,i)},clone:function(){var t=i.clone.call(this);return t._data=this._data.clone(),t},_minBufferSize:0});n.Hasher=u.extend({init:function(){this.reset()},reset:function(){u.reset.call(this),this._doReset()},update:function(t){return this._append(t),this._process(),this},finalize:function(t){return t&&this._append(t),this._doFinalize(),this._hash},clone:function(){var t=u.clone.call(this);return t._hash=this._hash.clone(),t},blockSize:16,_createHelper:function(t){return function(e,r){return t.create(r).finalize(e)}},_createHmacHelper:function(t){return function(e,r){return f.HMAC.create(t,r).finalize(e)}}});var f=r.algo={};return r}(Math);!function(e){var r=t,n=(i=r.lib).WordArray,i=i.Hasher,s=r.algo,o=[],a=[];!function(){function t(t){return 4294967296*(t-(0|t))|0}for(var r=2,n=0;64>n;)(function(t){for(var r=e.sqrt(t),n=2;n<=r;n++)if(!(t%n))return!1;return!0})(r)&&(8>n&&(o[n]=t(e.pow(r,.5))),a[n]=t(e.pow(r,1/3)),n++),r++}();var c=[],s=s.SHA256=i.extend({_doReset:function(){this._hash=n.create(o.slice(0))},_doProcessBlock:function(t,e){for(var r=this._hash.words,n=r[0],i=r[1],s=r[2],o=r[3],h=r[4],u=r[5],f=r[6],l=r[7],d=0;64>d;d++){if(16>d)c[d]=0|t[e+d];else{var p=c[d-15],_=c[d-2];c[d]=((p<<25|p>>>7)^(p<<14|p>>>18)^p>>>3)+c[d-7]+((_<<15|_>>>17)^(_<<13|_>>>19)^_>>>10)+c[d-16]}p=l+((h<<26|h>>>6)^(h<<21|h>>>11)^(h<<7|h>>>25))+(h&u^~h&f)+a[d]+c[d],_=((n<<30|n>>>2)^(n<<19|n>>>13)^(n<<10|n>>>22))+(n&i^n&s^i&s),l=f,f=u,u=h,h=o+p|0,o=s,s=i,i=n,n=p+_|0}r[0]=r[0]+n|0,r[1]=r[1]+i|0,r[2]=r[2]+s|0,r[3]=r[3]+o|0,r[4]=r[4]+h|0,r[5]=r[5]+u|0,r[6]=r[6]+f|0,r[7]=r[7]+l|0},_doFinalize:function(){var t=this._data,e=t.words,r=8*this._nDataBytes,n=8*t.sigBytes;e[n>>>5]|=128<<24-n%32,e[15+(n+64>>>9<<4)]=r,t.sigBytes=4*e.length,this._process()}});r.SHA256=i._createHelper(s),r.HmacSHA256=i._createHmacHelper(s)}(Math),function(){var e=t,r=e.enc.Utf8;e.algo.HMAC=e.lib.Base.extend({init:function(t,e){t=this._hasher=t.create(),"string"==typeof e&&(e=r.parse(e));var n=t.blockSize,i=4*n;e.sigBytes>i&&(e=t.finalize(e));for(var s=this._oKey=e.clone(),o=this._iKey=e.clone(),a=s.words,c=o.words,h=0;h<n;h++)a[h]^=1549556828,c[h]^=909522486;s.sigBytes=o.sigBytes=i,this.reset()},reset:function(){var t=this._hasher;t.reset(),t.update(this._iKey)},update:function(t){return this._hasher.update(t),this},finalize:function(t){var e=this._hasher,t=e.finalize(t);return e.reset(),e.finalize(this._oKey.clone().concat(t))}})}(),module.exports=t; 
 			}); 
		define("utils/md5.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function n(n,r){var t=(65535&n)+(65535&r);return(n>>16)+(r>>16)+(t>>16)<<16|65535&t}function r(n,r){return n<<r|n>>>32-r}function t(t,e,u,o,c,f){return n(r(n(n(e,t),n(o,f)),c),u)}function e(n,r,e,u,o,c,f){return t(r&e|~r&u,n,r,o,c,f)}function u(n,r,e,u,o,c,f){return t(r&u|e&~u,n,r,o,c,f)}function o(n,r,e,u,o,c,f){return t(r^e^u,n,r,o,c,f)}function c(n,r,e,u,o,c,f){return t(e^(r|~u),n,r,o,c,f)}function f(r){for(var t=1732584193,f=-271733879,i=-1732584194,a=271733878,h=0;h<r.length;h+=16){var l=t,g=f,v=i,d=a;f=c(f=c(f=c(f=c(f=o(f=o(f=o(f=o(f=u(f=u(f=u(f=u(f=e(f=e(f=e(f=e(f,i=e(i,a=e(a,t=e(t,f,i,a,r[h+0],7,-680876936),f,i,r[h+1],12,-389564586),t,f,r[h+2],17,606105819),a,t,r[h+3],22,-1044525330),i=e(i,a=e(a,t=e(t,f,i,a,r[h+4],7,-176418897),f,i,r[h+5],12,1200080426),t,f,r[h+6],17,-1473231341),a,t,r[h+7],22,-45705983),i=e(i,a=e(a,t=e(t,f,i,a,r[h+8],7,1770035416),f,i,r[h+9],12,-1958414417),t,f,r[h+10],17,-42063),a,t,r[h+11],22,-1990404162),i=e(i,a=e(a,t=e(t,f,i,a,r[h+12],7,1804603682),f,i,r[h+13],12,-40341101),t,f,r[h+14],17,-1502002290),a,t,r[h+15],22,1236535329),i=u(i,a=u(a,t=u(t,f,i,a,r[h+1],5,-165796510),f,i,r[h+6],9,-1069501632),t,f,r[h+11],14,643717713),a,t,r[h+0],20,-373897302),i=u(i,a=u(a,t=u(t,f,i,a,r[h+5],5,-701558691),f,i,r[h+10],9,38016083),t,f,r[h+15],14,-660478335),a,t,r[h+4],20,-405537848),i=u(i,a=u(a,t=u(t,f,i,a,r[h+9],5,568446438),f,i,r[h+14],9,-1019803690),t,f,r[h+3],14,-187363961),a,t,r[h+8],20,1163531501),i=u(i,a=u(a,t=u(t,f,i,a,r[h+13],5,-1444681467),f,i,r[h+2],9,-51403784),t,f,r[h+7],14,1735328473),a,t,r[h+12],20,-1926607734),i=o(i,a=o(a,t=o(t,f,i,a,r[h+5],4,-378558),f,i,r[h+8],11,-2022574463),t,f,r[h+11],16,1839030562),a,t,r[h+14],23,-35309556),i=o(i,a=o(a,t=o(t,f,i,a,r[h+1],4,-1530992060),f,i,r[h+4],11,1272893353),t,f,r[h+7],16,-155497632),a,t,r[h+10],23,-1094730640),i=o(i,a=o(a,t=o(t,f,i,a,r[h+13],4,681279174),f,i,r[h+0],11,-358537222),t,f,r[h+3],16,-722521979),a,t,r[h+6],23,76029189),i=o(i,a=o(a,t=o(t,f,i,a,r[h+9],4,-640364487),f,i,r[h+12],11,-421815835),t,f,r[h+15],16,530742520),a,t,r[h+2],23,-995338651),i=c(i,a=c(a,t=c(t,f,i,a,r[h+0],6,-198630844),f,i,r[h+7],10,1126891415),t,f,r[h+14],15,-1416354905),a,t,r[h+5],21,-57434055),i=c(i,a=c(a,t=c(t,f,i,a,r[h+12],6,1700485571),f,i,r[h+3],10,-1894986606),t,f,r[h+10],15,-1051523),a,t,r[h+1],21,-2054922799),i=c(i,a=c(a,t=c(t,f,i,a,r[h+8],6,1873313359),f,i,r[h+15],10,-30611744),t,f,r[h+6],15,-1560198380),a,t,r[h+13],21,1309151649),i=c(i,a=c(a,t=c(t,f,i,a,r[h+4],6,-145523070),f,i,r[h+11],10,-1120210379),t,f,r[h+2],15,718787259),a,t,r[h+9],21,-343485551),t=n(t,l),f=n(f,g),i=n(i,v),a=n(a,d)}return[t,f,i,a]}function i(n){for(var r="",t=0;t<4*n.length;t++)r+="0123456789abcdef".charAt(n[t>>2]>>t%4*8+4&15)+"0123456789abcdef".charAt(n[t>>2]>>t%4*8&15);return r}function a(n){for(var r=1+(n.length+8>>6),t=new Array(16*r),e=0;e<16*r;e++)t[e]=0;for(e=0;e<n.length;e++)t[e>>2]|=(255&n.charCodeAt(e))<<e%4*8;return t[e>>2]|=128<<e%4*8,t[16*r-2]=8*n.length,t}module.exports={hexMD5:function(n){return i(f(a(n)))}}; 
 			}); 
		define("utils/qrcode.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t;!function(){function e(t){this.mode=l.MODE_8BIT_BYTE,this.data=t,this.parsedData=[];for(var e=0,r=this.data.length;e<r;e++){var o=[],i=this.data.charCodeAt(e);i>65536?(o[0]=240|(1835008&i)>>>18,o[1]=128|(258048&i)>>>12,o[2]=128|(4032&i)>>>6,o[3]=128|63&i):i>2048?(o[0]=224|(61440&i)>>>12,o[1]=128|(4032&i)>>>6,o[2]=128|63&i):i>128?(o[0]=192|(1984&i)>>>6,o[1]=128|63&i):o[0]=i,this.parsedData.push(o)}this.parsedData=Array.prototype.concat.apply([],this.parsedData),this.parsedData.length!=this.data.length&&(this.parsedData.unshift(191),this.parsedData.unshift(187),this.parsedData.unshift(239))}function r(t,e){this.typeNumber=t,this.errorCorrectLevel=e,this.modules=null,this.moduleCount=0,this.dataCache=null,this.dataList=[]}function o(t,e){if(void 0==t.length)throw new Error(t.length+"/"+e);for(var r=0;r<t.length&&0==t[r];)r++;this.num=new Array(t.length-r+e);for(var o=0;o<t.length-r;o++)this.num[o]=t[o+r]}function i(t,e){this.totalCount=t,this.dataCount=e}function n(){this.buffer=[],this.length=0}function a(){var t=!1,e=navigator.userAgent;if(/android/i.test(e)){t=!0;var r=e.toString().match(/android ([0-9]\.[0-9])/i);r&&r[1]&&(t=parseFloat(r[1]))}return t}function s(t,e){for(var r=1,o=h(t),i=0,n=p.length;i<=n;i++){var a=0;switch(e){case u.L:a=p[i][0];break;case u.M:a=p[i][1];break;case u.Q:a=p[i][2];break;case u.H:a=p[i][3]}if(o<=a)break;r++}if(r>p.length)throw new Error("Too long data");return r}function h(t){var e=encodeURI(t).toString().replace(/\%[0-9a-fA-F]{2}/g,"a");return e.length+(e.length!=t?3:0)}e.prototype={getLength:function(t){return this.parsedData.length},write:function(t){for(var e=0,r=this.parsedData.length;e<r;e++)t.put(this.parsedData[e],8)}},r.prototype={addData:function(t){var r=new e(t);this.dataList.push(r),this.dataCache=null},isDark:function(t,e){if(t<0||this.moduleCount<=t||e<0||this.moduleCount<=e)throw new Error(t+","+e);return this.modules[t][e]},getModuleCount:function(){return this.moduleCount},make:function(){this.makeImpl(!1,this.getBestMaskPattern())},makeImpl:function(t,e){this.moduleCount=4*this.typeNumber+17,this.modules=new Array(this.moduleCount);for(var o=0;o<this.moduleCount;o++){this.modules[o]=new Array(this.moduleCount);for(var i=0;i<this.moduleCount;i++)this.modules[o][i]=null}this.setupPositionProbePattern(0,0),this.setupPositionProbePattern(this.moduleCount-7,0),this.setupPositionProbePattern(0,this.moduleCount-7),this.setupPositionAdjustPattern(),this.setupTimingPattern(),this.setupTypeInfo(t,e),this.typeNumber>=7&&this.setupTypeNumber(t),null==this.dataCache&&(this.dataCache=r.createData(this.typeNumber,this.errorCorrectLevel,this.dataList)),this.mapData(this.dataCache,e)},setupPositionProbePattern:function(t,e){for(var r=-1;r<=7;r++)if(!(t+r<=-1||this.moduleCount<=t+r))for(var o=-1;o<=7;o++)e+o<=-1||this.moduleCount<=e+o||(this.modules[t+r][e+o]=0<=r&&r<=6&&(0==o||6==o)||0<=o&&o<=6&&(0==r||6==r)||2<=r&&r<=4&&2<=o&&o<=4)},getBestMaskPattern:function(){for(var t=0,e=0,r=0;r<8;r++){this.makeImpl(!0,r);var o=g.getLostPoint(this);(0==r||t>o)&&(t=o,e=r)}return e},createMovieClip:function(t,e,r){var o=t.createEmptyMovieClip(e,r);this.make();for(var i=0;i<this.modules.length;i++)for(var n=1*i,a=0;a<this.modules[i].length;a++){var s=1*a;this.modules[i][a]&&(o.beginFill(0,100),o.moveTo(s,n),o.lineTo(s+1,n),o.lineTo(s+1,n+1),o.lineTo(s,n+1),o.endFill())}return o},setupTimingPattern:function(){for(var t=8;t<this.moduleCount-8;t++)null==this.modules[t][6]&&(this.modules[t][6]=t%2==0);for(var e=8;e<this.moduleCount-8;e++)null==this.modules[6][e]&&(this.modules[6][e]=e%2==0)},setupPositionAdjustPattern:function(){for(var t=g.getPatternPosition(this.typeNumber),e=0;e<t.length;e++)for(var r=0;r<t.length;r++){var o=t[e],i=t[r];if(null==this.modules[o][i])for(var n=-2;n<=2;n++)for(var a=-2;a<=2;a++)this.modules[o+n][i+a]=-2==n||2==n||-2==a||2==a||0==n&&0==a}},setupTypeNumber:function(t){for(var e=g.getBCHTypeNumber(this.typeNumber),r=0;r<18;r++){o=!t&&1==(e>>r&1);this.modules[Math.floor(r/3)][r%3+this.moduleCount-8-3]=o}for(r=0;r<18;r++){var o=!t&&1==(e>>r&1);this.modules[r%3+this.moduleCount-8-3][Math.floor(r/3)]=o}},setupTypeInfo:function(t,e){for(var r=this.errorCorrectLevel<<3|e,o=g.getBCHTypeInfo(r),i=0;i<15;i++){n=!t&&1==(o>>i&1);i<6?this.modules[i][8]=n:i<8?this.modules[i+1][8]=n:this.modules[this.moduleCount-15+i][8]=n}for(i=0;i<15;i++){var n=!t&&1==(o>>i&1);i<8?this.modules[8][this.moduleCount-i-1]=n:i<9?this.modules[8][15-i-1+1]=n:this.modules[8][15-i-1]=n}this.modules[this.moduleCount-8][8]=!t},mapData:function(t,e){for(var r=-1,o=this.moduleCount-1,i=7,n=0,a=this.moduleCount-1;a>0;a-=2)for(6==a&&a--;;){for(var s=0;s<2;s++)if(null==this.modules[o][a-s]){var h=!1;n<t.length&&(h=1==(t[n]>>>i&1)),g.getMask(e,o,a-s)&&(h=!h),this.modules[o][a-s]=h,-1==--i&&(n++,i=7)}if((o+=r)<0||this.moduleCount<=o){o-=r,r=-r;break}}}},r.PAD0=236,r.PAD1=17,r.createData=function(t,e,o){for(var a=i.getRSBlocks(t,e),s=new n,h=0;h<o.length;h++){var l=o[h];s.put(l.mode,4),s.put(l.getLength(),g.getLengthInBits(l.mode,t)),l.write(s)}for(var u=0,h=0;h<a.length;h++)u+=a[h].dataCount;if(s.getLengthInBits()>8*u)throw new Error("code length overflow. ("+s.getLengthInBits()+">"+8*u+")");for(s.getLengthInBits()+4<=8*u&&s.put(0,4);s.getLengthInBits()%8!=0;)s.putBit(!1);for(;;){if(s.getLengthInBits()>=8*u)break;if(s.put(r.PAD0,8),s.getLengthInBits()>=8*u)break;s.put(r.PAD1,8)}return r.createBytes(s,a)},r.createBytes=function(t,e){for(var r=0,i=0,n=0,a=new Array(e.length),s=new Array(e.length),h=0;h<e.length;h++){var l=e[h].dataCount,u=e[h].totalCount-l;i=Math.max(i,l),n=Math.max(n,u),a[h]=new Array(l);for(m=0;m<a[h].length;m++)a[h][m]=255&t.buffer[m+r];r+=l;var f=g.getErrorCorrectPolynomial(u),d=new o(a[h],f.getLength()-1).mod(f);s[h]=new Array(f.getLength()-1);for(m=0;m<s[h].length;m++){var c=m+d.getLength()-s[h].length;s[h][m]=c>=0?d.get(c):0}}for(var p=0,m=0;m<e.length;m++)p+=e[m].totalCount;for(var _=new Array(p),v=0,m=0;m<i;m++)for(h=0;h<e.length;h++)m<a[h].length&&(_[v++]=a[h][m]);for(m=0;m<n;m++)for(h=0;h<e.length;h++)m<s[h].length&&(_[v++]=s[h][m]);return _};for(var l={MODE_NUMBER:1,MODE_ALPHA_NUM:2,MODE_8BIT_BYTE:4,MODE_KANJI:8},u={L:1,M:0,Q:3,H:2},f={PATTERN000:0,PATTERN001:1,PATTERN010:2,PATTERN011:3,PATTERN100:4,PATTERN101:5,PATTERN110:6,PATTERN111:7},g={PATTERN_POSITION_TABLE:[[],[6,18],[6,22],[6,26],[6,30],[6,34],[6,22,38],[6,24,42],[6,26,46],[6,28,50],[6,30,54],[6,32,58],[6,34,62],[6,26,46,66],[6,26,48,70],[6,26,50,74],[6,30,54,78],[6,30,56,82],[6,30,58,86],[6,34,62,90],[6,28,50,72,94],[6,26,50,74,98],[6,30,54,78,102],[6,28,54,80,106],[6,32,58,84,110],[6,30,58,86,114],[6,34,62,90,118],[6,26,50,74,98,122],[6,30,54,78,102,126],[6,26,52,78,104,130],[6,30,56,82,108,134],[6,34,60,86,112,138],[6,30,58,86,114,142],[6,34,62,90,118,146],[6,30,54,78,102,126,150],[6,24,50,76,102,128,154],[6,28,54,80,106,132,158],[6,32,58,84,110,136,162],[6,26,54,82,110,138,166],[6,30,58,86,114,142,170]],G15:1335,G18:7973,G15_MASK:21522,getBCHTypeInfo:function(t){for(var e=t<<10;g.getBCHDigit(e)-g.getBCHDigit(g.G15)>=0;)e^=g.G15<<g.getBCHDigit(e)-g.getBCHDigit(g.G15);return(t<<10|e)^g.G15_MASK},getBCHTypeNumber:function(t){for(var e=t<<12;g.getBCHDigit(e)-g.getBCHDigit(g.G18)>=0;)e^=g.G18<<g.getBCHDigit(e)-g.getBCHDigit(g.G18);return t<<12|e},getBCHDigit:function(t){for(var e=0;0!=t;)e++,t>>>=1;return e},getPatternPosition:function(t){return g.PATTERN_POSITION_TABLE[t-1]},getMask:function(t,e,r){switch(t){case f.PATTERN000:return(e+r)%2==0;case f.PATTERN001:return e%2==0;case f.PATTERN010:return r%3==0;case f.PATTERN011:return(e+r)%3==0;case f.PATTERN100:return(Math.floor(e/2)+Math.floor(r/3))%2==0;case f.PATTERN101:return e*r%2+e*r%3==0;case f.PATTERN110:return(e*r%2+e*r%3)%2==0;case f.PATTERN111:return(e*r%3+(e+r)%2)%2==0;default:throw new Error("bad maskPattern:"+t)}},getErrorCorrectPolynomial:function(t){for(var e=new o([1],0),r=0;r<t;r++)e=e.multiply(new o([1,d.gexp(r)],0));return e},getLengthInBits:function(t,e){if(1<=e&&e<10)switch(t){case l.MODE_NUMBER:return 10;case l.MODE_ALPHA_NUM:return 9;case l.MODE_8BIT_BYTE:case l.MODE_KANJI:return 8;default:throw new Error("mode:"+t)}else if(e<27)switch(t){case l.MODE_NUMBER:return 12;case l.MODE_ALPHA_NUM:return 11;case l.MODE_8BIT_BYTE:return 16;case l.MODE_KANJI:return 10;default:throw new Error("mode:"+t)}else{if(!(e<41))throw new Error("type:"+e);switch(t){case l.MODE_NUMBER:return 14;case l.MODE_ALPHA_NUM:return 13;case l.MODE_8BIT_BYTE:return 16;case l.MODE_KANJI:return 12;default:throw new Error("mode:"+t)}}},getLostPoint:function(t){for(var e=t.getModuleCount(),r=0,o=0;o<e;o++)for(u=0;u<e;u++){for(var i=0,n=t.isDark(o,u),a=-1;a<=1;a++)if(!(o+a<0||e<=o+a))for(var s=-1;s<=1;s++)u+s<0||e<=u+s||0==a&&0==s||n==t.isDark(o+a,u+s)&&i++;i>5&&(r+=3+i-5)}for(o=0;o<e-1;o++)for(u=0;u<e-1;u++){var h=0;t.isDark(o,u)&&h++,t.isDark(o+1,u)&&h++,t.isDark(o,u+1)&&h++,t.isDark(o+1,u+1)&&h++,0!=h&&4!=h||(r+=3)}for(o=0;o<e;o++)for(u=0;u<e-6;u++)t.isDark(o,u)&&!t.isDark(o,u+1)&&t.isDark(o,u+2)&&t.isDark(o,u+3)&&t.isDark(o,u+4)&&!t.isDark(o,u+5)&&t.isDark(o,u+6)&&(r+=40);for(u=0;u<e;u++)for(o=0;o<e-6;o++)t.isDark(o,u)&&!t.isDark(o+1,u)&&t.isDark(o+2,u)&&t.isDark(o+3,u)&&t.isDark(o+4,u)&&!t.isDark(o+5,u)&&t.isDark(o+6,u)&&(r+=40);for(var l=0,u=0;u<e;u++)for(o=0;o<e;o++)t.isDark(o,u)&&l++;return r+=10*(Math.abs(100*l/e/e-50)/5)}},d={glog:function(t){if(t<1)throw new Error("glog("+t+")");return d.LOG_TABLE[t]},gexp:function(t){for(;t<0;)t+=255;for(;t>=256;)t-=255;return d.EXP_TABLE[t]},EXP_TABLE:new Array(256),LOG_TABLE:new Array(256)},c=0;c<8;c++)d.EXP_TABLE[c]=1<<c;for(c=8;c<256;c++)d.EXP_TABLE[c]=d.EXP_TABLE[c-4]^d.EXP_TABLE[c-5]^d.EXP_TABLE[c-6]^d.EXP_TABLE[c-8];for(c=0;c<255;c++)d.LOG_TABLE[d.EXP_TABLE[c]]=c;o.prototype={get:function(t){return this.num[t]},getLength:function(){return this.num.length},multiply:function(t){for(var e=new Array(this.getLength()+t.getLength()-1),r=0;r<this.getLength();r++)for(var i=0;i<t.getLength();i++)e[r+i]^=d.gexp(d.glog(this.get(r))+d.glog(t.get(i)));return new o(e,0)},mod:function(t){if(this.getLength()-t.getLength()<0)return this;for(var e=d.glog(this.get(0))-d.glog(t.get(0)),r=new Array(this.getLength()),i=0;i<this.getLength();i++)r[i]=this.get(i);for(i=0;i<t.getLength();i++)r[i]^=d.gexp(d.glog(t.get(i))+e);return new o(r,0).mod(t)}},i.RS_BLOCK_TABLE=[[1,26,19],[1,26,16],[1,26,13],[1,26,9],[1,44,34],[1,44,28],[1,44,22],[1,44,16],[1,70,55],[1,70,44],[2,35,17],[2,35,13],[1,100,80],[2,50,32],[2,50,24],[4,25,9],[1,134,108],[2,67,43],[2,33,15,2,34,16],[2,33,11,2,34,12],[2,86,68],[4,43,27],[4,43,19],[4,43,15],[2,98,78],[4,49,31],[2,32,14,4,33,15],[4,39,13,1,40,14],[2,121,97],[2,60,38,2,61,39],[4,40,18,2,41,19],[4,40,14,2,41,15],[2,146,116],[3,58,36,2,59,37],[4,36,16,4,37,17],[4,36,12,4,37,13],[2,86,68,2,87,69],[4,69,43,1,70,44],[6,43,19,2,44,20],[6,43,15,2,44,16],[4,101,81],[1,80,50,4,81,51],[4,50,22,4,51,23],[3,36,12,8,37,13],[2,116,92,2,117,93],[6,58,36,2,59,37],[4,46,20,6,47,21],[7,42,14,4,43,15],[4,133,107],[8,59,37,1,60,38],[8,44,20,4,45,21],[12,33,11,4,34,12],[3,145,115,1,146,116],[4,64,40,5,65,41],[11,36,16,5,37,17],[11,36,12,5,37,13],[5,109,87,1,110,88],[5,65,41,5,66,42],[5,54,24,7,55,25],[11,36,12],[5,122,98,1,123,99],[7,73,45,3,74,46],[15,43,19,2,44,20],[3,45,15,13,46,16],[1,135,107,5,136,108],[10,74,46,1,75,47],[1,50,22,15,51,23],[2,42,14,17,43,15],[5,150,120,1,151,121],[9,69,43,4,70,44],[17,50,22,1,51,23],[2,42,14,19,43,15],[3,141,113,4,142,114],[3,70,44,11,71,45],[17,47,21,4,48,22],[9,39,13,16,40,14],[3,135,107,5,136,108],[3,67,41,13,68,42],[15,54,24,5,55,25],[15,43,15,10,44,16],[4,144,116,4,145,117],[17,68,42],[17,50,22,6,51,23],[19,46,16,6,47,17],[2,139,111,7,140,112],[17,74,46],[7,54,24,16,55,25],[34,37,13],[4,151,121,5,152,122],[4,75,47,14,76,48],[11,54,24,14,55,25],[16,45,15,14,46,16],[6,147,117,4,148,118],[6,73,45,14,74,46],[11,54,24,16,55,25],[30,46,16,2,47,17],[8,132,106,4,133,107],[8,75,47,13,76,48],[7,54,24,22,55,25],[22,45,15,13,46,16],[10,142,114,2,143,115],[19,74,46,4,75,47],[28,50,22,6,51,23],[33,46,16,4,47,17],[8,152,122,4,153,123],[22,73,45,3,74,46],[8,53,23,26,54,24],[12,45,15,28,46,16],[3,147,117,10,148,118],[3,73,45,23,74,46],[4,54,24,31,55,25],[11,45,15,31,46,16],[7,146,116,7,147,117],[21,73,45,7,74,46],[1,53,23,37,54,24],[19,45,15,26,46,16],[5,145,115,10,146,116],[19,75,47,10,76,48],[15,54,24,25,55,25],[23,45,15,25,46,16],[13,145,115,3,146,116],[2,74,46,29,75,47],[42,54,24,1,55,25],[23,45,15,28,46,16],[17,145,115],[10,74,46,23,75,47],[10,54,24,35,55,25],[19,45,15,35,46,16],[17,145,115,1,146,116],[14,74,46,21,75,47],[29,54,24,19,55,25],[11,45,15,46,46,16],[13,145,115,6,146,116],[14,74,46,23,75,47],[44,54,24,7,55,25],[59,46,16,1,47,17],[12,151,121,7,152,122],[12,75,47,26,76,48],[39,54,24,14,55,25],[22,45,15,41,46,16],[6,151,121,14,152,122],[6,75,47,34,76,48],[46,54,24,10,55,25],[2,45,15,64,46,16],[17,152,122,4,153,123],[29,74,46,14,75,47],[49,54,24,10,55,25],[24,45,15,46,46,16],[4,152,122,18,153,123],[13,74,46,32,75,47],[48,54,24,14,55,25],[42,45,15,32,46,16],[20,147,117,4,148,118],[40,75,47,7,76,48],[43,54,24,22,55,25],[10,45,15,67,46,16],[19,148,118,6,149,119],[18,75,47,31,76,48],[34,54,24,34,55,25],[20,45,15,61,46,16]],i.getRSBlocks=function(t,e){var r=i.getRsBlockTable(t,e);if(void 0==r)throw new Error("bad rs block @ typeNumber:"+t+"/errorCorrectLevel:"+e);for(var o=r.length/3,n=[],a=0;a<o;a++)for(var s=r[3*a+0],h=r[3*a+1],l=r[3*a+2],u=0;u<s;u++)n.push(new i(h,l));return n},i.getRsBlockTable=function(t,e){switch(e){case u.L:return i.RS_BLOCK_TABLE[4*(t-1)+0];case u.M:return i.RS_BLOCK_TABLE[4*(t-1)+1];case u.Q:return i.RS_BLOCK_TABLE[4*(t-1)+2];case u.H:return i.RS_BLOCK_TABLE[4*(t-1)+3];default:return}},n.prototype={get:function(t){var e=Math.floor(t/8);return 1==(this.buffer[e]>>>7-t%8&1)},put:function(t,e){for(var r=0;r<e;r++)this.putBit(1==(t>>>e-r-1&1))},getLengthInBits:function(){return this.length},putBit:function(t){var e=Math.floor(this.length/8);this.buffer.length<=e&&this.buffer.push(0),t&&(this.buffer[e]|=128>>>this.length%8),this.length++}};var p=[[17,14,11,7],[32,26,20,14],[53,42,32,24],[78,62,46,34],[106,84,60,44],[134,106,74,58],[154,122,86,64],[192,152,108,84],[230,180,130,98],[271,213,151,119],[321,251,177,137],[367,287,203,155],[425,331,241,177],[458,362,258,194],[520,412,292,220],[586,450,322,250],[644,504,364,280],[718,560,394,310],[792,624,442,338],[858,666,482,382],[929,711,509,403],[1003,779,565,439],[1091,857,611,461],[1171,911,661,511],[1273,997,715,535],[1367,1059,751,593],[1465,1125,805,625],[1528,1190,868,658],[1628,1264,908,698],[1732,1370,982,742],[1840,1452,1030,790],[1952,1538,1112,842],[2068,1628,1168,898],[2188,1722,1228,958],[2303,1809,1283,983],[2431,1911,1351,1051],[2563,1989,1423,1093],[2699,2099,1499,1139],[2809,2213,1579,1219],[2953,2331,1663,1273]],m=function(){var t=function(t,e){this._el=t,this._htOption=e};return t.prototype.draw=function(t){function e(t,e){var r=document.createElementNS("http://www.w3.org/2000/svg",t);for(var o in e)e.hasOwnProperty(o)&&r.setAttribute(o,e[o]);return r}var r=this._htOption,o=this._el,i=t.getModuleCount();Math.floor(r.width/i),Math.floor(r.height/i);this.clear();var n=e("svg",{viewBox:"0 0 "+String(i)+" "+String(i),width:"100%",height:"100%",fill:r.colorLight});n.setAttributeNS("http://www.w3.org/2000/xmlns/","xmlns:xlink","http://www.w3.org/1999/xlink"),o.appendChild(n),n.appendChild(e("rect",{fill:r.colorLight,width:"100%",height:"100%"})),n.appendChild(e("rect",{fill:r.colorDark,width:"1",height:"1",id:"template"}));for(var a=0;a<i;a++)for(var s=0;s<i;s++)if(t.isDark(a,s)){var h=e("use",{x:String(s),y:String(a)});h.setAttributeNS("http://www.w3.org/1999/xlink","href","#template"),n.appendChild(h)}},t.prototype.clear=function(){for(;this._el.hasChildNodes();)this._el.removeChild(this._el.lastChild)},t}(),_="svg"===document.documentElement.tagName.toLowerCase()?m:"undefined"==typeof CanvasRenderingContext2D?function(){var t=function(t,e){this._el=t,this._htOption=e};return t.prototype.draw=function(t){for(var e=this._htOption,r=this._el,o=t.getModuleCount(),i=Math.floor(e.width/o),n=Math.floor(e.height/o),a=['<table style="border:0;border-collapse:collapse;">'],s=0;s<o;s++){a.push("<tr>");for(var h=0;h<o;h++)a.push('<td style="border:0;border-collapse:collapse;padding:0;margin:0;width:'+i+"px;height:"+n+"px;background-color:"+(t.isDark(s,h)?e.colorDark:e.colorLight)+';"></td>');a.push("</tr>")}a.push("</table>"),r.innerHTML=a.join("");var l=r.childNodes[0],u=(e.width-l.offsetWidth)/2,f=(e.height-l.offsetHeight)/2;u>0&&f>0&&(l.style.margin=f+"px "+u+"px")},t.prototype.clear=function(){this._el.innerHTML=""},t}():function(){function t(){this._elImage.src=this._elCanvas.toDataURL("image/png"),this._elImage.style.display="block",this._elCanvas.style.display="none"}function e(t,e){var r=this;if(r._fFail=e,r._fSuccess=t,null===r._bSupportDataURI){var o=document.createElement("img"),i=function(){r._bSupportDataURI=!1,r._fFail&&r._fFail.call(r)};return o.onabort=i,o.onerror=i,o.onload=function(){r._bSupportDataURI=!0,r._fSuccess&&r._fSuccess.call(r)},void(o.src="data:image/gif;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAFCAYAAACNbyblAAAAHElEQVQI12P4//8/w38GIAXDIBKE0DHxgljNBAAO9TXL0Y4OHwAAAABJRU5ErkJggg==")}!0===r._bSupportDataURI&&r._fSuccess?r._fSuccess.call(r):!1===r._bSupportDataURI&&r._fFail&&r._fFail.call(r)}if(this._android&&this._android<=2.1){var r=1/window.devicePixelRatio,o=CanvasRenderingContext2D.prototype.drawImage;CanvasRenderingContext2D.prototype.drawImage=function(t,e,i,n,a,s,h,l,u){if("nodeName"in t&&/img/i.test(t.nodeName))for(var f=arguments.length-1;f>=1;f--)arguments[f]=arguments[f]*r;else void 0===l&&(arguments[1]*=r,arguments[2]*=r,arguments[3]*=r,arguments[4]*=r);o.apply(this,arguments)}}var i=function(t,e){this._bIsPainted=!1,this._android=a(),this._htOption=e,this._elCanvas=document.createElement("canvas"),this._elCanvas.width=e.width,this._elCanvas.height=e.height,t.appendChild(this._elCanvas),this._el=t,this._oContext=this._elCanvas.getContext("2d"),this._bIsPainted=!1,this._elImage=document.createElement("img"),this._elImage.alt="Scan me!",this._elImage.style.display="none",this._el.appendChild(this._elImage),this._bSupportDataURI=null};return i.prototype.draw=function(t){var e=this._elImage,r=this._oContext,o=this._htOption,i=t.getModuleCount(),n=o.width/i,a=o.height/i,s=Math.round(n),h=Math.round(a);e.style.display="none",this.clear();for(var l=0;l<i;l++)for(var u=0;u<i;u++){var f=t.isDark(l,u),g=u*n,d=l*a;r.strokeStyle=f?o.colorDark:o.colorLight,r.lineWidth=1,r.fillStyle=f?o.colorDark:o.colorLight,r.fillRect(g,d,n,a),r.strokeRect(Math.floor(g)+.5,Math.floor(d)+.5,s,h),r.strokeRect(Math.ceil(g)-.5,Math.ceil(d)-.5,s,h)}this._bIsPainted=!0},i.prototype.makeImage=function(){this._bIsPainted&&e.call(this,t)},i.prototype.isPainted=function(){return this._bIsPainted},i.prototype.clear=function(){this._oContext.clearRect(0,0,this._elCanvas.width,this._elCanvas.height),this._bIsPainted=!1},i.prototype.round=function(t){return t?Math.floor(1e3*t)/1e3:t},i}();(t=function(t,e){if(this._htOption={width:256,height:256,typeNumber:4,colorDark:"#000000",colorLight:"#ffffff",correctLevel:u.H},"string"==typeof e&&(e={text:e}),e)for(var r in e)this._htOption[r]=e[r];"string"==typeof t&&(t=document.getElementById(t)),this._htOption.useSVG&&(_=m),this._android=a(),this._el=t,this._oQRCode=null,this._oDrawing=new _(this._el,this._htOption),this._htOption.text&&this.makeCode(this._htOption.text)}).prototype.makeCode=function(t){this._oQRCode=new r(s(t,this._htOption.correctLevel),this._htOption.correctLevel),this._oQRCode.addData(t),this._oQRCode.make(),this._el.title=t,this._oDrawing.draw(this._oQRCode),this.makeImage()},t.prototype.makeImage=function(){"function"==typeof this._oDrawing.makeImage&&(!this._android||this._android>=3)&&this._oDrawing.makeImage()},t.prototype.clear=function(){this._oDrawing.clear()},t.CorrectLevel=u}(); 
 			}); 
		define("utils/util.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function t(t){return(t=t.toString())[1]?t:"0"+t}function e(t){var e=new Date(t),n=e.getFullYear(),r=e.getMonth()+1,i=e.getDate();return n+"-"+(r<10?"0"+r:r)+"-"+(i<10?"0"+i:i)}function n(t){var n=new Date(t),r=e(t),i=n.getHours(),a=n.getMinutes(),o=n.getSeconds();return r+" "+(i<10?"0"+i:i)+":"+(a<10?"0"+a:a)+":"+(o<10?"0"+o:o)}var r=[[1,2,4,5,6,7,11,12,24,83,87],[25,69,84],[37,71],[13,14,15,16,18],[65,86],[19,20,21,23,28,29,35,42,60,73,89],[26,46,75,85],[39,40,76,68],[67],[32,33,34,77,78],[43,44,45],[36,56,57,66,79,80,90],[63,64,81,82]];module.exports={timerFormat:function(e){var n,r,i;if(e.indexOf("小时")>-1){var a=e.split("小时")[0],o=e.split("小时")[1].split("分")[0],u=e.split("小时")[1].split("分")[1].split("秒")[0];Number(3600*a),Number(60*o),Number(u),n=a,r=o,i=u}else if(e.indexOf("分")>-1){var o=e.split("分")[0],u=e.split("分")[1].split("秒")[0];Number(60*o),Number(u),n=0,r=o,i=u}else u=e.split("秒")[0],Number(u),n=0,r=0,i=u;return[n,r,i].map(t).join(":")},formatTime:function(e){var n=e.getFullYear(),r=e.getMonth()+1,i=e.getDate(),a=e.getHours(),o=e.getMinutes(),u=e.getSeconds();return[n,r,i].map(t).join("/")+" "+[a,o,u].map(t).join(":")},getDistance:function(t,e,n,r){t=t||0,e=e||0,n=n||0,r=r||0;var i=t*Math.PI/180,a=n*Math.PI/180,o=i-a,u=e*Math.PI/180-r*Math.PI/180;return 12756274*Math.asin(Math.sqrt(Math.pow(Math.sin(o/2),2)+Math.cos(i)*Math.cos(a)*Math.pow(Math.sin(u/2),2)))},repeatRemove:function(t){var e=[];e=t.split("市");for(var n=[],r=0;r<e.length;r++)-1==n.indexOf(e[r])&&n.push(e[r]);var i=[];i=n.join("市").split("市");for(var a=[],r=0;r<i.length;r++)-1==a.indexOf(i[r])&&a.push(i[r]);var o=a[0].toString(),u=(a.shift(),[]);u=a.join("市").split("区");for(var s=[],r=0;r<u.length;r++)-1==s.indexOf(u[r])&&s.push(u[r]);return o+"市"+s.join("区")},toDate:function(t){return 0==t?0:n(1e3*t)},formatDate:e,formatDateAndTime:n,EmptyToZero:function(t){return void 0==t?0:null==t?0:"undefined"==t?0:"null"==t?0:parseInt(t)},getNotNullVal:function(t,e){return t||e||""},getShopType:function(t){for(var e=0;e<r.length;e++)if(-1!=r[e].indexOf(t))return e+1;return 14}}; 
 			}); 
		define("utils/weapp-qrcode.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t;!function(){function e(t,e){for(var o=1,n=r(t),i=0,a=d.length;i<=a;i++){var s=0;switch(e){case u.L:s=d[i][0];break;case u.M:s=d[i][1];break;case u.Q:s=d[i][2];break;case u.H:s=d[i][3]}if(n<=s)break;o++}if(o>d.length)throw new Error("Too long data");return o}function r(t){var e=encodeURI(t).toString().replace(/\%[0-9a-fA-F]{2}/g,"a");return e.length+(e.length!=t?3:0)}function o(t){this.mode=h.MODE_8BIT_BYTE,this.data=t,this.parsedData=[];for(var e=0,r=this.data.length;e<r;e++){var o=[],n=this.data.charCodeAt(e);n>65536?(o[0]=240|(1835008&n)>>>18,o[1]=128|(258048&n)>>>12,o[2]=128|(4032&n)>>>6,o[3]=128|63&n):n>2048?(o[0]=224|(61440&n)>>>12,o[1]=128|(4032&n)>>>6,o[2]=128|63&n):n>128?(o[0]=192|(1984&n)>>>6,o[1]=128|63&n):o[0]=n,this.parsedData.push(o)}this.parsedData=Array.prototype.concat.apply([],this.parsedData),this.parsedData.length!=this.data.length&&(this.parsedData.unshift(191),this.parsedData.unshift(187),this.parsedData.unshift(239))}function n(t,e){this.typeNumber=t,this.errorCorrectLevel=e,this.modules=null,this.moduleCount=0,this.dataCache=null,this.dataList=[]}function i(t,e){if(void 0==t.length)throw new Error(t.length+"/"+e);for(var r=0;r<t.length&&0==t[r];)r++;this.num=new Array(t.length-r+e);for(var o=0;o<t.length-r;o++)this.num[o]=t[o+r]}function a(t,e){this.totalCount=t,this.dataCount=e}function s(){this.buffer=[],this.length=0}o.prototype={getLength:function(t){return this.parsedData.length},write:function(t){for(var e=0,r=this.parsedData.length;e<r;e++)t.put(this.parsedData[e],8)}},n.prototype={addData:function(t){var e=new o(t);this.dataList.push(e),this.dataCache=null},isDark:function(t,e){if(t<0||this.moduleCount<=t||e<0||this.moduleCount<=e)throw new Error(t+","+e);return this.modules[t][e]},getModuleCount:function(){return this.moduleCount},make:function(){this.makeImpl(!1,this.getBestMaskPattern())},makeImpl:function(t,e){this.moduleCount=4*this.typeNumber+17,this.modules=new Array(this.moduleCount);for(var r=0;r<this.moduleCount;r++){this.modules[r]=new Array(this.moduleCount);for(var o=0;o<this.moduleCount;o++)this.modules[r][o]=null}this.setupPositionProbePattern(0,0),this.setupPositionProbePattern(this.moduleCount-7,0),this.setupPositionProbePattern(0,this.moduleCount-7),this.setupPositionAdjustPattern(),this.setupTimingPattern(),this.setupTypeInfo(t,e),this.typeNumber>=7&&this.setupTypeNumber(t),null==this.dataCache&&(this.dataCache=n.createData(this.typeNumber,this.errorCorrectLevel,this.dataList)),this.mapData(this.dataCache,e)},setupPositionProbePattern:function(t,e){for(var r=-1;r<=7;r++)if(!(t+r<=-1||this.moduleCount<=t+r))for(var o=-1;o<=7;o++)e+o<=-1||this.moduleCount<=e+o||(this.modules[t+r][e+o]=0<=r&&r<=6&&(0==o||6==o)||0<=o&&o<=6&&(0==r||6==r)||2<=r&&r<=4&&2<=o&&o<=4)},getBestMaskPattern:function(){for(var t=0,e=0,r=0;r<8;r++){this.makeImpl(!0,r);var o=g.getLostPoint(this);(0==r||t>o)&&(t=o,e=r)}return e},createMovieClip:function(t,e,r){var o=t.createEmptyMovieClip(e,r);this.make();for(var n=0;n<this.modules.length;n++)for(var i=1*n,a=0;a<this.modules[n].length;a++){var s=1*a;this.modules[n][a]&&(o.beginFill(0,100),o.moveTo(s,i),o.lineTo(s+1,i),o.lineTo(s+1,i+1),o.lineTo(s,i+1),o.endFill())}return o},setupTimingPattern:function(){for(var t=8;t<this.moduleCount-8;t++)null==this.modules[t][6]&&(this.modules[t][6]=t%2==0);for(var e=8;e<this.moduleCount-8;e++)null==this.modules[6][e]&&(this.modules[6][e]=e%2==0)},setupPositionAdjustPattern:function(){for(var t=g.getPatternPosition(this.typeNumber),e=0;e<t.length;e++)for(var r=0;r<t.length;r++){var o=t[e],n=t[r];if(null==this.modules[o][n])for(var i=-2;i<=2;i++)for(var a=-2;a<=2;a++)this.modules[o+i][n+a]=-2==i||2==i||-2==a||2==a||0==i&&0==a}},setupTypeNumber:function(t){for(var e=g.getBCHTypeNumber(this.typeNumber),r=0;r<18;r++){o=!t&&1==(e>>r&1);this.modules[Math.floor(r/3)][r%3+this.moduleCount-8-3]=o}for(r=0;r<18;r++){var o=!t&&1==(e>>r&1);this.modules[r%3+this.moduleCount-8-3][Math.floor(r/3)]=o}},setupTypeInfo:function(t,e){for(var r=this.errorCorrectLevel<<3|e,o=g.getBCHTypeInfo(r),n=0;n<15;n++){i=!t&&1==(o>>n&1);n<6?this.modules[n][8]=i:n<8?this.modules[n+1][8]=i:this.modules[this.moduleCount-15+n][8]=i}for(n=0;n<15;n++){var i=!t&&1==(o>>n&1);n<8?this.modules[8][this.moduleCount-n-1]=i:n<9?this.modules[8][15-n-1+1]=i:this.modules[8][15-n-1]=i}this.modules[this.moduleCount-8][8]=!t},mapData:function(t,e){for(var r=-1,o=this.moduleCount-1,n=7,i=0,a=this.moduleCount-1;a>0;a-=2)for(6==a&&a--;;){for(var s=0;s<2;s++)if(null==this.modules[o][a-s]){var h=!1;i<t.length&&(h=1==(t[i]>>>n&1)),g.getMask(e,o,a-s)&&(h=!h),this.modules[o][a-s]=h,-1==--n&&(i++,n=7)}if((o+=r)<0||this.moduleCount<=o){o-=r,r=-r;break}}}},n.PAD0=236,n.PAD1=17,n.createData=function(t,e,r){for(var o=a.getRSBlocks(t,e),i=new s,h=0;h<r.length;h++){var u=r[h];i.put(u.mode,4),i.put(u.getLength(),g.getLengthInBits(u.mode,t)),u.write(i)}for(var l=0,h=0;h<o.length;h++)l+=o[h].dataCount;if(i.getLengthInBits()>8*l)throw new Error("code length overflow. ("+i.getLengthInBits()+">"+8*l+")");for(i.getLengthInBits()+4<=8*l&&i.put(0,4);i.getLengthInBits()%8!=0;)i.putBit(!1);for(;;){if(i.getLengthInBits()>=8*l)break;if(i.put(n.PAD0,8),i.getLengthInBits()>=8*l)break;i.put(n.PAD1,8)}return n.createBytes(i,o)},n.createBytes=function(t,e){for(var r=0,o=0,n=0,a=new Array(e.length),s=new Array(e.length),h=0;h<e.length;h++){var u=e[h].dataCount,l=e[h].totalCount-u;o=Math.max(o,u),n=Math.max(n,l),a[h]=new Array(u);for(p=0;p<a[h].length;p++)a[h][p]=255&t.buffer[p+r];r+=u;var f=g.getErrorCorrectPolynomial(l),c=new i(a[h],f.getLength()-1).mod(f);s[h]=new Array(f.getLength()-1);for(p=0;p<s[h].length;p++){var d=p+c.getLength()-s[h].length;s[h][p]=d>=0?c.get(d):0}}for(var m=0,p=0;p<e.length;p++)m+=e[p].totalCount;for(var v=new Array(m),E=0,p=0;p<o;p++)for(h=0;h<e.length;h++)p<a[h].length&&(v[E++]=a[h][p]);for(p=0;p<n;p++)for(h=0;h<e.length;h++)p<s[h].length&&(v[E++]=s[h][p]);return v};for(var h={MODE_NUMBER:1,MODE_ALPHA_NUM:2,MODE_8BIT_BYTE:4,MODE_KANJI:8},u={L:1,M:0,Q:3,H:2},l={PATTERN000:0,PATTERN001:1,PATTERN010:2,PATTERN011:3,PATTERN100:4,PATTERN101:5,PATTERN110:6,PATTERN111:7},g={PATTERN_POSITION_TABLE:[[],[6,18],[6,22],[6,26],[6,30],[6,34],[6,22,38],[6,24,42],[6,26,46],[6,28,50],[6,30,54],[6,32,58],[6,34,62],[6,26,46,66],[6,26,48,70],[6,26,50,74],[6,30,54,78],[6,30,56,82],[6,30,58,86],[6,34,62,90],[6,28,50,72,94],[6,26,50,74,98],[6,30,54,78,102],[6,28,54,80,106],[6,32,58,84,110],[6,30,58,86,114],[6,34,62,90,118],[6,26,50,74,98,122],[6,30,54,78,102,126],[6,26,52,78,104,130],[6,30,56,82,108,134],[6,34,60,86,112,138],[6,30,58,86,114,142],[6,34,62,90,118,146],[6,30,54,78,102,126,150],[6,24,50,76,102,128,154],[6,28,54,80,106,132,158],[6,32,58,84,110,136,162],[6,26,54,82,110,138,166],[6,30,58,86,114,142,170]],G15:1335,G18:7973,G15_MASK:21522,getBCHTypeInfo:function(t){for(var e=t<<10;g.getBCHDigit(e)-g.getBCHDigit(g.G15)>=0;)e^=g.G15<<g.getBCHDigit(e)-g.getBCHDigit(g.G15);return(t<<10|e)^g.G15_MASK},getBCHTypeNumber:function(t){for(var e=t<<12;g.getBCHDigit(e)-g.getBCHDigit(g.G18)>=0;)e^=g.G18<<g.getBCHDigit(e)-g.getBCHDigit(g.G18);return t<<12|e},getBCHDigit:function(t){for(var e=0;0!=t;)e++,t>>>=1;return e},getPatternPosition:function(t){return g.PATTERN_POSITION_TABLE[t-1]},getMask:function(t,e,r){switch(t){case l.PATTERN000:return(e+r)%2==0;case l.PATTERN001:return e%2==0;case l.PATTERN010:return r%3==0;case l.PATTERN011:return(e+r)%3==0;case l.PATTERN100:return(Math.floor(e/2)+Math.floor(r/3))%2==0;case l.PATTERN101:return e*r%2+e*r%3==0;case l.PATTERN110:return(e*r%2+e*r%3)%2==0;case l.PATTERN111:return(e*r%3+(e+r)%2)%2==0;default:throw new Error("bad maskPattern:"+t)}},getErrorCorrectPolynomial:function(t){for(var e=new i([1],0),r=0;r<t;r++)e=e.multiply(new i([1,f.gexp(r)],0));return e},getLengthInBits:function(t,e){if(1<=e&&e<10)switch(t){case h.MODE_NUMBER:return 10;case h.MODE_ALPHA_NUM:return 9;case h.MODE_8BIT_BYTE:case h.MODE_KANJI:return 8;default:throw new Error("mode:"+t)}else if(e<27)switch(t){case h.MODE_NUMBER:return 12;case h.MODE_ALPHA_NUM:return 11;case h.MODE_8BIT_BYTE:return 16;case h.MODE_KANJI:return 10;default:throw new Error("mode:"+t)}else{if(!(e<41))throw new Error("type:"+e);switch(t){case h.MODE_NUMBER:return 14;case h.MODE_ALPHA_NUM:return 13;case h.MODE_8BIT_BYTE:return 16;case h.MODE_KANJI:return 12;default:throw new Error("mode:"+t)}}},getLostPoint:function(t){for(var e=t.getModuleCount(),r=0,o=0;o<e;o++)for(l=0;l<e;l++){for(var n=0,i=t.isDark(o,l),a=-1;a<=1;a++)if(!(o+a<0||e<=o+a))for(var s=-1;s<=1;s++)l+s<0||e<=l+s||0==a&&0==s||i==t.isDark(o+a,l+s)&&n++;n>5&&(r+=3+n-5)}for(o=0;o<e-1;o++)for(l=0;l<e-1;l++){var h=0;t.isDark(o,l)&&h++,t.isDark(o+1,l)&&h++,t.isDark(o,l+1)&&h++,t.isDark(o+1,l+1)&&h++,0!=h&&4!=h||(r+=3)}for(o=0;o<e;o++)for(l=0;l<e-6;l++)t.isDark(o,l)&&!t.isDark(o,l+1)&&t.isDark(o,l+2)&&t.isDark(o,l+3)&&t.isDark(o,l+4)&&!t.isDark(o,l+5)&&t.isDark(o,l+6)&&(r+=40);for(l=0;l<e;l++)for(o=0;o<e-6;o++)t.isDark(o,l)&&!t.isDark(o+1,l)&&t.isDark(o+2,l)&&t.isDark(o+3,l)&&t.isDark(o+4,l)&&!t.isDark(o+5,l)&&t.isDark(o+6,l)&&(r+=40);for(var u=0,l=0;l<e;l++)for(o=0;o<e;o++)t.isDark(o,l)&&u++;return r+=10*(Math.abs(100*u/e/e-50)/5)}},f={glog:function(t){if(t<1)throw new Error("glog("+t+")");return f.LOG_TABLE[t]},gexp:function(t){for(;t<0;)t+=255;for(;t>=256;)t-=255;return f.EXP_TABLE[t]},EXP_TABLE:new Array(256),LOG_TABLE:new Array(256)},c=0;c<8;c++)f.EXP_TABLE[c]=1<<c;for(c=8;c<256;c++)f.EXP_TABLE[c]=f.EXP_TABLE[c-4]^f.EXP_TABLE[c-5]^f.EXP_TABLE[c-6]^f.EXP_TABLE[c-8];for(c=0;c<255;c++)f.LOG_TABLE[f.EXP_TABLE[c]]=c;i.prototype={get:function(t){return this.num[t]},getLength:function(){return this.num.length},multiply:function(t){for(var e=new Array(this.getLength()+t.getLength()-1),r=0;r<this.getLength();r++)for(var o=0;o<t.getLength();o++)e[r+o]^=f.gexp(f.glog(this.get(r))+f.glog(t.get(o)));return new i(e,0)},mod:function(t){if(this.getLength()-t.getLength()<0)return this;for(var e=f.glog(this.get(0))-f.glog(t.get(0)),r=new Array(this.getLength()),o=0;o<this.getLength();o++)r[o]=this.get(o);for(o=0;o<t.getLength();o++)r[o]^=f.gexp(f.glog(t.get(o))+e);return new i(r,0).mod(t)}},a.RS_BLOCK_TABLE=[[1,26,19],[1,26,16],[1,26,13],[1,26,9],[1,44,34],[1,44,28],[1,44,22],[1,44,16],[1,70,55],[1,70,44],[2,35,17],[2,35,13],[1,100,80],[2,50,32],[2,50,24],[4,25,9],[1,134,108],[2,67,43],[2,33,15,2,34,16],[2,33,11,2,34,12],[2,86,68],[4,43,27],[4,43,19],[4,43,15],[2,98,78],[4,49,31],[2,32,14,4,33,15],[4,39,13,1,40,14],[2,121,97],[2,60,38,2,61,39],[4,40,18,2,41,19],[4,40,14,2,41,15],[2,146,116],[3,58,36,2,59,37],[4,36,16,4,37,17],[4,36,12,4,37,13],[2,86,68,2,87,69],[4,69,43,1,70,44],[6,43,19,2,44,20],[6,43,15,2,44,16],[4,101,81],[1,80,50,4,81,51],[4,50,22,4,51,23],[3,36,12,8,37,13],[2,116,92,2,117,93],[6,58,36,2,59,37],[4,46,20,6,47,21],[7,42,14,4,43,15],[4,133,107],[8,59,37,1,60,38],[8,44,20,4,45,21],[12,33,11,4,34,12],[3,145,115,1,146,116],[4,64,40,5,65,41],[11,36,16,5,37,17],[11,36,12,5,37,13],[5,109,87,1,110,88],[5,65,41,5,66,42],[5,54,24,7,55,25],[11,36,12],[5,122,98,1,123,99],[7,73,45,3,74,46],[15,43,19,2,44,20],[3,45,15,13,46,16],[1,135,107,5,136,108],[10,74,46,1,75,47],[1,50,22,15,51,23],[2,42,14,17,43,15],[5,150,120,1,151,121],[9,69,43,4,70,44],[17,50,22,1,51,23],[2,42,14,19,43,15],[3,141,113,4,142,114],[3,70,44,11,71,45],[17,47,21,4,48,22],[9,39,13,16,40,14],[3,135,107,5,136,108],[3,67,41,13,68,42],[15,54,24,5,55,25],[15,43,15,10,44,16],[4,144,116,4,145,117],[17,68,42],[17,50,22,6,51,23],[19,46,16,6,47,17],[2,139,111,7,140,112],[17,74,46],[7,54,24,16,55,25],[34,37,13],[4,151,121,5,152,122],[4,75,47,14,76,48],[11,54,24,14,55,25],[16,45,15,14,46,16],[6,147,117,4,148,118],[6,73,45,14,74,46],[11,54,24,16,55,25],[30,46,16,2,47,17],[8,132,106,4,133,107],[8,75,47,13,76,48],[7,54,24,22,55,25],[22,45,15,13,46,16],[10,142,114,2,143,115],[19,74,46,4,75,47],[28,50,22,6,51,23],[33,46,16,4,47,17],[8,152,122,4,153,123],[22,73,45,3,74,46],[8,53,23,26,54,24],[12,45,15,28,46,16],[3,147,117,10,148,118],[3,73,45,23,74,46],[4,54,24,31,55,25],[11,45,15,31,46,16],[7,146,116,7,147,117],[21,73,45,7,74,46],[1,53,23,37,54,24],[19,45,15,26,46,16],[5,145,115,10,146,116],[19,75,47,10,76,48],[15,54,24,25,55,25],[23,45,15,25,46,16],[13,145,115,3,146,116],[2,74,46,29,75,47],[42,54,24,1,55,25],[23,45,15,28,46,16],[17,145,115],[10,74,46,23,75,47],[10,54,24,35,55,25],[19,45,15,35,46,16],[17,145,115,1,146,116],[14,74,46,21,75,47],[29,54,24,19,55,25],[11,45,15,46,46,16],[13,145,115,6,146,116],[14,74,46,23,75,47],[44,54,24,7,55,25],[59,46,16,1,47,17],[12,151,121,7,152,122],[12,75,47,26,76,48],[39,54,24,14,55,25],[22,45,15,41,46,16],[6,151,121,14,152,122],[6,75,47,34,76,48],[46,54,24,10,55,25],[2,45,15,64,46,16],[17,152,122,4,153,123],[29,74,46,14,75,47],[49,54,24,10,55,25],[24,45,15,46,46,16],[4,152,122,18,153,123],[13,74,46,32,75,47],[48,54,24,14,55,25],[42,45,15,32,46,16],[20,147,117,4,148,118],[40,75,47,7,76,48],[43,54,24,22,55,25],[10,45,15,67,46,16],[19,148,118,6,149,119],[18,75,47,31,76,48],[34,54,24,34,55,25],[20,45,15,61,46,16]],a.getRSBlocks=function(t,e){var r=a.getRsBlockTable(t,e);if(void 0==r)throw new Error("bad rs block @ typeNumber:"+t+"/errorCorrectLevel:"+e);for(var o=r.length/3,n=[],i=0;i<o;i++)for(var s=r[3*i+0],h=r[3*i+1],u=r[3*i+2],l=0;l<s;l++)n.push(new a(h,u));return n},a.getRsBlockTable=function(t,e){switch(e){case u.L:return a.RS_BLOCK_TABLE[4*(t-1)+0];case u.M:return a.RS_BLOCK_TABLE[4*(t-1)+1];case u.Q:return a.RS_BLOCK_TABLE[4*(t-1)+2];case u.H:return a.RS_BLOCK_TABLE[4*(t-1)+3];default:return}},s.prototype={get:function(t){var e=Math.floor(t/8);return 1==(this.buffer[e]>>>7-t%8&1)},put:function(t,e){for(var r=0;r<e;r++)this.putBit(1==(t>>>e-r-1&1))},getLengthInBits:function(){return this.length},putBit:function(t){var e=Math.floor(this.length/8);this.buffer.length<=e&&this.buffer.push(0),t&&(this.buffer[e]|=128>>>this.length%8),this.length++}};var d=[[17,14,11,7],[32,26,20,14],[53,42,32,24],[78,62,46,34],[106,84,60,44],[134,106,74,58],[154,122,86,64],[192,152,108,84],[230,180,130,98],[271,213,151,119],[321,251,177,137],[367,287,203,155],[425,331,241,177],[458,362,258,194],[520,412,292,220],[586,450,322,250],[644,504,364,280],[718,560,394,310],[792,624,442,338],[858,666,482,382],[929,711,509,403],[1003,779,565,439],[1091,857,611,461],[1171,911,661,511],[1273,997,715,535],[1367,1059,751,593],[1465,1125,805,625],[1528,1190,868,658],[1628,1264,908,698],[1732,1370,982,742],[1840,1452,1030,790],[1952,1538,1112,842],[2068,1628,1168,898],[2188,1722,1228,958],[2303,1809,1283,983],[2431,1911,1351,1051],[2563,1989,1423,1093],[2699,2099,1499,1139],[2809,2213,1579,1219],[2953,2331,1663,1273]];(t=function(t,e){if(this._htOption={width:256,height:256,typeNumber:4,colorDark:"#000000",colorLight:"#ffffff",correctLevel:u.H},"string"==typeof e&&(e={text:e}),e)for(var r in e)this._htOption[r]=e[r];this._oQRCode=null,this.canvasId=t,this._htOption.text&&this.canvasId&&this.makeCode(this._htOption.text)}).prototype.makeCode=function(t){this._oQRCode=new n(e(t,this._htOption.correctLevel),this._htOption.correctLevel),this._oQRCode.addData(t),this._oQRCode.make(),this.makeImage()},t.prototype.makeImage=function(){var t;t=this._htOption.usingIn?wx.createCanvasContext(this.canvasId,this._htOption.usingIn):wx.createCanvasContext(this.canvasId);var e=this._htOption,r=this._oQRCode,o=r.getModuleCount(),n=e.width/o,i=e.height/o,a=Math.round(n),s=Math.round(i);e.image&&""!=e.image&&t.drawImage(e.image,0,0,e.width,e.height);for(var h=0;h<o;h++)for(var u=0;u<o;u++){var l=r.isDark(h,u),g=u*n,f=h*i;t.setStrokeStyle(l?e.colorDark:e.colorLight),t.setLineWidth(1),t.setFillStyle(l?e.colorDark:e.colorLight),t.fillRect(g,f,n,i),t.strokeRect(Math.floor(g)+.5,Math.floor(f)+.5,a,s),t.strokeRect(Math.ceil(g)-.5,Math.ceil(f)-.5,a,s)}t.draw()},t.prototype.exportImage=function(t){t&&wx.canvasToTempFilePath({x:0,y:0,width:this._htOption.width,height:this._htOption.height,destWidth:this._htOption.width,destHeight:this._htOption.height,canvasId:this.canvasId,success:function(e){console.log(e.tempFilePath),t(e.tempFilePath)}})},t.CorrectLevel=u}(),module.exports=t; 
 			}); 
		define("utils/wxTimer.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e=function(e){e=e||{},this.beginTime=e.beginTime||"00:00:00",this.interval=e.interval||0,this.complete=e.complete,this.intervalFn=e.intervalFn,this.name=e.name,this.intervarID,this.endTime,this.endSystemTime};e.prototype={start:function(e){function t(){var t=new Date(i.endTime+1e3*n++),a=t.toString().substr(16,8),r=(t.getTime()-new Date("1970/01/01 00:00:00").getTime())/1e3,s=e.data.wxTimerList;s[i.name]={wxTimer:a,wxTimerSecond:r},e.setData({wxTimer:a,wxTimerSecond:r,wxTimerList:s}),0==(n-1)%i.interval&&i.intervalFn&&i.intervalFn(),r<=0&&(i.complete&&i.complete(),i.stop())}this.endTime=new Date("1970/01/01 "+this.beginTime).getTime(),this.endSystemTime=new Date(Date.now()+this.endTime);var i=this,n=0;t(),this.intervarID=setInterval(t,1e3)},stop:function(){clearInterval(this.intervarID)},calibration:function(){this.endTime=this.endSystemTime-Date.now()}},module.exports=e; 
 			}); 
		define("utils/wxqrcode.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function r(t,e){if(void 0===t.length)throw new Error(t.length+"/"+e);var n=function(){for(var r=0;r<t.length&&0==t[r];)r+=1;for(var n=new Array(t.length-r+e),o=0;o<t.length-r;o+=1)n[o]=t[o+r];return n}(),o={};return o.getAt=function(r){return n[r]},o.getLength=function(){return n.length},o.multiply=function(t){for(var e=new Array(o.getLength()+t.getLength()-1),n=0;n<o.getLength();n+=1)for(var a=0;a<t.getLength();a+=1)e[n+a]^=i.gexp(i.glog(o.getAt(n))+i.glog(t.getAt(a)));return r(e,0)},o.mod=function(t){if(o.getLength()-t.getLength()<0)return o;for(var e=i.glog(o.getAt(0))-i.glog(t.getAt(0)),n=new Array(o.getLength()),a=0;a<o.getLength();a+=1)n[a]=o.getAt(a);for(a=0;a<t.getLength();a+=1)n[a]^=i.gexp(i.glog(t.getAt(a))+e);return r(n,0).mod(t)},o}var t=function(t,e){var o=t,i=n[e],c=null,h=0,l=null,s=new Array,w={},d=function(r,t){c=function(r){for(var t=new Array(r),e=0;e<r;e+=1){t[e]=new Array(r);for(var n=0;n<r;n+=1)t[e][n]=null}return t}(h=4*o+17),y(0,0),y(h-7,0),y(0,h-7),p(),B(),T(r,t),o>=7&&E(r),null==l&&(l=D(o,i,s)),M(l,t)},y=function(r,t){for(var e=-1;e<=7;e+=1)if(!(r+e<=-1||h<=r+e))for(var n=-1;n<=7;n+=1)t+n<=-1||h<=t+n||(c[r+e][t+n]=0<=e&&e<=6&&(0==n||6==n)||0<=n&&n<=6&&(0==e||6==e)||2<=e&&e<=4&&2<=n&&n<=4)},A=function(){for(var r=0,t=0,e=0;e<8;e+=1){d(!0,e);var n=a.getLostPoint(w);(0==e||r>n)&&(r=n,t=e)}return t},B=function(){for(var r=8;r<h-8;r+=1)null==c[r][6]&&(c[r][6]=r%2==0);for(var t=8;t<h-8;t+=1)null==c[6][t]&&(c[6][t]=t%2==0)},p=function(){for(var r=a.getPatternPosition(o),t=0;t<r.length;t+=1)for(var e=0;e<r.length;e+=1){var n=r[t],i=r[e];if(null==c[n][i])for(var u=-2;u<=2;u+=1)for(var f=-2;f<=2;f+=1)c[n+u][i+f]=-2==u||2==u||-2==f||2==f||0==u&&0==f}},E=function(r){for(var t=a.getBCHTypeNumber(o),e=0;e<18;e+=1){n=!r&&1==(t>>e&1);c[Math.floor(e/3)][e%3+h-8-3]=n}for(e=0;e<18;e+=1){var n=!r&&1==(t>>e&1);c[e%3+h-8-3][Math.floor(e/3)]=n}},T=function(r,t){for(var e=i<<3|t,n=a.getBCHTypeInfo(e),o=0;o<15;o+=1){u=!r&&1==(n>>o&1);o<6?c[o][8]=u:o<8?c[o+1][8]=u:c[h-15+o][8]=u}for(o=0;o<15;o+=1){var u=!r&&1==(n>>o&1);o<8?c[8][h-o-1]=u:o<9?c[8][15-o-1+1]=u:c[8][15-o-1]=u}c[h-8][8]=!r},M=function(r,t){for(var e=-1,n=h-1,o=7,i=0,u=a.getMaskFunction(t),f=h-1;f>0;f-=2)for(6==f&&(f-=1);;){for(var g=0;g<2;g+=1)if(null==c[n][f-g]){var l=!1;i<r.length&&(l=1==(r[i]>>>o&1)),u(n,f-g)&&(l=!l),c[n][f-g]=l,-1==(o-=1)&&(i+=1,o=7)}if((n+=e)<0||h<=n){n-=e,e=-e;break}}},C=function(t,e){for(var n=0,o=0,i=0,u=new Array(e.length),f=new Array(e.length),g=0;g<e.length;g+=1){var c=e[g].dataCount,h=e[g].totalCount-c;o=Math.max(o,c),i=Math.max(i,h),u[g]=new Array(c);for(d=0;d<u[g].length;d+=1)u[g][d]=255&t.getBuffer()[d+n];n+=c;var l=a.getErrorCorrectPolynomial(h),s=r(u[g],l.getLength()-1).mod(l);f[g]=new Array(l.getLength()-1);for(d=0;d<f[g].length;d+=1){var v=d+s.getLength()-f[g].length;f[g][d]=v>=0?s.getAt(v):0}}for(var w=0,d=0;d<e.length;d+=1)w+=e[d].totalCount;for(var y=new Array(w),A=0,d=0;d<o;d+=1)for(g=0;g<e.length;g+=1)d<u[g].length&&(y[A]=u[g][d],A+=1);for(d=0;d<i;d+=1)for(g=0;g<e.length;g+=1)d<f[g].length&&(y[A]=f[g][d],A+=1);return y},D=function(r,t,e){for(var n=u.getRSBlocks(r,t),o=f(),i=0;i<e.length;i+=1){var g=e[i];o.put(g.getMode(),4),o.put(g.getLength(),a.getLengthInBits(g.getMode(),r)),g.write(o)}for(var c=0,i=0;i<n.length;i+=1)c+=n[i].dataCount;if(o.getLengthInBits()>8*c)throw new Error("code length overflow. ("+o.getLengthInBits()+">"+8*c+")");for(o.getLengthInBits()+4<=8*c&&o.put(0,4);o.getLengthInBits()%8!=0;)o.putBit(!1);for(;;){if(o.getLengthInBits()>=8*c)break;if(o.put(236,8),o.getLengthInBits()>=8*c)break;o.put(17,8)}return C(o,n)};return w.addData=function(r){var t=g(r);s.push(t),l=null},w.isDark=function(r,t){if(r<0||h<=r||t<0||h<=t)throw new Error(r+","+t);return c[r][t]},w.getModuleCount=function(){return h},w.make=function(){d(!1,A())},w.createTableTag=function(r,t){r=r||2;var e="";e+='<table style="',e+=" border-width: 0px; border-style: none;",e+=" border-collapse: collapse;",e+=" padding: 0px; margin: "+(t=void 0===t?4*r:t)+"px;",e+='">',e+="<tbody>";for(var n=0;n<w.getModuleCount();n+=1){e+="<tr>";for(var o=0;o<w.getModuleCount();o+=1)e+='<td style="',e+=" border-width: 0px; border-style: none;",e+=" border-collapse: collapse;",e+=" padding: 0px; margin: 0px;",e+=" width: "+r+"px;",e+=" height: "+r+"px;",e+=" background-color: ",e+=w.isDark(n,o)?"#000000":"#ffffff",e+=";",e+='"/>';e+="</tr>"}return e+="</tbody>",e+="</table>"},w.createImgTag=function(r,t,e){r=r||2;var n=t=void 0===t?4*r:t,o=w.getModuleCount()*r+t;return v(e,e,function(t,e){if(n<=t&&t<o&&n<=e&&e<o){var a=Math.floor((t-n)/r),i=Math.floor((e-n)/r);return w.isDark(i,a)?0:1}return 1})},w};t.stringToBytes=function(r){for(var t=new Array,e=0;e<r.length;e+=1){var n=r.charCodeAt(e);t.push(255&n)}return t},t.createStringToBytes=function(r,t){var e=function(){for(var e=l(r),n=function(){var r=e.read();if(-1==r)throw new Error;return r},o=0,a={};;){var i=e.read();if(-1==i)break;var u=n(),f=n()<<8|n();a[String.fromCharCode(i<<8|u)]=f,o+=1}if(o!=t)throw new Error(o+" != "+t);return a}(),n="?".charCodeAt(0);return function(r){for(var t=new Array,o=0;o<r.length;o+=1){var a=r.charCodeAt(o);if(a<128)t.push(a);else{var i=e[r.charAt(o)];"number"==typeof i?(255&i)==i?t.push(i):(t.push(i>>>8),t.push(255&i)):t.push(n)}}return t}};var e={MODE_NUMBER:1,MODE_ALPHA_NUM:2,MODE_8BIT_BYTE:4,MODE_KANJI:8},n={L:1,M:0,Q:3,H:2},o={PATTERN000:0,PATTERN001:1,PATTERN010:2,PATTERN011:3,PATTERN100:4,PATTERN101:5,PATTERN110:6,PATTERN111:7},a=function(){var t=[[],[6,18],[6,22],[6,26],[6,30],[6,34],[6,22,38],[6,24,42],[6,26,46],[6,28,50],[6,30,54],[6,32,58],[6,34,62],[6,26,46,66],[6,26,48,70],[6,26,50,74],[6,30,54,78],[6,30,56,82],[6,30,58,86],[6,34,62,90],[6,28,50,72,94],[6,26,50,74,98],[6,30,54,78,102],[6,28,54,80,106],[6,32,58,84,110],[6,30,58,86,114],[6,34,62,90,118],[6,26,50,74,98,122],[6,30,54,78,102,126],[6,26,52,78,104,130],[6,30,56,82,108,134],[6,34,60,86,112,138],[6,30,58,86,114,142],[6,34,62,90,118,146],[6,30,54,78,102,126,150],[6,24,50,76,102,128,154],[6,28,54,80,106,132,158],[6,32,58,84,110,136,162],[6,26,54,82,110,138,166],[6,30,58,86,114,142,170]],n={},a=function(r){for(var t=0;0!=r;)t+=1,r>>>=1;return t};return n.getBCHTypeInfo=function(r){for(var t=r<<10;a(t)-a(1335)>=0;)t^=1335<<a(t)-a(1335);return 21522^(r<<10|t)},n.getBCHTypeNumber=function(r){for(var t=r<<12;a(t)-a(7973)>=0;)t^=7973<<a(t)-a(7973);return r<<12|t},n.getPatternPosition=function(r){return t[r-1]},n.getMaskFunction=function(r){switch(r){case o.PATTERN000:return function(r,t){return(r+t)%2==0};case o.PATTERN001:return function(r,t){return r%2==0};case o.PATTERN010:return function(r,t){return t%3==0};case o.PATTERN011:return function(r,t){return(r+t)%3==0};case o.PATTERN100:return function(r,t){return(Math.floor(r/2)+Math.floor(t/3))%2==0};case o.PATTERN101:return function(r,t){return r*t%2+r*t%3==0};case o.PATTERN110:return function(r,t){return(r*t%2+r*t%3)%2==0};case o.PATTERN111:return function(r,t){return(r*t%3+(r+t)%2)%2==0};default:throw new Error("bad maskPattern:"+r)}},n.getErrorCorrectPolynomial=function(t){for(var e=r([1],0),n=0;n<t;n+=1)e=e.multiply(r([1,i.gexp(n)],0));return e},n.getLengthInBits=function(r,t){if(1<=t&&t<10)switch(r){case e.MODE_NUMBER:return 10;case e.MODE_ALPHA_NUM:return 9;case e.MODE_8BIT_BYTE:case e.MODE_KANJI:return 8;default:throw new Error("mode:"+r)}else if(t<27)switch(r){case e.MODE_NUMBER:return 12;case e.MODE_ALPHA_NUM:return 11;case e.MODE_8BIT_BYTE:return 16;case e.MODE_KANJI:return 10;default:throw new Error("mode:"+r)}else{if(!(t<41))throw new Error("type:"+t);switch(r){case e.MODE_NUMBER:return 14;case e.MODE_ALPHA_NUM:return 13;case e.MODE_8BIT_BYTE:return 16;case e.MODE_KANJI:return 12;default:throw new Error("mode:"+r)}}},n.getLostPoint=function(r){for(var t=r.getModuleCount(),e=0,n=0;n<t;n+=1)for(c=0;c<t;c+=1){for(var o=0,a=r.isDark(n,c),i=-1;i<=1;i+=1)if(!(n+i<0||t<=n+i))for(var u=-1;u<=1;u+=1)c+u<0||t<=c+u||0==i&&0==u||a==r.isDark(n+i,c+u)&&(o+=1);o>5&&(e+=3+o-5)}for(n=0;n<t-1;n+=1)for(c=0;c<t-1;c+=1){var f=0;r.isDark(n,c)&&(f+=1),r.isDark(n+1,c)&&(f+=1),r.isDark(n,c+1)&&(f+=1),r.isDark(n+1,c+1)&&(f+=1),0!=f&&4!=f||(e+=3)}for(n=0;n<t;n+=1)for(c=0;c<t-6;c+=1)r.isDark(n,c)&&!r.isDark(n,c+1)&&r.isDark(n,c+2)&&r.isDark(n,c+3)&&r.isDark(n,c+4)&&!r.isDark(n,c+5)&&r.isDark(n,c+6)&&(e+=40);for(c=0;c<t;c+=1)for(n=0;n<t-6;n+=1)r.isDark(n,c)&&!r.isDark(n+1,c)&&r.isDark(n+2,c)&&r.isDark(n+3,c)&&r.isDark(n+4,c)&&!r.isDark(n+5,c)&&r.isDark(n+6,c)&&(e+=40);for(var g=0,c=0;c<t;c+=1)for(n=0;n<t;n+=1)r.isDark(n,c)&&(g+=1);return e+=10*(Math.abs(100*g/t/t-50)/5)},n}(),i=function(){for(var r=new Array(256),t=new Array(256),e=0;e<8;e+=1)r[e]=1<<e;for(e=8;e<256;e+=1)r[e]=r[e-4]^r[e-5]^r[e-6]^r[e-8];for(e=0;e<255;e+=1)t[r[e]]=e;var n={};return n.glog=function(r){if(r<1)throw new Error("glog("+r+")");return t[r]},n.gexp=function(t){for(;t<0;)t+=255;for(;t>=256;)t-=255;return r[t]},n}(),u=function(){var r=[[1,26,19],[1,26,16],[1,26,13],[1,26,9],[1,44,34],[1,44,28],[1,44,22],[1,44,16],[1,70,55],[1,70,44],[2,35,17],[2,35,13],[1,100,80],[2,50,32],[2,50,24],[4,25,9],[1,134,108],[2,67,43],[2,33,15,2,34,16],[2,33,11,2,34,12],[2,86,68],[4,43,27],[4,43,19],[4,43,15],[2,98,78],[4,49,31],[2,32,14,4,33,15],[4,39,13,1,40,14],[2,121,97],[2,60,38,2,61,39],[4,40,18,2,41,19],[4,40,14,2,41,15],[2,146,116],[3,58,36,2,59,37],[4,36,16,4,37,17],[4,36,12,4,37,13],[2,86,68,2,87,69],[4,69,43,1,70,44],[6,43,19,2,44,20],[6,43,15,2,44,16],[4,101,81],[1,80,50,4,81,51],[4,50,22,4,51,23],[3,36,12,8,37,13],[2,116,92,2,117,93],[6,58,36,2,59,37],[4,46,20,6,47,21],[7,42,14,4,43,15],[4,133,107],[8,59,37,1,60,38],[8,44,20,4,45,21],[12,33,11,4,34,12],[3,145,115,1,146,116],[4,64,40,5,65,41],[11,36,16,5,37,17],[11,36,12,5,37,13],[5,109,87,1,110,88],[5,65,41,5,66,42],[5,54,24,7,55,25],[11,36,12],[5,122,98,1,123,99],[7,73,45,3,74,46],[15,43,19,2,44,20],[3,45,15,13,46,16],[1,135,107,5,136,108],[10,74,46,1,75,47],[1,50,22,15,51,23],[2,42,14,17,43,15],[5,150,120,1,151,121],[9,69,43,4,70,44],[17,50,22,1,51,23],[2,42,14,19,43,15],[3,141,113,4,142,114],[3,70,44,11,71,45],[17,47,21,4,48,22],[9,39,13,16,40,14],[3,135,107,5,136,108],[3,67,41,13,68,42],[15,54,24,5,55,25],[15,43,15,10,44,16],[4,144,116,4,145,117],[17,68,42],[17,50,22,6,51,23],[19,46,16,6,47,17],[2,139,111,7,140,112],[17,74,46],[7,54,24,16,55,25],[34,37,13],[4,151,121,5,152,122],[4,75,47,14,76,48],[11,54,24,14,55,25],[16,45,15,14,46,16],[6,147,117,4,148,118],[6,73,45,14,74,46],[11,54,24,16,55,25],[30,46,16,2,47,17],[8,132,106,4,133,107],[8,75,47,13,76,48],[7,54,24,22,55,25],[22,45,15,13,46,16],[10,142,114,2,143,115],[19,74,46,4,75,47],[28,50,22,6,51,23],[33,46,16,4,47,17],[8,152,122,4,153,123],[22,73,45,3,74,46],[8,53,23,26,54,24],[12,45,15,28,46,16],[3,147,117,10,148,118],[3,73,45,23,74,46],[4,54,24,31,55,25],[11,45,15,31,46,16],[7,146,116,7,147,117],[21,73,45,7,74,46],[1,53,23,37,54,24],[19,45,15,26,46,16],[5,145,115,10,146,116],[19,75,47,10,76,48],[15,54,24,25,55,25],[23,45,15,25,46,16],[13,145,115,3,146,116],[2,74,46,29,75,47],[42,54,24,1,55,25],[23,45,15,28,46,16],[17,145,115],[10,74,46,23,75,47],[10,54,24,35,55,25],[19,45,15,35,46,16],[17,145,115,1,146,116],[14,74,46,21,75,47],[29,54,24,19,55,25],[11,45,15,46,46,16],[13,145,115,6,146,116],[14,74,46,23,75,47],[44,54,24,7,55,25],[59,46,16,1,47,17],[12,151,121,7,152,122],[12,75,47,26,76,48],[39,54,24,14,55,25],[22,45,15,41,46,16],[6,151,121,14,152,122],[6,75,47,34,76,48],[46,54,24,10,55,25],[2,45,15,64,46,16],[17,152,122,4,153,123],[29,74,46,14,75,47],[49,54,24,10,55,25],[24,45,15,46,46,16],[4,152,122,18,153,123],[13,74,46,32,75,47],[48,54,24,14,55,25],[42,45,15,32,46,16],[20,147,117,4,148,118],[40,75,47,7,76,48],[43,54,24,22,55,25],[10,45,15,67,46,16],[19,148,118,6,149,119],[18,75,47,31,76,48],[34,54,24,34,55,25],[20,45,15,61,46,16]],t=function(r,t){var e={};return e.totalCount=r,e.dataCount=t,e},e={},o=function(t,e){switch(e){case n.L:return r[4*(t-1)+0];case n.M:return r[4*(t-1)+1];case n.Q:return r[4*(t-1)+2];case n.H:return r[4*(t-1)+3];default:return}};return e.getRSBlocks=function(r,e){var n=o(r,e);if(void 0===n)throw new Error("bad rs block [url=home.php?mod=space&uid=5302]@[/url] typeNumber:"+r+"/errorCorrectLevel:"+e);for(var a=n.length/3,i=new Array,u=0;u<a;u+=1)for(var f=n[3*u+0],g=n[3*u+1],c=n[3*u+2],h=0;h<f;h+=1)i.push(t(g,c));return i},e}(),f=function(){var r=new Array,t=0,e={};return e.getBuffer=function(){return r},e.getAt=function(t){var e=Math.floor(t/8);return 1==(r[e]>>>7-t%8&1)},e.put=function(r,t){for(var n=0;n<t;n+=1)e.putBit(1==(r>>>t-n-1&1))},e.getLengthInBits=function(){return t},e.putBit=function(e){var n=Math.floor(t/8);r.length<=n&&r.push(0),e&&(r[n]|=128>>>t%8),t+=1},e},g=function(r){for(var t=e.MODE_8BIT_BYTE,n=r,o=[],a={},i=0,u=n.length;i<u;i++){var f=[],g=n.charCodeAt(i);g>65536?(f[0]=240|(1835008&g)>>>18,f[1]=128|(258048&g)>>>12,f[2]=128|(4032&g)>>>6,f[3]=128|63&g):g>2048?(f[0]=224|(61440&g)>>>12,f[1]=128|(4032&g)>>>6,f[2]=128|63&g):g>128?(f[0]=192|(1984&g)>>>6,f[1]=128|63&g):f[0]=g,o.push(f)}(o=Array.prototype.concat.apply([],o)).length!=n.length&&(o.unshift(191),o.unshift(187),o.unshift(239));var c=o;return a.getMode=function(){return t},a.getLength=function(r){return c.length},a.write=function(r){for(var t=0;t<c.length;t+=1)r.put(c[t],8)},a},c=function(){var r=new Array,t={};return t.writeByte=function(t){r.push(255&t)},t.writeShort=function(r){t.writeByte(r),t.writeByte(r>>>8)},t.writeBytes=function(r,e,n){e=e||0,n=n||r.length;for(var o=0;o<n;o+=1)t.writeByte(r[o+e])},t.writeString=function(r){for(var e=0;e<r.length;e+=1)t.writeByte(r.charCodeAt(e))},t.toByteArray=function(){return r},t.toString=function(){var t="";t+="[";for(var e=0;e<r.length;e+=1)e>0&&(t+=","),t+=r[e];return t+="]"},t},h=function(){var r=0,t=0,e=0,n="",o={},a=function(r){n+=String.fromCharCode(i(63&r))},i=function(r){if(r<0);else{if(r<26)return 65+r;if(r<52)return r-26+97;if(r<62)return r-52+48;if(62==r)return 43;if(63==r)return 47}throw new Error("n:"+r)};return o.writeByte=function(n){for(r=r<<8|255&n,t+=8,e+=1;t>=6;)a(r>>>t-6),t-=6},o.flush=function(){if(t>0&&(a(r<<6-t),r=0,t=0),e%3!=0)for(var o=3-e%3,i=0;i<o;i+=1)n+="="},o.toString=function(){return n},o},l=function(r){var t=r,e=0,n=0,o=0,a={};a.read=function(){for(;o<8;){if(e>=t.length){if(0==o)return-1;throw new Error("unexpected end of file./"+o)}var r=t.charAt(e);if(e+=1,"="==r)return o=0,-1;r.match(/^\s$/)||(n=n<<6|i(r.charCodeAt(0)),o+=6)}var a=n>>>o-8&255;return o-=8,a};var i=function(r){if(65<=r&&r<=90)return r-65;if(97<=r&&r<=122)return r-97+26;if(48<=r&&r<=57)return r-48+52;if(43==r)return 62;if(47==r)return 63;throw new Error("c:"+r)};return a},s=function(r,t){var e=r,n=t,o=new Array(r*t),a={};a.setPixel=function(r,t,n){o[t*e+r]=n},a.write=function(r){r.writeString("GIF87a"),r.writeShort(e),r.writeShort(n),r.writeByte(128),r.writeByte(0),r.writeByte(0),r.writeByte(0),r.writeByte(0),r.writeByte(0),r.writeByte(255),r.writeByte(255),r.writeByte(255),r.writeString(","),r.writeShort(0),r.writeShort(0),r.writeShort(e),r.writeShort(n),r.writeByte(0);var t=u(2);r.writeByte(2);for(var o=0;t.length-o>255;)r.writeByte(255),r.writeBytes(t,o,255),o+=255;r.writeByte(t.length-o),r.writeBytes(t,o,t.length-o),r.writeByte(0),r.writeString(";")};var i=function(r){var t=r,e=0,n=0,o={};return o.write=function(r,o){if(r>>>o!=0)throw new Error("length over");for(;e+o>=8;)t.writeByte(255&(r<<e|n)),o-=8-e,r>>>=8-e,n=0,e=0;n|=r<<e,e+=o},o.flush=function(){e>0&&t.writeByte(n)},o},u=function(r){for(var t=1<<r,e=1+(1<<r),n=r+1,a=f(),u=0;u<t;u+=1)a.add(String.fromCharCode(u));a.add(String.fromCharCode(t)),a.add(String.fromCharCode(e));var g=c(),h=i(g);h.write(t,n);var l=0,s=String.fromCharCode(o[l]);for(l+=1;l<o.length;){var v=String.fromCharCode(o[l]);l+=1,a.contains(s+v)?s+=v:(h.write(a.indexOf(s),n),a.size()<4095&&(a.size()==1<<n&&(n+=1),a.add(s+v)),s=v)}return h.write(a.indexOf(s),n),h.write(e,n),h.flush(),g.toByteArray()},f=function(){var r={},t=0,e={};return e.add=function(n){if(e.contains(n))throw new Error("dup key:"+n);r[n]=t,t+=1},e.size=function(){return t},e.indexOf=function(t){return r[t]},e.contains=function(t){return void 0!==r[t]},e};return a},v=function(r,t,e,n){for(var o=s(r,t),a=0;a<t;a+=1)for(var i=0;i<r;i+=1)o.setPixel(i,a,e(i,a));var u=c();o.write(u);for(var f=h(),g=u.toByteArray(),l=0;l<g.length;l+=1)f.writeByte(g[l]);f.flush();var v="";return v+="data:image/gif;base64,",v+=f};module.exports={createQrCodeImg:function(r,e){var n,o=(e=e||{}).typeNumber||4,a=e.errorCorrectLevel||"M",i=e.size||500;try{(n=t(o,a||"M")).addData(r),n.make()}catch(t){if(o>=40)throw new Error("Text too long to encode");return gen(r,{size:i,errorCorrectLevel:a,typeNumber:o+1})}var u=parseInt(i/n.getModuleCount()),f=parseInt((i-n.getModuleCount()*u)/2);return n.createImgTag(u,f,i)}}; 
 			}); 
		define("app.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e=require("utils/WSCoordinate.js"),t=require("utils/util.js");App({configObj:require("./config"),memberObj:{},leaseDataObj:{},toWxMiniProgram:!1,bluetoothDataObj:{},customizedCDB:{},bluetoothRefundRequesting:!1,clickable:!0,memberCallback:!1,onLaunch:function(e){var t=this,a=wx.getStorageSync("userid");t.dataObj.user_id=a,t.adv_dataObj.userid=a;var o=e.scene;if("1011"==o||"1012"==o||"1013"==o||"1025"==o||"1031"==o||"1032"==o||"1047"==o||"1048"==o||"1049"==o);else;t.login(),t.getLocation(),wx.getSystemInfo({success:function(e){wx.setStorageSync("model",e.model);var a=e.system.split(" "),o=a[0],n=a[1];t.dataObj.version=e.version,t.dataObj.manufacturer=e.brand,t.dataObj.model=e.model.replace(/\s+/g,""),t.dataObj.os=o,t.dataObj.os_version=n,t.globalData.SDKVersion=e.SDKVersion,t.adv_dataObj.version=e.version,t.adv_dataObj.manufacturer=e.brand,t.adv_dataObj.model=e.model.replace(/\s+/g,""),t.adv_dataObj.os=o,t.adv_dataObj.os_version=n}})},onShow:function(e){var t=this;if(t.updataZFFData("onShow",t.toWxMiniProgram,e),1038===e.scene&&t.toWxMiniProgram){t.toWxMiniProgram=!1;var a=e.referrerInfo.appId;if("wxd8f3793ea3b935b8"===a)(o=e.referrerInfo.extraData)?t.creditNotifywx(o.query_id):t.creditNotifywx("");else if("wxbd687630cd02ce1d"===a){wx.showLoading({title:"请稍候",mask:!0});var o=e.referrerInfo.extraData;o?setTimeout(function(){t.applyDeduction()},3e3):setTimeout(function(){t.openingMember(function(e){e&&t.applyDeduction()})},3e3)}else t.leaseDataObj.canTouchZFFBtn=!0}else t.leaseDataObj.canTouchZFFBtn=!0;wx.getNetworkType({success:function(e){t.dataObj.network_type=e.networkType,t.adv_dataObj.network_type=e.networkType}})},dataObj:{pg_version:"1.1.6",bind_type:"微信小程序",nick_name:"",gender:"",phone_num:"",gps:"",version:"",manufacturer:"",model:"",os:"",os_version:"",network_type:"",station_id:"",user_id:"",act_obj:"",other:"",create_time:"",referrer_title:""},adv_dataObj:{pg_version:"1.1.6",bind_type:"WX",gps:"",userid:"",create_time:"",nick_name:"",gender:"",version:"",manufacturer:"",model:"",os:"",os_version:"",network_type:"",other:""},login:function(){var e=this;this.globalData.session||wx.login({success:function(t){t.code&&wx.getUserInfo({success:function(a){e.dataObj.nick_name=a.userInfo.nickName,e.dataObj.gender=a.userInfo.gender,e.adv_dataObj.nick_name=a.userInfo.nickName,e.adv_dataObj.gender=a.userInfo.gender,e.globalData.authCode=t.code,e.loginServer(t.code,a.encryptedData,a.iv)}})},complete:function(){}})},loginServer:function(e,t,a){var o=this;wx.request({url:o.configObj.loginUrl,data:{code:e,encryptedData:t,iv:a},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(e){0==e.data.code?(getApp().globalData.trdSessionId=e.data.data.trdSessionId,getApp().globalData.session=e.data.data.session,console.log("session:"+e.data.data.session),wx.setStorageSync("userid",e.data.data.userid),o.dataObj.user_id=e.data.data.userid,o.adv_dataObj.userid=e.data.data.userid,o.userLoginSuccessCallback&&o.userLoginSuccessCallback(e)):wx.showToast({title:"登录失败",icon:"none"})},fail:function(){wx.showToast({title:"网络错误，请稍后重试",icon:"none"})},complete:function(){}})},userInfoRequest:function(e){var t=this;wx.request({url:t.configObj.userInfoUrl,data:{session:t.globalData.session},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(a){5==a.data.code?(getApp().globalData.session=null,getApp().login()):0==a.data.code&&(t.globalData.userInfo=a.data.data.user_info,t.globalData.userInfo.phone_num=a.data.data.phone_num,e&&e())}})},qrCode:function(e){wx.scanCode({success:function(t){e(t.result)},fail:function(e){},complete:function(e){}})},globalData:{userInfo:null,session:null,authCode:null,trdSessionId:null,authToUrl:null},getLocation:function(){var t=this;wx.getLocation({success:function(a){var o=e.transformFromWGSToGCJ(a.latitude,a.longitude),n=o.longitude+","+o.latitude;t.dataObj.gps=n,t.adv_dataObj.gps=n;var i=o.latitude+","+o.longitude;t.addgps=i,t.addressResolution(i)},fail:function(e){t.adVertiseInfo("000000")}})},addressResolution:function(e){var t=this;wx.request({url:"https://apis.map.qq.com/ws/geocoder/v1/",data:{key:"GMZBZ-EDAL3-UFV3X-37FOM-NOTC7-5ZB42",location:e},method:"GET",success:function(e){var a=e.data.result.ad_info.city_code;if(a)o=(o=(o=(o=(o=a.substring(3)).replace(/110000/g,"110100")).replace(/310000/g,"310100")).replace(/500000/g,"500100")).replace(/120000/g,"120100"),t.advcheckChange(o),wx.setStorageSync("city_code",o),t.globalData.city_code=o;else{var o=wx.getStorageSync("city_code");t.globalData.city_code=wx.getStorageSync("city_code"),t.adVertiseInfo(o)}},fail:function(){var e=wx.getStorageSync("city_code");t.adVertiseInfo(e)}})},advcheckChange:function(e){var t=this;wx.request({url:t.configObj.checkChangeAdv,data:{type:"03",cityCode:e},method:"POST",header:{"Content-Type":"application/json"},success:function(a){if("0000"==a.data.errcode){var o=a.data.data;wx.getStorageSync("advtimeStamp")!=o?t.adVertiseInfo(e,o):(t.advRequested=!0,t.rootLoadAd&&t.rootLoadAd())}},fail:function(e){console.log(e)}})},adVertiseInfo:function(e,t){var a=this;wx.request({url:a.configObj.getAdvertiseInfo,data:{type:"03",cityCode:e},method:"POST",header:{"Content-Type":"application/json"},success:function(e){if("0000"==e.data.errcode){for(var o=e.data.data,n={},i=0;i<o.length;i++)n[o[i].spaceCode]=o[i];n=JSON.stringify(n),wx.setStorageSync("advtimeStamp",t),wx.setStorageSync("adv_obj",n)}else"0004"==e.data.errcode&&(wx.setStorageSync("advtimeStamp",t),wx.setStorageSync("adv_obj","{}"));a.advRequested=!0,a.rootLoadAd&&a.rootLoadAd()},fail:function(e){console.log(e)}})},bluetoothRefund:function(e,t){if(!this.bluetoothRefundRequesting){this.bluetoothRefundRequesting=!0;var a=this;wx.request({url:a.configObj.bluetoothOrderRefund,data:{session:a.globalData.session,operationType:3,orderid:e},method:"POST",header:{"Content-Type":"application/x-www-form-urlencoded"},success:function(e){t&&t()},complete:function(){a.bluetoothRefundRequesting=!1}})}},playAudio:function(e){this.innerAudioContext||(this.innerAudioContext=wx.createInnerAudioContext(),this.innerAudioContext.autoplay=!0);var t=this;setTimeout(function(){t.innerAudioContext.stop(),t.innerAudioContext.src=e,t.innerAudioContext.play()},1e3)},http_post:function(e){var a=this;a.dataObj.create_time=t.formatDateAndTime(new Date);var o=a.dataObj,n=Object.assign({},o,e);if(n.APIVersion="0.6.0","view"==n.bhv_type||"start"==n.bhv_type)i=a.configObj.buryingView;else var i=a.configObj.buryingClick;wx.request({url:i,data:n,method:"GET",header:{"Content-Type":"application/json"},success:function(e){},fail:function(e){}}),a.dataObj.other=""},adv_http_post:function(e){var t=this,a=(new Date).getTime();t.adv_dataObj.create_time=a;var o=t.adv_dataObj,n=Object.assign({},o,e);if(n.APIVersion="0.6.0","view"==n.bhv_type)i=t.configObj.advBuryingView;else var i=t.configObj.advBuryingClick;wx.request({url:i,data:n,method:"GET",header:{"Content-Type":"application/json"},success:function(e){},fail:function(e){}})},advExposure:function(e,t){this.adv_http_post({bhv_type:"view",ad_positionid:t,ad_spaceid:e.flowSourceSpaceId,ad_planid:e.planId,loadpage:""})},pushAdv:function(e,t){var a=this;a.adv_http_post({bhv_type:"click",ad_positionid:t,ad_spaceid:e.flowSourceSpaceId,ad_planid:e.planId,loadpage:e.checkUrl});var o=e.checkUrl;e.appId?a.clickable&&(a.clickable=!1,wx.navigateToMiniProgram({appId:e.appId,path:o,envVersion:"release",complete:function(){a.clickable=!0}})):o&&(0==o.indexOf("https")?wx.navigateTo({url:"/pages/advertising-h5/advertising-h5?advurl="+encodeURIComponent(o)}):wx.navigateTo({url:o}))},openingMember:function(e){var t=this;wx.request({url:t.configObj.productDetail,data:{session:t.globalData.session,version:"1.0"},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(t){0==t.data.code&&"function"==typeof e&&e(t.data.data.signing_code)},fail:function(){},complete:function(){wx.hideLoading()}})},updataZFFData:function(e,t,a){var o=this.leaseDataObj.orderid,n=this.adv_dataObj.userid;a=JSON.stringify(a),o&&wx.request({url:this.configObj.seversLogs,data:{loginfo:"支付分返回小程序-userid="+n+",orderid="+o+",type="+e+",no="+t+",res="+a},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST"})}}); 
 			}); 	require("app.js");
 		__wxRoute = 'packageuser/user/myCoupon/couponCell/couponCell';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'packageuser/user/myCoupon/couponCell/couponCell.js';	define("packageuser/user/myCoupon/couponCell/couponCell.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";require("../../../../utils/util.js");Component({properties:{couponData:{type:Map,value:{},observer:"onCouponData"}},data:{},methods:{onCouponData:function(e){e.endTime=e.end_time.replace(/\./g,"-"),this.setData({couponData:e})}}}); 
 			}); 	require("packageuser/user/myCoupon/couponCell/couponCell.js");
 		__wxRoute = 'pages/index/index';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/index/index.js';	define("pages/index/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e=require("../../utils/util.js"),t=require("../../utils/WSCoordinate.js"),a=[],o=getApp();Page({adv_objStr:{},requestLoc:{},shopRequestNum:0,selIndex:-1,data:{orderIngNum:0,hiddenTab:!0,tabIndex:-1,tabListLength:0,longitude:116.39747,latitude:39.908823,memberURL:"/images/root/headTitle.png",memberURLclick:"0",memberImgWidth:"300rpx",returnAd:!0},bindViewTap:function(){getApp().http_post({bhv_type:"click",obj_type:"Control",title:"首页",control_name:"首页_我的头像",act_obj:10010}),o.globalData.session?wx.navigateTo({url:"/packageuser/user/user"}):wx.getSetting({success:function(e){e.authSetting["scope.userInfo"]?o.login():wx.navigateTo({url:"/pages/index/authorization/authorization"})}})},ipt:function(){var e=this.data.loclatitude,t=this.data.loclongitude,a=this.data.madename;getApp().http_post({bhv_type:"click",obj_type:"Control",title:"首页",control_name:"首页_附近网点",other:{madename:a},act_obj:10013}),o.globalData.session?wx.navigateTo({url:"/packagenearby/nearby/nearby?latitude="+e+"&longitude="+t+"&madename="+a}):wx.getSetting({success:function(e){e.authSetting["scope.userInfo"]?o.login():wx.navigateTo({url:"/pages/index/authorization/authorization"})}})},openingMember:function(){if("1"==this.data.memberURLclick){getApp().http_post({bhv_type:"click",obj_type:"Control",title:"首页",control_name:"首页_点击会员按钮",other:{},act_obj:10076}),wx.navigateTo({url:"/pages/index/member/member?backRoot=true&referrer_title=首页"})}},onMapTap:function(e){var t=this;e.detail.value;wx.showToast({title:"加载选取工具",icon:"loading",duration:500}),wx.getSetting({success:function(e){e.authSetting["scope.userLocation"]?wx.chooseLocation({success:function(e){t.getNearbyShops(e.latitude,e.longitude),t.setData({addressName:e.name,longitude:e.longitude,latitude:e.latitude})}}):wx.showToast({title:"未授权地理位置",icon:"none",duration:2e3})}})},bindheaderTab:function(e){var t=this,a=e.currentTarget.dataset.index;if(a!=t.data.tabIndex){var o="-1"==a?"普通首页":"定制首页";getApp().http_post({bhv_type:"click",obj_type:"Control",title:"首页",control_name:"首页_Tab按钮",other:{type:o},act_obj:10068}),t.setData({tabIndex:a}),t.shopsFilter(),t.uncheckMark()}},onLoad:function(e){var a,i=this;a=wx.getStorageSync("model").indexOf("iPhone")>=0?500:1e3,i.mapCtx=wx.createMapContext("ycbmap"),wx.getSetting({success:function(e){e.authSetting["scope.userInfo"]||e.authSetting["scope.userLocation"]?wx.getLocation({success:function(e){var a=t.transformFromWGSToGCJ(e.latitude,e.longitude);i.setData({longitude:a.longitude,latitude:a.latitude,userLocation:!0})},fail:function(){i.setData({userLocation:!1}),setTimeout(function(){i.movetoPosition()},a)}}):(i.setData({userLocation:!1}),setTimeout(function(){i.movetoPosition()},a))}}),o.userLoginSuccessCallback=function(){i.getCenterLocation(),i.getRentedRecords(),i.statusMember()},e.pushSweep&&setTimeout(function(){wx.navigateTo({url:"/pages/index/sweep/sweep?qrcode="+e.qrcode+"&referrer_title="+e.referrer_title})},200),o.innerAudioContext&&o.innerAudioContext.stop()},onShow:function(){var e=this;e.closeBLEConnection(),o.globalData.session&&(e.getRentedRecords(),e.statusMember()),e.showed&&e.getCenterLocation(),e.showed=!0,wx.getSetting({success:function(t){t.authSetting["scope.userLocation"]?e.setData({userLocation:!0}):e.setData({userLocation:!1})}}),o.advRequested?e.update_adv():o.rootLoadAd=e.update_adv},onReady:function(){this.compareVersion(o.globalData.SDKVersion,"1.5.8")<0&&wx.showModal({title:"提示",content:"当前微信版本过低，部分功能无法使用，请升级到最新微信版本后重试。"})},bindregionchange:function(e){"scale"!=e.causedBy&&"end"==e.type&&this.getCenterLocation(!0)},getCenterLocation:function(e){var a=this;a.mapCtx.getCenterLocation({success:function(e){a.getNearbyShops(e.latitude,e.longitude),a.setData({loclatitude:e.latitude,loclongitude:e.longitude});var i=t.transformFromWGSToGCJ(e.latitude,e.longitude),n=i.latitude+","+i.longitude;0!=a.data.userLocation||wx.getStorageSync("advtimeStamp")||o.addressResolution(n)}})},movetoPosition:function(){this.mapCtx.moveToLocation()},getNearbyShops:function(t,a){var i=this;if(o.globalData.session){if(i.requestLoc.latitude){var n=e.getDistance(i.requestLoc.latitude,i.requestLoc.longitude,t,a);if((n=parseInt(n))<250)return}i.requestLoc.latitude=t,i.requestLoc.longitude=a,wx.request({url:o.configObj.nearbyShopsUrl,data:{session:o.globalData.session,longitude:a,latitude:t,citycode:wx.getStorageSync("city_code")},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(e){if(5==e.data.code)getApp().globalData.session=null,getApp().login();else if(0==e.data.code){i.setData({shops:e.data.data.shops});var t=e.data.data.tabList;t.length>0?(i.setData({hiddenTab:!1}),i.setData({tabList:t,tabListLength:t.length})):i.setData({hiddenTab:!0,tabList:t,tabListLength:t.length,tabIndex:-1}),e.data.data.shops.length>0&&i.shopsFilter()}},fail:function(){0==i.shopRequestNum&&i.getNearbyShops(t,a),i.shopRequestNum=1}})}},shopsFilter:function(){var t=this,i=t.data.shops,n=t.data.loclatitude,r=t.data.loclongitude,s=[],d=t.data.tabIndex,c=t.data.tabList;if(-1==d)a=i,t.setData({madename:"普通"});else{var l=c[d].tab_name;t.setData({madename:l}),a=i.filter(function(e){return"true"==e.is_customization})}var u;if(c.length){var h=-1==d?0:d;u=this.compareVersion(o.globalData.SDKVersion,"2.3.0")>=0?c[h].dot_icon:"/images/root/icon_root_shopType.png"}for(var p=t.data.materialUrl_wechat_dmi,g=a.length,m=0;m<g;m++){var b=a[m];if(b.shopType=14,b.dis=parseInt(e.getDistance(n,r,b.latitude,b.longitude)),p)_=p;else var _="/images/root/icon_root_shopType.png";var f={id:m,iconPath:"true"==b.is_customization&&c.length?u:_,latitude:b.latitude,longitude:b.longitude,width:32,height:36,dis:b.dis,oldid:b.id};s.push(f)}t.selIndex=-1,t.setData({markers:s})},getRentedRecords:function(){if(o.globalData.session){var e=this;wx.request({url:o.configObj.rentedRecordsUrl,data:{session:o.globalData.session},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(t){if(0==t.data.code&&t.data.data.orders.length>0){for(var a=[],i=0;i<t.data.data.orders.length;i++)if((2==(c=t.data.data.orders[i]).status||5==c.status||6==c.status||8==c.status||11==c.status)&&(a.push(c),201==c.device_ver)){var n=c.fee_strategy_entity.fixed_time*c.fee_strategy_entity.fixed_unit,r=(new Date).getTime(),s=c.borrow_time.replace(/-/g,"/"),d=Date.parse(new Date(s));n-Math.floor((r-d)/1e3)<=0&&(o.bluetoothRefund(c.orderid),a.pop())}if(1==a.length){var c=a[0];e.setData({orderid:c.orderid,device_ver:c.device_ver})}e.setData({orderIngNum:a.length})}}})}},click:function(){var e=this,t=e.data.tabIndex,a=e.data.madename;getApp().http_post({bhv_type:"click",obj_type:"Control",title:"首页",control_name:"首页_扫码租借",other:{madename:a},act_obj:10009}),o.qrCode(function(i){var n=i.split("/")[3];if("q"==n)if(o.globalData.session)if(-1==t)wx.navigateTo({url:"/pages/index/sweep/sweep?qrcode="+i+"&referrer_title=首页&madename="+a});else{var r=e.data.tabList[e.data.tabIndex];wx.navigateTo({url:"/pages/index/sweepMade/sweepMade?qrcode="+i+"&referrer_title=首页&custom_name="+r.custom_name+"&custom_url="+r.custom_url+"&background_color="+r.background_color+"&adv_url="+r.adv_url+"&madename="+a})}else wx.getSetting({success:function(e){e.authSetting["scope.userInfo"]?o.login():wx.navigateTo({url:"/pages/index/authorization/authorization"})}});else if("x"==n)o.globalData.session?wx.navigateTo({url:"/packageB/Bluetooth/Bluetooth?qrcode="+i+"&referrer_title=首页"}):wx.getSetting({success:function(e){e.authSetting["scope.userInfo"]?o.login():wx.navigateTo({url:"/pages/index/authorization/authorization"})}});else if("c"==n){var s=encodeURIComponent(i);o.globalData.session?wx.navigateTo({url:"/packageA/Lottery/Lottery?qrcode="+s}):wx.getSetting({success:function(e){e.authSetting["scope.userInfo"]?o.login():wx.navigateTo({url:"/pages/index/authorization/authorization"})}})}else wx.showModal({title:"温馨提示",content:"这不是速绿充电的二维码",success:function(e){e.confirm||e.cancel}})})},returnBut:function(){var e=this.data.orderid;getApp().http_post({bhv_type:"click",obj_type:"Control",title:"首页",control_name:"首页_我已归还"}),wx.navigateTo({url:"/pages/ordering/testing/testing?orderid="+e})},toOrderInfo:function(e){var t=this;if(getApp().http_post({bhv_type:"click",obj_type:"Control",title:"首页",control_name:"首页_查看",act_obj:10016}),t.data.orderIngNum>1)wx.navigateTo({url:"/pages/ordering/ordering"});else{var a=t.data.orderid;wx.navigateTo({url:"/pages/ordering/orderingend/orderingend?orderid="+a})}},helpproblem:function(){wx.navigateTo({url:"/pages/helpCenter/helpCenter?orderid="+this.data.orderid+"&csEntryType=1"})},advertising:function(){o.pushAdv(this.adv_objStr.wechat_dsb,"300001")},bindfloatingWindow:function(){o.pushAdv(this.adv_objStr.wechat_df,"300004")},onbinddirectional:function(){o.pushAdv(this.adv_objStr.wechat_dt,"300003"),this.adv_objStr.wechat_dt.checkUrl&&this.hideAd()},hideAd:function(){this.setData({showAd:!1,returnAd:!1})},toShopInfo:function(){getApp().http_post({bhv_type:"click",obj_type:"Control",title:"首页",other:{shopid:this.data.shopSel.ss_id,isipbattery:this.data.isipbattery,madename:this.data.madename},control_name:"首页_商铺选项卡",act_obj:10012});var e=this.data.shopSel.ss_id,t=this.data.shopSel.dis;wx.navigateTo({url:"/packagenearby/nearby/details/details?ss_id="+e+"&dis="+t+"&urladd=1&referrer_title=商铺选项卡"}),this.uncheckMark()},bindmarkertap:function(t){var o=this;setTimeout(function(){var i=o.data.markers,n=o.data.tabIndex,r=-1==n?0:n,s=o.data.tabList;if(i.length>o.selIndex&&-1!=o.selIndex){var d=i[o.selIndex];d.width=32,d.height=36,d.zIndex=100,d.iconPath="/images/root/icon_root_shopType.png"}o.selIndex=t.markerId;var c=i[o.selIndex];c.width=38,c.height=42,c.zIndex=200,c.iconPath="/images/root/icon_root_shopType_sel.png";var l=a[o.selIndex];if(l.shopType=e.getShopType(l.type),"true"==l.is_customization&&s.length)u=s[r].tab_name;else var u="0";l.isipbattery=u,o.setData({shopSel:l,markers:i,showShopInfo:!0}),getApp().http_post({bhv_type:"click",obj_type:"Control",title:"首页",other:{shopid:o.data.shopSel.ss_id,isipbattery:o.data.isipbattery,madename:o.data.madename},control_name:"首页_地图网点图标",act_obj:10011})},100)},uncheckMark:function(){this.setData({showShopInfo:!1});var e=this.data.markers;if(e&&e.length>this.selIndex){if(-1!=this.selIndex){var t=e[this.selIndex];t.width=32,t.height=36,t.zIndex=100,t.iconPath="/images/root/icon_root_shopType.png"}this.setData({markers:e})}},hereto:function(e){var t=Number(this.data.shopSel.latitude),a=Number(this.data.shopSel.longitude),o=e.currentTarget.dataset.name;wx.openLocation({latitude:t,longitude:a,name:o,scale:18})},closeBLEConnection:function(){o.bluetoothDataObj.deviceId&&wx.closeBLEConnection({deviceId:o.bluetoothDataObj.deviceId,success:function(e){console.log("已断开连接！！"),console.log(e)},fail:function(e){console.log("断开连接失败"),console.log(e)}})},statusMember:function(){var e=this;wx.request({url:o.configObj.memberStatus,data:{session:o.globalData.session},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(t){if(0==t.data.code){var a=t.data.data;o.userMemberStatus=a,t.data.isPastDue?(e.setData({memberURL:"/images/Member/memberExpired.png",memberURLclick:"1",memberImgWidth:"380rpx"}),o.memberObj.is_vip=0):"01"==a?(e.shopVipRequest(),o.memberObj.is_vip=0):"02"==a?(e.setData({memberURL:"/images/Member/vipMember.png",memberURLclick:"1",memberImgWidth:"234rpx"}),o.memberObj.is_vip=1):"03"==a?(e.setData({memberURL:"/images/Member/renewmenmber.png",memberURLclick:"1",memberImgWidth:"404rpx"}),o.memberObj.is_vip=1):(e.shopVipRequest(),o.memberObj.is_vip=0)}},fail:function(){},complete:function(){getApp().http_post({bhv_type:"view",obj_type:"Page",title:"首页",other:{},act_obj:10008})}})},shopVipRequest:function(){var e=this;o.userInfoRequest(function(){1==o.globalData.userInfo.is_vip?e.setData({memberURL:"/images/Member/shopVip.png",memberURLclick:"0",memberImgWidth:"244rpx"}):"01"==o.userMemberStatus?e.setData({memberURL:"/images/Member/Openingmember.png",memberURLclick:"1",memberImgWidth:"380rpx"}):e.setData({memberURL:"/images/root/headTitle.png",memberURLclick:"0",memberImgWidth:"300rpx"})})},update_adv:function(){var e=this,t=wx.getStorageSync("adv_obj");t&&(e.adv_objStr=JSON.parse(t),e.adv_objStr.wechat_dt?(e.data.returnAd&&o.advExposure(e.adv_objStr.wechat_dt,"300003"),e.setData({checkUrl_wechat_dt:e.adv_objStr.wechat_dt.checkUrl,materialUrl_wechat_dt:o.configObj.advImgAdd+e.adv_objStr.wechat_dt.materialUrl,showAd:!0})):wx.createInterstitialAd&&!e.adShowed&&(e.adShowed=!0,wx.createInterstitialAd({adUnitId:"adunit-300b88dbb615f027"}).show()),e.adv_objStr.wechat_dsb?(o.advExposure(e.adv_objStr.wechat_dsb,"300001"),e.setData({checkUrl_wechat_dsb:e.adv_objStr.wechat_dsb.checkUrl,materialUrl_wechat_dsb:o.configObj.advImgAdd+e.adv_objStr.wechat_dsb.materialUrl})):e.setData({showAd_banner_before:!0}),e.adv_objStr.wechat_dmi&&e.setData({checkUrl_wechat_dmi:e.adv_objStr.wechat_dmi.checkUrl,materialUrl_wechat_dmi:o.configObj.advImgAdd+e.adv_objStr.wechat_dmi.materialUrl}),e.adv_objStr.wechat_df&&(o.advExposure(e.adv_objStr.wechat_df,"300004"),e.setData({checkUrl_wechat_df:e.adv_objStr.wechat_df.checkUrl,materialUrl_wechat_df:o.configObj.advImgAdd+e.adv_objStr.wechat_df.materialUrl})))},compareVersion:function(e,t){if(void 0==e||void 0==t)return 1;for(var e=e.split("."),t=t.split("."),a=Math.max(e.length,t.length);e.length<a;)e.push("0");for(;t.length<a;)t.push("0");for(var o=0;o<a;o++){var i=parseInt(e[o]),n=parseInt(t[o]);if(i>n)return 1;if(i<n)return-1}return 0},adLoadFinish_banner:function(e){this.setData({showAd_banner:!0})},onShareAppMessage:function(){}}); 
 			}); 	require("pages/index/index.js");
 		__wxRoute = 'pages/index/authorization/authorization';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/index/authorization/authorization.js';	define("pages/index/authorization/authorization.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=getApp();Page({authUrl:"",onLoad:function(e){this.authUrl=t.globalData.authToUrl,t.globalData.authToUrl=null},onShow:function(){getApp().http_post({bhv_type:"view",obj_type:"Page",title:"授权登陆页",act_obj:10006})},bindbut:function(e){e.detail.userInfo?(console.log("用户按了允许授权按钮"),t.login(),setTimeout(function(){getApp().http_post({bhv_type:"click",obj_type:"Control",title:"授权登陆页",control_name:"授权登陆页_确认授权",act_obj:10007})},3e3),this.authUrl?wx.redirectTo({url:this.authUrl}):wx.reLaunch({url:"/pages/index/index"})):console.log("用户按了拒绝按钮")},agreement:function(){wx.navigateTo({url:"/packageuser/user/aboutUs/agreement/agreement"})}}); 
 			}); 	require("pages/index/authorization/authorization.js");
 		__wxRoute = 'pages/index/sweep/sweep';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/index/sweep/sweep.js';	define("pages/index/sweep/sweep.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e,t,a=getApp();Page({data:{},onLoad:function(o){var i=this;if(wx.getMenuButtonBoundingClientRect){var s=wx.getMenuButtonBoundingClientRect().top+2;i.setData({backBtnTop:s})}a.leaseDataObj={canTouchZFFBtn:!0},t=void 0==o.referrer_title?"扫一扫":o.referrer_title,wx.showLoading({title:"正在加载",mask:!0}),e=void 0!=o.q?decodeURIComponent(o.q):o.qrcode,wx.getSetting({success:function(t){t.authSetting["scope.userInfo"]||(wx.hideLoading(),a.globalData.authToUrl="/pages/index/sweep/sweep?qrcode="+e,wx.redirectTo({url:"/pages/index/authorization/authorization"}))}})},onReady:function(){var e=this;a.globalData.session&&e.getBorrowInfo(),getApp().userLoginSuccessCallback=function(){e.getBorrowInfo()}},onShow:function(){var e=this;e.data.sid&&getApp().http_post({bhv_type:"view",obj_type:"Page",title:"产品介绍页",referrer_title:t,station_id:e.data.sid,other:{soft_ver:e.data.soft_ver,madename:"普通",is_vip:a.memberObj.is_vip},act_obj:10017})},memberOpening:function(){var e=this;getApp().http_post({bhv_type:"click",obj_type:"Control",title:"产品介绍页",control_name:"产品介绍页_开通会员",station_id:this.data.sid,other:{is_vip:a.memberObj.is_vip},act_obj:10077}),wx.navigateTo({url:"/pages/index/member/member?referrer_title=产品介绍页",events:{reloadData:e.getBorrowInfo}})},getBorrowInfo:function(){var o=this;wx.request({url:a.configObj.borrowUrl,data:{session:a.globalData.session,qrcode:e,version:"1.1"},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(e){var i=!1;if(5==e.data.code)getApp().globalData.session=null,getApp().login();else if(0==e.data.code){var s=e.data.data,n=s.device_ver,r=s.soft_ver,d="02"==s.memberStatus||"03"==s.memberStatus;if(a.memberObj.is_vip=d?1:0,o.data.sid||getApp().http_post({bhv_type:"view",obj_type:"Page",title:"产品介绍页",referrer_title:t,station_id:s.sid,other:{soft_ver:r,madename:"普通",is_vip:a.memberObj.is_vip},act_obj:10017}),1==s.offLine){var p=s.sid;return void wx.redirectTo({url:"/pages/index/sweep/deviceAbnormal/deviceAbnormal?sid="+p+"&device_ver="+n+"&soft_ver="+r+"&madename=普通"})}s.cable_type[1]<=0&&s.cable_type[2]<=0&&s.cable_type[3]<=0&&s.cable_type[4]<=0&&(getApp().http_post({bhv_type:"view",obj_type:"Page",title:"提示正在充电",station_id:s.sid,other:{soft_ver:s.soft_ver,madename:"普通"},act_obj:10024}),i=!0,0==s.total&&o.setData({notBattery:!0}),o.setData({showBatteryLowpower:!0,showPopBg:!0})),s.memberStatus?wx.setStorageSync("memberStatus",s.memberStatus):wx.setStorageSync("memberStatus",""),a.leaseDataObj.device_ver=s.device_ver,a.leaseDataObj.soft_ver=s.soft_ver,a.leaseDataObj.auxiliary=s.auxiliary,a.leaseDataObj.sid=s.sid,a.leaseDataObj.deposite_need=s.deposite_need,a.leaseDataObj.madename="普通",a.leaseDataObj.memberShow=s.memberShow,s.bluetoothWaitTime&&(a.leaseDataObj.bluetoothWaitTime=s.bluetoothWaitTime),o.setData({sid:s.sid,tid:s.tid,deposite_need:s.deposite_need,need_pay:s.need_pay,usable_money:s.usable_money,fee_strategy:s.fee_strategy,device_ver:s.device_ver,soft_ver:s.soft_ver,auxiliary:s.auxiliary,adisabled:!1,cdisabled:i,isDepositPay:s.isDepositPay,bindStatus:s.bindStatus,frequency:s.frequency,isBindMobile:s.isBindMobile,memberShow:s.memberShow,memberStatus:s.memberStatus,memberBtnShow:!d&&s.memberShow}),d||s.isShopVip&&o.setData({isMemberSign:!0,isShopVip:!0}),wx.navigateToMiniProgram||o.setData({isDepositPay:!0})}else wx.showToast({title:e.data.msg,icon:"none"})},fail:function(e){wx.showToast({title:"获取设备信息失败",icon:"none"})},complete:function(){wx.hideLoading(),o.setData({showBorrowInfo:!0})}})},leaseBut:function(e){var t=e.target.dataset.modenum;1==this.data.isBindMobile&&(1==t?this.aPay():2==t&&this.cPay())},aPay:function(e){var t=this;if(a.leaseDataObj.canTouchZFFBtn){getApp().http_post({bhv_type:"click",obj_type:"Control",title:"产品介绍页",control_name:"产品介绍页_免押金租借",station_id:t.data.sid,other:{soft_ver:t.data.soft_ver,madename:"普通",is_vip:a.memberObj.is_vip},act_obj:10018});var o=t.data.frequency;t.data.isBindMobile;o?t.setData({numleasingbox:!0,showPopBg:!0}):wx.requestSubscribeMessage?t.notifyMethod(!0):t.pointsPayment()}},newsCheckboxChange:function(e){var t=!this.data.newscheckedbox;this.setData({newscheckedbox:t}),1==t&&this.notifyMethod(!1)},notifyMethod:function(e){var t=this;a.leaseDataObj.canTouchZFFBtn=!1;var o=[a.configObj.newsID.returnID,a.configObj.newsID.borrowID];"02"==t.data.memberStatus&&"03"==t.data.memberStatus||o.push(a.configObj.newsID.activityID),wx.requestSubscribeMessage({tmplIds:o,complete:function(o){a.leaseDataObj.canTouchZFFBtn=!0,t.setData({newscheckedbox:!0}),e&&t.pointsPayment()}})},cPay:function(e){var t=this;getApp().http_post({bhv_type:"click",obj_type:"Control",title:"产品介绍页",control_name:"产品介绍页_押金租借",station_id:t.data.sid,other:{soft_ver:t.data.soft_ver,madename:"普通",is_vip:a.memberObj.is_vip},act_obj:10019});var o=t.data.need_pay,i=t.data.frequency;t.data.isBindMobile;i?t.setData({numleasingbox:!0,showPopBg:!0}):0!=o?(t.setData({showModal:!0,showPopBg:!0}),getApp().http_post({bhv_type:"view",obj_type:"Page",title:"产品介绍页_押金租借_去支付弹窗",station_id:t.data.sid,other:{soft_ver:t.data.soft_ver,madename:"普通",is_vip:a.memberObj.is_vip},act_obj:10020})):t.payment()},pointsPayment:function(){var e=this;if(!e.data.adisabled){e.setData({adisabled:!0}),setTimeout(function(){e.setData({adisabled:!1})},3e3);var t=getApp().dataObj.model;wx.showLoading({title:"请稍候",mask:!0}),wx.request({url:a.configObj.wxCreditPay,data:{session:a.globalData.session,sid:e.data.sid,cable_type:2,photo_info:t},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(t){if(wx.hideLoading(),e.zffBorrowOrderLogs(t,"request.success"),0==t.data.code){a.leaseDataObj.canTouchZFFBtn=!1;var o=t.data.result,i=o.miniprogram_appid;a.leaseDataObj.miniprogram_appid=i,a.leaseDataObj.orderid=t.data.result.out_order_no,e.zffBorrowOrderLogs(t,"navigateToMiniProgram"),a.creditNotifywx=e.creditNotifywx,wx.navigateToMiniProgram({appId:i,path:o.miniprogram_path,extraData:{mch_id:o.mchid,package:o.package,timestamp:o.timestamp,nonce_str:o.nonce_str,sign_type:o.sign_type,sign:o.sign},success:function(t){getApp().toWxMiniProgram=!0,e.zffBorrowOrderLogs(t,"navigateToMiniProgram.success")},fail:function(t){e.setData({adisabled:!1}),a.leaseDataObj.canTouchZFFBtn=!0,e.zffBorrowOrderLogs(t,"navigateToMiniProgram.fail")}})}else 8==t.data.code?e.setData({lastOrderid:t.data.orderid,toBepaidModa:!0}):1==t.data.code?(getApp().http_post({bhv_type:"view",obj_type:"Page",title:"产品介绍页_设备正忙弹窗",station_id:e.data.sid,other:{soft_ver:e.data.soft_ver,madename:"普通"},act_obj:10046}),e.setData({momentBusybox:!0,showPopBg:!0})):(wx.showToast({title:t.data.msg,icon:"none",duration:2e3}),9==t.data.code&&e.setData({isDepositPay:!0}))},fail:function(t){wx.hideLoading(),e.zffBorrowOrderLogs(t,"navigateToMiniProgram.fail")}})}},payment:function(){if(a.leaseDataObj.canTouchZFFBtn){var e=this;e.setData({cdisabled:!0}),setTimeout(function(){e.setData({cdisabled:!1})},3e3),wx.showLoading({title:"请稍候",mask:!0}),wx.request({url:a.configObj.paymentUrl,data:{session:a.globalData.session,sid:e.data.sid,tid:e.data.tid,cable_type:2},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(t){if(wx.hideLoading(),0==t.data.errcode){var o=t.data.orderid;a.leaseDataObj.orderid=o,1==t.data.pay_type?e.toLeaseSuccess():(getApp().http_post({bhv_type:"click",obj_type:"Control",other:{orderid:o,soft_ver:e.data.soft_ver,is_vip:a.memberObj.is_vip},title:"产品介绍页",control_name:"产品介绍页_押金租借_去支付",station_id:e.data.sid,act_obj:10021}),wx.requestPayment({timeStamp:t.data.wxpay_params.timeStamp,nonceStr:t.data.wxpay_params.nonceStr,package:t.data.wxpay_params.package,signType:t.data.wxpay_params.signType,paySign:t.data.wxpay_params.paySign,success:function(t){e.toLeaseSuccess()},fail:function(e){},complete:function(e){}}))}else 1==t.data.errcode?(getApp().http_post({bhv_type:"view",obj_type:"Page",title:"产品介绍页_设备正忙弹窗",station_id:e.data.sid,other:{soft_ver:e.data.soft_ver,madename:"普通"},act_obj:10046}),e.setData({momentBusybox:!0,showPopBg:!0})):wx.showToast({title:t.data.msg,icon:"none",duration:2e3})},fail:function(){wx.hideLoading()}})}},creditNotifywx:function(e){var t=a.leaseDataObj.orderid;if(void 0!=t&&0==t.indexOf("WZF")){wx.showLoading({title:"请稍候",mask:!0});var o=this,i=a.dataObj.model;wx.request({url:a.configObj.wxCreditNotify,data:{session:a.globalData.session,orderid:t,query_id:e,photo_info:i},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(e){0==e.data.code?o.toLeaseSuccess():(o.setData({showDepositBorrow:!0}),getApp().http_post({bhv_type:"view",obj_type:"Page",title:"产品介绍页_是否选择押金租借",station_id:o.data.sid,other:{is_vip:a.memberObj.is_vip},act_obj:10103}))},fail:function(){},complete:function(e){wx.hideLoading(),a.leaseDataObj.canTouchZFFBtn=!0,a.updataZFFData("popupRequest","",e)}})}},toLeaseSuccess:function(){wx.reLaunch({url:"/pages/index/sweep/leaseSuccess/leaseSuccess"})},bindhelp:function(){wx.redirectTo({url:"/pages/helpCenter/helpCenter"})},cancelbut:function(){getApp().http_post({bhv_type:"view",obj_type:"Page",title:"产品介绍页",station_id:this.data.sid,other:{soft_ver:this.data.soft_ver,madename:"普通",is_vip:a.memberObj.is_vip},act_obj:10017}),this.setData({showModal:!1,showPopBg:!1})},tomomentBusy:function(){this.setData({momentBusybox:!1,showPopBg:!1})},Sure:function(){var e=a.dataObj.gps,t="",o="";e.indexOf(",")&&(t=e.split(",")[0],o=e.split(",")[1]),wx.redirectTo({url:"/packagenearby/nearby/nearby?latitude="+o+"&longitude="+t})},closeBorrowLimitBox:function(){this.setData({showPopBg:!1,numleasingbox:!1})},closeLowpowerBox:function(){this.setData({showPopBg:!1,showBatteryLowpower:!1}),this.mayNot()},mayNot:function(){wx.reLaunch({url:"/pages/index/index"})},paymentbut:function(){this.setData({showPopBg:!1,showModal:!1}),this.payment()},authorizationshop:function(){wx.navigateTo({url:"/pages/index/sweep/entrustbox/entrustbox"})},zffBorrowOrderLogs:function(e,t){var o=a.leaseDataObj.orderid?a.leaseDataObj.orderid:"",i=getApp().dataObj.version,s=JSON.stringify(e);wx.request({url:a.configObj.seversLogs,data:{loginfo:"支付分跳转问题--"+t+": userId="+a.dataObj.user_id+",orderid="+o+",res="+s+",version="+i},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST"})},getPhoneNumber:function(e){var t=this,o=e.detail.iv,i=e.detail.encryptedData,s=a.globalData.authCode,n=a.globalData.trdSessionId,r=e.target.dataset.modenum;"getPhoneNumber:ok"==e.detail.errMsg&&t.loginServerPhoneNumber(s,o,i,n,r,t)},loginServerPhoneNumber:function(e,t,o,i,s,n){wx.showLoading({title:"请稍候",mask:!0}),wx.request({url:a.configObj.loginPhoneNumber,data:{code:e,encryptedData:o,iv:t,trdSessionId:i},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(e){var t=e.data.data.purePhoneNumber;wx.request({url:a.configObj.bindingPhoneNum,data:{session:a.globalData.session,mobile:t,code:"weChatPhoneNumberCode"},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(e){wx.hideLoading(),1==e.data.code?(n.setData({isBindMobile:!0}),1==s?n.aPay():2==s&&n.cPay()):wx.showToast({title:e.data.msg,icon:"none",duration:1500})},fail:function(){wx.showToast({title:"失败",icon:"none"})}})},fail:function(){wx.showToast({title:"失败",icon:"none"})}})},toPayment:function(){wx.navigateTo({url:"/pages/ordering/ordering"}),this.setData({toBepaidModa:!1})},backBtnTouch:function(){1==getCurrentPages().length?wx.reLaunch({url:"/pages/index/index"}):wx.navigateBack()},handleDepositPop:function(e){this.setData({showDepositBorrow:!1});var t=e.target.dataset.flag;"success"===t&&this.cPay(),getApp().http_post({bhv_type:"click",obj_type:"Control",title:"产品介绍页",control_name:"产品介绍页_是否选择押金租借结果",station_id:this.data.sid,other:{is_vip:a.memberObj.is_vip,result:t},act_obj:10104})}}); 
 			}); 	require("pages/index/sweep/sweep.js");
 		__wxRoute = 'pages/index/sweepMade/sweepMade';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/index/sweepMade/sweepMade.js';	define("pages/index/sweepMade/sweepMade.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e,a,t,o=require("../../../utils/hmac.js"),i=getApp();Page({backindex:0,data:{advertisingflag:!1,showModal:!1,insufficientFive:!1,disabled:!1,adisabled:!0,checkedbox:!0,toBepaidModa:!1,toBepaidbox:!1,numleasingbox:!1,momentBusybox:!1},onLoad:function(t){var o=this;i.leaseDataObj={canTouchZFFBtn:!0},a=void 0==t.referrer_title?"扫一扫":t.referrer_title,wx.showLoading({title:"正在加载"}),e=void 0!=t.q?decodeURIComponent(t.q):t.qrcode,o.backindex=0},onReady:function(){var a=this;getApp().backOfWXMiniprogram=function(e){a.backindex=e},i.globalData.session&&a.getBorrowInfo(e,a),getApp().userLoginSuccessCallback=function(){a.getBorrowInfo(e,a)}},onShow:function(){var e=this;e.data.sid&&getApp().http_post({bhv_type:"view",obj_type:"Page",title:"产品介绍页",referrer_title:e.options.referrer_title,station_id:e.data.sid,other:{soft_ver:e.data.soft_ver,madename:t},act_obj:10017}),e.setData({checkedbox:!0,adisabled:!1,backindex:this.backindex})},getBorrowInfo:function(e,o){wx.request({url:i.configObj.borrowUrl,data:{session:i.globalData.session,qrcode:e},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(e){var n=!1;if(5==e.data.code)getApp().globalData.session=null,getApp().login();else if(0==e.data.code){var s=e.data.data,d=s.device_ver,r=s.soft_ver;if("null"==o.options.custom_url)c="../../../images/lease/productintroduction.png";else var c=o.options.custom_url;if(o.setData({customName:o.options.custom_name,customUrl:c,advUrl:o.options.adv_url,backgroundColor:o.options.background_color}),t=o.options.madename,wx.setBackgroundColor&&wx.setBackgroundColor({backgroundColor:o.data.backgroundColor}),wx.setNavigationBarColor({frontColor:"#ffffff",backgroundColor:o.data.backgroundColor}),getApp().http_post({bhv_type:"view",obj_type:"Page",title:"产品介绍页",referrer_title:a,station_id:s.sid,other:{soft_ver:r,madename:t},act_obj:10017}),1==s.offLine){var l=s.sid;return void wx.redirectTo({url:"/pages/index/sweep/deviceAbnormal/deviceAbnormal?sid="+l+"&device_ver="+d+"&soft_ver="+r+"&madename="+t})}s.cable_type[1]<=0&&s.cable_type[2]<=0&&s.cable_type[3]<=0&&s.cable_type[4]<=0&&(getApp().http_post({bhv_type:"view",obj_type:"Page",title:"提示正在充电",station_id:s.sid,other:{soft_ver:s.soft_ver,madename:t},act_obj:10024}),n=!0,o.setData({insufficientFive:!0,advertisingflag:!0})),i.leaseDataObj.device_ver=s.device_ver,i.leaseDataObj.soft_ver=s.soft_ver,i.leaseDataObj.auxiliary=s.auxiliary,i.leaseDataObj.sid=s.sid,i.leaseDataObj.deposite_need=s.deposite_need,i.leaseDataObj.madename=t,s.bluetoothWaitTime&&(i.leaseDataObj.bluetoothWaitTime=s.bluetoothWaitTime),o.setData({sid:s.sid,tid:s.tid,deposite_need:s.deposite_need,need_pay:s.need_pay,usable_money:s.usable_money,fee_strategy:s.fee_strategy,device_ver:s.device_ver,soft_ver:s.soft_ver,auxiliary:s.auxiliary,adisabled:!1,cdisabled:n,isDepositPay:s.isDepositPay,bindStatus:s.bindStatus,frequency:s.frequency,isBindMobile:s.isBindMobile}),wx.navigateToMiniProgram||o.setData({isDepositPay:!0,backindex:0})}else wx.showModal({content:e.data.msg,confirmText:"确定",showCancel:!1,success:function(e){e.confirm&&wx.reLaunch({url:"/pages/index/index"})}})},fail:function(e){wx.showModal({content:"获取设备信息失败",confirmText:"确定",showCancel:!1,success:function(e){e.confirm&&wx.reLaunch({url:"/pages/index/index"})}})},complete:function(){wx.hideLoading()}})},aPay:function(){var e=this,a=(e.data.need_pay,e.data.isDepositPay),t=e.data.frequency;0==e.data.isBindMobile?e.getPhoneNumber():t?e.setData({numleasingbox:!0,advertisingflag:!0}):0==a?e.pointsPayment():wx.showModal({content:"信息失败",showCancel:!1})},cPay:function(){getApp().http_post({bhv_type:"click",obj_type:"Control",title:"产品介绍页",control_name:"产品介绍页_押金租借",station_id:this.data.sid,other:{soft_ver:this.data.soft_ver,madename:t},act_obj:10019});var e=this,a=e.data.need_pay,o=e.data.frequency;0==e.data.isBindMobile?e.getPhoneNumber():o?e.setData({numleasingbox:!0,advertisingflag:!0}):0!=a?(e.setData({showModal:!0,advertisingflag:!0}),getApp().http_post({bhv_type:"view",obj_type:"Page",title:"产品介绍页_押金租借_去支付弹窗",station_id:e.data.sid,other:{soft_ver:e.data.soft_ver,madename:t},act_obj:10020})):e.payment()},pointsPayment:function(){if(i.leaseDataObj.canTouchZFFBtn){var e=this;e.setData({adisabled:!0}),setTimeout(function(){e.setData({adisabled:!1})},3e3),getApp().http_post({bhv_type:"click",obj_type:"Control",title:"产品介绍页",control_name:"产品介绍页_免押金租借",station_id:e.data.sid,other:{soft_ver:e.data.soft_ver,madename:t},act_obj:10018});var a=getApp().dataObj.model;wx.showLoading({title:"请稍候",mask:!0}),wx.request({url:i.configObj.wxCreditPay,data:{session:i.globalData.session,sid:e.data.sid,cable_type:2,photo_info:a},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(a){if(wx.hideLoading(),e.zffBorrowOrderLogs(a,"request.success"),0==a.data.code){var n=a.data.result.miniprogram_appid,s=Math.floor((new Date).getTime()/1e3)+"",d=a.data.result.package,r=a.data.result.nonce_str,c=a.data.result.mch_id,l="okmnhyfzfhonh2lqwer12345tgb6yhn0",p="mch_id="+c+"&nonce_str="+r+"&package="+d+"&sign_type=HMAC-SHA256&timestamp="+s+"&key="+l,u=o.HmacSHA256(p,l).toString().toUpperCase(),f=a.data.result.miniprogram_path+"?timestamp="+s+"&nonce_str="+r+"&sign_type=HMAC-SHA256&sign="+u;i.leaseDataObj.miniprogram_appid=a.data.result.miniprogram_appid,i.leaseDataObj.orderid=a.data.result.out_order_no,e.zffBorrowOrderLogs(a,"navigateToMiniProgram"),i.creditNotifywx=e.creditNotifywx,wx.navigateToMiniProgram({appId:n,path:f,extraData:{mch_id:c,package:d,timestamp:s,nonce_str:r,sign_type:"HMAC-SHA256",sign:u},success:function(a){i.leaseDataObj.canTouchZFFBtn=!1,console.log("打开成功"),e.backindex=1,getApp().toWxMiniProgram=!0,e.zffBorrowOrderLogs(a,"navigateToMiniProgram.success")},fail:function(a){e.zffBorrowOrderLogs(a,"navigateToMiniProgram.fail")}})}else 8==a.data.code?e.setData({orderid:a.data.orderid,toBepaidModa:!0,toBepaidbox:!0}):1==a.data.code?(getApp().http_post({bhv_type:"view",obj_type:"Page",title:"产品介绍页_设备正忙弹窗",station_id:e.data.sid,other:{soft_ver:e.data.soft_ver,madename:t},act_obj:10046}),e.setData({momentBusybox:!0,advertisingflag:!0})):wx.showToast({title:a.data.msg,icon:"none",duration:2e3})},fail:function(a){wx.hideLoading(),e.zffBorrowOrderLogs(a,"navigateToMiniProgram.fail")}})}},payment:function(){if(i.leaseDataObj.canTouchZFFBtn){var e=this;e.setData({cdisabled:!0}),setTimeout(function(){e.setData({cdisabled:!1})},3e3);e.data.device_ver,e.data.soft_ver,e.data.auxiliary,e.data.sid;wx.showLoading({title:"请稍候",mask:!0}),wx.request({url:i.configObj.paymentUrl,data:{session:i.globalData.session,sid:e.data.sid,tid:e.data.tid,cable_type:2},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(a){if(wx.hideLoading(),0==a.data.errcode){var o=a.data.orderid;i.leaseDataObj.orderid=o,1==a.data.pay_type?wx.reLaunch({url:"/pages/index/sweep/leaseSuccess/leaseSuccess"}):(getApp().http_post({bhv_type:"click",obj_type:"Control",other:{orderid:o,soft_ver:e.data.soft_ver,madename:t},title:"产品介绍页",control_name:"产品介绍页_押金租借_去支付",station_id:e.data.sid,act_obj:10021}),wx.requestPayment({timeStamp:a.data.wxpay_params.timeStamp,nonceStr:a.data.wxpay_params.nonceStr,package:a.data.wxpay_params.package,signType:a.data.wxpay_params.signType,paySign:a.data.wxpay_params.paySign,success:function(e){wx.redirectTo({url:"/pages/index/sweep/leaseSuccess/leaseSuccess"})},fail:function(e){},complete:function(e){}}))}else 1==a.data.errcode?(getApp().http_post({bhv_type:"view",obj_type:"Page",title:"产品介绍页_设备正忙弹窗",station_id:e.data.sid,other:{soft_ver:e.data.soft_ver,madename:t},act_obj:10046}),e.setData({momentBusybox:!0,advertisingflag:!0})):wx.showToast({title:a.data.msg,icon:"none",duration:2e3})},fail:function(){wx.hideLoading()}})}},creditNotifywx:function(e){var a=i.leaseDataObj.orderid;if(0==a.indexOf("WZF")){wx.showLoading({title:"请稍候",mask:!0});var t=i.dataObj.model;wx.request({url:i.configObj.wxCreditNotify,data:{session:i.globalData.session,orderid:a,query_id:e,photo_info:t},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(e){0==e.data.code&&(console.log("弹电池成功"),wx.reLaunch({url:"/pages/index/sweep/leaseSuccess/leaseSuccess"}))},fail:function(){},complete:function(){wx.hideLoading(),i.leaseDataObj.canTouchZFFBtn=!0}})}},closewindow:function(){this.setData({adisabled:!1,cdisabled:!1,toBepaidModa:!1,toBepaidbox:!1})},bindhelp:function(){wx.redirectTo({url:"/pages/helpCenter/helpCenter"})},cancelbut:function(){getApp().http_post({bhv_type:"view",obj_type:"Page",title:"产品介绍页",station_id:this.data.sid,other:{soft_ver:this.data.soft_ver,madename:t},act_obj:10017}),this.setData({showModal:!1,advertisingflag:!1})},tomomentBusy:function(){this.setData({momentBusybox:!1,advertisingflag:!1})},Sure:function(){var e=i.dataObj.gps,a="",t="";e.indexOf(",")&&(a=e.split(",")[0],t=e.split(",")[1]),wx.navigateTo({url:"/packagenearby/nearby/nearby?latitude="+t+"&longitude="+a})},mayNot:function(){wx.reLaunch({url:"/pages/index/index"})},paymentbut:function(){var e=this;e.setData({showModal:!1,advertisingflag:!1}),e.payment()},checkboxChange:function(e){""==e.detail.value?this.setData({adisabled:!0}):this.setData({adisabled:!1})},authorizationshop:function(){wx.navigateTo({url:"/pages/index/sweep/entrustbox/entrustbox"})},zffBorrowOrderLogs:function(e,a){var t=i.leaseDataObj.orderid?i.leaseDataObj.orderid:"",o=getApp().dataObj.version,n=JSON.stringify(e);wx.request({url:i.configObj.seversLogs,data:{loginfo:"支付分跳转问题--"+a+": orderid="+t+",res="+n+",version="+o},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST"})},getPhoneNumber:function(e){var a=this,t=e.detail.iv,o=e.detail.encryptedData,n=i.globalData.authCode,s=i.globalData.trdSessionId,d=e.target.dataset.modenum;"getPhoneNumber:fail 用户未绑定手机，请先在微信客户端进行绑定后重试"==e.detail.errMsg||"getPhoneNumber:fail user deny"==e.detail.errMsg||"getPhoneNumber:ok"==e.detail.errMsg&&a.loginServerPhoneNumber(n,t,o,s,d,a)},loginServerPhoneNumber:function(e,a,t,o,n,s){wx.request({url:i.configObj.loginPhoneNumber,data:{code:e,encryptedData:t,iv:a,trdSessionId:o},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(e){var a=e.data.data.purePhoneNumber;wx.request({url:i.configObj.bindingPhoneNum,data:{session:i.globalData.session,mobile:a,code:"weChatPhoneNumberCode"},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(e){1==e.data.code?(s.setData({isBindMobile:!0}),1==n?s.aPay():2==n&&s.cPay()):wx.showToast({title:e.data.msg,icon:"none",duration:1500})},fail:function(){wx.showToast({title:"失败",icon:"none"})}})}})}}); 
 			}); 	require("pages/index/sweepMade/sweepMade.js");
 		__wxRoute = 'pages/index/member/member';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/index/member/member.js';	define("pages/index/member/member.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e=getApp();Page({backRoot:"",openingAccess:"",orderid:"",clickBut:!0,data:{buttonType:"",modalmember:!1,modalfail:!1,modalNeedKnow:!1,videoList:[{text:"优酷会员",videoHY:"ykhy",imgUrl:"/images/Member/youku_logo.png"},{text:"爱奇艺会员",videoHY:"aqyhy",imgUrl:"/images/Member/aiqiyi_logo.png"},{text:"腾讯会员",videoHY:"tengxu",imgUrl:"/images/Member/tengxun_logo.png"}]},onLoad:function(t){var a=this;if(t.backRoot&&(a.backRoot=t.backRoot),a.setData({referrer_title:t.referrer_title}),t.access)a.openingAccess="06";else if(t.q){var i=decodeURIComponent(t.q);i.indexOf("/a/5")>0?a.openingAccess="11":i.indexOf("/a/7")>0?a.openingAccess="12":a.openingAccess="05"}else{var n={"产品介绍页":"01","租借结果":"02","首页":"03","个人中心":"04","附近网点":"07","商铺详情":"08","订单详情":"09"};a.openingAccess=n[t.referrer_title],a.openingAccess||(a.openingAccess="05")}this.orderid=t.orderid||"",e.globalData.session&&(a.openingMember(),a.getUserInfo()),getApp().userLoginSuccessCallback=function(){a.openingMember(),a.getUserInfo()},wx.getSetting({success:function(a){a.authSetting["scope.userInfo"]||(wx.hideLoading(),e.globalData.authToUrl="/pages/index/member/member?access="+t.access,wx.redirectTo({url:"/pages/index/authorization/authorization"}))}})},getUserInfo:function(){var t=this,a=function(){if(e.globalData.userInfo.phone_num){var a=e.globalData.userInfo.phone_num;a=a.replace(/(\d{3})\d{4}(\d{4})/,"$1****$2"),t.setData({phone_num:a})}else t.setData({phone_num:"未绑定手机号"})};e.globalData.userInfo?a():e.userInfoRequest(function(){a()})},menberItemTouch:function(t,a){var i=t?t.currentTarget.dataset.index:a,n=this.data.memberObjs[i],o="",s=!1;this.data.is_limit?(o="明日再来",s=!0):this.data.signing_code&&this.data.end_time?(o="会员已开通",s=!0):"04"==n.type?this.data.signing_code?(o="会员已过期",s=!0):n.paid_flag?(o="您已购买过，请选择其它套餐",s=!0):n.sku_is_limit?(o="明日再来",s=!0):o="限时抢购"+n.current_price+"元":"02"==n.type?o=this.data.end_time||this.data.signing_code?"立即续费，预计省30元/月":"立即开通，预计省30元/月":"01"==n.type?this.data.end_time?o="立即续费，预计省20元/月":this.data.signing_code?(o="会员已过期",s=!0):o="立即开通，预计省20元/月":"03"==n.type&&(this.data.end_time?o="立即续费，预计省300元/年":this.data.signing_code?(o="会员已过期",s=!0):o="立即开通，预计省300元/年"),this.setData({item_sel:i,buttonTxt:o,buttonDisabled:s}),getApp().http_post({bhv_type:"click",obj_type:"Control",title:"会员中心",control_name:"会员中心_选购会员类型",referrer_title:this.openingAccess,station_id:e.leaseDataObj.sid||"",other:{sku:n.type,vipbutton:this.data.buttonTxt.split("，")[0],is_vip:e.memberObj.is_vip,is_contract:this.data.signing_code?1:0,orderid:this.orderid},act_obj:10105})},openingMember:function(){var t=this;wx.showLoading({title:"正在加载",mask:!0}),wx.request({url:e.configObj.productDetail,data:{session:e.globalData.session,version:"1.1"},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(a){if(5==a.data.code)getApp().globalData.session=null,getApp().login();else if(0==a.data.code){var i=a.data.data;if(i.end_time){var n=i.end_time.trim().split(/\s+/)[0];t.setData({end_time_new:n})}var o=i.is_limit,s=i.signing_code,r=i.product_details;s&&!i.end_time&&(t.data.modalmember||(t.setData({modalfail:!0}),getApp().http_post({bhv_type:"view",obj_type:"Page",title:"会员中心_连续包月扣款失败",other:{contractcode:s},act_obj:10088})));var d=[r.type_02,r.type_01,r.type_03],c={"04":{title:"会员体验卡",subTitle:"有效期3天",msg:"每个用户限购一次"},"02":{title:"连续包月",subTitle:"",msg:"次月起￥--/月，自动续费，可随时关闭"},"01":{title:"月卡",subTitle:"有效期30天",msg:"选择连续包月，享受优惠价格"},"03":{title:"年卡",subTitle:"有效期365天",msg:"全年享受会员特权"}};d=d.filter(function(e,t){if(e){var a=c[e.type];return e.title=a.title,e.subTitle=a.subTitle,e.msg=a.msg.replace(/--/g,e.current_price),!0}return!1}),t.setData({is_limit:o,signing_code:s,end_time:i.end_time,deduction_price:i.deduction_price,memberObjs:d}),e.memberObj.is_vip=t.data.end_time_new?1:0}else wx.showModal({content:a.data.msg,confirmText:"确定",showCancel:!1,success:function(e){e.confirm&&wx.reLaunch({url:"/pages/index/index"})}});0==t.data.modalmember&&getApp().http_post({bhv_type:"view",obj_type:"Page",title:"会员中心",referrer_title:t.openingAccess,station_id:e.leaseDataObj.sid||"",other:{is_vip:e.memberObj.is_vip||"",is_contract:t.data.signing_code?1:0,orderid:t.orderid},act_obj:10082}),t.itemSelected||(t.menberItemTouch(null,0),t.itemSelected=!0)},fail:function(){wx.showToast({title:"网络错误",icon:"none",duration:1e3})},complete:function(){wx.hideLoading()}})},paymentMemberOrder:function(){var t=this,a=this.data.memberObjs[this.data.item_sel];t.clickBut&&(getApp().http_post({bhv_type:"click",obj_type:"Control",title:"会员中心",control_name:"会员中心_立即购买",referrer_title:this.openingAccess,station_id:e.leaseDataObj.sid||"",other:{sku:a.type,vipbutton:this.data.buttonTxt.split("，")[0],is_vip:e.memberObj.is_vip,is_contract:this.data.signing_code?1:0,orderid:this.orderid},act_obj:10106}),wx.showLoading({title:"请稍候...",mask:!0}),t.clickBut=!1,setTimeout(function(){t.clickBut=!0},2e3),"02"==a.type?t.freePayment():t.memberPayment())},memberPayment:function(){var t=this,a=t.data.memberObjs[t.data.item_sel],i=(a.current_price,a.type,e.leaseDataObj.sid?e.leaseDataObj.sid:"");wx.request({url:e.configObj.createMemberOrder,data:{session:e.globalData.session,sid:i,openingAccess:t.openingAccess,memberStrategyType:a.type},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(e){0==e.data.code?(t.setData({memberOrderNo:e.data.data.member_order_no}),wx.requestPayment({timeStamp:e.data.data.pay_data.timeStamp,nonceStr:e.data.data.pay_data.nonceStr,package:e.data.data.pay_data.package,signType:e.data.data.pay_data.signType,paySign:e.data.data.pay_data.paySign,success:function(e){wx.hideLoading(),t.setData({modalmember:!0}),t.memberBuyResultMD("success");var a=getCurrentPages(),i=a[a.length-2];-1!=i.route.indexOf("sweep/sweep")&&i.getBorrowInfo()},fail:function(e){wx.hideLoading(),wx.showToast({title:"已取消支付",icon:"none",duration:2e3}),t.memberBuyResultMD("fail")},complete:function(){t.setData({memberrenew:!!t.data.end_time}),t.openingMember()}})):(wx.hideLoading(),wx.showToast({title:e.data.msg,icon:"none",duration:2e3}))},fail:function(){wx.hideLoading(),wx.showToast({title:"网络错误,请检查网络",icon:"none"})},complete:function(){}})},freePayment:function(){var t=this,a=t.data.memberObjs[1],i=(a.frist_price>0?a.frist_price:a.current_price,e.leaseDataObj.sid?e.leaseDataObj.sid:"");t.data.signing_code?t.applyDeduction():wx.request({url:e.configObj.applySign,data:{sid:i,openingAccess:t.openingAccess,session:e.globalData.session},method:"POST",header:{"Content-Type":"application/x-www-form-urlencoded"},success:function(a){if(0==a.data.code){e.leaseDataObj.contractCode=a.data.data.contract_code,e.applyDeduction=t.applyDeduction;var i=a.data.data.contract_data;wx.navigateToMiniProgram({appId:"wxbd687630cd02ce1d",path:"pages/index/index",extraData:i,success:function(e){getApp().toWxMiniProgram=!0},complete:function(e){wx.hideLoading()}})}else wx.hideLoading(),wx.showToast({title:a.data.msg,icon:"none"})}})},applyDeduction:function(){var t=this,a=e.leaseDataObj.sid?e.leaseDataObj.sid:"",i=e.leaseDataObj.contractCode?e.leaseDataObj.contractCode:t.data.signing_code,n=t.data.memberObjs[1];n.frist_price>0?n.frist_price:n.current_price;0==i.indexOf("WMM")&&wx.request({url:e.configObj.pappayapply,data:{session:e.globalData.session,sid:a,contractCode:i,openingAccess:t.openingAccess},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(e){wx.hideLoading(),0==e.data.code?(t.openingMember(),t.setData({modalmember:!0}),t.memberBuyResultMD("doing")):(wx.showToast({title:e.data.msg,icon:"none",duration:2e3}),t.memberBuyResultMD("fail"))},fail:function(){wx.hideLoading(),wx.showToast({title:"失败",icon:"none",duration:2e3})},complete:function(e){}})},memberLease:function(){var e=this;e.data.memberObjs[e.data.item_sel].current_price;"true"==e.backRoot?wx.reLaunch({url:"/pages/index/index"}):wx.navigateBack()},videoItemTouch:function(e){var t=e.currentTarget.dataset.videoFlag,a="11"===this.openingAccess||"12"===this.openingAccess?"01":"02";wx.navigateTo({url:"/packageaiqiyi/aiqiyi/aiqiyi?videoHY="+t+"&resource="+a})},handleKnowModal:function(e){this.setData({modalNeedKnow:"open"===e.currentTarget.dataset.flag})},backpage:function(){getCurrentPages().length>1?wx.navigateBack():wx.reLaunch({url:"/pages/index/index"})},hideModal:function(){this.setData({modalmember:!1});var e=this.getOpenerEventChannel();e.emit&&e.emit("buySuccess"),wx.navigateBack()},closePopup:function(){this.setData({modalfail:!1})},onPullDownRefresh:function(){wx.showLoading({title:"正在加载",mask:!0}),this.openingMember(),wx.stopPullDownRefresh()},onUnload:function(){var e=this.getOpenerEventChannel();e.emit&&e.emit("reloadData")},memberBuyResultMD:function(t){getApp().http_post({bhv_type:"view",obj_type:"Page",title:"会员中心_会员购买结果",referrer_title:this.openingAccess,station_id:e.leaseDataObj.sid||"",other:{sku:this.data.memberObjs[this.data.item_sel].type,result:t,is_vip:e.memberObj.is_vip,is_contract:this.data.signing_code?1:0,orderid:this.orderid},act_obj:10107})}}); 
 			}); 	require("pages/index/member/member.js");
 		__wxRoute = 'pages/index/member/runRenew/runRenew';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/index/member/runRenew/runRenew.js';	define("pages/index/member/runRenew/runRenew.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e=getApp();Page({data:{modalmember:!1},onLoad:function(e){this.setData({backRoot:e.backRoot,referrer_title:e.referrer_title,deduction_price:e.deduction_price})},onReady:function(){},onShow:function(){getApp().http_post({bhv_type:"view",obj_type:"Page",title:"管理续费",act_obj:10089})},onHide:function(){},onUnload:function(){},rescission:function(){var t=this;wx.showLoading({title:"请稍候...",mask:!0}),wx.request({url:e.configObj.applyRecission,data:{session:e.globalData.session},method:"POST",header:{"Content-Type":"application/x-www-form-urlencoded"},success:function(e){if(200==e.data.code){var o=t.data.backRoot,a=t.data.referrer_title;"false"==o?wx.navigateBack({delta:1}):wx.redirectTo({url:"/pages/index/member/member?backRoot="+o+"&referrer_title="+a})}else wx.showToast({title:e.data.message,icon:"none"})},fail:function(){wx.showToast({title:"网络错误",icon:"none"})},complete:function(){t.setData({modalmember:!1})}})},cancelmember:function(){this.setData({modalmember:!0}),getApp().http_post({bhv_type:"view",obj_type:"Page",title:"管理续费_是否取消连续包月",act_obj:10090})},cancel:function(){getApp().http_post({bhv_type:"click",obj_type:"Control",title:"管理续费",control_name:"是否取消连续包月_取消",act_obj:10092});var e=this.data.backRoot,t=this.data.referrer_title;"false"==e?this.setData({modalmember:!1}):wx.redirectTo({url:"/pages/index/member/member?backRoot="+e+"&referrer_title="+t})},confirm:function(){getApp().http_post({bhv_type:"click",obj_type:"Control",title:"管理续费",control_name:"是否取消连续包月_确定",act_obj:10091}),this.rescission()},onPullDownRefresh:function(){},onReachBottom:function(){}}); 
 			}); 	require("pages/index/member/runRenew/runRenew.js");
 		__wxRoute = 'pages/index/sweep/leaseSuccess/leaseSuccess';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/index/sweep/leaseSuccess/leaseSuccess.js';	define("pages/index/sweep/leaseSuccess/leaseSuccess.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e=getApp();Page({adv_objStr:{},requestTimer:"",times:"",progress:"",interval:"",judgeOpenBluetoothShowed:!1,deviceId:"",serviceId:"",orderIDCharacteristicId:"",resultCharacteristicId:"",frontbluetoothWaitTime:"",afterbluetoothWaitTime:"",orderMdStr:"",leaseDataObj:{},bluetoothResult:{},timeCount:90,data:{percent:1,status:"",smallBattery:[1,2,3,4,5,6,7,8,9,10],showSlotBox:!0,colorCircleFirst:"#31A448",countDown:3},onLoad:function(t){var o=this;o.leaseDataObj=e.leaseDataObj;var a,r=o.leaseDataObj.device_ver;a=101==r||102==r||103==r||104==r||105==r||106==r||107==r||108==r||111==r||150==r||151==r?"H3":2==r||31==r||32==r||33==r||34==r||36==r?"Big_40":150==r||151==r||152==r||153==r||154==r||155==r||156==r||270==r||271==r||272==r||273==r||274==r||275==r?"H3_C":35==r?"Big_80":501==r?"Big_20":"H2",o.setData({deviceType:a,showMemberBtn:o.leaseDataObj.memberShow&&"01"==wx.getStorageSync("memberStatus")}),o.percentAdd(),o.progress=setInterval(o.progressNum,1e3);var s=e.leaseDataObj.bluetoothWaitTime;s&&(s.length?(o.frontbluetoothWaitTime=s.split("/")[0],o.afterbluetoothWaitTime=s.split("/")[1]):(o.frontbluetoothWaitTime=20,o.afterbluetoothWaitTime=30),setTimeout(function(){o.orderMdStr&&o.orderMdStr.length&&2!=o.data.status&&o.startBluetoothDevicesDiscovery()},1e3*o.frontbluetoothWaitTime),o.returnMd5Order()),getApp().http_post({bhv_type:"view",obj_type:"Page",title:"弹出电池进度条",other:{orderid:o.leaseDataObj.orderid,soft_ver:o.leaseDataObj.soft_ver,madename:o.leaseDataObj.madename},station_id:o.leaseDataObj.sid,act_obj:10025})},onShow:function(){var t=this,o=wx.getStorageSync("adv_obj");if(o){t.adv_objStr=JSON.parse(o);var a=!0;t.adv_objStr.wechat_zbo&&(a=!1,e.advExposure(t.adv_objStr.wechat_zbo,"300011"),t.setData({checkUrl_wechat_zbo:t.adv_objStr.wechat_zbo.checkUrl,materialUrl_wechat_zbo:e.configObj.advImgAdd+t.adv_objStr.wechat_zbo.materialUrl})),t.adv_objStr.wechat_zbt&&(a=!1,e.advExposure(t.adv_objStr.wechat_zbt,"300012"),t.setData({checkUrl_wechat_zbt:t.adv_objStr.wechat_zbt.checkUrl,materialUrl_wechat_zbt:e.configObj.advImgAdd+t.adv_objStr.wechat_zbt.materialUrl})),t.adv_objStr.wechat_zbth&&(a=!1,e.advExposure(t.adv_objStr.wechat_zbth,"300013"),t.setData({checkUrl_wechat_zbth:t.adv_objStr.wechat_zbth.checkUrl,materialUrl_wechat_zbth:e.configObj.advImgAdd+t.adv_objStr.wechat_zbth.materialUrl})),t.setData({showAbBanner:a}),t.adv_objStr.wechat_zt&&1==t.data.showModal&&e.advExposure(t.adv_objStr.wechat_zt,"300009")}"02"==wx.getStorageSync("memberStatus")||"03"==wx.getStorageSync("memberStatus")?e.memberObj.is_vip=1:e.memberObj.is_vip=0},progressNum:function(){var e=this;if(2==e.data.status)clearInterval(e.progress),clearTimeout(e.requestTimer),e.stopBluetooth(),wx.closeBluetoothAdapter({}),e.setData({advertisingflag:!1,showOpenBluetooth:!1,leaseResult:{status:"租借成功",subTxt:"感谢使用速绿充电",img:"success"},membershipCopy:"开通会员，此单立享3小时免费"}),getApp().http_post({bhv_type:"view",obj_type:"Page",title:"租借结果页",other:{orderid:e.leaseDataObj.orderid,soft_ver:e.leaseDataObj.soft_ver,madename:e.leaseDataObj.madename,result:"success"},station_id:e.leaseDataObj.sid,act_obj:10078});else{var t=e.data.percent;t>=e.timeCount?(e.setData({advertisingflag:!1,showOpenBluetooth:!1}),clearInterval(e.progress),clearTimeout(e.requestTimer),e.stopBluetooth(),wx.closeBluetoothAdapter({}),e.progressBarOver(),e.judgeOpenBluetoothShowed&&e.bluetoothLog(-2)):e.setData({percent:++t})}},percentAdd:function(){var t=this;wx.request({url:e.configObj.stateUrl,data:{session:e.globalData.session,orderid:t.leaseDataObj.orderid},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(e){if(0==e.data.code){var o=e.data.data.status;t.setData({status:o}),2==o?(t.setData({borrowSlot:e.data.data.borrowSlot}),t.showGif()):t.requestTimer=setTimeout(t.percentAdd,2e3)}},fail:function(){t.requestTimer=setTimeout(t.percentAdd,2e3)}})},getOrderInfo:function(){var t=this;wx.request({url:e.configObj.getOrderInfo,data:{session:e.globalData.session,orderid:t.leaseDataObj.orderid},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(e){if(0==e.data.code){var o=e.data.data.order,a=t.data.leaseResult;a.borrow_time=o.borrow_time,a.fee_strategy=o.fee_strategy,t.setData({leaseResult:a})}}})},showGif:function(){var t=this;t.progressNum(),t.getOrderInfo();var o=2*t.data.countDown;t.interval=setInterval(function(){0==--o?(clearInterval(t.interval),t.setData({showSlotBox:!1}),t.adv_objStr.wechat_zt?(e.advExposure(t.adv_objStr.wechat_zt,"300009"),t.setData({showModal:!0,checkUrl_wechat_zt:t.adv_objStr.wechat_zt.checkUrl,materialUrl_wechat_zt:e.configObj.advImgAdd+t.adv_objStr.wechat_zt.materialUrl})):t.data.showMemberBtn||!wx.createInterstitialAd||t.adShowed||(t.adShowed=!0,wx.createInterstitialAd({adUnitId:"adunit-f24935c921d3717d"}).show()),t.data.showMemberBtn||1==getCurrentPages().length&&(t.times=setTimeout(function(){wx.navigateTo({url:"/packageLuckdraw/luckdraw/luckdraw?routeid=1"})},5e3))):t.setData({colorCircleFirst:o%2?"#31A448":"#C1C1C1",countDown:(o/2).toFixed(0)})},500)},progressBarOver:function(){var t=this;wx.request({url:e.configObj.progressBarOverPageSkip,data:{session:e.globalData.session,sid:t.leaseDataObj.sid},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(e){1==e.data.dispose?t.timeoutResult(!0):t.timeoutResult(!1)},fail:function(e){t.timeoutResult(!1)}})},timeoutResult:function(e){var t,o=this;t=e?{status:"订单处理中",subTxt:"当前订单将在5分钟内处理完毕",img:"ing"}:{status:"租借失败",subTxt:"充电宝租借未成功，请再次租借",img:"fail"},o.setData({leaseResult:t,showSlotBox:!1,membershipCopy:"开通会员，免费使用充电宝"}),getApp().http_post({bhv_type:"view",obj_type:"Page",title:"租借结果页",other:{orderid:o.leaseDataObj.orderid,soft_ver:o.leaseDataObj.soft_ver,madename:o.leaseDataObj.madename,result:e?"doing":"fail"},station_id:o.leaseDataObj.sid,act_obj:10078})},openingMember:function(){var e=this;getApp().http_post({bhv_type:"click",obj_type:"Control",title:"租借结果页",control_name:"租借结果页__点击会员按钮",station_id:this.leaseDataObj.sid,other:{orderid:this.leaseDataObj.orderid},act_obj:10079}),wx.navigateTo({url:"/pages/index/member/member?backRoot=true&referrer_title=租借结果&orderid="+this.leaseDataObj.orderid,events:{buySuccess:function(){e.setData({showMemberBtn:!1})}}})},bindAdvBannerOne:function(){e.pushAdv(this.adv_objStr.wechat_zbo,"300011")},bindAdvBannerTwo:function(){e.pushAdv(this.adv_objStr.wechat_zbt,"300012")},bindAdvBannerThree:function(){e.pushAdv(this.adv_objStr.wechat_zbth,"300013")},onbinddoumob:function(){e.pushAdv(this.adv_objStr.wechat_zt,"300009"),this.hideModal()},hideModal:function(){this.setData({showModal:!1})},toOrderInfo:function(){var e=this.leaseDataObj.orderid;wx.navigateTo({url:"/pages/ordering/orderingend/orderingend?orderid="+e})},toScan:function(){e.qrCode(function(e){var t=e.split("/")[3];if("q"==t)wx.redirectTo({url:"/pages/index/sweep/sweep?qrcode="+e+"&referrer_title=租借失败"});else if("x"==t)wx.redirectTo({url:"/packageB/Bluetooth/Bluetooth?qrcode="+e+"&referrer_title=租借失败"});else if("c"==t){var o=encodeURIComponent(e);wx.redirectTo({url:"/packageA/Lottery/Lottery?qrcode="+o})}else wx.showModal({title:"温馨提示",content:"这不是速绿充电的二维码",success:function(e){e.confirm||e.cancel}})})},servicebtnTouch:function(){var e=this.leaseDataObj.orderid;wx.navigateTo({url:"/pages/helpCenter/helpCenter?orderid="+e+"&csEntryType=5"})},adLoadFinish_banner:function(e){this.setData({showAd_banner:!0})},onHide:function(){clearTimeout(this.times)},onUnload:function(){clearInterval(this.interval),clearInterval(this.progress),clearTimeout(this.requestTimer),clearTimeout(this.times),this.closeBLEConnection()},bluetoothRecharge:function(){var e=this;e.setData({advertisingflag:!1,showOpenBluetooth:!1,percent:1}),getApp().http_post({bhv_type:"click",obj_type:"Control",title:"弹出电池进度条_已开蓝牙,重新弹出",control_name:"",station_id:e.leaseDataObj.sid,other:{orderid:e.leaseDataObj.orderid,soft_ver:e.leaseDataObj.soft_ver},act_obj:10073}),setTimeout(function(){e.timeCount=e.afterbluetoothWaitTime,e.startBluetoothDevicesDiscovery()},2e3)},overtimeConfirmReport:function(){var t=this;wx.request({url:e.configObj.overtimeConfirm,data:{orderid:t.leaseDataObj.orderid,sid:t.leaseDataObj.sid,status:t.bluetoothResult.result,slot:t.bluetoothResult.slotNo,battery_id:t.bluetoothResult.batteryId,power:t.bluetoothResult.power,source:1,type:1},method:"POST",header:{"Content-Type":"application/x-www-form-urlencoded"},success:function(e){console.log("蓝牙广告机调用传输订单租借信息"+JSON.stringify(e))}})},startBluetoothDevicesDiscovery:function(){var t=this;wx.closeBluetoothAdapter({complete:function(){wx.openBluetoothAdapter({success:function(e){console.log("初始化蓝牙模块成功"+JSON.stringify(e)),t.searchBluetooth(),t.judgeOpenBluetoothShowed||t.openBluetoothLog(1),t.judgeOpenBluetoothShowed=!0},fail:function(o){if(console.log("初始化蓝牙模块失败"+JSON.stringify(o)),t.judgeOpenBluetoothShowed)t.bluetoothLog(-1);else{var a=e.dataObj.model.indexOf("iPhone")>=0;t.setData({isiPhone:a,advertisingflag:!0,showOpenBluetooth:!0}),t.openBluetoothLog(0)}t.judgeOpenBluetoothShowed=!0}})}})},searchBluetooth:function(){var e=this;wx.startBluetoothDevicesDiscovery({allowDuplicatesKey:!0,services:[],success:function(t){console.log("开始搜索蓝牙设备"),e.deviceId=null,e.bluetoothFound=!1,wx.onBluetoothDeviceFound(function(t){if(e.bluetoothFound=!0,!e.deviceId){var o=t.devices[0],a=o.name||o.deviceName;if(console.log("名字"+a),a&&-1!=a.indexOf("rk")){var r=e.ab2hex(o.advertisData);r=e.hexToNumCharCode(r.substr(4)),console.log("mac--"+r),r==e.leaseDataObj.sid&&(console.log("搜索到的目标设备"),e.stopBluetooth(),e.deviceId=o.deviceId,e.connectBLEDevice())}}})},fail:function(e){console.log("调用搜寻蓝牙设备失败"),console.log(e)}})},stopBluetooth:function(){wx.stopBluetoothDevicesDiscovery({success:function(e){console.log("停止搜索成功"),console.log(e)},fail:function(e){console.log("停止搜索失败"),console.log(e)}})},connectBLEDevice:function(){var e=this;console.log("准备连接蓝牙设备"),wx.createBLEConnection({deviceId:e.deviceId,success:function(t){console.log("蓝牙连接成功"),e.readServices()},fail:function(t){-1==t.errCode?e.readServices():(e.bluetoothLog(-3),console.log("蓝牙连接失败"),console.log(t))}})},readServices:function(){var e=this;wx.getBLEDeviceServices({deviceId:e.deviceId,success:function(t){console.log("获取服务"+JSON.stringify(t)),e.serviceId="1000FFF0-0000-0000-0000-000000000000",wx.getBLEDeviceCharacteristics({deviceId:e.deviceId,serviceId:e.serviceId,success:function(t){e.orderIDCharacteristicId=t.characteristics[0].uuid,e.resultCharacteristicId=t.characteristics[2].uuid,wx.notifyBLECharacteristicValueChange({state:!0,deviceId:e.deviceId,serviceId:e.serviceId,characteristicId:e.resultCharacteristicId,success:function(e){console.log("notifyBLECharacteristicValueChange success",e.errMsg)}}),wx.onBLECharacteristicValueChange(function(t){if(t.characteristicId==e.resultCharacteristicId){var o=e.ab2hex(t.value);console.log("租借结果："+o);var a=parseInt(o.substr(0,2),16);console.log("租借结果："+a),1==a?(e.bluetoothLog(6),e.bluetoothResult.slotNo=parseInt(o.substr(2,2),16),e.bluetoothResult.power=parseInt(o.substr(4,2),16),e.bluetoothResult.batteryId=e.hexToNumCharCode(o.substr(6)),e.setData({status:2,borrowSlot:e.bluetoothResult.slotNo,leaseResult:{status:"租借成功",subTxt:"感谢使用速绿充电",img:"success"},membershipCopy:"开通会员，此单立享3小时免费"}),e.showGif()):(e.bluetoothLog(-6),e.bluetoothResult.slotNo="",e.bluetoothResult.power="",e.bluetoothResult.batteryId=""),e.bluetoothResult.result=a,e.overtimeConfirmReport()}}),e.writeBluetoothData()},fail:function(t){e.bluetoothLog(-4),console.log("读取特征失败。。"),console.log(t)}})},fail:function(t){e.bluetoothLog(-4),console.log("读取服务失败"),console.log(t)}})},closeBLEConnection:function(){this.deviceId&&wx.closeBLEConnection({deviceId:this.deviceId})},writeBluetoothData:function(){console.log("写入数据");var e=this,t=e.leaseDataObj.orderid;t=t.replace(/-/g,"");var o=e.strToHexCharCode(t.substr(0,3))+e.numToHexCharCode(t.substr(3),2)+e.orderMdStr;console.log("明文："+o);var a=e.getBuffer(o);console.log(a),wx.writeBLECharacteristicValue({deviceId:e.deviceId,serviceId:e.serviceId,characteristicId:e.orderIDCharacteristicId,value:a,success:function(t){e.bluetoothLog(5),console.log("弹电池指令发送成功："),console.log(t)},fail:function(t){e.bluetoothLog(-5),console.log("弹电池指令发送失败："),console.log(t)}})},openBluetoothLog:function(e){var t=this;getApp().http_post({bhv_type:"click",obj_type:"Control",title:"弹出电池进度条_是否开启手机蓝牙",control_name:"",station_id:t.leaseDataObj.sid,other:{orderid:t.leaseDataObj.orderid,soft_ver:t.leaseDataObj.soft_ver,isopen:e},act_obj:10072})},bluetoothLog:function(e){var t=this;getApp().http_post({bhv_type:"click",obj_type:"Control",title:"大设备蓝牙通道",control_name:"",station_id:t.leaseDataObj.sid,other:{orderid:t.leaseDataObj.orderid,soft_ver:t.leaseDataObj.soft_ver,reason:e},act_obj:10074})},ab2hex:function(e){return Array.prototype.map.call(new Uint8Array(e),function(e){return("00"+e.toString(16)).slice(-2)}).join("")},strToHexCharCode:function(e){if(""===e)return"";for(var t=[],o=0;o<e.length;o++){var a=e.charCodeAt(o);a=this.str_pad(a.toString(16),2),t.push(a)}return t.join("")},numToHexCharCode:function(e,t){if(""===e)return"";t||(t=1);for(var o=[],a=0;a<e.length/t;a++){var r=Number(e.substr(a*t,t));r=this.str_pad(r.toString(16),2),o.push(r)}return o.join("")},hexToNumCharCode:function(e){if(""===e)return"";for(var t=[],o=0;o<e.length/2;o++){var a=Number(e.substr(2*o,2));a=a.toString(10),t.push(a)}return t.join("")},getBuffer:function(e){if(e){for(var t=e.length/2,o=new ArrayBuffer(t),a=new DataView(o),r=0;r<t;r++){var s=parseInt(e.substr(2*r,2),16);a.setUint8(r,s)}return o}},str_pad:function(e,t){var o=t-e.length;return"00000000".substr(0,o)+e},returnMd5Order:function(){var t=this;wx.request({url:e.configObj.returnOrderMd5,data:{session:e.globalData.session,orderid:t.leaseDataObj.orderid},method:"POST",header:{"Content-Type":"application/x-www-form-urlencoded"},success:function(e){console.log(e),0==e.data.code&&(t.orderMdStr=e.data.orderid)}})}}); 
 			}); 	require("pages/index/sweep/leaseSuccess/leaseSuccess.js");
 		__wxRoute = 'pages/index/sweep/deviceAbnormal/deviceAbnormal';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/index/sweep/deviceAbnormal/deviceAbnormal.js';	define("pages/index/sweep/deviceAbnormal/deviceAbnormal.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=require("../../../../utils/WSCoordinate.js"),e=getApp();Page({latitude:"",longitude:"",data:{advertisingflag:!1,issucopen:!1},onLoad:function(e){var a=this,i=e.sid,o=e.soft_ver,n=e.device_ver;a.setData({sid:i,device_ver:n,soft_ver:o,madename:e.madename}),wx.showLoading({title:"请稍后...",mask:!0}),wx.getLocation({success:function(e){var i=t.transformFromWGSToGCJ(e.latitude,e.longitude);a.latitude=i.latitude,a.longitude=i.longitude},fail:function(){a.latitude="39.9088230000",a.longitude="116.3974700000"},complete:function(){wx.hideLoading()}})},onShow:function(){var t=this;getApp().http_post({bhv_type:"view",obj_type:"Page",title:"设备断网提示",station_id:t.data.sid,other:{soft_ver:t.data.soft_ver,madename:t.data.madename},act_obj:10022})},toShopList:function(){wx.redirectTo({url:"/packagenearby/nearby/nearby?latitude="+this.latitude+"&longitude="+this.longitude})},backRoot:function(){wx.reLaunch({url:"/pages/index/index"})},dianwo:function(t){var a=this;wx.showLoading({title:"请稍后",mask:!0});var i=a.data.sid;wx.request({url:e.configObj.getRepair,data:{stationId:i},method:"POST",header:{"Content-Type":"application/x-www-form-urlencoded"},success:function(t){console.log(t.data),wx.hideLoading(),a.setData({advertisingflag:!0,issucopen:!0})},fail:function(t){wx.showToast({title:"失败",icon:"none",duration:2e3})}})}}); 
 			}); 	require("pages/index/sweep/deviceAbnormal/deviceAbnormal.js");
 		__wxRoute = 'pages/index/sweep/protocol/protocol';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/index/sweep/protocol/protocol.js';	define("pages/index/sweep/protocol/protocol.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Page({data:{},onLoad:function(n){},onReady:function(){},onShow:function(){},onHide:function(){},onUnload:function(){},onPullDownRefresh:function(){},onReachBottom:function(){}}); 
 			}); 	require("pages/index/sweep/protocol/protocol.js");
 		__wxRoute = 'pages/index/sweep/entrustbox/entrustbox';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/index/sweep/entrustbox/entrustbox.js';	define("pages/index/sweep/entrustbox/entrustbox.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Page({data:{},onLoad:function(n){},onReady:function(){},onShow:function(){},onHide:function(){},onUnload:function(){},onPullDownRefresh:function(){},onReachBottom:function(){}}); 
 			}); 	require("pages/index/sweep/entrustbox/entrustbox.js");
 		__wxRoute = 'pages/ordering/ordering';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/ordering/ordering.js';	define("pages/ordering/ordering.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=require("../../utils/WSCoordinate.js"),s=getApp();Page({adv_objStr:{},data:{},onLoad:function(){var t=this;wx.showLoading({title:"正在加载"}),wx.getSystemInfo({success:function(s){t.setData({width:s.windowWidth,height:s.windowHeight})}})},onShow:function(){var a=this;wx.getLocation({success:function(s){var e=t.transformFromWGSToGCJ(s.latitude,s.longitude);a.setData({longitude:e.longitude,latitude:e.latitude})},fail:function(){a.setData({longitude:116.39747,latitude:39.908823})}}),s.globalData.session&&a.getRentedRecords(),getApp().userLoginSuccessCallback=function(){a.getRentedRecords()};var e=wx.getStorageSync("adv_obj");e&&(a.adv_objStr=JSON.parse(e),a.adv_objStr.wechat_wdib&&(s.advExposure(a.adv_objStr.wechat_wdib,"300016"),a.setData({checkUrl_wechat_wdib:a.adv_objStr.wechat_wdib.checkUrl,materialUrl_wechat_wdib:s.configObj.advImgAdd+a.adv_objStr.wechat_wdib.materialUrl})))},onHide:function(){},onUnload:function(){},onPullDownRefresh:function(){wx.showLoading({title:"正在加载"}),this.getRentedRecords(),wx.stopPullDownRefresh()},getRentedRecords:function(){if(s.globalData.session){var t=this;wx.request({url:s.configObj.rentedRecordsUrl,data:{session:s.globalData.session},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(a){if(0==a.data.code){var e=a.data.data.orders;if(e.length>0){for(var o=0;o<e.length;o++){var u=e[o];if(1==u.credit_flage?(u.status="待付款",u.statusImg=6,e.splice(o,1),e.unshift(u)):2!=u.status&&5!=u.status&&6!=u.status&&8!=u.status&&11!=u.status||0!=u.credit_flage?10!=u.status&&64!=u.status&&65!=u.status&&66!=u.status&&67!=u.status&&68!=u.status&&69!=u.status&&70!=u.status&&82!=u.status&&83!=u.status&&84!=u.status&&85!=u.status&&86!=u.status&&87!=u.status&&88!=u.status&&89!=u.status&&90!=u.status&&94!=u.status&&95!=u.status&&96!=u.status&&97!=u.status&&201!=u.status&&202!=u.status&&203!=u.status&&204!=u.status&&205!=u.status&&301!=u.status&&302!=u.status||0!=u.credit_flage?1!=u.status&&104!=u.status||0!=u.credit_flage?92==u.status&&0==u.credit_flage?(u.status="押金已扣完",u.statusImg=4):93!=u.status&&103!=u.status||201!=u.device_ver?1002==u.status?(u.status="已成功拥有",u.statusImg=3):1003==u.status?(u.status="已退款",u.statusImg=3):(u.status="已完成",u.statusImg=7):(u.status="已退款",u.statusImg=5):(u.status="订单处理中",u.statusImg=3):(u.status="租借失败",u.statusImg=2):(u.status="租借中",u.statusImg=1),"租借中"==u.status&&201==u.device_ver){var i=u.fee_strategy_entity.fixed_time*u.fee_strategy_entity.fixed_unit,n=(new Date).getTime(),d=u.borrow_time.replace(/-/g,"/"),r=Date.parse(new Date(d));i-Math.floor((n-r)/1e3)<=0&&(s.bluetoothRefund(u.orderid),u.status="已完成")}}t.setData({orders:e})}else t.setData({orders:0})}else wx.showModal({content:a.data.msg,showCancel:!1})},fail:function(){},complete:function(){wx.hideLoading()}})}},toOrderInfo:function(t){var s=t.currentTarget.dataset.id;wx.navigateTo({url:"/pages/ordering/orderingend/orderingend?orderid="+s})},copyID:function(t){wx.setClipboardData({data:this.data.orders[t.currentTarget.dataset.ind].orderid,success:function(t){wx.showToast({title:"复制成功",icon:"success",duration:1500,complete:function(){}})}})},wechat_wdib:function(){s.pushAdv(this.adv_objStr.wechat_wdib,"300016")},adLoadFinish_banner:function(t){this.setData({showAd_banner:!0})}}); 
 			}); 	require("pages/ordering/ordering.js");
 		__wxRoute = 'pages/advertising-h5/advertising-h5';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/advertising-h5/advertising-h5.js';	define("pages/advertising-h5/advertising-h5.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Page({data:{},onLoad:function(n){var o=decodeURIComponent(n.advurl);this.setData({advurl:o})},onReady:function(){},onShow:function(){},onHide:function(){},onUnload:function(){},onPullDownRefresh:function(){},onReachBottom:function(){}}); 
 			}); 	require("pages/advertising-h5/advertising-h5.js");
 		__wxRoute = 'pages/ordering/returnsuccess/returnsuccess';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/ordering/returnsuccess/returnsuccess.js';	define("pages/ordering/returnsuccess/returnsuccess.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e=getApp();Page({adv_objStr:{},data:{},onLoad:function(e){var t=this;wx.showLoading({title:"正在加载"}),t.setData({orderid:e.orderid,last_time:e.last_time,ticket_usefee:Number(e.ticket_usefee),usefee:Number(e.usefee),fee_strategy:e.fee_strategy}),wx.hideLoading()},onShow:function(){var t=this,a=wx.getStorageSync("adv_obj");a&&(t.adv_objStr=JSON.parse(a),t.adv_objStr.wechat_gdb&&(e.advExposure(t.adv_objStr.wechat_gdb,"300018"),t.setData({checkUrl_wechat_gdb:t.adv_objStr.wechat_gdb.checkUrl,materialUrl_wechat_gdb:e.configObj.advImgAdd+t.adv_objStr.wechat_gdb.materialUrl})))},returnone:function(){wx.reLaunch({url:"/pages/index/index"})},catchAd:function(){e.pushAdv(this.adv_objStr.wechat_gdb,"300018")}}); 
 			}); 	require("pages/ordering/returnsuccess/returnsuccess.js");
 		__wxRoute = 'pages/ordering/testing/testing';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/ordering/testing/testing.js';	define("pages/ordering/testing/testing.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t,e,a=getApp();Page({data:{status:2,leasefail:!1,percent:1,isTesting:0},onLoad:function(a){var r=this;r.setData({orderid:a.orderid}),e=setInterval(function(){r.data.percent;r.percentAdd(a.orderid,function(t){})},2e3),t=setInterval(function(){var a=r.data.percent;if(2==r.data.status||5==r.data.status||6==r.data.status||8==r.data.status||11==r.data.status)r.setData({percent:++a});else{var s=r.data.orderid,d=r.data.last_time,o=r.data.ticket_usefee,n=r.data.usefee,i=r.data.fee_strategy;r.setData({percent:100}),clearInterval(e),wx.redirectTo({url:"/pages/ordering/returnsuccess/returnsuccess?orderid="+s+"&last_time="+d+"&ticket_usefee="+o+"&usefee="+n+"&fee_strategy="+i})}100==a&&(clearInterval(e),clearInterval(t),r.setData({isTesting:1}),wx.setNavigationBarTitle({title:"归还失败"}))},200)},onShow:function(t){var e=this.data.orderid;getApp().http_post({bhv_type:"view",obj_type:"Page",title:"检测充电宝归还",other:{orderid:e},act_obj:10030})},retestTap:function(){var t=this;this.setData({code:0,leasefail:!1,percent:1,isTesting:0}),wx.setNavigationBarTitle({title:"系统检测"}),getCurrentPages().pop().onLoad({orderid:t.data.orderid})},onHide:function(){},onUnload:function(){clearInterval(e),clearInterval(t)},percentAdd:function(t,e){var r=this;wx.request({url:a.configObj.getOrderInfo,data:{session:a.globalData.session,orderid:t},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(t){0==t.data.code?(2==t.data.data.order.status||5==t.data.data.order.status||6==t.data.data.order.status||8==t.data.data.order.status||11==t.data.data.order.status?r.setData({status:t.data.data.order.status}):r.setData({status:t.data.data.order.status,orderid:t.data.data.order.orderid,last_time:t.data.data.order.last_time,ticket_usefee:t.data.data.order.ticket_usefee,usefee:t.data.data.order.use_fee,fee_strategy:t.data.data.order.fee_strategy}),"function"==typeof e&&e(t.data.data.order.status)):wx.showToast({title:t.data.msg,icon:"none"})},fail:function(t){"function"==typeof e&&e(0)}})},collphone:function(){var t=this.data.orderid;wx.navigateTo({url:"/pages/helpCenter/helpCenter?orderid="+t+"&csEntryType=4"})},onPullDownRefresh:function(){wx.stopPullDownRefresh()}}); 
 			}); 	require("pages/ordering/testing/testing.js");
 		__wxRoute = 'pages/ordering/orderingend/orderingend';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/ordering/orderingend/orderingend.js';	define("pages/ordering/orderingend/orderingend.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e=require("../../../utils/util.js"),t=getApp();Page({data:{isShow:!1,advertisingflag:!1,hour:"00",minute:"00",second:"00",orderEnd:0},onLoad:function(e){this.setData({orderid:e.orderid}),this.statusMember()},onShow:function(){getApp().http_post({bhv_type:"view",obj_type:"Page",title:"订单详情",other:{orderid:this.data.orderid},act_obj:10028}),this.getRentedRecords()},onUnload:function(){clearInterval(void 0)},onPullDownRefresh:function(){wx.showLoading({title:"正在加载"}),this.getRentedRecords(),wx.stopPullDownRefresh()},getRentedRecords:function(){wx.showLoading({title:"正在加载"});var e=this;wx.request({url:t.configObj.getOrderInfo,data:{session:t.globalData.session,orderid:e.data.orderid},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(t){if(0==t.data.code){var o=t.data.data.order;o.subTxt="感谢使用速绿充电";var a,i=o.status;if(1==o.credit_flage){var r=o.return_time?o.return_time.replace(/-/g,"/"):new Date,n=((new Date).getTime()-new Date(r).getTime())/1e3/60;e.setData({timeRange:n}),o.status="待付款",o.statusImg=6,o.toolBtn="去支付",a=[[{title:"订单编号",code:"orderid"},{title:"租借地点",code:"borrow_name"},{title:"归还地点",code:"return_name"},{title:"借出时间",code:"borrow_time"},{title:"归还时间",code:"return_time"}],[{title:"租借时长",code:"last_time"},{title:"费用合计",code:"sum_fee"},{title:"待支付金额",code:"sum_fee"},{title:"收费策略",code:"fee_strategy"}]]}else 2!=i&&5!=i&&6!=i&&8!=i&&11!=i||0!=o.credit_flage?10!=i&&64!=i&&65!=i&&66!=i&&67!=i&&68!=i&&69!=i&&70!=i&&82!=i&&83!=i&&84!=i&&85!=i&&86!=i&&87!=i&&88!=i&&89!=i&&90!=i&&94!=i&&95!=i&&96!=i&&97!=i&&201!=i&&202!=i&&203!=i&&204!=i&&205!=i&&301!=i&&302!=i||0!=o.credit_flage?1!=i&&104!=i||0!=o.credit_flage?93!=i&&103!=i||201!=o.device_ver?(92==i&&0==o.credit_flage?(o.status="押金已扣完",o.statusImg=4):(o.status="已完成",o.statusImg=7,o.toolBtn="再次租借"),a=[[{title:"订单编号",code:"orderid"},{title:"租借地点",code:"borrow_name"},{title:"归还地点",code:"return_name"},{title:"借出时间",code:"borrow_time"},{title:"归还时间",code:"return_time"}],[{title:"租借时长",code:"last_time"},{title:"费用合计",code:"sum_fee"},{title:"优惠金额",code:"ticket_usefee"},{title:"实际扣费",code:"use_fee"},{title:"收费策略",code:"fee_strategy"}]]):(o.status="已退款",o.subTxt="订单已退款，预计0-3个工作日到账",o.statusImg=5,o.toolBtn="再次租借"):(o.status="订单处理中",o.statusImg=3,o.toolBtn="返回首页",a=[[{title:"订单编号",code:"orderid"},{title:"租借地点",code:"borrow_name"}],[{title:"收费策略",code:"fee_strategy"}]]):(o.status="租借失败",o.statusImg=2,o.toolBtn="重新租借",a=[[{title:"订单编号",code:"orderid"},{title:"租借地点",code:"borrow_name"},{title:"借出时间",code:"borrow_time"}],[{title:"收费策略",code:"fee_strategy"}]]):(o.status="租借中",o.subTxt="使用完成后请及时归还充电宝",o.statusImg=1,o.toolBtn="在线客服",a=[[{title:"订单编号",code:"orderid"},{title:"租借地点",code:"borrow_name"},{title:"借出时间",code:"borrow_time"}],[{title:"租借时长",code:"last_time"},{title:"费用合计",code:"sum_fee"},{title:"收费策略",code:"fee_strategy"}]]);if(201==o.device_ver){a=[[{title:"订单编号",code:"orderid"},{title:"租借地点",code:"borrow_name"},{title:"借出时间",code:"borrow_time"}],[{title:"已退款"==o.status?"退款金额":"支付费用",code:"use_fee"},{title:"使用限制时长",code:"usr_confine"}]];var s=o.fee_strategy_entity.fixed_time*o.fee_strategy_entity.fixed_unit;e.setData({bluetoothMac:o.mac,Stime:s})}a.map(function(t,a){t.map(function(t){var a="ticket_usefee"==t.code||"use_fee"==t.code?"元":"";if("sum_fee"==t.code){var i=o.use_fee+o.ticket_usefee;t.value=i+"元"}else"usr_confine"==t.code?t.value=e.getBlueToothUsrConfine():t.value=o[t.code]+a})}),e.setData({orderInfo:o,orderData:a}),201==o.device_ver&&("租借中"==o.status?(e.setData({showBluetoothTimeCount:!0}),e.time()):e.setData({showBluetoothTimeCount:!1})),"租借中"==o.status&&201!=o.device_ver&&e.getNearbyShops()}else wx.showToast({title:t.data.msg,icon:"none"})},fail:function(){},complete:function(){wx.hideLoading()}})},getBlueToothUsrConfine:function(){var e,t,o=this.data.Stime;return o<3600?e="分钟":o>=3600&&(e="小时"),o<3600?t=o/60:o>=3600&&(t=o/3600),t+e},getNearbyShops:function(){var o=this,a=t.dataObj.gps,i="",r="";a.indexOf(",")&&(i=a.split(",")[0],r=a.split(",")[1]),wx.request({url:t.configObj.getShopListPagingUrl,data:{session:t.globalData.session,longitude:i,latitude:r,skip:0},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(t){if(0==t.data.code){for(var a=t.data.data.shops,n=0;n<a.length;n++){var s=a[n],d=e.getDistance(r,i,s.latitude,s.longitude);s.dis=parseInt(d),s.shopType=e.getShopType(s.type)}(a=a.slice(0,10)).sort(o.objSort("dis")),o.setData({shops:a})}},fail:function(){},complete:function(){wx.hideLoading()}})},objSort:function(e){return function(t,o){return t[e]-o[e]}},toolBtnTouch:function(e){var t=this.data.orderInfo.toolBtn;"在线客服"==t?this.bindhelp():"重新租借"==t||"再次租借"==t?this.rentAgain():"返回首页"==t?this.returnone():"去支付"==t&&this.toPayment()},toPayment:function(){wx.showLoading({title:"请稍候",mask:!0});var e=this,o=e.data.orderid;wx.request({url:t.configObj.paycreditUrl,data:{session:t.globalData.session,orderid:o},method:"POST",header:{"Content-Type":"application/x-www-form-urlencoded"},success:function(t){wx.hideLoading(),setTimeout(e.getRentedRecords,3e3),wx.showToast({title:t.data.msg,icon:"none"})},fail:function(){wx.hideLoading()}})},rentAgain:function(){t.qrCode(function(e){var t=e.split("/")[3];if("q"==t)wx.navigateTo({url:"/pages/index/sweep/sweep?qrcode="+e+"&referrer_title=订单详情"});else if("x"==t)wx.navigateTo({url:"/packageB/Bluetooth/Bluetooth?qrcode="+e+"&referrer_title=订单详情"});else if("c"==t){var o=encodeURIComponent(e);wx.navigateTo({url:"/packageA/Lottery/Lottery?qrcode="+o})}else wx.showModal({title:"温馨提示",content:"这不是速绿充电的二维码",success:function(e){e.confirm||e.cancel}})})},binduse:function(e){var t=this.data.orderid;wx.navigateTo({url:"/pages/ordering/feedback/feedback?orderid="+t})},bindlose:function(e){var t=this.data.orderid;wx.navigateTo({url:"/pages/ordering/lost-powerback/lost-powerback?orderid="+t})},bindhelp:function(){var e=this.data.orderid;wx.navigateTo({url:"/pages/helpCenter/helpCenter?orderid="+e+"&csEntryType=2"})},returnone:function(){wx.reLaunch({url:"/pages/index/index"})},copyID:function(e){wx.setClipboardData({data:this.data.orderid,success:function(e){wx.showToast({title:"复制成功",icon:"success",duration:1500,complete:function(){}})}})},bluetoothBlackout:function(){var e=this,t=Math.ceil(e.data.timer/60),o=e.data.bluetoothMac,a=e.data.orderid;getApp().http_post({bhv_type:"click",obj_type:"Control",title:"订单详情",other:{orderid:a},control_name:"订单详情_无故断电",act_obj:10064}),wx.redirectTo({url:"/packageB/Bluetooth/openbluetoothNotice/openbluetoothNotice?states=2&timer="+t+"&bluetoothMac="+o+"&orderid="+a})},breakSure:function(){var e=this,t=Math.ceil(e.data.timer/60),o=e.data.bluetoothMac;wx.redirectTo({url:"/packageB/Bluetooth/progress/progress?states=2&timer="+t+"&bluetoothMac="+o})},time:function(){var e=this;clearInterval(e.timesclear),e.timesclear=setInterval(function(){e.countDown()},1e3),e.countDown()},countDown:function(){var e=this,t=(new Date).getTime(),o=e.data.orderInfo.borrow_time.replace(/-/g,"/"),a=Date.parse(new Date(o)),i=Math.floor((t-a)/1e3),r=e.data.Stime-i;if(e.setData({timer:r,goingtime:i}),r<=0)e.setData({hour:"00",minute:"00",second:"00"}),clearInterval(e.timesclear),getApp().bluetoothRefund(e.data.orderid,e.getRentedRecords);else{e.setData({timer:e.data.timer-1});var n=Math.floor(e.data.timer/3600),s=Math.floor(e.data.timer%3600/60),d=Math.floor(e.data.timer%60);n=n<10?"0"+n:n,s=s<10?"0"+s:s,d=d<10?"0"+d:d,e.setData({hour:n,minute:s,second:d})}},statusMember:function(){var e=this;wx.request({url:t.configObj.memberStatus,data:{session:t.globalData.session},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(o){if(0==o.data.code){var a=o.data.data;t.userMemberStatus=a,"01"==a&&e.setData({memberShow:!0})}}})},memberViewTouch:function(){wx.navigateTo({url:"/pages/index/member/member?backRoot=true&referrer_title=订单详情"})},hereto:function(e){var t=this.data.shops[e.currentTarget.dataset.index];wx.openLocation({latitude:Number(t.latitude),longitude:Number(t.longitude),name:t.name,address:t.address,scale:18})},toShopInfo:function(e){var t=e.currentTarget.dataset.ind,o=this.data.shops[t];wx.navigateTo({url:"/packagenearby/nearby/details/details?dis="+o.dis+"&ss_id="+o.ss_id+"&urladd=1&referrer_title=订单详情"})}}); 
 			}); 	require("pages/ordering/orderingend/orderingend.js");
 		__wxRoute = 'pages/ordering/feedback/feedback';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/ordering/feedback/feedback.js';	define("pages/ordering/feedback/feedback.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e=getApp();Page({data:{advertisingflag:!1,Unopened:!1,same_station:"",textarea_val:"",phonenum:0,height:20,focus:!1,picUrls:[],items:[{name:"0",value:"取出异常"},{name:"1",value:"归还异常"},{name:"2",value:"充电宝无法充电"}]},onLoad:function(e){this.setData({orderid:e.orderid})},bindCamera:function(a){var t=this,n=this;wx.chooseImage({count:2,sizeType:["original","compressed"],sourceType:["album","camera"],success:function(a){var s=a.tempFilePaths,i=t.data.picUrls;wx.uploadFile({url:e.configObj.fileImgUrl,filePath:s[0],name:"file",headers:{"Content-Type":"multipart/form-data"},formData:{session:e.globalData.session,file:s},success:function(a){var t=JSON.parse(a.data);t.data.image_url;i.length<2&&(i.push(t.data.image_url),n.setData({picUrls:i,phonenum:1})),2==i.length&&n.setData({picUrls:i,phonenum:2}),wx.uploadFile({url:e.configObj.fileImgUrl,filePath:s[1],name:"file",headers:{"Content-Type":"multipart/form-data"},formData:{session:e.globalData.session,file:s},success:function(e){var a=JSON.parse(e.data);a.data.image_url;i.length<2&&(i.push(a.data.image_url),n.setData({picUrls:i,phonenum:1})),2==i.length&&n.setData({picUrls:i,phonenum:2})}})}})}})},delPic:function(e){var a=e.target.dataset.index,t=this.data.picUrls;t.splice(a,1),0==t.length?this.setData({picUrls:t,phonenum:0}):this.setData({picUrls:t,phonenum:1})},radioChange:function(e){this.setData({same_station:e.detail.value})},bindTextAreaBlur:function(e){this.setData({textarea_val:e.detail.value})},formSubmit:function(a){var t=this,n=[3],s=JSON.stringify(n),i=t.data.picUrls,o=JSON.stringify(i),r=t.data.same_station,l=t.data.textarea_val,c=a.currentTarget.dataset.orderid;""!=r?""!=l?this.data.picUrls.length<=0?wx.showModal({content:"请上传图片",confirmText:"确定",confirmColor:"#23C788",showCancel:!1,success:function(e){}}):wx.request({url:e.configObj.ProblemUrl,data:{session:e.globalData.session,service:"order",problem_ids:s,message:"充电宝已归还,但订单还在计费",orderid:c,img:o,same_station:r},method:"POST",header:{"Content-Type":"application/x-www-form-urlencoded"},success:function(e){1==e.data.data.over_submit?wx.showModal({title:"温馨提示",content:"同一个订单最多提交两次反馈",showCancel:!1,confirmColor:"#23C788",success:function(e){e.confirm&&wx.reLaunch({url:"/pages/index/index"})}}):t.setData({advertisingflag:!0,Unopened:!0})}}):wx.showModal({content:"请输入问题描述",confirmText:"确定",confirmColor:"#23C788",showCancel:!1,success:function(e){}}):wx.showModal({content:"请选择问题类型",confirmText:"确定",confirmColor:"#23C788",showCancel:!1,success:function(e){}})},preventTouchMove:function(e){},Close:function(){wx.reLaunch({url:"/pages/index/index"})}}); 
 			}); 	require("pages/ordering/feedback/feedback.js");
 		__wxRoute = 'pages/ordering/lost-powerback/lost-powerback';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/ordering/lost-powerback/lost-powerback.js';	define("pages/ordering/lost-powerback/lost-powerback.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var n=getApp();Page({data:{advertisingflag:!1,isconnection:!1,Unopened:!1},onLoad:function(n){this.setData({orderid:n.orderid})},cancel:function(){this.setData({advertisingflag:!1,isconnection:!1})},bindlost:function(){this.setData({advertisingflag:!0,isconnection:!0})},withdrawal:function(){var a=this;a.setData({advertisingflag:!1,isconnection:!1});var e=a.data.orderid;wx.request({url:n.configObj.loseDisposeUrl,data:{session:n.globalData.session,orderid:e},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(n){0==n.data.code?a.setData({advertisingflag:!0,Unopened:!0}):1==n.data.code&&wx.showModal({content:n.data.msg,showCancel:!1,confirmText:"关闭",success:function(n){n.confirm&&wx.reLaunch({url:"/pages/index/index"})}})}})},Close:function(){wx.reLaunch({url:"/pages/index/index"})},bindback:function(){wx.navigateBack({delta:1})}}); 
 			}); 	require("pages/ordering/lost-powerback/lost-powerback.js");
 		__wxRoute = 'pages/helpCenter/helpCenter';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/helpCenter/helpCenter.js';	define("pages/helpCenter/helpCenter.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=getApp();Page({data:{issueDataArr:[{groupTitle:"使用问题",issueArr:[{title:"充电宝无法充电",solution:"若充电宝无法充电，可轻敲充电宝，充电宝上的指示灯亮起即可充电。如仍无法充电，请归还充电宝再次租借"}]},{groupTitle:"归还问题",issueArr:[{title:"归还后订单未结束",solution:"充电宝归还后，订单仍在进行中时，请再次按压充电宝，或联系在线客服"},{title:"异地归还",solution:"充电宝支持异地归还"}]},{groupTitle:"支付问题",issueArr:[{title:"订单如何支付",solution:"请确保第三方账户余额充足，订单完结后将从您的第三方账户余额中自动扣款。若扣款未成功，请充值第三方账户余额，进入第三方守约记录支付待付款订单"}]},{groupTitle:"费用问题",issueArr:[{title:"押金如何提现",solution:"进入“个人中心-我的钱包”，点击余额提现"}]}],answerArr:[]},toIssueInfo:function(t){var e=t.currentTarget.dataset.index,o=parseInt(e.split(",")[0]),n=parseInt(e.split(",")[1]),i=this.data.issueDataArr[o].issueArr[n];wx.navigateTo({url:"issueInfo?title="+i.title+"&solution="+i.solution})},helps:function(e){wx.showLoading({title:"请稍候",mask:!0});var o=this;wx.request({url:t.configObj.helpH5,data:{session:t.globalData.session,orderid:o.data.orderid,csEntryType:o.data.csEntryType,userType:"3"},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"GET",success:function(t){if("9802"==t.data.code)wx.navigateTo({url:"/pages/index/authorization/authorization"});else{var e="https://1tfdm1g.cschat-ccs.aliyun.com/index.htm?tntInstId=_1tfDm1g&scene=SCE00007330"+("0000"==t.data.code?t.data.data:"");wx.navigateTo({url:"/pages/advertising-h5/advertising-h5?advurl="+encodeURIComponent(e)})}},complete:function(){wx.hideLoading()}})},onLoad:function(t){var e=this;"undefined"==t.orderid?(e.setData({orderid:"",csEntryType:t.csEntryType}),console.log(e.data.orderid)):e.setData({orderid:t.orderid,csEntryType:t.csEntryType})},onReady:function(){},onShow:function(){},onHide:function(){},onUnload:function(){},onPullDownRefresh:function(){},onReachBottom:function(){},onShareAppMessage:function(){}}); 
 			}); 	require("pages/helpCenter/helpCenter.js");
 		__wxRoute = 'packageLuckdraw/luckdraw/luckdraw';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'packageLuckdraw/luckdraw/luckdraw.js';	define("packageLuckdraw/luckdraw/luckdraw.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var a=getApp();Page({data:{showboxhide:!1,showmodalhide:!1,showpopupboxhide:!1,canPrizeNumhide:!1,carWidth:"",number:8,cardData:[]},onLoad:function(a){wx.showLoading({title:"正在加载"});var e=0;wx.getSystemInfo({success:function(a){e=parseInt((a.windowWidth-180)/3)}}),this.setData({routeid:a.routeid,carWidth:e})},onShow:function(){var e=this,t=setInterval(function(){a.globalData.session&&(e.getPrizeAwardsluck(),getApp().userLoginSuccessCallback=function(){e.getPrizeAwardsluck()},clearInterval(t))},500)},onPullDownRefresh:function(){wx.showLoading({title:"正在加载"}),this.getPrizeAwardsluck(),wx.stopPullDownRefresh()},getPrizeAwardsluck:function(){var e=this;wx.request({url:a.configObj.getPrizeAwards,data:{session:a.globalData.session},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(a){if(5==a.data.code)getApp().globalData.session=null,getApp().login();else if(0==a.data.code){for(var t=[],i=a.data.awards,o=0;o<i.length;o++){var n=100;o%3==0&&(n=o+200),t.push({front:"../images/img2_03.png",id:i[o].id,imgurl:i[o].imgurl,advurl:i[o].advurl,name:i[o].name,disabled:!1,animationData:{},idnum:o+1,showClass:!1,zIndex:n})}if(a.data.canPrizeNum<=0)r=0;else var r=a.data.canPrizeNum;e.setData({cardData:t,canPrizeNum:r}),e.addPosition()}else wx.showModal({content:a.data.msg,confirmText:"确定",showCancel:!1,success:function(a){a.confirm&&wx.reLaunch({url:"/pages/index/index"})}})},fail:function(){wx.showToast({title:"请求失败",duration:1500,complete:function(){}})},complete:function(){wx.hideLoading()}})},handleCurClick:function(e){var t=this,i=e.currentTarget.dataset.idnum;t.setData({curId:i,showClass:!0,showboxhide:!0});var o=e.currentTarget.dataset.imgurl,n=e.currentTarget.dataset.advurl,r=e.currentTarget.dataset.id,s=e.currentTarget.dataset.name,d=t.data.canPrizeNum;t.allMove(),setTimeout(function(){d>0?(t.setData({name:s,pid:r,imgurl:o,advurl:n,showmodalhide:!0,showpopupboxhide:!0,showboxhide:!1}),wx.request({url:a.configObj.savePrizeLog,data:{session:a.globalData.session,pid:r,name:s},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(a){0==a.data.code&&t.getPrizeAwardsluck()},fail:function(){},complete:function(){}})):t.setData({showmodalhide:!0,canPrizeNumhide:!0,showboxhide:!1})},1500)},hidepopuh:function(){this.setData({showmodalhide:!1,showpopupboxhide:!1,showboxhide:!1})},determine:function(){this.setData({showmodalhide:!1,canPrizeNumhide:!1,showboxhide:!1})},bindhome:function(){var a=this.data.routeid;1==a?wx.navigateBack({}):2==a&&wx.reLaunch({url:"/pages/index/index"})},receive:function(){var e=this,t=e.data.advurl,i=(e.data.name,e.data.pid);if(e.setData({showmodalhide:!1,showpopupboxhide:!1}),"爱奇艺"==t)wx.navigateTo({url:"/packageaiqiyi/aiqiyi/aiqiyi?videoHY=aqyhy"});else if("优酷"==t)wx.navigateTo({url:"/packageaiqiyi/aiqiyi/aiqiyi?videoHY=ykhy"});else if("喜马拉雅"==t)wx.navigateTo({url:"/packageaiqiyi/aiqiyi/aiqiyi?videoHY=xmly"});else if("腾讯"==t)wx.navigateTo({url:"/packageaiqiyi/aiqiyi/aiqiyi?videoHY=tengxu"});else if("芒果"==t)wx.navigateTo({url:"/packageaiqiyi/aiqiyi/aiqiyi?videoHY=mangguo"});else{var o=a.configObj.host+"/a/"+i;wx.navigateTo({url:"/pages/advertising-h5/advertising-h5?advurl="+encodeURIComponent(o)})}},addPosition:function(){var a=this.data.cardData;a.map(function(a,e){var t=e%3,i=parseInt((e+3)/3);a.twoArry={x:t,y:i},a.zindex=0,a.disabled=!1}),this.setData({cardData:a})},allMove:function(){var a=this;console.log("hahahahah");var e=this.data,t=e.carWidth;e.cardData;this.shuffle(t);var i=setTimeout(function(){clearTimeout(i),a.shuffle2(0)},1e3)},shuffle:function(a){a=a;console.log("translateUnit"+a);var e=this.data.cardData,t=this.data.curId-1;if(3==t||4==t||5==t)a=a+10;if(6==t||7==t||8==t)var a=a+20;console.log(e);var i=wx.createAnimation({duration:500,timingFunction:"ease"});if(i.export(),0==t)o=-(a*(e[t].twoArry.x-1)-30);else if(3==t||6==t)o=-(a*(e[t].twoArry.x-1)-30);else if(2==t||5==t||8==t)o=-(a*(e[t].twoArry.x-1)+30);else var o=-a*(e[t].twoArry.x-1);var n=a*e[t].twoArry.y;i.translate(o,-n).scale(1.5,1.5).step({duration:500}).rotate(-30).step({duration:50}).rotate(30).step({duration:100}).rotate(-30).step({duration:100}).rotate(0).step({duration:50}),e[t].animationData=i.export(),this.setData({cardData:e})},shuffle2:function(a){var a=a;console.log("translateUnit"+a);var e=this.data.cardData,t=this.data.curId-1;console.log(e);var i=wx.createAnimation({duration:500,timingFunction:"ease"});i.export();var o=a*(1-e[t].twoArry.x),n=a*(1-e[t].twoArry.y);i.translate(o,n).scale(1,1).step(),e[t].animationData=i.export(),this.setData({cardData:e})}}); 
 			}); 	require("packageLuckdraw/luckdraw/luckdraw.js");
 		__wxRoute = 'pages/index/member/memberExchange/memberExchange';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/index/member/memberExchange/memberExchange.js';	define("pages/index/member/memberExchange/memberExchange.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e=getApp();Page({data:{btnDisabled:!0},onLoad:function(e){},onShow:function(){},inputEdit:function(e){var t=e.detail.value;this.setData({codeStr:t,btnDisabled:8!=t.length})},exchangeBtnTouch:function(){console.log(this.data.codeStr),wx.showLoading({title:"请稍候",mask:!0});var t=this;wx.request({url:e.configObj.memberExchange,data:{session:getApp().globalData.session,code:this.data.codeStr},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(e){console.log(e.data),0==e.data.code?t.setData({showAle:!0,aleSuccess:!0}):2==e.data.code?(t.hideAle(),t.setData({showMsg:!0})):t.setData({showAle:!0,aleSuccess:!1})},fail:function(){wx.showToast({title:"网络错误",icon:"none",duration:1e3})},complete:function(){wx.hideLoading()}})},toMember:function(){wx.redirectTo({url:"/pages/index/member/member?backRoot=true&referrer_title=会员兑换"})},hideAle:function(){this.setData({showAle:!1,codeStr:"",btnDisabled:!0})}}); 
 			}); 	require("pages/index/member/memberExchange/memberExchange.js");
 		__wxRoute = 'pages/helpCenter/issueInfo';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/helpCenter/issueInfo.js';	define("pages/helpCenter/issueInfo.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Page({data:{},onLoad:function(n){this.setData({issueObj:n})},onReady:function(){},onShow:function(){},onHide:function(){},onUnload:function(){},onPullDownRefresh:function(){},onReachBottom:function(){}}); 
 			}); 	require("pages/helpCenter/issueInfo.js");
 		__wxRoute = 'packageuser/user/user';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'packageuser/user/user.js';	define("packageuser/user/user.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e=require("../../utils/util.js"),t=getApp();Page({adv_objStr:{},data:{showModalAdv:!0,listData:[{title:"我的订单",image:"order"},{title:"我的钱包",image:"wallet"},{title:"我的卡券",image:"ticket"},{title:"使用帮助",image:"help"},{title:"设置",image:"set"}]},onLoad:function(){wx.showLoading({title:"正在加载"})},onShow:function(){var e=this;t.globalData.session&&e.requestUserInfo(),getApp().userLoginSuccessCallback=function(){e.requestUserInfo()},wx.getSetting({success:function(e){e.authSetting["scope.userInfo"]?wx.getUserInfo({success:function(e){}}):(wx.hideLoading(),t.globalData.authToUrl="/packageuser/user/user",wx.redirectTo({url:"/pages/index/authorization/authorization"}))}});var a=wx.getStorageSync("adv_obj");a&&(e.adv_objStr=JSON.parse(a),e.adv_objStr.wechat_yt?(e.data.showModalAdv&&t.advExposure(e.adv_objStr.wechat_yt,"300006"),e.setData({checkUrl_wechat_yt:e.adv_objStr.wechat_yt.checkUrl,materialUrl_wechat_yt:t.configObj.advImgAdd+e.adv_objStr.wechat_yt.materialUrl})):wx.createInterstitialAd&&!e.adShowed&&(e.adShowed=!0,wx.createInterstitialAd({adUnitId:"adunit-0c12f0abf1522eab"}).show()),e.adv_objStr.wechat_ydb&&(t.advExposure(e.adv_objStr.wechat_ydb,"300005"),e.setData({checkUrl_wechat_ydb:e.adv_objStr.wechat_ydb.checkUrl,materialUrl_wechat_ydb:t.configObj.advImgAdd+e.adv_objStr.wechat_ydb.materialUrl})))},requestUserInfo:function(){var a=this;wx.request({url:t.configObj.userInfoUrl,data:{session:t.globalData.session},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(o){if(5==o.data.code)getApp().globalData.session=null,getApp().login();else if(0==o.data.code){var n=o.data.data;t.globalData.userInfo=n.user_info,t.globalData.userInfo.phone_num=n.phone_num;var i,r=null;n.phone_num&&(getApp().dataObj.phone_num=i=n.phone_num,r=i.replace(/(\d{3})\d{4}(\d{4})/,"$1****$2"));var s={isVip:n.user_info.is_vip,phone:i,phonenum:r,showmember:!0};if(n.member_info){var c=e.toDate(n.member_info.end_time/1e3).trim().split(/\s+/)[0];Object.assign(s,{show_member_info:!0,fee_strategy:n.fee_strategy,end_time:c}),t.memberObj.is_vip=1}else{Object.assign(s,{show_member_info:!1});var d=wx.getStorageSync("memberStatus");t.memberObj.is_vip="02"==d||"03"==d?1:0}a.setData(s),wx.hideLoading()}else wx.hideLoading(),wx.showModal({content:o.data.msg,confirmText:"确定",showCancel:!1,success:function(e){e.confirm&&wx.reLaunch({url:"/pages/index/index"})}})},fail:function(){wx.hideLoading(),wx.showModal({content:"当前网络不佳,请切换网络重新进入该页面",showCancel:!1,confirmText:"我知道了",success:function(e){e.confirm&&wx.navigateBack({delta:1})}})},complete:function(){getApp().http_post({bhv_type:"view",obj_type:"Page",title:"首页",other:{},act_obj:10080})}})},onPullDownRefresh:function(){wx.showLoading({title:"正在加载"}),this.requestUserInfo(),wx.stopPullDownRefresh()},listTouch:function(e){var t=e.currentTarget.dataset.title;"我的钱包"==t?wx.navigateTo({url:"/packageuser/user/mywallet/mywallet"}):"我的订单"==t?wx.navigateTo({url:"/pages/ordering/ordering"}):"我的卡券"==t?wx.navigateTo({url:"/packageuser/user/myCoupon/myCoupon"}):"会员兑换"==t?wx.navigateTo({url:"/pages/index/member/memberExchange/memberExchange"}):"使用帮助"==t?this.helpBtnTouch():"设置"==t&&wx.navigateTo({url:"/packageuser/user/setUp/setUp"})},openingMember:function(){getApp().http_post({bhv_type:"click",obj_type:"Control",title:"个人中心",control_name:"个人中心_会员按钮",other:{},act_obj:10081}),wx.navigateTo({url:"/pages/index/member/member?backRoot=true&referrer_title=个人中心"})},userinfoBut:function(){wx.navigateTo({url:"/packageuser/user/information/information"})},todeposit:function(){wx.navigateTo({url:"/pages/deposit/deposit"})},changePhone:function(){var e=this.data.phone;wx.navigateTo({url:"/packageuser/user/getPhoneNum/getPhoneNum?phonenum="+e})},toCoiling:function(){wx.navigateTo({url:"/packageuser/user/myCoupon/myCoupon"})},downloadApp:function(){wx.showModal({title:"温馨提示",showCancel:!1,content:"请于各大应用市场下载速绿充电APP",success:function(e){}})},getPhoneNumber:function(e){var a=this,o=(a.data.phone,e.detail.iv),n=e.detail.encryptedData,i=t.globalData.authCode,r=t.globalData.trdSessionId;"getPhoneNumber:fail 用户未绑定手机，请先在微信客户端进行绑定后重试"==e.detail.errMsg||"getPhoneNumber:fail user deny"==e.detail.errMsg||"getPhoneNumber:ok"==e.detail.errMsg&&a.loginServerPhoneNumber(i,o,n,r,a)},loginServerPhoneNumber:function(e,a,o,n,i){wx.request({url:t.configObj.loginPhoneNumber,data:{code:e,encryptedData:o,iv:a,trdSessionId:n},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(e){var a=e.data.data.purePhoneNumber;wx.request({url:t.configObj.bindingPhoneNum,data:{session:t.globalData.session,mobile:a,code:"weChatPhoneNumberCode"},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(e){1==e.data.code?(i.setData({advertisingflag:!0,Unopened:!0}),i.requestUserInfo()):wx.showModal({content:e.data.msg,showCancel:!1,confirmText:"确定",success:function(e){e.confirm&&wx.navigateBack({delta:1})}})},fail:function(){wx.showToast({title:"失败",icon:"none"})}})}})},catchAd:function(){t.pushAdv(this.adv_objStr.wechat_ydb,"300005")},onbinddoumob:function(){t.pushAdv(this.adv_objStr.wechat_yt,"300006"),this.adv_objStr.wechat_yt.checkUrl&&this.setData({showModalAdv:!1})},hideModal:function(){this.setData({showModalAdv:!1})},helpBtnTouch:function(){wx.navigateTo({url:"/pages/helpCenter/helpCenter?orderid=&csEntryType=3"})},adLoadFinish_banner:function(e){this.setData({showAd_banner:!0})}}); 
 			}); 	require("packageuser/user/user.js");
 		__wxRoute = 'packageuser/user/mywallet/mywallet';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'packageuser/user/mywallet/mywallet.js';	define("packageuser/user/mywallet/mywallet.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=getApp();Page({adv_objStr:{},data:{adisabled:!0,showModalAdv:!0},setUpData:function(){var a=t.globalData.userInfo;if(a){var e;e=!(a.usablemoney>0),this.setData({userInfo:a,adisabled:e}),wx.hideLoading()}},onLoad:function(){wx.showLoading({title:"正在加载"}),this.setUpData(),t.userInfoRequest(this.setUpData)},onShow:function(){var a=this;getApp().http_post({bhv_type:"view",obj_type:"Page",title:"我的钱包",act_obj:10045});var e=wx.getStorageSync("adv_obj");e&&(a.adv_objStr=JSON.parse(e),a.adv_objStr.wechat_wt&&(a.data.showModalAdv&&t.advExposure(a.adv_objStr.wechat_wt,"300015"),a.setData({checkUrl_wechat_wt:a.adv_objStr.wechat_wt.checkUrl,materialUrl_wechat_wt:t.configObj.advImgAdd+a.adv_objStr.wechat_wt.materialUrl})),a.adv_objStr.wechat_wdb&&(t.advExposure(a.adv_objStr.wechat_wdb,"300014"),a.setData({checkUrl_wechat_wdb:a.adv_objStr.wechat_wdb.checkUrl,materialUrl_wechat_wdb:t.configObj.advImgAdd+a.adv_objStr.wechat_wdb.materialUrl})))},onPullDownRefresh:function(){wx.showLoading({title:"正在加载"}),t.userInfoRequest(this.setUpData),wx.stopPullDownRefresh()},noTitlemodalTap:function(t){var a=this;getApp().http_post({bhv_type:"click",obj_type:"Control",title:"我的钱包",control_name:"我的钱包_提现",act_obj:10041});var e=a.data.userInfo.usablemoney;wx.navigateTo({url:"/packageuser/user/mywallet/withdraw/withdraw?usablemoney="+e})},catchAd:function(){t.pushAdv(this.adv_objStr.wechat_wdb,"300014")},onbinddoumob:function(){t.pushAdv(this.adv_objStr.wechat_wt,"300015"),this.adv_objStr.wechat_wt.checkUrl&&this.setData({showModalAdv:!1})},hideModal:function(){this.setData({showModalAdv:!1})},transactionDetails:function(){wx.navigateTo({url:"/packageuser/user/mywallet/transaction/transaction"})}}); 
 			}); 	require("packageuser/user/mywallet/mywallet.js");
 		__wxRoute = 'packageuser/user/mywallet/transaction/transaction';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'packageuser/user/mywallet/transaction/transaction.js';	define("packageuser/user/mywallet/transaction/transaction.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=require("../../../../utils/util.js"),a=getApp();Page({toolItemW:0,data:{width:0,height:0,currentTab:0,status:0,request_time:"",refund_time:""},onLoad:function(){var t=this;wx.showLoading({title:"正在加载"}),wx.getSystemInfo({success:function(a){t.setData({width:a.windowWidth,height:a.windowHeight})}}),t.recharge(),t.deductions(),t.getWithdrawRecods(),t.paidMember(),this.toolItemW=wx.getSystemInfoSync().windowWidth/4;var a=(this.toolItemW-50)/2;t.setData({lineX:a})},onPullDownRefresh:function(){wx.showLoading({title:"正在加载"}),this.recharge(),this.deductions(),this.getWithdrawRecods(),this.paidMember(),wx.stopPullDownRefresh()},scheTap:function(t){var a=this,e=t.currentTarget.dataset.ind,d=a.data.refund_logs[e].request_time,n=a.data.refund_logs[e].status,o=a.data.refund_logs[e].refund;wx.navigateTo({url:"/packageuser/user/mywallet/refund/refund?request_time="+d+"&status="+n+"&refund="+o})},bindChange:function(t){var a=this;if("touch"==t.detail.source){var e=t.detail.current,d=this.toolItemW*e+(this.toolItemW-50)/2;a.setData({currentTab:e,lineX:d})}},swichNav:function(t){var a=this;if(this.data.currentTab===t.target.dataset.current)return!1;var e=t.target.dataset.current,d=this.toolItemW*e+(this.toolItemW-50)/2;a.setData({currentTab:e,lineX:d})},objSort:function(t){return function(a){return 1==a[t]?-1:0}},getWithdrawRecods:function(){var e=this;wx.request({url:a.configObj.withdrawRecodsUrl,data:{session:a.globalData.session},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(a){if(0==a.data.code&&a.data.data.refund_logs.length>0){for(var d=0;d<a.data.data.refund_logs.length;d++)a.data.data.refund_logs[d].request_time=t.toDate(a.data.data.refund_logs[d].request_time),a.data.data.refund_logs[d].refund_time=t.toDate(a.data.data.refund_logs[d].refund_time);e.setData({refund_logs:a.data.data.refund_logs})}},fail:function(){},complete:function(){wx.hideLoading()}})},look:function(t){this.data.refund_logs[t.currentTarget.dataset.ind].look="查看"===this.data.refund_logs[t.currentTarget.dataset.ind].look?"收起":"查看",this.data.refund_logs[t.currentTarget.dataset.ind].open=!this.data.refund_logs[t.currentTarget.dataset.ind].open,this.setData({refund_logs:this.data.refund_logs})},refundHelp:function(){wx.navigateTo({url:"/pages/deposit/refundHelp/refundHelp"})},recharge:function(){var e=this;wx.request({url:a.configObj.getUserPaidLogs,data:{session:a.globalData.session},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(a){if(0==a.data.code&&a.data.data.userPaidLogs.length>0)for(var d=0;d<a.data.data.userPaidLogs.length;d++){a.data.data.userPaidLogs[d].created_date=t.toDate(a.data.data.userPaidLogs[d].created_date/1e3);a.data.data.userPaidLogs[d].created_date,a.data.data.userPaidLogs[d].paid;e.setData({userPaidLogs:a.data.data.userPaidLogs})}},fail:function(){},complete:function(){wx.hideLoading()}})},deductions:function(){var e=this;wx.request({url:a.configObj.getUseFeeOrderList,data:{session:a.globalData.session,page:0},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(a){if(0==a.data.code&&a.data.data.length>0){for(var d=0;d<a.data.data.length;d++)a.data.data[d].returnTime=t.toDate(a.data.data[d].returnTime/1e3);e.setData({OrderList:a.data.data})}},fail:function(){},complete:function(){wx.hideLoading()}})},paidMember:function(){var e=this;wx.request({url:a.configObj.memberPaidOrder,data:{session:a.globalData.session},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(a){if(0==a.data.code&&a.data.data.length>0){for(var d=0;d<a.data.data.length;d++)a.data.data[d].pay_time=t.toDate(a.data.data[d].pay_time/1e3);e.setData({paymember:a.data.data})}},fail:function(){},complete:function(){wx.hideLoading()}})}}); 
 			}); 	require("packageuser/user/mywallet/transaction/transaction.js");
 		__wxRoute = 'packageuser/user/information/information';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'packageuser/user/information/information.js';	define("packageuser/user/information/information.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var o=getApp();Page({onLoad:function(){},onShow:function(){var a=this;wx.showLoading({title:"正在加载"});var e=setInterval(function(){o.globalData.session&&(a.requestUserInfo(),a.numIsPhone(),clearInterval(e))},500)},requestUserInfo:function(){var a=this;o.globalData.session&&wx.request({url:o.configObj.userInfoUrl,data:{session:o.globalData.session},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(e){var n=!1;if((e.data.data.user_info.usablemoney<=0||0!=e.data.code)&&(n=!0),a.setData({adisabled:n,isbinding:1}),0==e.data.code){if(null!=e.data.data.phone_num)s=e.data.data.phone_num.replace(/(\d{3})\d{4}(\d{4})/,"$1****$2");else var s=null;a.setData({userInfo:e.data.data.user_info,phonenum:s}),wx.hideLoading()}else 1==e.data.code?console.log("缺少必要参数"):2==e.data.code?(console.log("session有误"),o.globalData.session=null,o.login()):3==e.data.code?console.log("登录code不合法"):4==e.data.code?console.log("用户加密数据解密错误"):5==e.data.code&&(console.log("session 过期"),o.globalData.session=null,o.login())},fail:function(){wx.showModal({content:"当前网络不佳,请切换网络重新进入该页面",showCancel:!1,confirmText:"我知道了",success:function(o){o.confirm&&wx.navigateBack({delta:1})}})},complete:function(){}})},onPullDownRefresh:function(){wx.showLoading({title:"正在加载"}),this.requestUserInfo(),this.numIsPhone(),wx.stopPullDownRefresh()},numIsPhone:function(){var a=this;o.globalData.session&&wx.request({url:o.configObj.IsPhoneNum,data:{session:o.globalData.session},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(o){0==o.data.code?a.setData({datacode:0}):1==o.data.code&&a.setData({datacode:1})}})}}); 
 			}); 	require("packageuser/user/information/information.js");
 		__wxRoute = 'packageuser/user/getPhoneNum/getPhoneNum';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'packageuser/user/getPhoneNum/getPhoneNum.js';	define("packageuser/user/getPhoneNum/getPhoneNum.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=getApp(),o=/^(((13[0-9]{1})|(14[0-9]{1})|(15[0-9]{1})|(16[0-9]{1})|(17[0-9]{1})|(18[0-9]{1})|(19[0-9]{1}))+\d{8})$/;Page({countdown:60,data:{advertisingflag:!1,issucsCode:!1,binded:!1,isopen:!1,issucopen:!1,isHistoryData:!1,isgray:!0,isgreen:!1,isnobut:!0,isyesbut:!1,last_time:"",is_show:!0,isimg_show:!1,data_phone:"",data_verify:"",datacode:2},onLoad:function(t){var o=this;"null"==t.phonenum?o.setData({isBinded:!1}):o.setData({isBinded:!0,phonenum:t.phonenum})},onShow:function(){},settime:function(t){if(0==t.countdown)return t.setData({is_show:!0,isHistoryData:!0}),void(t.countdown=60);t.setData({is_show:!1,last_time:t.countdown,isHistoryData:!0}),t.countdown--,setTimeout(function(){t.settime(t)},1e3)},input_phoneNum:function(t){this.setData({data_phone:t.detail.value}),11==this.data.data_phone.length?this.setData({isgray:!1,isgreen:!0,isimg_show:!0}):60==this.countdown?this.setData({isgray:!0,isgreen:!1,isimg_show:!1}):this.countdown>0&&this.countdown<60&&this.setData({isgray:!1,isgreen:!1,isimg_show:!1,is_show:!1})},clear_phoneNum:function(){this.countdown>0&&this.countdown<60?this.setData({inputValue:"",isimg_show:!1,isgreen:!1,isgray:!1,data_phone:"",is_show:!1}):this.setData({inputValue:"",isimg_show:!1,isgreen:!1,isgray:!0,data_phone:""})},input_identifyCode:function(t){this.setData({data_verify:t.detail.value}),4!=this.data.data_verify.length&&6!=this.data.data_verify.length||11!=this.data.data_phone.length?this.setData({isnobut:!0,isyesbut:!1}):this.setData({isnobut:!1,isyesbut:!0})},clickVerify:function(){var n=this,s=n.data.data_phone;return 0==s.length?(wx.showModal({content:"手机号不能为空",confirmText:"确定",confirmColor:"#23C788",showCancel:!1,success:function(t){}}),!1):s.length<11?(wx.showModal({content:"手机号长度有误",confirmText:"确定",confirmColor:"#23C788",showCancel:!1,success:function(t){}}),!1):o.test(s)?(wx.showLoading({title:"加载中",mask:!0}),void wx.request({url:t.configObj.verification,data:{session:t.globalData.session,mobile:s},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(t){wx.hideLoading(),1==t.data.code?(n.setData({issucsCode:!0,advertisingflag:!0}),n.setData({is_show:!n.data.is_show}),n.settime(n)):wx.showToast({title:"发送失败,请稍后再试",icon:"none"})},fail:function(){wx.hideLoading(),wx.showToast({title:"发送失败,请稍后再试",icon:"none"})}})):(wx.showModal({content:"手机号有误",confirmText:"确定",confirmColor:"#23C788",showCancel:!1,success:function(t){}}),!1)},nextStep:function(){var n=this,s=n.data.data_phone,e=(n.data.isBinded,n.data.datacode,n.data.data_verify);return 0==s.length?(wx.showModal({content:"手机号不能为空",confirmText:"确定",confirmColor:"#23C788",showCancel:!1,success:function(t){}}),!1):s.length<11?(wx.showModal({content:"手机号长度有误",confirmText:"确定",confirmColor:"#23C788",showCancel:!1,success:function(t){}}),!1):o.test(s)?0==e.length?(wx.showModal({content:"验证码不能为空",confirmText:"确定",confirmColor:"#23C788",showCancel:!1,success:function(t){}}),!1):void wx.request({url:t.configObj.checkMobileIsBinded,data:{session:t.globalData.session,code:e,mobile:s},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(o){0==o.data.code||2==o.data.code?wx.request({url:t.configObj.bindingPhoneNum,data:{session:t.globalData.session,mobile:s},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(t){0==t.data.code?n.setData({advertisingflag:!0,binded:!0}):3==t.data.code&&n.setData({advertisingflag:!0,issucopen:!0})},fail:function(t){wx.showModal({content:"当前网络延迟，请稍后再试",confirmText:"确定",success:function(t){t.confirm&&wx.navigateBack({delta:1})}})}}):1==o.data.code?n.setData({advertisingflag:!0,isopen:!0}):wx.showModal({content:o.data.msg,confirmText:"确定",confirmColor:"#23C788",showCancel:!1,success:function(t){}})}}):(wx.showModal({content:"手机号有误",confirmText:"确定",confirmColor:"#23C788",showCancel:!1,success:function(t){}}),!1)},Sure:function(){wx.navigateBack({delta:1})},sucsCode:function(){this.setData({issucsCode:!1,advertisingflag:!1})}}); 
 			}); 	require("packageuser/user/getPhoneNum/getPhoneNum.js");
 		__wxRoute = 'packageuser/user/aboutUs/aboutUs';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'packageuser/user/aboutUs/aboutUs.js';	define("packageuser/user/aboutUs/aboutUs.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Page({onLoad:function(){var e=getApp().dataObj.pg_version;this.setData({version:e})},agreement:function(){wx.navigateTo({url:"/packageuser/user/aboutUs/agreement/agreement"})}}); 
 			}); 	require("packageuser/user/aboutUs/aboutUs.js");
 		__wxRoute = 'packageuser/user/setUp/setUp';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'packageuser/user/setUp/setUp.js';	define("packageuser/user/setUp/setUp.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var n=getApp();Page({data:{},onLoad:function(){this.openingMember()},onReady:function(){},onShow:function(){},openingMember:function(){var e=this;wx.request({url:n.configObj.productDetail,data:{session:n.globalData.session,version:"1.0"},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(n){if(0==n.data.code){var o=n.data.data.signing_code,t=n.data.data.deduction_price;e.setData({deduction_price:t,signing_code:o})}},fail:function(){},complete:function(){}})},manageRenew:function(){var n=this.data.deduction_price;wx.redirectTo({url:"/pages/index/member/runRenew/runRenew?backRoot=false&deduction_price="+n})},toaboutUs:function(){wx.navigateTo({url:"/packageuser/user/aboutUs/aboutUs"})},handleCall:function(n){var e=n.target.dataset.phone;wx.makePhoneCall({phoneNumber:e})},onHide:function(){},onUnload:function(){},onPullDownRefresh:function(){},onReachBottom:function(){}}); 
 			}); 	require("packageuser/user/setUp/setUp.js");
 		__wxRoute = 'packageuser/user/aboutUs/agreement/agreement';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'packageuser/user/aboutUs/agreement/agreement.js';	define("packageuser/user/aboutUs/agreement/agreement.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Page({data:{},onLoad:function(n){},onReady:function(){},onShow:function(){},onHide:function(){},onUnload:function(){},onPullDownRefresh:function(){},onReachBottom:function(){}}); 
 			}); 	require("packageuser/user/aboutUs/agreement/agreement.js");
 		__wxRoute = 'packageuser/user/mywallet/refund/refund';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'packageuser/user/mywallet/refund/refund.js';	define("packageuser/user/mywallet/refund/refund.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=require("../../../../utils/util.js"),e=getApp();Page({data:{request_time:"",status:0,usablemoney:0},onLoad:function(t){t.request_time?this.setData({request_time:t.request_time,status:t.status}):this.getWithdrawRecods(),this.setData({refund:t.refund})},onShow:function(){getApp().http_post({bhv_type:"view",obj_type:"Page",title:"提现进度",act_obj:10044})},getWithdrawRecods:function(){var s=this;wx.request({url:e.configObj.withdrawRecodsUrl,data:{session:e.globalData.session},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(e){var a=e.data.data.refund_logs[0],i=t.toDate(a.request_time);s.setData({request_time:i,status:a.status})},fail:function(){},complete:function(){}})},gohome:function(){wx.reLaunch({url:"/pages/index/index"})}}); 
 			}); 	require("packageuser/user/mywallet/refund/refund.js");
 		__wxRoute = 'packageuser/user/mywallet/withdraw/withdraw';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'packageuser/user/mywallet/withdraw/withdraw.js';	define("packageuser/user/mywallet/withdraw/withdraw.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e=getApp();Page({clickableNot:!0,data:{usablemoney:0,advertisingflag:!1,Unopened:!1,isconnection:!1},onLoad:function(e){var a=this;a.numIsPhone(),a.setData({usablemoney:e.usablemoney})},onShow:function(){getApp().http_post({bhv_type:"view",obj_type:"Page",title:"提现",act_obj:10042})},numIsPhone:function(){var a=this;wx.request({url:e.configObj.IsPhoneNum,data:{session:e.globalData.session},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(e){0==e.data.code?a.setData({datacode:0}):1==e.data.code&&a.setData({datacode:1})}})},goHomeTap:function(){wx.navigateBack({delta:1})},resultTap:function(){var a=this;getApp().http_post({bhv_type:"click",obj_type:"Control",title:"提现",control_name:"提现_申请提现",act_obj:10043}),1==a.clickableNot&&(a.clickableNot=!1,wx.requestSubscribeMessage?wx.requestSubscribeMessage({tmplIds:[e.configObj.newsID.withdrawID],success:function(e){},fail:function(e){},complete:function(e){a.setData({isconnection:!0,advertisingflag:!0}),a.clickableNot=!0}}):(a.setData({isconnection:!0,advertisingflag:!0}),a.clickableNot=!0))},cancel:function(){this.setData({isconnection:!1,advertisingflag:!1})},withdrawal:function(){var a=this,o=a.data.usablemoney;wx.showLoading({title:"请稍后",mask:!0}),wx.request({url:e.configObj.refundUrl,data:{session:e.globalData.session},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(e){0==e.data.errcode||3==e.data.errcode||5==e.data.errcode?(a.requestUserInfo(),wx.redirectTo({url:"/packageuser/user/mywallet/refund/refund?refund="+o})):1==e.data.errcode?wx.showModal({content:"账户余额不足!",confirmText:"确定",success:function(e){e.confirm}}):2==e.data.errcode?wx.showModal({content:"提现申请中,请耐心等待",confirmText:"确定",success:function(e){e.confirm&&a.requestUserInfo()}}):wx.showToast({title:"提现申请失败",icon:"fail",duration:2e3})},fail:function(){wx.showModal({content:res.data.msg,showCancel:!1,confirmText:"确定",success:function(e){}})},complete:function(){wx.hideLoading()}})},getPhoneNumber:function(a){var o=this,t=a.detail.iv,n=a.detail.encryptedData,s=e.globalData.authCode,c=e.globalData.trdSessionId;"getPhoneNumber:fail 用户未绑定手机，请先在微信客户端进行绑定后重试"==a.detail.errMsg||"getPhoneNumber:fail user deny"==a.detail.errMsg||"getPhoneNumber:ok"==a.detail.errMsg&&o.loginServerPhoneNumber(s,t,n,c,o)},loginServerPhoneNumber:function(a,o,t,n,s){wx.request({url:e.configObj.loginPhoneNumber,data:{code:a,encryptedData:t,iv:o,trdSessionId:n},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(a){var o=a.data.data.purePhoneNumber;wx.request({url:e.configObj.bindingPhoneNum,data:{session:e.globalData.session,mobile:o,code:"weChatPhoneNumberCode"},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(e){1==e.data.code?(s.setData({advertisingflag:!0,Unopened:!0}),s.numIsPhone()):wx.showModal({content:e.data.msg,showCancel:!1,confirmText:"确定",success:function(e){e.confirm&&wx.navigateBack({delta:1})}})}})}})},Close:function(){this.setData({advertisingflag:!1,Unopened:!1})},requestUserInfo:function(){var a=this;e.globalData.session&&wx.request({url:e.configObj.userInfoUrl,data:{session:e.globalData.session},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(o){var t=!1;if((o.data.data.user_info.usablemoney<=0||0!=o.data.code)&&(t=!0),a.setData({adisabled:t}),0==o.data.code){if(null!=o.data.data.phone_num)n=o.data.data.phone_num.replace(/(\d{3})\d{4}(\d{4})/,"$1****$2");else var n=null;a.setData({userInfo:o.data.data.user_info,phonenum:n})}else 1==o.data.code?console.log("缺少必要参数"):2==o.data.code?(console.log("session有误"),e.globalData.session=null,e.login()):3==o.data.code?console.log("登录code不合法"):4==o.data.code?console.log("用户加密数据解密错误"):5==o.data.code&&(console.log("session 过期"),e.globalData.session=null,e.login())},fail:function(){wx.showModal({content:"当前网络不佳,请切换网络重新进入该页面",showCancel:!1,confirmText:"我知道了",success:function(e){e.confirm&&wx.navigateBack({delta:1})}})},complete:function(){}})}}); 
 			}); 	require("packageuser/user/mywallet/withdraw/withdraw.js");
 		__wxRoute = 'packageuser/user/myCoupon/myCoupon';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'packageuser/user/myCoupon/myCoupon.js';	define("packageuser/user/myCoupon/myCoupon.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t,a=require("../../../utils/weapp-qrcode.js"),o=getApp();Page({isHistoryData:!1,dataArray1:[],dataArray2:[],data:{code_num:"",lineX:0,widWidth:0,optionSel:0},onLoad:function(o){var e=this;void 0!=o.isHistoryData&&(e.isHistoryData="true"==o.isHistoryData),e.isHistoryData&&wx.setNavigationBarTitle({title:"历史优惠券"}),wx.getSystemInfo({success:function(t){e.setData({width:t.windowWidth,height:t.windowHeight})}}),e.setData({isHistoryData:e.isHistoryData,lineX:e.data.width/6,widWidth:e.data.width/6}),t=new a("canvas",{text:"code=00000000",width:200,height:200,colorDark:"#000000",colorLight:"#ffffff",correctLevel:a.CorrectLevel.H}),wx.showLoading({title:"请稍候..."}),this.onPullDownRefresh()},optionBtnTouch:function(t){console.log(t);var a=t.currentTarget.dataset.index;if(0==a)o=this.data.width/6;else var o=this.data.width/6*4;this.setData({lineX:o,optionSel:a}),this.setUpListData()},toHistory:function(){wx.navigateTo({url:"myCoupon?isHistoryData=true"})},toExplain:function(){wx.navigateTo({url:"/packageuser/user/myCoupon/Instructions/Instructions"})},getCouponRequest:function(t){var a=this,e=t;wx.request({url:o.configObj.getTickets,data:{session:o.globalData.session,status:t},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(t){if(0==t.data.code){a.isHistoryData?"1"==e?a.dataArray1=[]:a.dataArray2=[]:a.dataArray1=[];for(var o=0;o<t.data.data.length;o++){var i=t.data.data[o],s=i.status;a.isHistoryData?(i.isHistoryData=!0,1==s?a.dataArray1.push(i):2==s&&a.dataArray2.push(i)):0!=s&&3!=s||a.dataArray1.push(i)}a.setUpListData()}},complete:function(){wx.stopPullDownRefresh(),wx.hideLoading()}})},setUpListData:function(){0==this.data.optionSel?this.setData({listData:this.dataArray1}):1==this.data.optionSel&&this.setData({listData:this.dataArray2})},couponcode:function(t){this.setData({code_num:t.detail.value})},exchange:function(){var t=this,a=t.data.code_num;return 0==a.length?(wx.showToast({title:"券码不能为空",icon:"none",duration:1500}),!1):8!=a.length?(wx.showToast({title:"券码长度有误",icon:"none",duration:1500}),!1):void wx.request({url:o.configObj.exchangeTicket,data:{session:o.globalData.session,ticketNo:a},header:{"Content-Type":"application/x-www-form-urlencoded"},method:"POST",success:function(a){wx.showToast({title:a.data.msg,icon:"none",duration:1500}),t.setData({code_num:""}),setTimeout(function(){t.getCouponRequest("0")},1e3)}})},QRTouch:function(a){var o=a.detail;console.log(o),t.makeCode("code="+o.user_coupons_no),this.setData({showQR:!0})},advertisinghide:function(){this.setData({showQR:!1})},onReady:function(){},onShow:function(){},onHide:function(){},onUnload:function(){},onPullDownRefresh:function(){this.isHistoryData?(this.getCouponRequest("1"),this.getCouponRequest("2"),this.setData({notdataMsg:"暂无优惠券"})):this.getCouponRequest("0")},onReachBottom:function(){}}); 
 			}); 	require("packageuser/user/myCoupon/myCoupon.js");
 		__wxRoute = 'packageuser/user/myCoupon/Instructions/Instructions';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'packageuser/user/myCoupon/Instructions/Instructions.js';	define("packageuser/user/myCoupon/Instructions/Instructions.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Page({data:{},onLoad:function(n){},onReady:function(){},onShow:function(){},onHide:function(){},onUnload:function(){},onPullDownRefresh:function(){},onReachBottom:function(){}}); 
 			}); 	require("packageuser/user/myCoupon/Instructions/Instructions.js");
 	