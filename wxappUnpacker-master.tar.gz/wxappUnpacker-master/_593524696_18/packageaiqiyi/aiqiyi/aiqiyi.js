// packageaiqiyi/aiqiyi/aiqiyi.js
Page({data: {}})