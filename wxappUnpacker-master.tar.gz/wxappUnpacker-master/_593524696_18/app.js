var e = require("utils/WSCoordinate.js"), t = require("utils/util.js");

App({
    configObj: require("./config"),
    memberObj: {},
    leaseDataObj: {},
    toWxMiniProgram: !1,
    bluetoothDataObj: {},
    customizedCDB: {},
    bluetoothRefundRequesting: !1,
    clickable: !0,
    memberCallback: !1,
    onLaunch: function(e) {
        var t = this, a = wx.getStorageSync("userid");
        t.dataObj.user_id = a, t.adv_dataObj.userid = a;
        var o = e.scene;
        if ("1011" == o || "1012" == o || "1013" == o || "1025" == o || "1031" == o || "1032" == o || "1047" == o || "1048" == o || "1049" == o) ; else ;
        t.login(), t.getLocation(), wx.getSystemInfo({
            success: function(e) {
                wx.setStorageSync("model", e.model);
                var a = e.system.split(" "), o = a[0], n = a[1];
                t.dataObj.version = e.version, t.dataObj.manufacturer = e.brand, t.dataObj.model = e.model.replace(/\s+/g, ""), 
                t.dataObj.os = o, t.dataObj.os_version = n, t.globalData.SDKVersion = e.SDKVersion, 
                t.adv_dataObj.version = e.version, t.adv_dataObj.manufacturer = e.brand, t.adv_dataObj.model = e.model.replace(/\s+/g, ""), 
                t.adv_dataObj.os = o, t.adv_dataObj.os_version = n;
            }
        });
    },
    onShow: function(e) {
        var t = this;
        if (t.updataZFFData("onShow", t.toWxMiniProgram, e), 1038 === e.scene && t.toWxMiniProgram) {
            t.toWxMiniProgram = !1;
            var a = e.referrerInfo.appId;
            if ("wxd8f3793ea3b935b8" === a) (o = e.referrerInfo.extraData) ? t.creditNotifywx(o.query_id) : t.creditNotifywx(""); else if ("wxbd687630cd02ce1d" === a) {
                wx.showLoading({
                    title: "请稍候",
                    mask: !0
                });
                var o = e.referrerInfo.extraData;
                o ? setTimeout(function() {
                    t.applyDeduction();
                }, 3e3) : setTimeout(function() {
                    t.openingMember(function(e) {
                        e && t.applyDeduction();
                    });
                }, 3e3);
            } else t.leaseDataObj.canTouchZFFBtn = !0;
        } else t.leaseDataObj.canTouchZFFBtn = !0;
        wx.getNetworkType({
            success: function(e) {
                t.dataObj.network_type = e.networkType, t.adv_dataObj.network_type = e.networkType;
            }
        });
    },
    dataObj: {
        pg_version: "1.1.6",
        bind_type: "微信小程序",
        nick_name: "",
        gender: "",
        phone_num: "",
        gps: "",
        version: "",
        manufacturer: "",
        model: "",
        os: "",
        os_version: "",
        network_type: "",
        station_id: "",
        user_id: "",
        act_obj: "",
        other: "",
        create_time: "",
        referrer_title: ""
    },
    adv_dataObj: {
        pg_version: "1.1.6",
        bind_type: "WX",
        gps: "",
        userid: "",
        create_time: "",
        nick_name: "",
        gender: "",
        version: "",
        manufacturer: "",
        model: "",
        os: "",
        os_version: "",
        network_type: "",
        other: ""
    },
    login: function() {
        var e = this;
        this.globalData.session || wx.login({
            success: function(t) {
                t.code && wx.getUserInfo({
                    success: function(a) {
                        e.dataObj.nick_name = a.userInfo.nickName, e.dataObj.gender = a.userInfo.gender, 
                        e.adv_dataObj.nick_name = a.userInfo.nickName, e.adv_dataObj.gender = a.userInfo.gender, 
                        e.globalData.authCode = t.code, e.loginServer(t.code, a.encryptedData, a.iv);
                    }
                });
            },
            complete: function() {}
        });
    },
    loginServer: function(e, t, a) {
        var o = this;
        wx.request({
            url: o.configObj.loginUrl,
            data: {
                code: e,
                encryptedData: t,
                iv: a
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(e) {
                0 == e.data.code ? (getApp().globalData.trdSessionId = e.data.data.trdSessionId, 
                getApp().globalData.session = e.data.data.session, console.log("session:" + e.data.data.session), 
                wx.setStorageSync("userid", e.data.data.userid), o.dataObj.user_id = e.data.data.userid, 
                o.adv_dataObj.userid = e.data.data.userid, o.userLoginSuccessCallback && o.userLoginSuccessCallback(e)) : wx.showToast({
                    title: "登录失败",
                    icon: "none"
                });
            },
            fail: function() {
                wx.showToast({
                    title: "网络错误，请稍后重试",
                    icon: "none"
                });
            },
            complete: function() {}
        });
    },
    userInfoRequest: function(e) {
        var t = this;
        wx.request({
            url: t.configObj.userInfoUrl,
            data: {
                session: t.globalData.session
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(a) {
                5 == a.data.code ? (getApp().globalData.session = null, getApp().login()) : 0 == a.data.code && (t.globalData.userInfo = a.data.data.user_info, 
                t.globalData.userInfo.phone_num = a.data.data.phone_num, e && e());
            }
        });
    },
    qrCode: function(e) {
        wx.scanCode({
            success: function(t) {
                e(t.result);
            },
            fail: function(e) {},
            complete: function(e) {}
        });
    },
    globalData: {
        userInfo: null,
        session: null,
        authCode: null,
        trdSessionId: null,
        authToUrl: null
    },
    getLocation: function() {
        var t = this;
        wx.getLocation({
            success: function(a) {
                var o = e.transformFromWGSToGCJ(a.latitude, a.longitude), n = o.longitude + "," + o.latitude;
                t.dataObj.gps = n, t.adv_dataObj.gps = n;
                var i = o.latitude + "," + o.longitude;
                t.addgps = i, t.addressResolution(i);
            },
            fail: function(e) {
                t.adVertiseInfo("000000");
            }
        });
    },
    addressResolution: function(e) {
        var t = this;
        wx.request({
            url: "https://apis.map.qq.com/ws/geocoder/v1/",
            data: {
                key: "GMZBZ-EDAL3-UFV3X-37FOM-NOTC7-5ZB42",
                location: e
            },
            method: "GET",
            success: function(e) {
                var a = e.data.result.ad_info.city_code;
                if (a) o = (o = (o = (o = (o = a.substring(3)).replace(/110000/g, "110100")).replace(/310000/g, "310100")).replace(/500000/g, "500100")).replace(/120000/g, "120100"), 
                t.advcheckChange(o), wx.setStorageSync("city_code", o), t.globalData.city_code = o; else {
                    var o = wx.getStorageSync("city_code");
                    t.globalData.city_code = wx.getStorageSync("city_code"), t.adVertiseInfo(o);
                }
            },
            fail: function() {
                var e = wx.getStorageSync("city_code");
                t.adVertiseInfo(e);
            }
        });
    },
    advcheckChange: function(e) {
        var t = this;
        wx.request({
            url: t.configObj.checkChangeAdv,
            data: {
                type: "03",
                cityCode: e
            },
            method: "POST",
            header: {
                "Content-Type": "application/json"
            },
            success: function(a) {
                if ("0000" == a.data.errcode) {
                    var o = a.data.data;
                    wx.getStorageSync("advtimeStamp") != o ? t.adVertiseInfo(e, o) : (t.advRequested = !0, 
                    t.rootLoadAd && t.rootLoadAd());
                }
            },
            fail: function(e) {
                console.log(e);
            }
        });
    },
    adVertiseInfo: function(e, t) {
        var a = this;
        wx.request({
            url: a.configObj.getAdvertiseInfo,
            data: {
                type: "03",
                cityCode: e
            },
            method: "POST",
            header: {
                "Content-Type": "application/json"
            },
            success: function(e) {
                if ("0000" == e.data.errcode) {
                    for (var o = e.data.data, n = {}, i = 0; i < o.length; i++) n[o[i].spaceCode] = o[i];
                    n = JSON.stringify(n), wx.setStorageSync("advtimeStamp", t), wx.setStorageSync("adv_obj", n);
                } else "0004" == e.data.errcode && (wx.setStorageSync("advtimeStamp", t), wx.setStorageSync("adv_obj", "{}"));
                a.advRequested = !0, a.rootLoadAd && a.rootLoadAd();
            },
            fail: function(e) {
                console.log(e);
            }
        });
    },
    bluetoothRefund: function(e, t) {
        if (!this.bluetoothRefundRequesting) {
            this.bluetoothRefundRequesting = !0;
            var a = this;
            wx.request({
                url: a.configObj.bluetoothOrderRefund,
                data: {
                    session: a.globalData.session,
                    operationType: 3,
                    orderid: e
                },
                method: "POST",
                header: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                success: function(e) {
                    t && t();
                },
                complete: function() {
                    a.bluetoothRefundRequesting = !1;
                }
            });
        }
    },
    playAudio: function(e) {
        this.innerAudioContext || (this.innerAudioContext = wx.createInnerAudioContext(), 
        this.innerAudioContext.autoplay = !0);
        var t = this;
        setTimeout(function() {
            t.innerAudioContext.stop(), t.innerAudioContext.src = e, t.innerAudioContext.play();
        }, 1e3);
    },
    http_post: function(e) {
        var a = this;
        a.dataObj.create_time = t.formatDateAndTime(new Date());
        var o = a.dataObj, n = Object.assign({}, o, e);
        if (n.APIVersion = "0.6.0", "view" == n.bhv_type || "start" == n.bhv_type) i = a.configObj.buryingView; else var i = a.configObj.buryingClick;
        wx.request({
            url: i,
            data: n,
            method: "GET",
            header: {
                "Content-Type": "application/json"
            },
            success: function(e) {},
            fail: function(e) {}
        }), a.dataObj.other = "";
    },
    adv_http_post: function(e) {
        var t = this, a = new Date().getTime();
        t.adv_dataObj.create_time = a;
        var o = t.adv_dataObj, n = Object.assign({}, o, e);
        if (n.APIVersion = "0.6.0", "view" == n.bhv_type) i = t.configObj.advBuryingView; else var i = t.configObj.advBuryingClick;
        wx.request({
            url: i,
            data: n,
            method: "GET",
            header: {
                "Content-Type": "application/json"
            },
            success: function(e) {},
            fail: function(e) {}
        });
    },
    advExposure: function(e, t) {
        this.adv_http_post({
            bhv_type: "view",
            ad_positionid: t,
            ad_spaceid: e.flowSourceSpaceId,
            ad_planid: e.planId,
            loadpage: ""
        });
    },
    pushAdv: function(e, t) {
        var a = this;
        a.adv_http_post({
            bhv_type: "click",
            ad_positionid: t,
            ad_spaceid: e.flowSourceSpaceId,
            ad_planid: e.planId,
            loadpage: e.checkUrl
        });
        var o = e.checkUrl;
        e.appId ? a.clickable && (a.clickable = !1, wx.navigateToMiniProgram({
            appId: e.appId,
            path: o,
            envVersion: "release",
            complete: function() {
                a.clickable = !0;
            }
        })) : o && (0 == o.indexOf("https") ? wx.navigateTo({
            url: "/pages/advertising-h5/advertising-h5?advurl=" + encodeURIComponent(o)
        }) : wx.navigateTo({
            url: o
        }));
    },
    openingMember: function(e) {
        var t = this;
        wx.request({
            url: t.configObj.productDetail,
            data: {
                session: t.globalData.session,
                version: "1.0"
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(t) {
                0 == t.data.code && "function" == typeof e && e(t.data.data.signing_code);
            },
            fail: function() {},
            complete: function() {
                wx.hideLoading();
            }
        });
    },
    updataZFFData: function(e, t, a) {
        var o = this.leaseDataObj.orderid, n = this.adv_dataObj.userid;
        a = JSON.stringify(a), o && wx.request({
            url: this.configObj.seversLogs,
            data: {
                loginfo: "支付分返回小程序-userid=" + n + ",orderid=" + o + ",type=" + e + ",no=" + t + ",res=" + a
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST"
        });
    }
});