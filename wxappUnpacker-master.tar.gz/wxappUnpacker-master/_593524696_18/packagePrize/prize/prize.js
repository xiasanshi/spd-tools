// packagePrize/prize/prize.js
Page({data: {}})