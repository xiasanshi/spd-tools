var e, a, t, o = require("../../../utils/hmac.js"), i = getApp();

Page({
    backindex: 0,
    data: {
        advertisingflag: !1,
        showModal: !1,
        insufficientFive: !1,
        disabled: !1,
        adisabled: !0,
        checkedbox: !0,
        toBepaidModa: !1,
        toBepaidbox: !1,
        numleasingbox: !1,
        momentBusybox: !1
    },
    onLoad: function(t) {
        var o = this;
        i.leaseDataObj = {
            canTouchZFFBtn: !0
        }, a = void 0 == t.referrer_title ? "扫一扫" : t.referrer_title, wx.showLoading({
            title: "正在加载"
        }), e = void 0 != t.q ? decodeURIComponent(t.q) : t.qrcode, o.backindex = 0;
    },
    onReady: function() {
        var a = this;
        getApp().backOfWXMiniprogram = function(e) {
            a.backindex = e;
        }, i.globalData.session && a.getBorrowInfo(e, a), getApp().userLoginSuccessCallback = function() {
            a.getBorrowInfo(e, a);
        };
    },
    onShow: function() {
        var e = this;
        e.data.sid && getApp().http_post({
            bhv_type: "view",
            obj_type: "Page",
            title: "产品介绍页",
            referrer_title: e.options.referrer_title,
            station_id: e.data.sid,
            other: {
                soft_ver: e.data.soft_ver,
                madename: t
            },
            act_obj: 10017
        }), e.setData({
            checkedbox: !0,
            adisabled: !1,
            backindex: this.backindex
        });
    },
    getBorrowInfo: function(e, o) {
        wx.request({
            url: i.configObj.borrowUrl,
            data: {
                session: i.globalData.session,
                qrcode: e
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(e) {
                var n = !1;
                if (5 == e.data.code) getApp().globalData.session = null, getApp().login(); else if (0 == e.data.code) {
                    var s = e.data.data, d = s.device_ver, r = s.soft_ver;
                    if ("null" == o.options.custom_url) c = "../../../images/lease/productintroduction.png"; else var c = o.options.custom_url;
                    if (o.setData({
                        customName: o.options.custom_name,
                        customUrl: c,
                        advUrl: o.options.adv_url,
                        backgroundColor: o.options.background_color
                    }), t = o.options.madename, wx.setBackgroundColor && wx.setBackgroundColor({
                        backgroundColor: o.data.backgroundColor
                    }), wx.setNavigationBarColor({
                        frontColor: "#ffffff",
                        backgroundColor: o.data.backgroundColor
                    }), getApp().http_post({
                        bhv_type: "view",
                        obj_type: "Page",
                        title: "产品介绍页",
                        referrer_title: a,
                        station_id: s.sid,
                        other: {
                            soft_ver: r,
                            madename: t
                        },
                        act_obj: 10017
                    }), 1 == s.offLine) {
                        var l = s.sid;
                        return void wx.redirectTo({
                            url: "/pages/index/sweep/deviceAbnormal/deviceAbnormal?sid=" + l + "&device_ver=" + d + "&soft_ver=" + r + "&madename=" + t
                        });
                    }
                    s.cable_type[1] <= 0 && s.cable_type[2] <= 0 && s.cable_type[3] <= 0 && s.cable_type[4] <= 0 && (getApp().http_post({
                        bhv_type: "view",
                        obj_type: "Page",
                        title: "提示正在充电",
                        station_id: s.sid,
                        other: {
                            soft_ver: s.soft_ver,
                            madename: t
                        },
                        act_obj: 10024
                    }), n = !0, o.setData({
                        insufficientFive: !0,
                        advertisingflag: !0
                    })), i.leaseDataObj.device_ver = s.device_ver, i.leaseDataObj.soft_ver = s.soft_ver, 
                    i.leaseDataObj.auxiliary = s.auxiliary, i.leaseDataObj.sid = s.sid, i.leaseDataObj.deposite_need = s.deposite_need, 
                    i.leaseDataObj.madename = t, s.bluetoothWaitTime && (i.leaseDataObj.bluetoothWaitTime = s.bluetoothWaitTime), 
                    o.setData({
                        sid: s.sid,
                        tid: s.tid,
                        deposite_need: s.deposite_need,
                        need_pay: s.need_pay,
                        usable_money: s.usable_money,
                        fee_strategy: s.fee_strategy,
                        device_ver: s.device_ver,
                        soft_ver: s.soft_ver,
                        auxiliary: s.auxiliary,
                        adisabled: !1,
                        cdisabled: n,
                        isDepositPay: s.isDepositPay,
                        bindStatus: s.bindStatus,
                        frequency: s.frequency,
                        isBindMobile: s.isBindMobile
                    }), wx.navigateToMiniProgram || o.setData({
                        isDepositPay: !0,
                        backindex: 0
                    });
                } else wx.showModal({
                    content: e.data.msg,
                    confirmText: "确定",
                    showCancel: !1,
                    success: function(e) {
                        e.confirm && wx.reLaunch({
                            url: "/pages/index/index"
                        });
                    }
                });
            },
            fail: function(e) {
                wx.showModal({
                    content: "获取设备信息失败",
                    confirmText: "确定",
                    showCancel: !1,
                    success: function(e) {
                        e.confirm && wx.reLaunch({
                            url: "/pages/index/index"
                        });
                    }
                });
            },
            complete: function() {
                wx.hideLoading();
            }
        });
    },
    aPay: function() {
        var e = this, a = (e.data.need_pay, e.data.isDepositPay), t = e.data.frequency;
        0 == e.data.isBindMobile ? e.getPhoneNumber() : t ? e.setData({
            numleasingbox: !0,
            advertisingflag: !0
        }) : 0 == a ? e.pointsPayment() : wx.showModal({
            content: "信息失败",
            showCancel: !1
        });
    },
    cPay: function() {
        getApp().http_post({
            bhv_type: "click",
            obj_type: "Control",
            title: "产品介绍页",
            control_name: "产品介绍页_押金租借",
            station_id: this.data.sid,
            other: {
                soft_ver: this.data.soft_ver,
                madename: t
            },
            act_obj: 10019
        });
        var e = this, a = e.data.need_pay, o = e.data.frequency;
        0 == e.data.isBindMobile ? e.getPhoneNumber() : o ? e.setData({
            numleasingbox: !0,
            advertisingflag: !0
        }) : 0 != a ? (e.setData({
            showModal: !0,
            advertisingflag: !0
        }), getApp().http_post({
            bhv_type: "view",
            obj_type: "Page",
            title: "产品介绍页_押金租借_去支付弹窗",
            station_id: e.data.sid,
            other: {
                soft_ver: e.data.soft_ver,
                madename: t
            },
            act_obj: 10020
        })) : e.payment();
    },
    pointsPayment: function() {
        if (i.leaseDataObj.canTouchZFFBtn) {
            var e = this;
            e.setData({
                adisabled: !0
            }), setTimeout(function() {
                e.setData({
                    adisabled: !1
                });
            }, 3e3), getApp().http_post({
                bhv_type: "click",
                obj_type: "Control",
                title: "产品介绍页",
                control_name: "产品介绍页_免押金租借",
                station_id: e.data.sid,
                other: {
                    soft_ver: e.data.soft_ver,
                    madename: t
                },
                act_obj: 10018
            });
            var a = getApp().dataObj.model;
            wx.showLoading({
                title: "请稍候",
                mask: !0
            }), wx.request({
                url: i.configObj.wxCreditPay,
                data: {
                    session: i.globalData.session,
                    sid: e.data.sid,
                    cable_type: 2,
                    photo_info: a
                },
                header: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                method: "POST",
                success: function(a) {
                    if (wx.hideLoading(), e.zffBorrowOrderLogs(a, "request.success"), 0 == a.data.code) {
                        var n = a.data.result.miniprogram_appid, s = Math.floor(new Date().getTime() / 1e3) + "", d = a.data.result.package, r = a.data.result.nonce_str, c = a.data.result.mch_id, l = "okmnhyfzfhonh2lqwer12345tgb6yhn0", p = "mch_id=" + c + "&nonce_str=" + r + "&package=" + d + "&sign_type=HMAC-SHA256&timestamp=" + s + "&key=" + l, u = o.HmacSHA256(p, l).toString().toUpperCase(), f = a.data.result.miniprogram_path + "?timestamp=" + s + "&nonce_str=" + r + "&sign_type=HMAC-SHA256&sign=" + u;
                        i.leaseDataObj.miniprogram_appid = a.data.result.miniprogram_appid, i.leaseDataObj.orderid = a.data.result.out_order_no, 
                        e.zffBorrowOrderLogs(a, "navigateToMiniProgram"), i.creditNotifywx = e.creditNotifywx, 
                        wx.navigateToMiniProgram({
                            appId: n,
                            path: f,
                            extraData: {
                                mch_id: c,
                                package: d,
                                timestamp: s,
                                nonce_str: r,
                                sign_type: "HMAC-SHA256",
                                sign: u
                            },
                            success: function(a) {
                                i.leaseDataObj.canTouchZFFBtn = !1, console.log("打开成功"), e.backindex = 1, getApp().toWxMiniProgram = !0, 
                                e.zffBorrowOrderLogs(a, "navigateToMiniProgram.success");
                            },
                            fail: function(a) {
                                e.zffBorrowOrderLogs(a, "navigateToMiniProgram.fail");
                            }
                        });
                    } else 8 == a.data.code ? e.setData({
                        orderid: a.data.orderid,
                        toBepaidModa: !0,
                        toBepaidbox: !0
                    }) : 1 == a.data.code ? (getApp().http_post({
                        bhv_type: "view",
                        obj_type: "Page",
                        title: "产品介绍页_设备正忙弹窗",
                        station_id: e.data.sid,
                        other: {
                            soft_ver: e.data.soft_ver,
                            madename: t
                        },
                        act_obj: 10046
                    }), e.setData({
                        momentBusybox: !0,
                        advertisingflag: !0
                    })) : wx.showToast({
                        title: a.data.msg,
                        icon: "none",
                        duration: 2e3
                    });
                },
                fail: function(a) {
                    wx.hideLoading(), e.zffBorrowOrderLogs(a, "navigateToMiniProgram.fail");
                }
            });
        }
    },
    payment: function() {
        if (i.leaseDataObj.canTouchZFFBtn) {
            var e = this;
            e.setData({
                cdisabled: !0
            }), setTimeout(function() {
                e.setData({
                    cdisabled: !1
                });
            }, 3e3);
            e.data.device_ver, e.data.soft_ver, e.data.auxiliary, e.data.sid;
            wx.showLoading({
                title: "请稍候",
                mask: !0
            }), wx.request({
                url: i.configObj.paymentUrl,
                data: {
                    session: i.globalData.session,
                    sid: e.data.sid,
                    tid: e.data.tid,
                    cable_type: 2
                },
                header: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                method: "POST",
                success: function(a) {
                    if (wx.hideLoading(), 0 == a.data.errcode) {
                        var o = a.data.orderid;
                        i.leaseDataObj.orderid = o, 1 == a.data.pay_type ? wx.reLaunch({
                            url: "/pages/index/sweep/leaseSuccess/leaseSuccess"
                        }) : (getApp().http_post({
                            bhv_type: "click",
                            obj_type: "Control",
                            other: {
                                orderid: o,
                                soft_ver: e.data.soft_ver,
                                madename: t
                            },
                            title: "产品介绍页",
                            control_name: "产品介绍页_押金租借_去支付",
                            station_id: e.data.sid,
                            act_obj: 10021
                        }), wx.requestPayment({
                            timeStamp: a.data.wxpay_params.timeStamp,
                            nonceStr: a.data.wxpay_params.nonceStr,
                            package: a.data.wxpay_params.package,
                            signType: a.data.wxpay_params.signType,
                            paySign: a.data.wxpay_params.paySign,
                            success: function(e) {
                                wx.redirectTo({
                                    url: "/pages/index/sweep/leaseSuccess/leaseSuccess"
                                });
                            },
                            fail: function(e) {},
                            complete: function(e) {}
                        }));
                    } else 1 == a.data.errcode ? (getApp().http_post({
                        bhv_type: "view",
                        obj_type: "Page",
                        title: "产品介绍页_设备正忙弹窗",
                        station_id: e.data.sid,
                        other: {
                            soft_ver: e.data.soft_ver,
                            madename: t
                        },
                        act_obj: 10046
                    }), e.setData({
                        momentBusybox: !0,
                        advertisingflag: !0
                    })) : wx.showToast({
                        title: a.data.msg,
                        icon: "none",
                        duration: 2e3
                    });
                },
                fail: function() {
                    wx.hideLoading();
                }
            });
        }
    },
    creditNotifywx: function(e) {
        var a = i.leaseDataObj.orderid;
        if (0 == a.indexOf("WZF")) {
            wx.showLoading({
                title: "请稍候",
                mask: !0
            });
            var t = i.dataObj.model;
            wx.request({
                url: i.configObj.wxCreditNotify,
                data: {
                    session: i.globalData.session,
                    orderid: a,
                    query_id: e,
                    photo_info: t
                },
                header: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                method: "POST",
                success: function(e) {
                    0 == e.data.code && (console.log("弹电池成功"), wx.reLaunch({
                        url: "/pages/index/sweep/leaseSuccess/leaseSuccess"
                    }));
                },
                fail: function() {},
                complete: function() {
                    wx.hideLoading(), i.leaseDataObj.canTouchZFFBtn = !0;
                }
            });
        }
    },
    closewindow: function() {
        this.setData({
            adisabled: !1,
            cdisabled: !1,
            toBepaidModa: !1,
            toBepaidbox: !1
        });
    },
    bindhelp: function() {
        wx.redirectTo({
            url: "/pages/helpCenter/helpCenter"
        });
    },
    cancelbut: function() {
        getApp().http_post({
            bhv_type: "view",
            obj_type: "Page",
            title: "产品介绍页",
            station_id: this.data.sid,
            other: {
                soft_ver: this.data.soft_ver,
                madename: t
            },
            act_obj: 10017
        }), this.setData({
            showModal: !1,
            advertisingflag: !1
        });
    },
    tomomentBusy: function() {
        this.setData({
            momentBusybox: !1,
            advertisingflag: !1
        });
    },
    Sure: function() {
        var e = i.dataObj.gps, a = "", t = "";
        e.indexOf(",") && (a = e.split(",")[0], t = e.split(",")[1]), wx.navigateTo({
            url: "/packagenearby/nearby/nearby?latitude=" + t + "&longitude=" + a
        });
    },
    mayNot: function() {
        wx.reLaunch({
            url: "/pages/index/index"
        });
    },
    paymentbut: function() {
        var e = this;
        e.setData({
            showModal: !1,
            advertisingflag: !1
        }), e.payment();
    },
    checkboxChange: function(e) {
        "" == e.detail.value ? this.setData({
            adisabled: !0
        }) : this.setData({
            adisabled: !1
        });
    },
    authorizationshop: function() {
        wx.navigateTo({
            url: "/pages/index/sweep/entrustbox/entrustbox"
        });
    },
    zffBorrowOrderLogs: function(e, a) {
        var t = i.leaseDataObj.orderid ? i.leaseDataObj.orderid : "", o = getApp().dataObj.version, n = JSON.stringify(e);
        wx.request({
            url: i.configObj.seversLogs,
            data: {
                loginfo: "支付分跳转问题--" + a + ": orderid=" + t + ",res=" + n + ",version=" + o
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST"
        });
    },
    getPhoneNumber: function(e) {
        var a = this, t = e.detail.iv, o = e.detail.encryptedData, n = i.globalData.authCode, s = i.globalData.trdSessionId, d = e.target.dataset.modenum;
        "getPhoneNumber:fail 用户未绑定手机，请先在微信客户端进行绑定后重试" == e.detail.errMsg || "getPhoneNumber:fail user deny" == e.detail.errMsg || "getPhoneNumber:ok" == e.detail.errMsg && a.loginServerPhoneNumber(n, t, o, s, d, a);
    },
    loginServerPhoneNumber: function(e, a, t, o, n, s) {
        wx.request({
            url: i.configObj.loginPhoneNumber,
            data: {
                code: e,
                encryptedData: t,
                iv: a,
                trdSessionId: o
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(e) {
                var a = e.data.data.purePhoneNumber;
                wx.request({
                    url: i.configObj.bindingPhoneNum,
                    data: {
                        session: i.globalData.session,
                        mobile: a,
                        code: "weChatPhoneNumberCode"
                    },
                    header: {
                        "Content-Type": "application/x-www-form-urlencoded"
                    },
                    method: "POST",
                    success: function(e) {
                        1 == e.data.code ? (s.setData({
                            isBindMobile: !0
                        }), 1 == n ? s.aPay() : 2 == n && s.cPay()) : wx.showToast({
                            title: e.data.msg,
                            icon: "none",
                            duration: 1500
                        });
                    },
                    fail: function() {
                        wx.showToast({
                            title: "失败",
                            icon: "none"
                        });
                    }
                });
            }
        });
    }
});