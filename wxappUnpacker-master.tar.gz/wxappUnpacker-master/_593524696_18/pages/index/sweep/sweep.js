var e, t, a = getApp();

Page({
    data: {},
    onLoad: function(o) {
        var i = this;
        if (wx.getMenuButtonBoundingClientRect) {
            var s = wx.getMenuButtonBoundingClientRect().top + 2;
            i.setData({
                backBtnTop: s
            });
        }
        a.leaseDataObj = {
            canTouchZFFBtn: !0
        }, t = void 0 == o.referrer_title ? "扫一扫" : o.referrer_title, wx.showLoading({
            title: "正在加载",
            mask: !0
        }), e = void 0 != o.q ? decodeURIComponent(o.q) : o.qrcode, wx.getSetting({
            success: function(t) {
                t.authSetting["scope.userInfo"] || (wx.hideLoading(), a.globalData.authToUrl = "/pages/index/sweep/sweep?qrcode=" + e, 
                wx.redirectTo({
                    url: "/pages/index/authorization/authorization"
                }));
            }
        });
    },
    onReady: function() {
        var e = this;
        a.globalData.session && e.getBorrowInfo(), getApp().userLoginSuccessCallback = function() {
            e.getBorrowInfo();
        };
    },
    onShow: function() {
        var e = this;
        e.data.sid && getApp().http_post({
            bhv_type: "view",
            obj_type: "Page",
            title: "产品介绍页",
            referrer_title: t,
            station_id: e.data.sid,
            other: {
                soft_ver: e.data.soft_ver,
                madename: "普通",
                is_vip: a.memberObj.is_vip
            },
            act_obj: 10017
        });
    },
    memberOpening: function() {
        var e = this;
        getApp().http_post({
            bhv_type: "click",
            obj_type: "Control",
            title: "产品介绍页",
            control_name: "产品介绍页_开通会员",
            station_id: this.data.sid,
            other: {
                is_vip: a.memberObj.is_vip
            },
            act_obj: 10077
        }), wx.navigateTo({
            url: "/pages/index/member/member?referrer_title=产品介绍页",
            events: {
                reloadData: e.getBorrowInfo
            }
        });
    },
    getBorrowInfo: function() {
        var o = this;
        wx.request({
            url: a.configObj.borrowUrl,
            data: {
                session: a.globalData.session,
                qrcode: e,
                version: "1.1"
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(e) {
                var i = !1;
                if (5 == e.data.code) getApp().globalData.session = null, getApp().login(); else if (0 == e.data.code) {
                    var s = e.data.data, n = s.device_ver, r = s.soft_ver, d = "02" == s.memberStatus || "03" == s.memberStatus;
                    if (a.memberObj.is_vip = d ? 1 : 0, o.data.sid || getApp().http_post({
                        bhv_type: "view",
                        obj_type: "Page",
                        title: "产品介绍页",
                        referrer_title: t,
                        station_id: s.sid,
                        other: {
                            soft_ver: r,
                            madename: "普通",
                            is_vip: a.memberObj.is_vip
                        },
                        act_obj: 10017
                    }), 1 == s.offLine) {
                        var p = s.sid;
                        return void wx.redirectTo({
                            url: "/pages/index/sweep/deviceAbnormal/deviceAbnormal?sid=" + p + "&device_ver=" + n + "&soft_ver=" + r + "&madename=普通"
                        });
                    }
                    s.cable_type[1] <= 0 && s.cable_type[2] <= 0 && s.cable_type[3] <= 0 && s.cable_type[4] <= 0 && (getApp().http_post({
                        bhv_type: "view",
                        obj_type: "Page",
                        title: "提示正在充电",
                        station_id: s.sid,
                        other: {
                            soft_ver: s.soft_ver,
                            madename: "普通"
                        },
                        act_obj: 10024
                    }), i = !0, 0 == s.total && o.setData({
                        notBattery: !0
                    }), o.setData({
                        showBatteryLowpower: !0,
                        showPopBg: !0
                    })), s.memberStatus ? wx.setStorageSync("memberStatus", s.memberStatus) : wx.setStorageSync("memberStatus", ""), 
                    a.leaseDataObj.device_ver = s.device_ver, a.leaseDataObj.soft_ver = s.soft_ver, 
                    a.leaseDataObj.auxiliary = s.auxiliary, a.leaseDataObj.sid = s.sid, a.leaseDataObj.deposite_need = s.deposite_need, 
                    a.leaseDataObj.madename = "普通", a.leaseDataObj.memberShow = s.memberShow, s.bluetoothWaitTime && (a.leaseDataObj.bluetoothWaitTime = s.bluetoothWaitTime), 
                    o.setData({
                        sid: s.sid,
                        tid: s.tid,
                        deposite_need: s.deposite_need,
                        need_pay: s.need_pay,
                        usable_money: s.usable_money,
                        fee_strategy: s.fee_strategy,
                        device_ver: s.device_ver,
                        soft_ver: s.soft_ver,
                        auxiliary: s.auxiliary,
                        adisabled: !1,
                        cdisabled: i,
                        isDepositPay: s.isDepositPay,
                        bindStatus: s.bindStatus,
                        frequency: s.frequency,
                        isBindMobile: s.isBindMobile,
                        memberShow: s.memberShow,
                        memberStatus: s.memberStatus,
                        memberBtnShow: !d && s.memberShow
                    }), d || s.isShopVip && o.setData({
                        isMemberSign: !0,
                        isShopVip: !0
                    }), wx.navigateToMiniProgram || o.setData({
                        isDepositPay: !0
                    });
                } else wx.showToast({
                    title: e.data.msg,
                    icon: "none"
                });
            },
            fail: function(e) {
                wx.showToast({
                    title: "获取设备信息失败",
                    icon: "none"
                });
            },
            complete: function() {
                wx.hideLoading(), o.setData({
                    showBorrowInfo: !0
                });
            }
        });
    },
    leaseBut: function(e) {
        var t = e.target.dataset.modenum;
        1 == this.data.isBindMobile && (1 == t ? this.aPay() : 2 == t && this.cPay());
    },
    aPay: function(e) {
        var t = this;
        if (a.leaseDataObj.canTouchZFFBtn) {
            getApp().http_post({
                bhv_type: "click",
                obj_type: "Control",
                title: "产品介绍页",
                control_name: "产品介绍页_免押金租借",
                station_id: t.data.sid,
                other: {
                    soft_ver: t.data.soft_ver,
                    madename: "普通",
                    is_vip: a.memberObj.is_vip
                },
                act_obj: 10018
            });
            var o = t.data.frequency;
            t.data.isBindMobile;
            o ? t.setData({
                numleasingbox: !0,
                showPopBg: !0
            }) : wx.requestSubscribeMessage ? t.notifyMethod(!0) : t.pointsPayment();
        }
    },
    newsCheckboxChange: function(e) {
        var t = !this.data.newscheckedbox;
        this.setData({
            newscheckedbox: t
        }), 1 == t && this.notifyMethod(!1);
    },
    notifyMethod: function(e) {
        var t = this;
        a.leaseDataObj.canTouchZFFBtn = !1;
        var o = [ a.configObj.newsID.returnID, a.configObj.newsID.borrowID ];
        "02" == t.data.memberStatus && "03" == t.data.memberStatus || o.push(a.configObj.newsID.activityID), 
        wx.requestSubscribeMessage({
            tmplIds: o,
            complete: function(o) {
                a.leaseDataObj.canTouchZFFBtn = !0, t.setData({
                    newscheckedbox: !0
                }), e && t.pointsPayment();
            }
        });
    },
    cPay: function(e) {
        var t = this;
        getApp().http_post({
            bhv_type: "click",
            obj_type: "Control",
            title: "产品介绍页",
            control_name: "产品介绍页_押金租借",
            station_id: t.data.sid,
            other: {
                soft_ver: t.data.soft_ver,
                madename: "普通",
                is_vip: a.memberObj.is_vip
            },
            act_obj: 10019
        });
        var o = t.data.need_pay, i = t.data.frequency;
        t.data.isBindMobile;
        i ? t.setData({
            numleasingbox: !0,
            showPopBg: !0
        }) : 0 != o ? (t.setData({
            showModal: !0,
            showPopBg: !0
        }), getApp().http_post({
            bhv_type: "view",
            obj_type: "Page",
            title: "产品介绍页_押金租借_去支付弹窗",
            station_id: t.data.sid,
            other: {
                soft_ver: t.data.soft_ver,
                madename: "普通",
                is_vip: a.memberObj.is_vip
            },
            act_obj: 10020
        })) : t.payment();
    },
    pointsPayment: function() {
        var e = this;
        if (!e.data.adisabled) {
            e.setData({
                adisabled: !0
            }), setTimeout(function() {
                e.setData({
                    adisabled: !1
                });
            }, 3e3);
            var t = getApp().dataObj.model;
            wx.showLoading({
                title: "请稍候",
                mask: !0
            }), wx.request({
                url: a.configObj.wxCreditPay,
                data: {
                    session: a.globalData.session,
                    sid: e.data.sid,
                    cable_type: 2,
                    photo_info: t
                },
                header: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                method: "POST",
                success: function(t) {
                    if (wx.hideLoading(), e.zffBorrowOrderLogs(t, "request.success"), 0 == t.data.code) {
                        a.leaseDataObj.canTouchZFFBtn = !1;
                        var o = t.data.result, i = o.miniprogram_appid;
                        a.leaseDataObj.miniprogram_appid = i, a.leaseDataObj.orderid = t.data.result.out_order_no, 
                        e.zffBorrowOrderLogs(t, "navigateToMiniProgram"), a.creditNotifywx = e.creditNotifywx, 
                        wx.navigateToMiniProgram({
                            appId: i,
                            path: o.miniprogram_path,
                            extraData: {
                                mch_id: o.mchid,
                                package: o.package,
                                timestamp: o.timestamp,
                                nonce_str: o.nonce_str,
                                sign_type: o.sign_type,
                                sign: o.sign
                            },
                            success: function(t) {
                                getApp().toWxMiniProgram = !0, e.zffBorrowOrderLogs(t, "navigateToMiniProgram.success");
                            },
                            fail: function(t) {
                                e.setData({
                                    adisabled: !1
                                }), a.leaseDataObj.canTouchZFFBtn = !0, e.zffBorrowOrderLogs(t, "navigateToMiniProgram.fail");
                            }
                        });
                    } else 8 == t.data.code ? e.setData({
                        lastOrderid: t.data.orderid,
                        toBepaidModa: !0
                    }) : 1 == t.data.code ? (getApp().http_post({
                        bhv_type: "view",
                        obj_type: "Page",
                        title: "产品介绍页_设备正忙弹窗",
                        station_id: e.data.sid,
                        other: {
                            soft_ver: e.data.soft_ver,
                            madename: "普通"
                        },
                        act_obj: 10046
                    }), e.setData({
                        momentBusybox: !0,
                        showPopBg: !0
                    })) : (wx.showToast({
                        title: t.data.msg,
                        icon: "none",
                        duration: 2e3
                    }), 9 == t.data.code && e.setData({
                        isDepositPay: !0
                    }));
                },
                fail: function(t) {
                    wx.hideLoading(), e.zffBorrowOrderLogs(t, "navigateToMiniProgram.fail");
                }
            });
        }
    },
    payment: function() {
        if (a.leaseDataObj.canTouchZFFBtn) {
            var e = this;
            e.setData({
                cdisabled: !0
            }), setTimeout(function() {
                e.setData({
                    cdisabled: !1
                });
            }, 3e3), wx.showLoading({
                title: "请稍候",
                mask: !0
            }), wx.request({
                url: a.configObj.paymentUrl,
                data: {
                    session: a.globalData.session,
                    sid: e.data.sid,
                    tid: e.data.tid,
                    cable_type: 2
                },
                header: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                method: "POST",
                success: function(t) {
                    if (wx.hideLoading(), 0 == t.data.errcode) {
                        var o = t.data.orderid;
                        a.leaseDataObj.orderid = o, 1 == t.data.pay_type ? e.toLeaseSuccess() : (getApp().http_post({
                            bhv_type: "click",
                            obj_type: "Control",
                            other: {
                                orderid: o,
                                soft_ver: e.data.soft_ver,
                                is_vip: a.memberObj.is_vip
                            },
                            title: "产品介绍页",
                            control_name: "产品介绍页_押金租借_去支付",
                            station_id: e.data.sid,
                            act_obj: 10021
                        }), wx.requestPayment({
                            timeStamp: t.data.wxpay_params.timeStamp,
                            nonceStr: t.data.wxpay_params.nonceStr,
                            package: t.data.wxpay_params.package,
                            signType: t.data.wxpay_params.signType,
                            paySign: t.data.wxpay_params.paySign,
                            success: function(t) {
                                e.toLeaseSuccess();
                            },
                            fail: function(e) {},
                            complete: function(e) {}
                        }));
                    } else 1 == t.data.errcode ? (getApp().http_post({
                        bhv_type: "view",
                        obj_type: "Page",
                        title: "产品介绍页_设备正忙弹窗",
                        station_id: e.data.sid,
                        other: {
                            soft_ver: e.data.soft_ver,
                            madename: "普通"
                        },
                        act_obj: 10046
                    }), e.setData({
                        momentBusybox: !0,
                        showPopBg: !0
                    })) : wx.showToast({
                        title: t.data.msg,
                        icon: "none",
                        duration: 2e3
                    });
                },
                fail: function() {
                    wx.hideLoading();
                }
            });
        }
    },
    creditNotifywx: function(e) {
        var t = a.leaseDataObj.orderid;
        if (void 0 != t && 0 == t.indexOf("WZF")) {
            wx.showLoading({
                title: "请稍候",
                mask: !0
            });
            var o = this, i = a.dataObj.model;
            wx.request({
                url: a.configObj.wxCreditNotify,
                data: {
                    session: a.globalData.session,
                    orderid: t,
                    query_id: e,
                    photo_info: i
                },
                header: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                method: "POST",
                success: function(e) {
                    0 == e.data.code ? o.toLeaseSuccess() : (o.setData({
                        showDepositBorrow: !0
                    }), getApp().http_post({
                        bhv_type: "view",
                        obj_type: "Page",
                        title: "产品介绍页_是否选择押金租借",
                        station_id: o.data.sid,
                        other: {
                            is_vip: a.memberObj.is_vip
                        },
                        act_obj: 10103
                    }));
                },
                fail: function() {},
                complete: function(e) {
                    wx.hideLoading(), a.leaseDataObj.canTouchZFFBtn = !0, a.updataZFFData("popupRequest", "", e);
                }
            });
        }
    },
    toLeaseSuccess: function() {
        wx.reLaunch({
            url: "/pages/index/sweep/leaseSuccess/leaseSuccess"
        });
    },
    bindhelp: function() {
        wx.redirectTo({
            url: "/pages/helpCenter/helpCenter"
        });
    },
    cancelbut: function() {
        getApp().http_post({
            bhv_type: "view",
            obj_type: "Page",
            title: "产品介绍页",
            station_id: this.data.sid,
            other: {
                soft_ver: this.data.soft_ver,
                madename: "普通",
                is_vip: a.memberObj.is_vip
            },
            act_obj: 10017
        }), this.setData({
            showModal: !1,
            showPopBg: !1
        });
    },
    tomomentBusy: function() {
        this.setData({
            momentBusybox: !1,
            showPopBg: !1
        });
    },
    Sure: function() {
        var e = a.dataObj.gps, t = "", o = "";
        e.indexOf(",") && (t = e.split(",")[0], o = e.split(",")[1]), wx.redirectTo({
            url: "/packagenearby/nearby/nearby?latitude=" + o + "&longitude=" + t
        });
    },
    closeBorrowLimitBox: function() {
        this.setData({
            showPopBg: !1,
            numleasingbox: !1
        });
    },
    closeLowpowerBox: function() {
        this.setData({
            showPopBg: !1,
            showBatteryLowpower: !1
        }), this.mayNot();
    },
    mayNot: function() {
        wx.reLaunch({
            url: "/pages/index/index"
        });
    },
    paymentbut: function() {
        this.setData({
            showPopBg: !1,
            showModal: !1
        }), this.payment();
    },
    authorizationshop: function() {
        wx.navigateTo({
            url: "/pages/index/sweep/entrustbox/entrustbox"
        });
    },
    zffBorrowOrderLogs: function(e, t) {
        var o = a.leaseDataObj.orderid ? a.leaseDataObj.orderid : "", i = getApp().dataObj.version, s = JSON.stringify(e);
        wx.request({
            url: a.configObj.seversLogs,
            data: {
                loginfo: "支付分跳转问题--" + t + ": userId=" + a.dataObj.user_id + ",orderid=" + o + ",res=" + s + ",version=" + i
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST"
        });
    },
    getPhoneNumber: function(e) {
        var t = this, o = e.detail.iv, i = e.detail.encryptedData, s = a.globalData.authCode, n = a.globalData.trdSessionId, r = e.target.dataset.modenum;
        "getPhoneNumber:ok" == e.detail.errMsg && t.loginServerPhoneNumber(s, o, i, n, r, t);
    },
    loginServerPhoneNumber: function(e, t, o, i, s, n) {
        wx.showLoading({
            title: "请稍候",
            mask: !0
        }), wx.request({
            url: a.configObj.loginPhoneNumber,
            data: {
                code: e,
                encryptedData: o,
                iv: t,
                trdSessionId: i
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(e) {
                var t = e.data.data.purePhoneNumber;
                wx.request({
                    url: a.configObj.bindingPhoneNum,
                    data: {
                        session: a.globalData.session,
                        mobile: t,
                        code: "weChatPhoneNumberCode"
                    },
                    header: {
                        "Content-Type": "application/x-www-form-urlencoded"
                    },
                    method: "POST",
                    success: function(e) {
                        wx.hideLoading(), 1 == e.data.code ? (n.setData({
                            isBindMobile: !0
                        }), 1 == s ? n.aPay() : 2 == s && n.cPay()) : wx.showToast({
                            title: e.data.msg,
                            icon: "none",
                            duration: 1500
                        });
                    },
                    fail: function() {
                        wx.showToast({
                            title: "失败",
                            icon: "none"
                        });
                    }
                });
            },
            fail: function() {
                wx.showToast({
                    title: "失败",
                    icon: "none"
                });
            }
        });
    },
    toPayment: function() {
        wx.navigateTo({
            url: "/pages/ordering/ordering"
        }), this.setData({
            toBepaidModa: !1
        });
    },
    backBtnTouch: function() {
        1 == getCurrentPages().length ? wx.reLaunch({
            url: "/pages/index/index"
        }) : wx.navigateBack();
    },
    handleDepositPop: function(e) {
        this.setData({
            showDepositBorrow: !1
        });
        var t = e.target.dataset.flag;
        "success" === t && this.cPay(), getApp().http_post({
            bhv_type: "click",
            obj_type: "Control",
            title: "产品介绍页",
            control_name: "产品介绍页_是否选择押金租借结果",
            station_id: this.data.sid,
            other: {
                is_vip: a.memberObj.is_vip,
                result: t
            },
            act_obj: 10104
        });
    }
});