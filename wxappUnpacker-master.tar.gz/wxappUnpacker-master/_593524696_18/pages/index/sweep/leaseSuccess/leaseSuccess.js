var e = getApp();

Page({
    adv_objStr: {},
    requestTimer: "",
    times: "",
    progress: "",
    interval: "",
    judgeOpenBluetoothShowed: !1,
    deviceId: "",
    serviceId: "",
    orderIDCharacteristicId: "",
    resultCharacteristicId: "",
    frontbluetoothWaitTime: "",
    afterbluetoothWaitTime: "",
    orderMdStr: "",
    leaseDataObj: {},
    bluetoothResult: {},
    timeCount: 90,
    data: {
        percent: 1,
        status: "",
        smallBattery: [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 ],
        showSlotBox: !0,
        colorCircleFirst: "#31A448",
        countDown: 3
    },
    onLoad: function(t) {
        var o = this;
        o.leaseDataObj = e.leaseDataObj;
        var a, r = o.leaseDataObj.device_ver;
        a = 101 == r || 102 == r || 103 == r || 104 == r || 105 == r || 106 == r || 107 == r || 108 == r || 111 == r || 150 == r || 151 == r ? "H3" : 2 == r || 31 == r || 32 == r || 33 == r || 34 == r || 36 == r ? "Big_40" : 150 == r || 151 == r || 152 == r || 153 == r || 154 == r || 155 == r || 156 == r || 270 == r || 271 == r || 272 == r || 273 == r || 274 == r || 275 == r ? "H3_C" : 35 == r ? "Big_80" : 501 == r ? "Big_20" : "H2", 
        o.setData({
            deviceType: a,
            showMemberBtn: o.leaseDataObj.memberShow && "01" == wx.getStorageSync("memberStatus")
        }), o.percentAdd(), o.progress = setInterval(o.progressNum, 1e3);
        var s = e.leaseDataObj.bluetoothWaitTime;
        s && (s.length ? (o.frontbluetoothWaitTime = s.split("/")[0], o.afterbluetoothWaitTime = s.split("/")[1]) : (o.frontbluetoothWaitTime = 20, 
        o.afterbluetoothWaitTime = 30), setTimeout(function() {
            o.orderMdStr && o.orderMdStr.length && 2 != o.data.status && o.startBluetoothDevicesDiscovery();
        }, 1e3 * o.frontbluetoothWaitTime), o.returnMd5Order()), getApp().http_post({
            bhv_type: "view",
            obj_type: "Page",
            title: "弹出电池进度条",
            other: {
                orderid: o.leaseDataObj.orderid,
                soft_ver: o.leaseDataObj.soft_ver,
                madename: o.leaseDataObj.madename
            },
            station_id: o.leaseDataObj.sid,
            act_obj: 10025
        });
    },
    onShow: function() {
        var t = this, o = wx.getStorageSync("adv_obj");
        if (o) {
            t.adv_objStr = JSON.parse(o);
            var a = !0;
            t.adv_objStr.wechat_zbo && (a = !1, e.advExposure(t.adv_objStr.wechat_zbo, "300011"), 
            t.setData({
                checkUrl_wechat_zbo: t.adv_objStr.wechat_zbo.checkUrl,
                materialUrl_wechat_zbo: e.configObj.advImgAdd + t.adv_objStr.wechat_zbo.materialUrl
            })), t.adv_objStr.wechat_zbt && (a = !1, e.advExposure(t.adv_objStr.wechat_zbt, "300012"), 
            t.setData({
                checkUrl_wechat_zbt: t.adv_objStr.wechat_zbt.checkUrl,
                materialUrl_wechat_zbt: e.configObj.advImgAdd + t.adv_objStr.wechat_zbt.materialUrl
            })), t.adv_objStr.wechat_zbth && (a = !1, e.advExposure(t.adv_objStr.wechat_zbth, "300013"), 
            t.setData({
                checkUrl_wechat_zbth: t.adv_objStr.wechat_zbth.checkUrl,
                materialUrl_wechat_zbth: e.configObj.advImgAdd + t.adv_objStr.wechat_zbth.materialUrl
            })), t.setData({
                showAbBanner: a
            }), t.adv_objStr.wechat_zt && 1 == t.data.showModal && e.advExposure(t.adv_objStr.wechat_zt, "300009");
        }
        "02" == wx.getStorageSync("memberStatus") || "03" == wx.getStorageSync("memberStatus") ? e.memberObj.is_vip = 1 : e.memberObj.is_vip = 0;
    },
    progressNum: function() {
        var e = this;
        if (2 == e.data.status) clearInterval(e.progress), clearTimeout(e.requestTimer), 
        e.stopBluetooth(), wx.closeBluetoothAdapter({}), e.setData({
            advertisingflag: !1,
            showOpenBluetooth: !1,
            leaseResult: {
                status: "租借成功",
                subTxt: "感谢使用速绿充电",
                img: "success"
            },
            membershipCopy: "开通会员，此单立享3小时免费"
        }), getApp().http_post({
            bhv_type: "view",
            obj_type: "Page",
            title: "租借结果页",
            other: {
                orderid: e.leaseDataObj.orderid,
                soft_ver: e.leaseDataObj.soft_ver,
                madename: e.leaseDataObj.madename,
                result: "success"
            },
            station_id: e.leaseDataObj.sid,
            act_obj: 10078
        }); else {
            var t = e.data.percent;
            t >= e.timeCount ? (e.setData({
                advertisingflag: !1,
                showOpenBluetooth: !1
            }), clearInterval(e.progress), clearTimeout(e.requestTimer), e.stopBluetooth(), 
            wx.closeBluetoothAdapter({}), e.progressBarOver(), e.judgeOpenBluetoothShowed && e.bluetoothLog(-2)) : e.setData({
                percent: ++t
            });
        }
    },
    percentAdd: function() {
        var t = this;
        wx.request({
            url: e.configObj.stateUrl,
            data: {
                session: e.globalData.session,
                orderid: t.leaseDataObj.orderid
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(e) {
                if (0 == e.data.code) {
                    var o = e.data.data.status;
                    t.setData({
                        status: o
                    }), 2 == o ? (t.setData({
                        borrowSlot: e.data.data.borrowSlot
                    }), t.showGif()) : t.requestTimer = setTimeout(t.percentAdd, 2e3);
                }
            },
            fail: function() {
                t.requestTimer = setTimeout(t.percentAdd, 2e3);
            }
        });
    },
    getOrderInfo: function() {
        var t = this;
        wx.request({
            url: e.configObj.getOrderInfo,
            data: {
                session: e.globalData.session,
                orderid: t.leaseDataObj.orderid
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(e) {
                if (0 == e.data.code) {
                    var o = e.data.data.order, a = t.data.leaseResult;
                    a.borrow_time = o.borrow_time, a.fee_strategy = o.fee_strategy, t.setData({
                        leaseResult: a
                    });
                }
            }
        });
    },
    showGif: function() {
        var t = this;
        t.progressNum(), t.getOrderInfo();
        var o = 2 * t.data.countDown;
        t.interval = setInterval(function() {
            0 == --o ? (clearInterval(t.interval), t.setData({
                showSlotBox: !1
            }), t.adv_objStr.wechat_zt ? (e.advExposure(t.adv_objStr.wechat_zt, "300009"), t.setData({
                showModal: !0,
                checkUrl_wechat_zt: t.adv_objStr.wechat_zt.checkUrl,
                materialUrl_wechat_zt: e.configObj.advImgAdd + t.adv_objStr.wechat_zt.materialUrl
            })) : t.data.showMemberBtn || !wx.createInterstitialAd || t.adShowed || (t.adShowed = !0, 
            wx.createInterstitialAd({
                adUnitId: "adunit-f24935c921d3717d"
            }).show()), t.data.showMemberBtn || 1 == getCurrentPages().length && (t.times = setTimeout(function() {
                wx.navigateTo({
                    url: "/packageLuckdraw/luckdraw/luckdraw?routeid=1"
                });
            }, 5e3))) : t.setData({
                colorCircleFirst: o % 2 ? "#31A448" : "#C1C1C1",
                countDown: (o / 2).toFixed(0)
            });
        }, 500);
    },
    progressBarOver: function() {
        var t = this;
        wx.request({
            url: e.configObj.progressBarOverPageSkip,
            data: {
                session: e.globalData.session,
                sid: t.leaseDataObj.sid
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(e) {
                1 == e.data.dispose ? t.timeoutResult(!0) : t.timeoutResult(!1);
            },
            fail: function(e) {
                t.timeoutResult(!1);
            }
        });
    },
    timeoutResult: function(e) {
        var t, o = this;
        t = e ? {
            status: "订单处理中",
            subTxt: "当前订单将在5分钟内处理完毕",
            img: "ing"
        } : {
            status: "租借失败",
            subTxt: "充电宝租借未成功，请再次租借",
            img: "fail"
        }, o.setData({
            leaseResult: t,
            showSlotBox: !1,
            membershipCopy: "开通会员，免费使用充电宝"
        }), getApp().http_post({
            bhv_type: "view",
            obj_type: "Page",
            title: "租借结果页",
            other: {
                orderid: o.leaseDataObj.orderid,
                soft_ver: o.leaseDataObj.soft_ver,
                madename: o.leaseDataObj.madename,
                result: e ? "doing" : "fail"
            },
            station_id: o.leaseDataObj.sid,
            act_obj: 10078
        });
    },
    openingMember: function() {
        var e = this;
        getApp().http_post({
            bhv_type: "click",
            obj_type: "Control",
            title: "租借结果页",
            control_name: "租借结果页__点击会员按钮",
            station_id: this.leaseDataObj.sid,
            other: {
                orderid: this.leaseDataObj.orderid
            },
            act_obj: 10079
        }), wx.navigateTo({
            url: "/pages/index/member/member?backRoot=true&referrer_title=租借结果&orderid=" + this.leaseDataObj.orderid,
            events: {
                buySuccess: function() {
                    e.setData({
                        showMemberBtn: !1
                    });
                }
            }
        });
    },
    bindAdvBannerOne: function() {
        e.pushAdv(this.adv_objStr.wechat_zbo, "300011");
    },
    bindAdvBannerTwo: function() {
        e.pushAdv(this.adv_objStr.wechat_zbt, "300012");
    },
    bindAdvBannerThree: function() {
        e.pushAdv(this.adv_objStr.wechat_zbth, "300013");
    },
    onbinddoumob: function() {
        e.pushAdv(this.adv_objStr.wechat_zt, "300009"), this.hideModal();
    },
    hideModal: function() {
        this.setData({
            showModal: !1
        });
    },
    toOrderInfo: function() {
        var e = this.leaseDataObj.orderid;
        wx.navigateTo({
            url: "/pages/ordering/orderingend/orderingend?orderid=" + e
        });
    },
    toScan: function() {
        e.qrCode(function(e) {
            var t = e.split("/")[3];
            if ("q" == t) wx.redirectTo({
                url: "/pages/index/sweep/sweep?qrcode=" + e + "&referrer_title=租借失败"
            }); else if ("x" == t) wx.redirectTo({
                url: "/packageB/Bluetooth/Bluetooth?qrcode=" + e + "&referrer_title=租借失败"
            }); else if ("c" == t) {
                var o = encodeURIComponent(e);
                wx.redirectTo({
                    url: "/packageA/Lottery/Lottery?qrcode=" + o
                });
            } else wx.showModal({
                title: "温馨提示",
                content: "这不是速绿充电的二维码",
                success: function(e) {
                    e.confirm || e.cancel;
                }
            });
        });
    },
    servicebtnTouch: function() {
        var e = this.leaseDataObj.orderid;
        wx.navigateTo({
            url: "/pages/helpCenter/helpCenter?orderid=" + e + "&csEntryType=5"
        });
    },
    adLoadFinish_banner: function(e) {
        this.setData({
            showAd_banner: !0
        });
    },
    onHide: function() {
        clearTimeout(this.times);
    },
    onUnload: function() {
        clearInterval(this.interval), clearInterval(this.progress), clearTimeout(this.requestTimer), 
        clearTimeout(this.times), this.closeBLEConnection();
    },
    bluetoothRecharge: function() {
        var e = this;
        e.setData({
            advertisingflag: !1,
            showOpenBluetooth: !1,
            percent: 1
        }), getApp().http_post({
            bhv_type: "click",
            obj_type: "Control",
            title: "弹出电池进度条_已开蓝牙,重新弹出",
            control_name: "",
            station_id: e.leaseDataObj.sid,
            other: {
                orderid: e.leaseDataObj.orderid,
                soft_ver: e.leaseDataObj.soft_ver
            },
            act_obj: 10073
        }), setTimeout(function() {
            e.timeCount = e.afterbluetoothWaitTime, e.startBluetoothDevicesDiscovery();
        }, 2e3);
    },
    overtimeConfirmReport: function() {
        var t = this;
        wx.request({
            url: e.configObj.overtimeConfirm,
            data: {
                orderid: t.leaseDataObj.orderid,
                sid: t.leaseDataObj.sid,
                status: t.bluetoothResult.result,
                slot: t.bluetoothResult.slotNo,
                battery_id: t.bluetoothResult.batteryId,
                power: t.bluetoothResult.power,
                source: 1,
                type: 1
            },
            method: "POST",
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            success: function(e) {
                console.log("蓝牙广告机调用传输订单租借信息" + JSON.stringify(e));
            }
        });
    },
    startBluetoothDevicesDiscovery: function() {
        var t = this;
        wx.closeBluetoothAdapter({
            complete: function() {
                wx.openBluetoothAdapter({
                    success: function(e) {
                        console.log("初始化蓝牙模块成功" + JSON.stringify(e)), t.searchBluetooth(), t.judgeOpenBluetoothShowed || t.openBluetoothLog(1), 
                        t.judgeOpenBluetoothShowed = !0;
                    },
                    fail: function(o) {
                        if (console.log("初始化蓝牙模块失败" + JSON.stringify(o)), t.judgeOpenBluetoothShowed) t.bluetoothLog(-1); else {
                            var a = e.dataObj.model.indexOf("iPhone") >= 0;
                            t.setData({
                                isiPhone: a,
                                advertisingflag: !0,
                                showOpenBluetooth: !0
                            }), t.openBluetoothLog(0);
                        }
                        t.judgeOpenBluetoothShowed = !0;
                    }
                });
            }
        });
    },
    searchBluetooth: function() {
        var e = this;
        wx.startBluetoothDevicesDiscovery({
            allowDuplicatesKey: !0,
            services: [],
            success: function(t) {
                console.log("开始搜索蓝牙设备"), e.deviceId = null, e.bluetoothFound = !1, wx.onBluetoothDeviceFound(function(t) {
                    if (e.bluetoothFound = !0, !e.deviceId) {
                        var o = t.devices[0], a = o.name || o.deviceName;
                        if (console.log("名字" + a), a && -1 != a.indexOf("rk")) {
                            var r = e.ab2hex(o.advertisData);
                            r = e.hexToNumCharCode(r.substr(4)), console.log("mac--" + r), r == e.leaseDataObj.sid && (console.log("搜索到的目标设备"), 
                            e.stopBluetooth(), e.deviceId = o.deviceId, e.connectBLEDevice());
                        }
                    }
                });
            },
            fail: function(e) {
                console.log("调用搜寻蓝牙设备失败"), console.log(e);
            }
        });
    },
    stopBluetooth: function() {
        wx.stopBluetoothDevicesDiscovery({
            success: function(e) {
                console.log("停止搜索成功"), console.log(e);
            },
            fail: function(e) {
                console.log("停止搜索失败"), console.log(e);
            }
        });
    },
    connectBLEDevice: function() {
        var e = this;
        console.log("准备连接蓝牙设备"), wx.createBLEConnection({
            deviceId: e.deviceId,
            success: function(t) {
                console.log("蓝牙连接成功"), e.readServices();
            },
            fail: function(t) {
                -1 == t.errCode ? e.readServices() : (e.bluetoothLog(-3), console.log("蓝牙连接失败"), 
                console.log(t));
            }
        });
    },
    readServices: function() {
        var e = this;
        wx.getBLEDeviceServices({
            deviceId: e.deviceId,
            success: function(t) {
                console.log("获取服务" + JSON.stringify(t)), e.serviceId = "1000FFF0-0000-0000-0000-000000000000", 
                wx.getBLEDeviceCharacteristics({
                    deviceId: e.deviceId,
                    serviceId: e.serviceId,
                    success: function(t) {
                        e.orderIDCharacteristicId = t.characteristics[0].uuid, e.resultCharacteristicId = t.characteristics[2].uuid, 
                        wx.notifyBLECharacteristicValueChange({
                            state: !0,
                            deviceId: e.deviceId,
                            serviceId: e.serviceId,
                            characteristicId: e.resultCharacteristicId,
                            success: function(e) {
                                console.log("notifyBLECharacteristicValueChange success", e.errMsg);
                            }
                        }), wx.onBLECharacteristicValueChange(function(t) {
                            if (t.characteristicId == e.resultCharacteristicId) {
                                var o = e.ab2hex(t.value);
                                console.log("租借结果：" + o);
                                var a = parseInt(o.substr(0, 2), 16);
                                console.log("租借结果：" + a), 1 == a ? (e.bluetoothLog(6), e.bluetoothResult.slotNo = parseInt(o.substr(2, 2), 16), 
                                e.bluetoothResult.power = parseInt(o.substr(4, 2), 16), e.bluetoothResult.batteryId = e.hexToNumCharCode(o.substr(6)), 
                                e.setData({
                                    status: 2,
                                    borrowSlot: e.bluetoothResult.slotNo,
                                    leaseResult: {
                                        status: "租借成功",
                                        subTxt: "感谢使用速绿充电",
                                        img: "success"
                                    },
                                    membershipCopy: "开通会员，此单立享3小时免费"
                                }), e.showGif()) : (e.bluetoothLog(-6), e.bluetoothResult.slotNo = "", e.bluetoothResult.power = "", 
                                e.bluetoothResult.batteryId = ""), e.bluetoothResult.result = a, e.overtimeConfirmReport();
                            }
                        }), e.writeBluetoothData();
                    },
                    fail: function(t) {
                        e.bluetoothLog(-4), console.log("读取特征失败。。"), console.log(t);
                    }
                });
            },
            fail: function(t) {
                e.bluetoothLog(-4), console.log("读取服务失败"), console.log(t);
            }
        });
    },
    closeBLEConnection: function() {
        this.deviceId && wx.closeBLEConnection({
            deviceId: this.deviceId
        });
    },
    writeBluetoothData: function() {
        console.log("写入数据");
        var e = this, t = e.leaseDataObj.orderid;
        t = t.replace(/-/g, "");
        var o = e.strToHexCharCode(t.substr(0, 3)) + e.numToHexCharCode(t.substr(3), 2) + e.orderMdStr;
        console.log("明文：" + o);
        var a = e.getBuffer(o);
        console.log(a), wx.writeBLECharacteristicValue({
            deviceId: e.deviceId,
            serviceId: e.serviceId,
            characteristicId: e.orderIDCharacteristicId,
            value: a,
            success: function(t) {
                e.bluetoothLog(5), console.log("弹电池指令发送成功："), console.log(t);
            },
            fail: function(t) {
                e.bluetoothLog(-5), console.log("弹电池指令发送失败："), console.log(t);
            }
        });
    },
    openBluetoothLog: function(e) {
        var t = this;
        getApp().http_post({
            bhv_type: "click",
            obj_type: "Control",
            title: "弹出电池进度条_是否开启手机蓝牙",
            control_name: "",
            station_id: t.leaseDataObj.sid,
            other: {
                orderid: t.leaseDataObj.orderid,
                soft_ver: t.leaseDataObj.soft_ver,
                isopen: e
            },
            act_obj: 10072
        });
    },
    bluetoothLog: function(e) {
        var t = this;
        getApp().http_post({
            bhv_type: "click",
            obj_type: "Control",
            title: "大设备蓝牙通道",
            control_name: "",
            station_id: t.leaseDataObj.sid,
            other: {
                orderid: t.leaseDataObj.orderid,
                soft_ver: t.leaseDataObj.soft_ver,
                reason: e
            },
            act_obj: 10074
        });
    },
    ab2hex: function(e) {
        return Array.prototype.map.call(new Uint8Array(e), function(e) {
            return ("00" + e.toString(16)).slice(-2);
        }).join("");
    },
    strToHexCharCode: function(e) {
        if ("" === e) return "";
        for (var t = [], o = 0; o < e.length; o++) {
            var a = e.charCodeAt(o);
            a = this.str_pad(a.toString(16), 2), t.push(a);
        }
        return t.join("");
    },
    numToHexCharCode: function(e, t) {
        if ("" === e) return "";
        t || (t = 1);
        for (var o = [], a = 0; a < e.length / t; a++) {
            var r = Number(e.substr(a * t, t));
            r = this.str_pad(r.toString(16), 2), o.push(r);
        }
        return o.join("");
    },
    hexToNumCharCode: function(e) {
        if ("" === e) return "";
        for (var t = [], o = 0; o < e.length / 2; o++) {
            var a = Number(e.substr(2 * o, 2));
            a = a.toString(10), t.push(a);
        }
        return t.join("");
    },
    getBuffer: function(e) {
        if (e) {
            for (var t = e.length / 2, o = new ArrayBuffer(t), a = new DataView(o), r = 0; r < t; r++) {
                var s = parseInt(e.substr(2 * r, 2), 16);
                a.setUint8(r, s);
            }
            return o;
        }
    },
    str_pad: function(e, t) {
        var o = t - e.length;
        return "00000000".substr(0, o) + e;
    },
    returnMd5Order: function() {
        var t = this;
        wx.request({
            url: e.configObj.returnOrderMd5,
            data: {
                session: e.globalData.session,
                orderid: t.leaseDataObj.orderid
            },
            method: "POST",
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            success: function(e) {
                console.log(e), 0 == e.data.code && (t.orderMdStr = e.data.orderid);
            }
        });
    }
});