var t = require("../../../../utils/WSCoordinate.js"), e = getApp();

Page({
    latitude: "",
    longitude: "",
    data: {
        advertisingflag: !1,
        issucopen: !1
    },
    onLoad: function(e) {
        var a = this, i = e.sid, o = e.soft_ver, n = e.device_ver;
        a.setData({
            sid: i,
            device_ver: n,
            soft_ver: o,
            madename: e.madename
        }), wx.showLoading({
            title: "请稍后...",
            mask: !0
        }), wx.getLocation({
            success: function(e) {
                var i = t.transformFromWGSToGCJ(e.latitude, e.longitude);
                a.latitude = i.latitude, a.longitude = i.longitude;
            },
            fail: function() {
                a.latitude = "39.9088230000", a.longitude = "116.3974700000";
            },
            complete: function() {
                wx.hideLoading();
            }
        });
    },
    onShow: function() {
        var t = this;
        getApp().http_post({
            bhv_type: "view",
            obj_type: "Page",
            title: "设备断网提示",
            station_id: t.data.sid,
            other: {
                soft_ver: t.data.soft_ver,
                madename: t.data.madename
            },
            act_obj: 10022
        });
    },
    toShopList: function() {
        wx.redirectTo({
            url: "/packagenearby/nearby/nearby?latitude=" + this.latitude + "&longitude=" + this.longitude
        });
    },
    backRoot: function() {
        wx.reLaunch({
            url: "/pages/index/index"
        });
    },
    dianwo: function(t) {
        var a = this;
        wx.showLoading({
            title: "请稍后",
            mask: !0
        });
        var i = a.data.sid;
        wx.request({
            url: e.configObj.getRepair,
            data: {
                stationId: i
            },
            method: "POST",
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            success: function(t) {
                console.log(t.data), wx.hideLoading(), a.setData({
                    advertisingflag: !0,
                    issucopen: !0
                });
            },
            fail: function(t) {
                wx.showToast({
                    title: "失败",
                    icon: "none",
                    duration: 2e3
                });
            }
        });
    }
});