var t = getApp();

Page({
    authUrl: "",
    onLoad: function(e) {
        this.authUrl = t.globalData.authToUrl, t.globalData.authToUrl = null;
    },
    onShow: function() {
        getApp().http_post({
            bhv_type: "view",
            obj_type: "Page",
            title: "授权登陆页",
            act_obj: 10006
        });
    },
    bindbut: function(e) {
        e.detail.userInfo ? (console.log("用户按了允许授权按钮"), t.login(), setTimeout(function() {
            getApp().http_post({
                bhv_type: "click",
                obj_type: "Control",
                title: "授权登陆页",
                control_name: "授权登陆页_确认授权",
                act_obj: 10007
            });
        }, 3e3), this.authUrl ? wx.redirectTo({
            url: this.authUrl
        }) : wx.reLaunch({
            url: "/pages/index/index"
        })) : console.log("用户按了拒绝按钮");
    },
    agreement: function() {
        wx.navigateTo({
            url: "/packageuser/user/aboutUs/agreement/agreement"
        });
    }
});