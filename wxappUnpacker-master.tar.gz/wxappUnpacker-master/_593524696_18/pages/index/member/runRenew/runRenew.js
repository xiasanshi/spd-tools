var e = getApp();

Page({
    data: {
        modalmember: !1
    },
    onLoad: function(e) {
        this.setData({
            backRoot: e.backRoot,
            referrer_title: e.referrer_title,
            deduction_price: e.deduction_price
        });
    },
    onReady: function() {},
    onShow: function() {
        getApp().http_post({
            bhv_type: "view",
            obj_type: "Page",
            title: "管理续费",
            act_obj: 10089
        });
    },
    onHide: function() {},
    onUnload: function() {},
    rescission: function() {
        var t = this;
        wx.showLoading({
            title: "请稍候...",
            mask: !0
        }), wx.request({
            url: e.configObj.applyRecission,
            data: {
                session: e.globalData.session
            },
            method: "POST",
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            success: function(e) {
                if (200 == e.data.code) {
                    var o = t.data.backRoot, a = t.data.referrer_title;
                    "false" == o ? wx.navigateBack({
                        delta: 1
                    }) : wx.redirectTo({
                        url: "/pages/index/member/member?backRoot=" + o + "&referrer_title=" + a
                    });
                } else wx.showToast({
                    title: e.data.message,
                    icon: "none"
                });
            },
            fail: function() {
                wx.showToast({
                    title: "网络错误",
                    icon: "none"
                });
            },
            complete: function() {
                t.setData({
                    modalmember: !1
                });
            }
        });
    },
    cancelmember: function() {
        this.setData({
            modalmember: !0
        }), getApp().http_post({
            bhv_type: "view",
            obj_type: "Page",
            title: "管理续费_是否取消连续包月",
            act_obj: 10090
        });
    },
    cancel: function() {
        getApp().http_post({
            bhv_type: "click",
            obj_type: "Control",
            title: "管理续费",
            control_name: "是否取消连续包月_取消",
            act_obj: 10092
        });
        var e = this.data.backRoot, t = this.data.referrer_title;
        "false" == e ? this.setData({
            modalmember: !1
        }) : wx.redirectTo({
            url: "/pages/index/member/member?backRoot=" + e + "&referrer_title=" + t
        });
    },
    confirm: function() {
        getApp().http_post({
            bhv_type: "click",
            obj_type: "Control",
            title: "管理续费",
            control_name: "是否取消连续包月_确定",
            act_obj: 10091
        }), this.rescission();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});