var e = getApp();

Page({
    backRoot: "",
    openingAccess: "",
    orderid: "",
    clickBut: !0,
    data: {
        buttonType: "",
        modalmember: !1,
        modalfail: !1,
        modalNeedKnow: !1,
        videoList: [ {
            text: "优酷会员",
            videoHY: "ykhy",
            imgUrl: "/images/Member/youku_logo.png"
        }, {
            text: "爱奇艺会员",
            videoHY: "aqyhy",
            imgUrl: "/images/Member/aiqiyi_logo.png"
        }, {
            text: "腾讯会员",
            videoHY: "tengxu",
            imgUrl: "/images/Member/tengxun_logo.png"
        } ]
    },
    onLoad: function(t) {
        var a = this;
        if (t.backRoot && (a.backRoot = t.backRoot), a.setData({
            referrer_title: t.referrer_title
        }), t.access) a.openingAccess = "06"; else if (t.q) {
            var i = decodeURIComponent(t.q);
            i.indexOf("/a/5") > 0 ? a.openingAccess = "11" : i.indexOf("/a/7") > 0 ? a.openingAccess = "12" : a.openingAccess = "05";
        } else {
            var n = {
                "产品介绍页": "01",
                "租借结果": "02",
                "首页": "03",
                "个人中心": "04",
                "附近网点": "07",
                "商铺详情": "08",
                "订单详情": "09"
            };
            a.openingAccess = n[t.referrer_title], a.openingAccess || (a.openingAccess = "05");
        }
        this.orderid = t.orderid || "", e.globalData.session && (a.openingMember(), a.getUserInfo()), 
        getApp().userLoginSuccessCallback = function() {
            a.openingMember(), a.getUserInfo();
        }, wx.getSetting({
            success: function(a) {
                a.authSetting["scope.userInfo"] || (wx.hideLoading(), e.globalData.authToUrl = "/pages/index/member/member?access=" + t.access, 
                wx.redirectTo({
                    url: "/pages/index/authorization/authorization"
                }));
            }
        });
    },
    getUserInfo: function() {
        var t = this, a = function() {
            if (e.globalData.userInfo.phone_num) {
                var a = e.globalData.userInfo.phone_num;
                a = a.replace(/(\d{3})\d{4}(\d{4})/, "$1****$2"), t.setData({
                    phone_num: a
                });
            } else t.setData({
                phone_num: "未绑定手机号"
            });
        };
        e.globalData.userInfo ? a() : e.userInfoRequest(function() {
            a();
        });
    },
    menberItemTouch: function(t, a) {
        var i = t ? t.currentTarget.dataset.index : a, n = this.data.memberObjs[i], o = "", s = !1;
        this.data.is_limit ? (o = "明日再来", s = !0) : this.data.signing_code && this.data.end_time ? (o = "会员已开通", 
        s = !0) : "04" == n.type ? this.data.signing_code ? (o = "会员已过期", s = !0) : n.paid_flag ? (o = "您已购买过，请选择其它套餐", 
        s = !0) : n.sku_is_limit ? (o = "明日再来", s = !0) : o = "限时抢购" + n.current_price + "元" : "02" == n.type ? o = this.data.end_time || this.data.signing_code ? "立即续费，预计省30元/月" : "立即开通，预计省30元/月" : "01" == n.type ? this.data.end_time ? o = "立即续费，预计省20元/月" : this.data.signing_code ? (o = "会员已过期", 
        s = !0) : o = "立即开通，预计省20元/月" : "03" == n.type && (this.data.end_time ? o = "立即续费，预计省300元/年" : this.data.signing_code ? (o = "会员已过期", 
        s = !0) : o = "立即开通，预计省300元/年"), this.setData({
            item_sel: i,
            buttonTxt: o,
            buttonDisabled: s
        }), getApp().http_post({
            bhv_type: "click",
            obj_type: "Control",
            title: "会员中心",
            control_name: "会员中心_选购会员类型",
            referrer_title: this.openingAccess,
            station_id: e.leaseDataObj.sid || "",
            other: {
                sku: n.type,
                vipbutton: this.data.buttonTxt.split("，")[0],
                is_vip: e.memberObj.is_vip,
                is_contract: this.data.signing_code ? 1 : 0,
                orderid: this.orderid
            },
            act_obj: 10105
        });
    },
    openingMember: function() {
        var t = this;
        wx.showLoading({
            title: "正在加载",
            mask: !0
        }), wx.request({
            url: e.configObj.productDetail,
            data: {
                session: e.globalData.session,
                version: "1.1"
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(a) {
                if (5 == a.data.code) getApp().globalData.session = null, getApp().login(); else if (0 == a.data.code) {
                    var i = a.data.data;
                    if (i.end_time) {
                        var n = i.end_time.trim().split(/\s+/)[0];
                        t.setData({
                            end_time_new: n
                        });
                    }
                    var o = i.is_limit, s = i.signing_code, r = i.product_details;
                    s && !i.end_time && (t.data.modalmember || (t.setData({
                        modalfail: !0
                    }), getApp().http_post({
                        bhv_type: "view",
                        obj_type: "Page",
                        title: "会员中心_连续包月扣款失败",
                        other: {
                            contractcode: s
                        },
                        act_obj: 10088
                    })));
                    var d = [ r.type_02, r.type_01, r.type_03 ], c = {
                        "04": {
                            title: "会员体验卡",
                            subTitle: "有效期3天",
                            msg: "每个用户限购一次"
                        },
                        "02": {
                            title: "连续包月",
                            subTitle: "",
                            msg: "次月起￥--/月，自动续费，可随时关闭"
                        },
                        "01": {
                            title: "月卡",
                            subTitle: "有效期30天",
                            msg: "选择连续包月，享受优惠价格"
                        },
                        "03": {
                            title: "年卡",
                            subTitle: "有效期365天",
                            msg: "全年享受会员特权"
                        }
                    };
                    d = d.filter(function(e, t) {
                        if (e) {
                            var a = c[e.type];
                            return e.title = a.title, e.subTitle = a.subTitle, e.msg = a.msg.replace(/--/g, e.current_price), 
                            !0;
                        }
                        return !1;
                    }), t.setData({
                        is_limit: o,
                        signing_code: s,
                        end_time: i.end_time,
                        deduction_price: i.deduction_price,
                        memberObjs: d
                    }), e.memberObj.is_vip = t.data.end_time_new ? 1 : 0;
                } else wx.showModal({
                    content: a.data.msg,
                    confirmText: "确定",
                    showCancel: !1,
                    success: function(e) {
                        e.confirm && wx.reLaunch({
                            url: "/pages/index/index"
                        });
                    }
                });
                0 == t.data.modalmember && getApp().http_post({
                    bhv_type: "view",
                    obj_type: "Page",
                    title: "会员中心",
                    referrer_title: t.openingAccess,
                    station_id: e.leaseDataObj.sid || "",
                    other: {
                        is_vip: e.memberObj.is_vip || "",
                        is_contract: t.data.signing_code ? 1 : 0,
                        orderid: t.orderid
                    },
                    act_obj: 10082
                }), t.itemSelected || (t.menberItemTouch(null, 0), t.itemSelected = !0);
            },
            fail: function() {
                wx.showToast({
                    title: "网络错误",
                    icon: "none",
                    duration: 1e3
                });
            },
            complete: function() {
                wx.hideLoading();
            }
        });
    },
    paymentMemberOrder: function() {
        var t = this, a = this.data.memberObjs[this.data.item_sel];
        t.clickBut && (getApp().http_post({
            bhv_type: "click",
            obj_type: "Control",
            title: "会员中心",
            control_name: "会员中心_立即购买",
            referrer_title: this.openingAccess,
            station_id: e.leaseDataObj.sid || "",
            other: {
                sku: a.type,
                vipbutton: this.data.buttonTxt.split("，")[0],
                is_vip: e.memberObj.is_vip,
                is_contract: this.data.signing_code ? 1 : 0,
                orderid: this.orderid
            },
            act_obj: 10106
        }), wx.showLoading({
            title: "请稍候...",
            mask: !0
        }), t.clickBut = !1, setTimeout(function() {
            t.clickBut = !0;
        }, 2e3), "02" == a.type ? t.freePayment() : t.memberPayment());
    },
    memberPayment: function() {
        var t = this, a = t.data.memberObjs[t.data.item_sel], i = (a.current_price, a.type, 
        e.leaseDataObj.sid ? e.leaseDataObj.sid : "");
        wx.request({
            url: e.configObj.createMemberOrder,
            data: {
                session: e.globalData.session,
                sid: i,
                openingAccess: t.openingAccess,
                memberStrategyType: a.type
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(e) {
                0 == e.data.code ? (t.setData({
                    memberOrderNo: e.data.data.member_order_no
                }), wx.requestPayment({
                    timeStamp: e.data.data.pay_data.timeStamp,
                    nonceStr: e.data.data.pay_data.nonceStr,
                    package: e.data.data.pay_data.package,
                    signType: e.data.data.pay_data.signType,
                    paySign: e.data.data.pay_data.paySign,
                    success: function(e) {
                        wx.hideLoading(), t.setData({
                            modalmember: !0
                        }), t.memberBuyResultMD("success");
                        var a = getCurrentPages(), i = a[a.length - 2];
                        -1 != i.route.indexOf("sweep/sweep") && i.getBorrowInfo();
                    },
                    fail: function(e) {
                        wx.hideLoading(), wx.showToast({
                            title: "已取消支付",
                            icon: "none",
                            duration: 2e3
                        }), t.memberBuyResultMD("fail");
                    },
                    complete: function() {
                        t.setData({
                            memberrenew: !!t.data.end_time
                        }), t.openingMember();
                    }
                })) : (wx.hideLoading(), wx.showToast({
                    title: e.data.msg,
                    icon: "none",
                    duration: 2e3
                }));
            },
            fail: function() {
                wx.hideLoading(), wx.showToast({
                    title: "网络错误,请检查网络",
                    icon: "none"
                });
            },
            complete: function() {}
        });
    },
    freePayment: function() {
        var t = this, a = t.data.memberObjs[1], i = (a.frist_price > 0 ? a.frist_price : a.current_price, 
        e.leaseDataObj.sid ? e.leaseDataObj.sid : "");
        t.data.signing_code ? t.applyDeduction() : wx.request({
            url: e.configObj.applySign,
            data: {
                sid: i,
                openingAccess: t.openingAccess,
                session: e.globalData.session
            },
            method: "POST",
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            success: function(a) {
                if (0 == a.data.code) {
                    e.leaseDataObj.contractCode = a.data.data.contract_code, e.applyDeduction = t.applyDeduction;
                    var i = a.data.data.contract_data;
                    wx.navigateToMiniProgram({
                        appId: "wxbd687630cd02ce1d",
                        path: "pages/index/index",
                        extraData: i,
                        success: function(e) {
                            getApp().toWxMiniProgram = !0;
                        },
                        complete: function(e) {
                            wx.hideLoading();
                        }
                    });
                } else wx.hideLoading(), wx.showToast({
                    title: a.data.msg,
                    icon: "none"
                });
            }
        });
    },
    applyDeduction: function() {
        var t = this, a = e.leaseDataObj.sid ? e.leaseDataObj.sid : "", i = e.leaseDataObj.contractCode ? e.leaseDataObj.contractCode : t.data.signing_code, n = t.data.memberObjs[1];
        n.frist_price > 0 ? n.frist_price : n.current_price;
        0 == i.indexOf("WMM") && wx.request({
            url: e.configObj.pappayapply,
            data: {
                session: e.globalData.session,
                sid: a,
                contractCode: i,
                openingAccess: t.openingAccess
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(e) {
                wx.hideLoading(), 0 == e.data.code ? (t.openingMember(), t.setData({
                    modalmember: !0
                }), t.memberBuyResultMD("doing")) : (wx.showToast({
                    title: e.data.msg,
                    icon: "none",
                    duration: 2e3
                }), t.memberBuyResultMD("fail"));
            },
            fail: function() {
                wx.hideLoading(), wx.showToast({
                    title: "失败",
                    icon: "none",
                    duration: 2e3
                });
            },
            complete: function(e) {}
        });
    },
    memberLease: function() {
        var e = this;
        e.data.memberObjs[e.data.item_sel].current_price;
        "true" == e.backRoot ? wx.reLaunch({
            url: "/pages/index/index"
        }) : wx.navigateBack();
    },
    videoItemTouch: function(e) {
        var t = e.currentTarget.dataset.videoFlag, a = "11" === this.openingAccess || "12" === this.openingAccess ? "01" : "02";
        wx.navigateTo({
            url: "/packageaiqiyi/aiqiyi/aiqiyi?videoHY=" + t + "&resource=" + a
        });
    },
    handleKnowModal: function(e) {
        this.setData({
            modalNeedKnow: "open" === e.currentTarget.dataset.flag
        });
    },
    backpage: function() {
        getCurrentPages().length > 1 ? wx.navigateBack() : wx.reLaunch({
            url: "/pages/index/index"
        });
    },
    hideModal: function() {
        this.setData({
            modalmember: !1
        });
        var e = this.getOpenerEventChannel();
        e.emit && e.emit("buySuccess"), wx.navigateBack();
    },
    closePopup: function() {
        this.setData({
            modalfail: !1
        });
    },
    onPullDownRefresh: function() {
        wx.showLoading({
            title: "正在加载",
            mask: !0
        }), this.openingMember(), wx.stopPullDownRefresh();
    },
    onUnload: function() {
        var e = this.getOpenerEventChannel();
        e.emit && e.emit("reloadData");
    },
    memberBuyResultMD: function(t) {
        getApp().http_post({
            bhv_type: "view",
            obj_type: "Page",
            title: "会员中心_会员购买结果",
            referrer_title: this.openingAccess,
            station_id: e.leaseDataObj.sid || "",
            other: {
                sku: this.data.memberObjs[this.data.item_sel].type,
                result: t,
                is_vip: e.memberObj.is_vip,
                is_contract: this.data.signing_code ? 1 : 0,
                orderid: this.orderid
            },
            act_obj: 10107
        });
    }
});