var e = getApp();

Page({
    data: {
        btnDisabled: !0
    },
    onLoad: function(e) {},
    onShow: function() {},
    inputEdit: function(e) {
        var t = e.detail.value;
        this.setData({
            codeStr: t,
            btnDisabled: 8 != t.length
        });
    },
    exchangeBtnTouch: function() {
        console.log(this.data.codeStr), wx.showLoading({
            title: "请稍候",
            mask: !0
        });
        var t = this;
        wx.request({
            url: e.configObj.memberExchange,
            data: {
                session: getApp().globalData.session,
                code: this.data.codeStr
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(e) {
                console.log(e.data), 0 == e.data.code ? t.setData({
                    showAle: !0,
                    aleSuccess: !0
                }) : 2 == e.data.code ? (t.hideAle(), t.setData({
                    showMsg: !0
                })) : t.setData({
                    showAle: !0,
                    aleSuccess: !1
                });
            },
            fail: function() {
                wx.showToast({
                    title: "网络错误",
                    icon: "none",
                    duration: 1e3
                });
            },
            complete: function() {
                wx.hideLoading();
            }
        });
    },
    toMember: function() {
        wx.redirectTo({
            url: "/pages/index/member/member?backRoot=true&referrer_title=会员兑换"
        });
    },
    hideAle: function() {
        this.setData({
            showAle: !1,
            codeStr: "",
            btnDisabled: !0
        });
    }
});