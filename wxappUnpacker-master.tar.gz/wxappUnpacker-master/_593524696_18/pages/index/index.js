var e = require("../../utils/util.js"), t = require("../../utils/WSCoordinate.js"), a = [], o = getApp();

Page({
    adv_objStr: {},
    requestLoc: {},
    shopRequestNum: 0,
    selIndex: -1,
    data: {
        orderIngNum: 0,
        hiddenTab: !0,
        tabIndex: -1,
        tabListLength: 0,
        longitude: 116.39747,
        latitude: 39.908823,
        memberURL: "/images/root/headTitle.png",
        memberURLclick: "0",
        memberImgWidth: "300rpx",
        returnAd: !0
    },
    bindViewTap: function() {
        getApp().http_post({
            bhv_type: "click",
            obj_type: "Control",
            title: "首页",
            control_name: "首页_我的头像",
            act_obj: 10010
        }), o.globalData.session ? wx.navigateTo({
            url: "/packageuser/user/user"
        }) : wx.getSetting({
            success: function(e) {
                e.authSetting["scope.userInfo"] ? o.login() : wx.navigateTo({
                    url: "/pages/index/authorization/authorization"
                });
            }
        });
    },
    ipt: function() {
        var e = this.data.loclatitude, t = this.data.loclongitude, a = this.data.madename;
        getApp().http_post({
            bhv_type: "click",
            obj_type: "Control",
            title: "首页",
            control_name: "首页_附近网点",
            other: {
                madename: a
            },
            act_obj: 10013
        }), o.globalData.session ? wx.navigateTo({
            url: "/packagenearby/nearby/nearby?latitude=" + e + "&longitude=" + t + "&madename=" + a
        }) : wx.getSetting({
            success: function(e) {
                e.authSetting["scope.userInfo"] ? o.login() : wx.navigateTo({
                    url: "/pages/index/authorization/authorization"
                });
            }
        });
    },
    openingMember: function() {
        if ("1" == this.data.memberURLclick) {
            getApp().http_post({
                bhv_type: "click",
                obj_type: "Control",
                title: "首页",
                control_name: "首页_点击会员按钮",
                other: {},
                act_obj: 10076
            }), wx.navigateTo({
                url: "/pages/index/member/member?backRoot=true&referrer_title=首页"
            });
        }
    },
    onMapTap: function(e) {
        var t = this;
        e.detail.value;
        wx.showToast({
            title: "加载选取工具",
            icon: "loading",
            duration: 500
        }), wx.getSetting({
            success: function(e) {
                e.authSetting["scope.userLocation"] ? wx.chooseLocation({
                    success: function(e) {
                        t.getNearbyShops(e.latitude, e.longitude), t.setData({
                            addressName: e.name,
                            longitude: e.longitude,
                            latitude: e.latitude
                        });
                    }
                }) : wx.showToast({
                    title: "未授权地理位置",
                    icon: "none",
                    duration: 2e3
                });
            }
        });
    },
    bindheaderTab: function(e) {
        var t = this, a = e.currentTarget.dataset.index;
        if (a != t.data.tabIndex) {
            var o = "-1" == a ? "普通首页" : "定制首页";
            getApp().http_post({
                bhv_type: "click",
                obj_type: "Control",
                title: "首页",
                control_name: "首页_Tab按钮",
                other: {
                    type: o
                },
                act_obj: 10068
            }), t.setData({
                tabIndex: a
            }), t.shopsFilter(), t.uncheckMark();
        }
    },
    onLoad: function(e) {
        var a, i = this;
        a = wx.getStorageSync("model").indexOf("iPhone") >= 0 ? 500 : 1e3, i.mapCtx = wx.createMapContext("ycbmap"), 
        wx.getSetting({
            success: function(e) {
                e.authSetting["scope.userInfo"] || e.authSetting["scope.userLocation"] ? wx.getLocation({
                    success: function(e) {
                        var a = t.transformFromWGSToGCJ(e.latitude, e.longitude);
                        i.setData({
                            longitude: a.longitude,
                            latitude: a.latitude,
                            userLocation: !0
                        });
                    },
                    fail: function() {
                        i.setData({
                            userLocation: !1
                        }), setTimeout(function() {
                            i.movetoPosition();
                        }, a);
                    }
                }) : (i.setData({
                    userLocation: !1
                }), setTimeout(function() {
                    i.movetoPosition();
                }, a));
            }
        }), o.userLoginSuccessCallback = function() {
            i.getCenterLocation(), i.getRentedRecords(), i.statusMember();
        }, e.pushSweep && setTimeout(function() {
            wx.navigateTo({
                url: "/pages/index/sweep/sweep?qrcode=" + e.qrcode + "&referrer_title=" + e.referrer_title
            });
        }, 200), o.innerAudioContext && o.innerAudioContext.stop();
    },
    onShow: function() {
        var e = this;
        e.closeBLEConnection(), o.globalData.session && (e.getRentedRecords(), e.statusMember()), 
        e.showed && e.getCenterLocation(), e.showed = !0, wx.getSetting({
            success: function(t) {
                t.authSetting["scope.userLocation"] ? e.setData({
                    userLocation: !0
                }) : e.setData({
                    userLocation: !1
                });
            }
        }), o.advRequested ? e.update_adv() : o.rootLoadAd = e.update_adv;
    },
    onReady: function() {
        this.compareVersion(o.globalData.SDKVersion, "1.5.8") < 0 && wx.showModal({
            title: "提示",
            content: "当前微信版本过低，部分功能无法使用，请升级到最新微信版本后重试。"
        });
    },
    bindregionchange: function(e) {
        "scale" != e.causedBy && "end" == e.type && this.getCenterLocation(!0);
    },
    getCenterLocation: function(e) {
        var a = this;
        a.mapCtx.getCenterLocation({
            success: function(e) {
                a.getNearbyShops(e.latitude, e.longitude), a.setData({
                    loclatitude: e.latitude,
                    loclongitude: e.longitude
                });
                var i = t.transformFromWGSToGCJ(e.latitude, e.longitude), n = i.latitude + "," + i.longitude;
                0 != a.data.userLocation || wx.getStorageSync("advtimeStamp") || o.addressResolution(n);
            }
        });
    },
    movetoPosition: function() {
        this.mapCtx.moveToLocation();
    },
    getNearbyShops: function(t, a) {
        var i = this;
        if (o.globalData.session) {
            if (i.requestLoc.latitude) {
                var n = e.getDistance(i.requestLoc.latitude, i.requestLoc.longitude, t, a);
                if ((n = parseInt(n)) < 250) return;
            }
            i.requestLoc.latitude = t, i.requestLoc.longitude = a, wx.request({
                url: o.configObj.nearbyShopsUrl,
                data: {
                    session: o.globalData.session,
                    longitude: a,
                    latitude: t,
                    citycode: wx.getStorageSync("city_code")
                },
                header: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                method: "POST",
                success: function(e) {
                    if (5 == e.data.code) getApp().globalData.session = null, getApp().login(); else if (0 == e.data.code) {
                        i.setData({
                            shops: e.data.data.shops
                        });
                        var t = e.data.data.tabList;
                        t.length > 0 ? (i.setData({
                            hiddenTab: !1
                        }), i.setData({
                            tabList: t,
                            tabListLength: t.length
                        })) : i.setData({
                            hiddenTab: !0,
                            tabList: t,
                            tabListLength: t.length,
                            tabIndex: -1
                        }), e.data.data.shops.length > 0 && i.shopsFilter();
                    }
                },
                fail: function() {
                    0 == i.shopRequestNum && i.getNearbyShops(t, a), i.shopRequestNum = 1;
                }
            });
        }
    },
    shopsFilter: function() {
        var t = this, i = t.data.shops, n = t.data.loclatitude, r = t.data.loclongitude, s = [], d = t.data.tabIndex, c = t.data.tabList;
        if (-1 == d) a = i, t.setData({
            madename: "普通"
        }); else {
            var l = c[d].tab_name;
            t.setData({
                madename: l
            }), a = i.filter(function(e) {
                return "true" == e.is_customization;
            });
        }
        var u;
        if (c.length) {
            var h = -1 == d ? 0 : d;
            u = this.compareVersion(o.globalData.SDKVersion, "2.3.0") >= 0 ? c[h].dot_icon : "/images/root/icon_root_shopType.png";
        }
        for (var p = t.data.materialUrl_wechat_dmi, g = a.length, m = 0; m < g; m++) {
            var b = a[m];
            if (b.shopType = 14, b.dis = parseInt(e.getDistance(n, r, b.latitude, b.longitude)), 
            p) _ = p; else var _ = "/images/root/icon_root_shopType.png";
            var f = {
                id: m,
                iconPath: "true" == b.is_customization && c.length ? u : _,
                latitude: b.latitude,
                longitude: b.longitude,
                width: 32,
                height: 36,
                dis: b.dis,
                oldid: b.id
            };
            s.push(f);
        }
        t.selIndex = -1, t.setData({
            markers: s
        });
    },
    getRentedRecords: function() {
        if (o.globalData.session) {
            var e = this;
            wx.request({
                url: o.configObj.rentedRecordsUrl,
                data: {
                    session: o.globalData.session
                },
                header: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                method: "POST",
                success: function(t) {
                    if (0 == t.data.code && t.data.data.orders.length > 0) {
                        for (var a = [], i = 0; i < t.data.data.orders.length; i++) if ((2 == (c = t.data.data.orders[i]).status || 5 == c.status || 6 == c.status || 8 == c.status || 11 == c.status) && (a.push(c), 
                        201 == c.device_ver)) {
                            var n = c.fee_strategy_entity.fixed_time * c.fee_strategy_entity.fixed_unit, r = new Date().getTime(), s = c.borrow_time.replace(/-/g, "/"), d = Date.parse(new Date(s));
                            n - Math.floor((r - d) / 1e3) <= 0 && (o.bluetoothRefund(c.orderid), a.pop());
                        }
                        if (1 == a.length) {
                            var c = a[0];
                            e.setData({
                                orderid: c.orderid,
                                device_ver: c.device_ver
                            });
                        }
                        e.setData({
                            orderIngNum: a.length
                        });
                    }
                }
            });
        }
    },
    click: function() {
        var e = this, t = e.data.tabIndex, a = e.data.madename;
        getApp().http_post({
            bhv_type: "click",
            obj_type: "Control",
            title: "首页",
            control_name: "首页_扫码租借",
            other: {
                madename: a
            },
            act_obj: 10009
        }), o.qrCode(function(i) {
            var n = i.split("/")[3];
            if ("q" == n) if (o.globalData.session) if (-1 == t) wx.navigateTo({
                url: "/pages/index/sweep/sweep?qrcode=" + i + "&referrer_title=首页&madename=" + a
            }); else {
                var r = e.data.tabList[e.data.tabIndex];
                wx.navigateTo({
                    url: "/pages/index/sweepMade/sweepMade?qrcode=" + i + "&referrer_title=首页&custom_name=" + r.custom_name + "&custom_url=" + r.custom_url + "&background_color=" + r.background_color + "&adv_url=" + r.adv_url + "&madename=" + a
                });
            } else wx.getSetting({
                success: function(e) {
                    e.authSetting["scope.userInfo"] ? o.login() : wx.navigateTo({
                        url: "/pages/index/authorization/authorization"
                    });
                }
            }); else if ("x" == n) o.globalData.session ? wx.navigateTo({
                url: "/packageB/Bluetooth/Bluetooth?qrcode=" + i + "&referrer_title=首页"
            }) : wx.getSetting({
                success: function(e) {
                    e.authSetting["scope.userInfo"] ? o.login() : wx.navigateTo({
                        url: "/pages/index/authorization/authorization"
                    });
                }
            }); else if ("c" == n) {
                var s = encodeURIComponent(i);
                o.globalData.session ? wx.navigateTo({
                    url: "/packageA/Lottery/Lottery?qrcode=" + s
                }) : wx.getSetting({
                    success: function(e) {
                        e.authSetting["scope.userInfo"] ? o.login() : wx.navigateTo({
                            url: "/pages/index/authorization/authorization"
                        });
                    }
                });
            } else wx.showModal({
                title: "温馨提示",
                content: "这不是速绿充电的二维码",
                success: function(e) {
                    e.confirm || e.cancel;
                }
            });
        });
    },
    returnBut: function() {
        var e = this.data.orderid;
        getApp().http_post({
            bhv_type: "click",
            obj_type: "Control",
            title: "首页",
            control_name: "首页_我已归还"
        }), wx.navigateTo({
            url: "/pages/ordering/testing/testing?orderid=" + e
        });
    },
    toOrderInfo: function(e) {
        var t = this;
        if (getApp().http_post({
            bhv_type: "click",
            obj_type: "Control",
            title: "首页",
            control_name: "首页_查看",
            act_obj: 10016
        }), t.data.orderIngNum > 1) wx.navigateTo({
            url: "/pages/ordering/ordering"
        }); else {
            var a = t.data.orderid;
            wx.navigateTo({
                url: "/pages/ordering/orderingend/orderingend?orderid=" + a
            });
        }
    },
    helpproblem: function() {
        wx.navigateTo({
            url: "/pages/helpCenter/helpCenter?orderid=" + this.data.orderid + "&csEntryType=1"
        });
    },
    advertising: function() {
        o.pushAdv(this.adv_objStr.wechat_dsb, "300001");
    },
    bindfloatingWindow: function() {
        o.pushAdv(this.adv_objStr.wechat_df, "300004");
    },
    onbinddirectional: function() {
        o.pushAdv(this.adv_objStr.wechat_dt, "300003"), this.adv_objStr.wechat_dt.checkUrl && this.hideAd();
    },
    hideAd: function() {
        this.setData({
            showAd: !1,
            returnAd: !1
        });
    },
    toShopInfo: function() {
        getApp().http_post({
            bhv_type: "click",
            obj_type: "Control",
            title: "首页",
            other: {
                shopid: this.data.shopSel.ss_id,
                isipbattery: this.data.isipbattery,
                madename: this.data.madename
            },
            control_name: "首页_商铺选项卡",
            act_obj: 10012
        });
        var e = this.data.shopSel.ss_id, t = this.data.shopSel.dis;
        wx.navigateTo({
            url: "/packagenearby/nearby/details/details?ss_id=" + e + "&dis=" + t + "&urladd=1&referrer_title=商铺选项卡"
        }), this.uncheckMark();
    },
    bindmarkertap: function(t) {
        var o = this;
        setTimeout(function() {
            var i = o.data.markers, n = o.data.tabIndex, r = -1 == n ? 0 : n, s = o.data.tabList;
            if (i.length > o.selIndex && -1 != o.selIndex) {
                var d = i[o.selIndex];
                d.width = 32, d.height = 36, d.zIndex = 100, d.iconPath = "/images/root/icon_root_shopType.png";
            }
            o.selIndex = t.markerId;
            var c = i[o.selIndex];
            c.width = 38, c.height = 42, c.zIndex = 200, c.iconPath = "/images/root/icon_root_shopType_sel.png";
            var l = a[o.selIndex];
            if (l.shopType = e.getShopType(l.type), "true" == l.is_customization && s.length) u = s[r].tab_name; else var u = "0";
            l.isipbattery = u, o.setData({
                shopSel: l,
                markers: i,
                showShopInfo: !0
            }), getApp().http_post({
                bhv_type: "click",
                obj_type: "Control",
                title: "首页",
                other: {
                    shopid: o.data.shopSel.ss_id,
                    isipbattery: o.data.isipbattery,
                    madename: o.data.madename
                },
                control_name: "首页_地图网点图标",
                act_obj: 10011
            });
        }, 100);
    },
    uncheckMark: function() {
        this.setData({
            showShopInfo: !1
        });
        var e = this.data.markers;
        if (e && e.length > this.selIndex) {
            if (-1 != this.selIndex) {
                var t = e[this.selIndex];
                t.width = 32, t.height = 36, t.zIndex = 100, t.iconPath = "/images/root/icon_root_shopType.png";
            }
            this.setData({
                markers: e
            });
        }
    },
    hereto: function(e) {
        var t = Number(this.data.shopSel.latitude), a = Number(this.data.shopSel.longitude), o = e.currentTarget.dataset.name;
        wx.openLocation({
            latitude: t,
            longitude: a,
            name: o,
            scale: 18
        });
    },
    closeBLEConnection: function() {
        o.bluetoothDataObj.deviceId && wx.closeBLEConnection({
            deviceId: o.bluetoothDataObj.deviceId,
            success: function(e) {
                console.log("已断开连接！！"), console.log(e);
            },
            fail: function(e) {
                console.log("断开连接失败"), console.log(e);
            }
        });
    },
    statusMember: function() {
        var e = this;
        wx.request({
            url: o.configObj.memberStatus,
            data: {
                session: o.globalData.session
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(t) {
                if (0 == t.data.code) {
                    var a = t.data.data;
                    o.userMemberStatus = a, t.data.isPastDue ? (e.setData({
                        memberURL: "/images/Member/memberExpired.png",
                        memberURLclick: "1",
                        memberImgWidth: "380rpx"
                    }), o.memberObj.is_vip = 0) : "01" == a ? (e.shopVipRequest(), o.memberObj.is_vip = 0) : "02" == a ? (e.setData({
                        memberURL: "/images/Member/vipMember.png",
                        memberURLclick: "1",
                        memberImgWidth: "234rpx"
                    }), o.memberObj.is_vip = 1) : "03" == a ? (e.setData({
                        memberURL: "/images/Member/renewmenmber.png",
                        memberURLclick: "1",
                        memberImgWidth: "404rpx"
                    }), o.memberObj.is_vip = 1) : (e.shopVipRequest(), o.memberObj.is_vip = 0);
                }
            },
            fail: function() {},
            complete: function() {
                getApp().http_post({
                    bhv_type: "view",
                    obj_type: "Page",
                    title: "首页",
                    other: {},
                    act_obj: 10008
                });
            }
        });
    },
    shopVipRequest: function() {
        var e = this;
        o.userInfoRequest(function() {
            1 == o.globalData.userInfo.is_vip ? e.setData({
                memberURL: "/images/Member/shopVip.png",
                memberURLclick: "0",
                memberImgWidth: "244rpx"
            }) : "01" == o.userMemberStatus ? e.setData({
                memberURL: "/images/Member/Openingmember.png",
                memberURLclick: "1",
                memberImgWidth: "380rpx"
            }) : e.setData({
                memberURL: "/images/root/headTitle.png",
                memberURLclick: "0",
                memberImgWidth: "300rpx"
            });
        });
    },
    update_adv: function() {
        var e = this, t = wx.getStorageSync("adv_obj");
        t && (e.adv_objStr = JSON.parse(t), e.adv_objStr.wechat_dt ? (e.data.returnAd && o.advExposure(e.adv_objStr.wechat_dt, "300003"), 
        e.setData({
            checkUrl_wechat_dt: e.adv_objStr.wechat_dt.checkUrl,
            materialUrl_wechat_dt: o.configObj.advImgAdd + e.adv_objStr.wechat_dt.materialUrl,
            showAd: !0
        })) : wx.createInterstitialAd && !e.adShowed && (e.adShowed = !0, wx.createInterstitialAd({
            adUnitId: "adunit-300b88dbb615f027"
        }).show()), e.adv_objStr.wechat_dsb ? (o.advExposure(e.adv_objStr.wechat_dsb, "300001"), 
        e.setData({
            checkUrl_wechat_dsb: e.adv_objStr.wechat_dsb.checkUrl,
            materialUrl_wechat_dsb: o.configObj.advImgAdd + e.adv_objStr.wechat_dsb.materialUrl
        })) : e.setData({
            showAd_banner_before: !0
        }), e.adv_objStr.wechat_dmi && e.setData({
            checkUrl_wechat_dmi: e.adv_objStr.wechat_dmi.checkUrl,
            materialUrl_wechat_dmi: o.configObj.advImgAdd + e.adv_objStr.wechat_dmi.materialUrl
        }), e.adv_objStr.wechat_df && (o.advExposure(e.adv_objStr.wechat_df, "300004"), 
        e.setData({
            checkUrl_wechat_df: e.adv_objStr.wechat_df.checkUrl,
            materialUrl_wechat_df: o.configObj.advImgAdd + e.adv_objStr.wechat_df.materialUrl
        })));
    },
    compareVersion: function(e, t) {
        if (void 0 == e || void 0 == t) return 1;
        for (var e = e.split("."), t = t.split("."), a = Math.max(e.length, t.length); e.length < a; ) e.push("0");
        for (;t.length < a; ) t.push("0");
        for (var o = 0; o < a; o++) {
            var i = parseInt(e[o]), n = parseInt(t[o]);
            if (i > n) return 1;
            if (i < n) return -1;
        }
        return 0;
    },
    adLoadFinish_banner: function(e) {
        this.setData({
            showAd_banner: !0
        });
    },
    onShareAppMessage: function() {}
});