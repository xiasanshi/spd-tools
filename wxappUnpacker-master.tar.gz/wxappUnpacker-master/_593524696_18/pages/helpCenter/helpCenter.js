var t = getApp();

Page({
    data: {
        issueDataArr: [ {
            groupTitle: "使用问题",
            issueArr: [ {
                title: "充电宝无法充电",
                solution: "若充电宝无法充电，可轻敲充电宝，充电宝上的指示灯亮起即可充电。如仍无法充电，请归还充电宝再次租借"
            } ]
        }, {
            groupTitle: "归还问题",
            issueArr: [ {
                title: "归还后订单未结束",
                solution: "充电宝归还后，订单仍在进行中时，请再次按压充电宝，或联系在线客服"
            }, {
                title: "异地归还",
                solution: "充电宝支持异地归还"
            } ]
        }, {
            groupTitle: "支付问题",
            issueArr: [ {
                title: "订单如何支付",
                solution: "请确保第三方账户余额充足，订单完结后将从您的第三方账户余额中自动扣款。若扣款未成功，请充值第三方账户余额，进入第三方守约记录支付待付款订单"
            } ]
        }, {
            groupTitle: "费用问题",
            issueArr: [ {
                title: "押金如何提现",
                solution: "进入“个人中心-我的钱包”，点击余额提现"
            } ]
        } ],
        answerArr: []
    },
    toIssueInfo: function(t) {
        var e = t.currentTarget.dataset.index, o = parseInt(e.split(",")[0]), n = parseInt(e.split(",")[1]), i = this.data.issueDataArr[o].issueArr[n];
        wx.navigateTo({
            url: "issueInfo?title=" + i.title + "&solution=" + i.solution
        });
    },
    helps: function(e) {
        wx.showLoading({
            title: "请稍候",
            mask: !0
        });
        var o = this;
        wx.request({
            url: t.configObj.helpH5,
            data: {
                session: t.globalData.session,
                orderid: o.data.orderid,
                csEntryType: o.data.csEntryType,
                userType: "3"
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "GET",
            success: function(t) {
                if ("9802" == t.data.code) wx.navigateTo({
                    url: "/pages/index/authorization/authorization"
                }); else {
                    var e = "https://1tfdm1g.cschat-ccs.aliyun.com/index.htm?tntInstId=_1tfDm1g&scene=SCE00007330" + ("0000" == t.data.code ? t.data.data : "");
                    wx.navigateTo({
                        url: "/pages/advertising-h5/advertising-h5?advurl=" + encodeURIComponent(e)
                    });
                }
            },
            complete: function() {
                wx.hideLoading();
            }
        });
    },
    onLoad: function(t) {
        var e = this;
        "undefined" == t.orderid ? (e.setData({
            orderid: "",
            csEntryType: t.csEntryType
        }), console.log(e.data.orderid)) : e.setData({
            orderid: t.orderid,
            csEntryType: t.csEntryType
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});