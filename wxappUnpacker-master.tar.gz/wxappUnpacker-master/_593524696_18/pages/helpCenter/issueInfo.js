Page({
    data: {},
    onLoad: function(n) {
        this.setData({
            issueObj: n
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});