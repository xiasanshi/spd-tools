var t, e, a = getApp();

Page({
    data: {
        status: 2,
        leasefail: !1,
        percent: 1,
        isTesting: 0
    },
    onLoad: function(a) {
        var r = this;
        r.setData({
            orderid: a.orderid
        }), e = setInterval(function() {
            r.data.percent;
            r.percentAdd(a.orderid, function(t) {});
        }, 2e3), t = setInterval(function() {
            var a = r.data.percent;
            if (2 == r.data.status || 5 == r.data.status || 6 == r.data.status || 8 == r.data.status || 11 == r.data.status) r.setData({
                percent: ++a
            }); else {
                var s = r.data.orderid, d = r.data.last_time, o = r.data.ticket_usefee, n = r.data.usefee, i = r.data.fee_strategy;
                r.setData({
                    percent: 100
                }), clearInterval(e), wx.redirectTo({
                    url: "/pages/ordering/returnsuccess/returnsuccess?orderid=" + s + "&last_time=" + d + "&ticket_usefee=" + o + "&usefee=" + n + "&fee_strategy=" + i
                });
            }
            100 == a && (clearInterval(e), clearInterval(t), r.setData({
                isTesting: 1
            }), wx.setNavigationBarTitle({
                title: "归还失败"
            }));
        }, 200);
    },
    onShow: function(t) {
        var e = this.data.orderid;
        getApp().http_post({
            bhv_type: "view",
            obj_type: "Page",
            title: "检测充电宝归还",
            other: {
                orderid: e
            },
            act_obj: 10030
        });
    },
    retestTap: function() {
        var t = this;
        this.setData({
            code: 0,
            leasefail: !1,
            percent: 1,
            isTesting: 0
        }), wx.setNavigationBarTitle({
            title: "系统检测"
        }), getCurrentPages().pop().onLoad({
            orderid: t.data.orderid
        });
    },
    onHide: function() {},
    onUnload: function() {
        clearInterval(e), clearInterval(t);
    },
    percentAdd: function(t, e) {
        var r = this;
        wx.request({
            url: a.configObj.getOrderInfo,
            data: {
                session: a.globalData.session,
                orderid: t
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(t) {
                0 == t.data.code ? (2 == t.data.data.order.status || 5 == t.data.data.order.status || 6 == t.data.data.order.status || 8 == t.data.data.order.status || 11 == t.data.data.order.status ? r.setData({
                    status: t.data.data.order.status
                }) : r.setData({
                    status: t.data.data.order.status,
                    orderid: t.data.data.order.orderid,
                    last_time: t.data.data.order.last_time,
                    ticket_usefee: t.data.data.order.ticket_usefee,
                    usefee: t.data.data.order.use_fee,
                    fee_strategy: t.data.data.order.fee_strategy
                }), "function" == typeof e && e(t.data.data.order.status)) : wx.showToast({
                    title: t.data.msg,
                    icon: "none"
                });
            },
            fail: function(t) {
                "function" == typeof e && e(0);
            }
        });
    },
    collphone: function() {
        var t = this.data.orderid;
        wx.navigateTo({
            url: "/pages/helpCenter/helpCenter?orderid=" + t + "&csEntryType=4"
        });
    },
    onPullDownRefresh: function() {
        wx.stopPullDownRefresh();
    }
});