var n = getApp();

Page({
    data: {
        advertisingflag: !1,
        isconnection: !1,
        Unopened: !1
    },
    onLoad: function(n) {
        this.setData({
            orderid: n.orderid
        });
    },
    cancel: function() {
        this.setData({
            advertisingflag: !1,
            isconnection: !1
        });
    },
    bindlost: function() {
        this.setData({
            advertisingflag: !0,
            isconnection: !0
        });
    },
    withdrawal: function() {
        var a = this;
        a.setData({
            advertisingflag: !1,
            isconnection: !1
        });
        var e = a.data.orderid;
        wx.request({
            url: n.configObj.loseDisposeUrl,
            data: {
                session: n.globalData.session,
                orderid: e
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(n) {
                0 == n.data.code ? a.setData({
                    advertisingflag: !0,
                    Unopened: !0
                }) : 1 == n.data.code && wx.showModal({
                    content: n.data.msg,
                    showCancel: !1,
                    confirmText: "关闭",
                    success: function(n) {
                        n.confirm && wx.reLaunch({
                            url: "/pages/index/index"
                        });
                    }
                });
            }
        });
    },
    Close: function() {
        wx.reLaunch({
            url: "/pages/index/index"
        });
    },
    bindback: function() {
        wx.navigateBack({
            delta: 1
        });
    }
});