var e = getApp();

Page({
    data: {
        advertisingflag: !1,
        Unopened: !1,
        same_station: "",
        textarea_val: "",
        phonenum: 0,
        height: 20,
        focus: !1,
        picUrls: [],
        items: [ {
            name: "0",
            value: "取出异常"
        }, {
            name: "1",
            value: "归还异常"
        }, {
            name: "2",
            value: "充电宝无法充电"
        } ]
    },
    onLoad: function(e) {
        this.setData({
            orderid: e.orderid
        });
    },
    bindCamera: function(a) {
        var t = this, n = this;
        wx.chooseImage({
            count: 2,
            sizeType: [ "original", "compressed" ],
            sourceType: [ "album", "camera" ],
            success: function(a) {
                var s = a.tempFilePaths, i = t.data.picUrls;
                wx.uploadFile({
                    url: e.configObj.fileImgUrl,
                    filePath: s[0],
                    name: "file",
                    headers: {
                        "Content-Type": "multipart/form-data"
                    },
                    formData: {
                        session: e.globalData.session,
                        file: s
                    },
                    success: function(a) {
                        var t = JSON.parse(a.data);
                        t.data.image_url;
                        i.length < 2 && (i.push(t.data.image_url), n.setData({
                            picUrls: i,
                            phonenum: 1
                        })), 2 == i.length && n.setData({
                            picUrls: i,
                            phonenum: 2
                        }), wx.uploadFile({
                            url: e.configObj.fileImgUrl,
                            filePath: s[1],
                            name: "file",
                            headers: {
                                "Content-Type": "multipart/form-data"
                            },
                            formData: {
                                session: e.globalData.session,
                                file: s
                            },
                            success: function(e) {
                                var a = JSON.parse(e.data);
                                a.data.image_url;
                                i.length < 2 && (i.push(a.data.image_url), n.setData({
                                    picUrls: i,
                                    phonenum: 1
                                })), 2 == i.length && n.setData({
                                    picUrls: i,
                                    phonenum: 2
                                });
                            }
                        });
                    }
                });
            }
        });
    },
    delPic: function(e) {
        var a = e.target.dataset.index, t = this.data.picUrls;
        t.splice(a, 1), 0 == t.length ? this.setData({
            picUrls: t,
            phonenum: 0
        }) : this.setData({
            picUrls: t,
            phonenum: 1
        });
    },
    radioChange: function(e) {
        this.setData({
            same_station: e.detail.value
        });
    },
    bindTextAreaBlur: function(e) {
        this.setData({
            textarea_val: e.detail.value
        });
    },
    formSubmit: function(a) {
        var t = this, n = [ 3 ], s = JSON.stringify(n), i = t.data.picUrls, o = JSON.stringify(i), r = t.data.same_station, l = t.data.textarea_val, c = a.currentTarget.dataset.orderid;
        "" != r ? "" != l ? this.data.picUrls.length <= 0 ? wx.showModal({
            content: "请上传图片",
            confirmText: "确定",
            confirmColor: "#23C788",
            showCancel: !1,
            success: function(e) {}
        }) : wx.request({
            url: e.configObj.ProblemUrl,
            data: {
                session: e.globalData.session,
                service: "order",
                problem_ids: s,
                message: "充电宝已归还,但订单还在计费",
                orderid: c,
                img: o,
                same_station: r
            },
            method: "POST",
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            success: function(e) {
                1 == e.data.data.over_submit ? wx.showModal({
                    title: "温馨提示",
                    content: "同一个订单最多提交两次反馈",
                    showCancel: !1,
                    confirmColor: "#23C788",
                    success: function(e) {
                        e.confirm && wx.reLaunch({
                            url: "/pages/index/index"
                        });
                    }
                }) : t.setData({
                    advertisingflag: !0,
                    Unopened: !0
                });
            }
        }) : wx.showModal({
            content: "请输入问题描述",
            confirmText: "确定",
            confirmColor: "#23C788",
            showCancel: !1,
            success: function(e) {}
        }) : wx.showModal({
            content: "请选择问题类型",
            confirmText: "确定",
            confirmColor: "#23C788",
            showCancel: !1,
            success: function(e) {}
        });
    },
    preventTouchMove: function(e) {},
    Close: function() {
        wx.reLaunch({
            url: "/pages/index/index"
        });
    }
});