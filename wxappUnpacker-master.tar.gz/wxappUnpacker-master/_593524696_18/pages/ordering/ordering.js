var t = require("../../utils/WSCoordinate.js"), s = getApp();

Page({
    adv_objStr: {},
    data: {},
    onLoad: function() {
        var t = this;
        wx.showLoading({
            title: "正在加载"
        }), wx.getSystemInfo({
            success: function(s) {
                t.setData({
                    width: s.windowWidth,
                    height: s.windowHeight
                });
            }
        });
    },
    onShow: function() {
        var a = this;
        wx.getLocation({
            success: function(s) {
                var e = t.transformFromWGSToGCJ(s.latitude, s.longitude);
                a.setData({
                    longitude: e.longitude,
                    latitude: e.latitude
                });
            },
            fail: function() {
                a.setData({
                    longitude: 116.39747,
                    latitude: 39.908823
                });
            }
        }), s.globalData.session && a.getRentedRecords(), getApp().userLoginSuccessCallback = function() {
            a.getRentedRecords();
        };
        var e = wx.getStorageSync("adv_obj");
        e && (a.adv_objStr = JSON.parse(e), a.adv_objStr.wechat_wdib && (s.advExposure(a.adv_objStr.wechat_wdib, "300016"), 
        a.setData({
            checkUrl_wechat_wdib: a.adv_objStr.wechat_wdib.checkUrl,
            materialUrl_wechat_wdib: s.configObj.advImgAdd + a.adv_objStr.wechat_wdib.materialUrl
        })));
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        wx.showLoading({
            title: "正在加载"
        }), this.getRentedRecords(), wx.stopPullDownRefresh();
    },
    getRentedRecords: function() {
        if (s.globalData.session) {
            var t = this;
            wx.request({
                url: s.configObj.rentedRecordsUrl,
                data: {
                    session: s.globalData.session
                },
                header: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                method: "POST",
                success: function(a) {
                    if (0 == a.data.code) {
                        var e = a.data.data.orders;
                        if (e.length > 0) {
                            for (var o = 0; o < e.length; o++) {
                                var u = e[o];
                                if (1 == u.credit_flage ? (u.status = "待付款", u.statusImg = 6, e.splice(o, 1), e.unshift(u)) : 2 != u.status && 5 != u.status && 6 != u.status && 8 != u.status && 11 != u.status || 0 != u.credit_flage ? 10 != u.status && 64 != u.status && 65 != u.status && 66 != u.status && 67 != u.status && 68 != u.status && 69 != u.status && 70 != u.status && 82 != u.status && 83 != u.status && 84 != u.status && 85 != u.status && 86 != u.status && 87 != u.status && 88 != u.status && 89 != u.status && 90 != u.status && 94 != u.status && 95 != u.status && 96 != u.status && 97 != u.status && 201 != u.status && 202 != u.status && 203 != u.status && 204 != u.status && 205 != u.status && 301 != u.status && 302 != u.status || 0 != u.credit_flage ? 1 != u.status && 104 != u.status || 0 != u.credit_flage ? 92 == u.status && 0 == u.credit_flage ? (u.status = "押金已扣完", 
                                u.statusImg = 4) : 93 != u.status && 103 != u.status || 201 != u.device_ver ? 1002 == u.status ? (u.status = "已成功拥有", 
                                u.statusImg = 3) : 1003 == u.status ? (u.status = "已退款", u.statusImg = 3) : (u.status = "已完成", 
                                u.statusImg = 7) : (u.status = "已退款", u.statusImg = 5) : (u.status = "订单处理中", u.statusImg = 3) : (u.status = "租借失败", 
                                u.statusImg = 2) : (u.status = "租借中", u.statusImg = 1), "租借中" == u.status && 201 == u.device_ver) {
                                    var i = u.fee_strategy_entity.fixed_time * u.fee_strategy_entity.fixed_unit, n = new Date().getTime(), d = u.borrow_time.replace(/-/g, "/"), r = Date.parse(new Date(d));
                                    i - Math.floor((n - r) / 1e3) <= 0 && (s.bluetoothRefund(u.orderid), u.status = "已完成");
                                }
                            }
                            t.setData({
                                orders: e
                            });
                        } else t.setData({
                            orders: 0
                        });
                    } else wx.showModal({
                        content: a.data.msg,
                        showCancel: !1
                    });
                },
                fail: function() {},
                complete: function() {
                    wx.hideLoading();
                }
            });
        }
    },
    toOrderInfo: function(t) {
        var s = t.currentTarget.dataset.id;
        wx.navigateTo({
            url: "/pages/ordering/orderingend/orderingend?orderid=" + s
        });
    },
    copyID: function(t) {
        wx.setClipboardData({
            data: this.data.orders[t.currentTarget.dataset.ind].orderid,
            success: function(t) {
                wx.showToast({
                    title: "复制成功",
                    icon: "success",
                    duration: 1500,
                    complete: function() {}
                });
            }
        });
    },
    wechat_wdib: function() {
        s.pushAdv(this.adv_objStr.wechat_wdib, "300016");
    },
    adLoadFinish_banner: function(t) {
        this.setData({
            showAd_banner: !0
        });
    }
});