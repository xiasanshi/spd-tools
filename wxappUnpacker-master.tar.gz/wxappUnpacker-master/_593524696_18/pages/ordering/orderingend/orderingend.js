var e = require("../../../utils/util.js"), t = getApp();

Page({
    data: {
        isShow: !1,
        advertisingflag: !1,
        hour: "00",
        minute: "00",
        second: "00",
        orderEnd: 0
    },
    onLoad: function(e) {
        this.setData({
            orderid: e.orderid
        }), this.statusMember();
    },
    onShow: function() {
        getApp().http_post({
            bhv_type: "view",
            obj_type: "Page",
            title: "订单详情",
            other: {
                orderid: this.data.orderid
            },
            act_obj: 10028
        }), this.getRentedRecords();
    },
    onUnload: function() {
        clearInterval(void 0);
    },
    onPullDownRefresh: function() {
        wx.showLoading({
            title: "正在加载"
        }), this.getRentedRecords(), wx.stopPullDownRefresh();
    },
    getRentedRecords: function() {
        wx.showLoading({
            title: "正在加载"
        });
        var e = this;
        wx.request({
            url: t.configObj.getOrderInfo,
            data: {
                session: t.globalData.session,
                orderid: e.data.orderid
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(t) {
                if (0 == t.data.code) {
                    var o = t.data.data.order;
                    o.subTxt = "感谢使用速绿充电";
                    var a, i = o.status;
                    if (1 == o.credit_flage) {
                        var r = o.return_time ? o.return_time.replace(/-/g, "/") : new Date(), n = (new Date().getTime() - new Date(r).getTime()) / 1e3 / 60;
                        e.setData({
                            timeRange: n
                        }), o.status = "待付款", o.statusImg = 6, o.toolBtn = "去支付", a = [ [ {
                            title: "订单编号",
                            code: "orderid"
                        }, {
                            title: "租借地点",
                            code: "borrow_name"
                        }, {
                            title: "归还地点",
                            code: "return_name"
                        }, {
                            title: "借出时间",
                            code: "borrow_time"
                        }, {
                            title: "归还时间",
                            code: "return_time"
                        } ], [ {
                            title: "租借时长",
                            code: "last_time"
                        }, {
                            title: "费用合计",
                            code: "sum_fee"
                        }, {
                            title: "待支付金额",
                            code: "sum_fee"
                        }, {
                            title: "收费策略",
                            code: "fee_strategy"
                        } ] ];
                    } else 2 != i && 5 != i && 6 != i && 8 != i && 11 != i || 0 != o.credit_flage ? 10 != i && 64 != i && 65 != i && 66 != i && 67 != i && 68 != i && 69 != i && 70 != i && 82 != i && 83 != i && 84 != i && 85 != i && 86 != i && 87 != i && 88 != i && 89 != i && 90 != i && 94 != i && 95 != i && 96 != i && 97 != i && 201 != i && 202 != i && 203 != i && 204 != i && 205 != i && 301 != i && 302 != i || 0 != o.credit_flage ? 1 != i && 104 != i || 0 != o.credit_flage ? 93 != i && 103 != i || 201 != o.device_ver ? (92 == i && 0 == o.credit_flage ? (o.status = "押金已扣完", 
                    o.statusImg = 4) : (o.status = "已完成", o.statusImg = 7, o.toolBtn = "再次租借"), a = [ [ {
                        title: "订单编号",
                        code: "orderid"
                    }, {
                        title: "租借地点",
                        code: "borrow_name"
                    }, {
                        title: "归还地点",
                        code: "return_name"
                    }, {
                        title: "借出时间",
                        code: "borrow_time"
                    }, {
                        title: "归还时间",
                        code: "return_time"
                    } ], [ {
                        title: "租借时长",
                        code: "last_time"
                    }, {
                        title: "费用合计",
                        code: "sum_fee"
                    }, {
                        title: "优惠金额",
                        code: "ticket_usefee"
                    }, {
                        title: "实际扣费",
                        code: "use_fee"
                    }, {
                        title: "收费策略",
                        code: "fee_strategy"
                    } ] ]) : (o.status = "已退款", o.subTxt = "订单已退款，预计0-3个工作日到账", o.statusImg = 5, o.toolBtn = "再次租借") : (o.status = "订单处理中", 
                    o.statusImg = 3, o.toolBtn = "返回首页", a = [ [ {
                        title: "订单编号",
                        code: "orderid"
                    }, {
                        title: "租借地点",
                        code: "borrow_name"
                    } ], [ {
                        title: "收费策略",
                        code: "fee_strategy"
                    } ] ]) : (o.status = "租借失败", o.statusImg = 2, o.toolBtn = "重新租借", a = [ [ {
                        title: "订单编号",
                        code: "orderid"
                    }, {
                        title: "租借地点",
                        code: "borrow_name"
                    }, {
                        title: "借出时间",
                        code: "borrow_time"
                    } ], [ {
                        title: "收费策略",
                        code: "fee_strategy"
                    } ] ]) : (o.status = "租借中", o.subTxt = "使用完成后请及时归还充电宝", o.statusImg = 1, o.toolBtn = "在线客服", 
                    a = [ [ {
                        title: "订单编号",
                        code: "orderid"
                    }, {
                        title: "租借地点",
                        code: "borrow_name"
                    }, {
                        title: "借出时间",
                        code: "borrow_time"
                    } ], [ {
                        title: "租借时长",
                        code: "last_time"
                    }, {
                        title: "费用合计",
                        code: "sum_fee"
                    }, {
                        title: "收费策略",
                        code: "fee_strategy"
                    } ] ]);
                    if (201 == o.device_ver) {
                        a = [ [ {
                            title: "订单编号",
                            code: "orderid"
                        }, {
                            title: "租借地点",
                            code: "borrow_name"
                        }, {
                            title: "借出时间",
                            code: "borrow_time"
                        } ], [ {
                            title: "已退款" == o.status ? "退款金额" : "支付费用",
                            code: "use_fee"
                        }, {
                            title: "使用限制时长",
                            code: "usr_confine"
                        } ] ];
                        var s = o.fee_strategy_entity.fixed_time * o.fee_strategy_entity.fixed_unit;
                        e.setData({
                            bluetoothMac: o.mac,
                            Stime: s
                        });
                    }
                    a.map(function(t, a) {
                        t.map(function(t) {
                            var a = "ticket_usefee" == t.code || "use_fee" == t.code ? "元" : "";
                            if ("sum_fee" == t.code) {
                                var i = o.use_fee + o.ticket_usefee;
                                t.value = i + "元";
                            } else "usr_confine" == t.code ? t.value = e.getBlueToothUsrConfine() : t.value = o[t.code] + a;
                        });
                    }), e.setData({
                        orderInfo: o,
                        orderData: a
                    }), 201 == o.device_ver && ("租借中" == o.status ? (e.setData({
                        showBluetoothTimeCount: !0
                    }), e.time()) : e.setData({
                        showBluetoothTimeCount: !1
                    })), "租借中" == o.status && 201 != o.device_ver && e.getNearbyShops();
                } else wx.showToast({
                    title: t.data.msg,
                    icon: "none"
                });
            },
            fail: function() {},
            complete: function() {
                wx.hideLoading();
            }
        });
    },
    getBlueToothUsrConfine: function() {
        var e, t, o = this.data.Stime;
        return o < 3600 ? e = "分钟" : o >= 3600 && (e = "小时"), o < 3600 ? t = o / 60 : o >= 3600 && (t = o / 3600), 
        t + e;
    },
    getNearbyShops: function() {
        var o = this, a = t.dataObj.gps, i = "", r = "";
        a.indexOf(",") && (i = a.split(",")[0], r = a.split(",")[1]), wx.request({
            url: t.configObj.getShopListPagingUrl,
            data: {
                session: t.globalData.session,
                longitude: i,
                latitude: r,
                skip: 0
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(t) {
                if (0 == t.data.code) {
                    for (var a = t.data.data.shops, n = 0; n < a.length; n++) {
                        var s = a[n], d = e.getDistance(r, i, s.latitude, s.longitude);
                        s.dis = parseInt(d), s.shopType = e.getShopType(s.type);
                    }
                    (a = a.slice(0, 10)).sort(o.objSort("dis")), o.setData({
                        shops: a
                    });
                }
            },
            fail: function() {},
            complete: function() {
                wx.hideLoading();
            }
        });
    },
    objSort: function(e) {
        return function(t, o) {
            return t[e] - o[e];
        };
    },
    toolBtnTouch: function(e) {
        var t = this.data.orderInfo.toolBtn;
        "在线客服" == t ? this.bindhelp() : "重新租借" == t || "再次租借" == t ? this.rentAgain() : "返回首页" == t ? this.returnone() : "去支付" == t && this.toPayment();
    },
    toPayment: function() {
        wx.showLoading({
            title: "请稍候",
            mask: !0
        });
        var e = this, o = e.data.orderid;
        wx.request({
            url: t.configObj.paycreditUrl,
            data: {
                session: t.globalData.session,
                orderid: o
            },
            method: "POST",
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            success: function(t) {
                wx.hideLoading(), setTimeout(e.getRentedRecords, 3e3), wx.showToast({
                    title: t.data.msg,
                    icon: "none"
                });
            },
            fail: function() {
                wx.hideLoading();
            }
        });
    },
    rentAgain: function() {
        t.qrCode(function(e) {
            var t = e.split("/")[3];
            if ("q" == t) wx.navigateTo({
                url: "/pages/index/sweep/sweep?qrcode=" + e + "&referrer_title=订单详情"
            }); else if ("x" == t) wx.navigateTo({
                url: "/packageB/Bluetooth/Bluetooth?qrcode=" + e + "&referrer_title=订单详情"
            }); else if ("c" == t) {
                var o = encodeURIComponent(e);
                wx.navigateTo({
                    url: "/packageA/Lottery/Lottery?qrcode=" + o
                });
            } else wx.showModal({
                title: "温馨提示",
                content: "这不是速绿充电的二维码",
                success: function(e) {
                    e.confirm || e.cancel;
                }
            });
        });
    },
    binduse: function(e) {
        var t = this.data.orderid;
        wx.navigateTo({
            url: "/pages/ordering/feedback/feedback?orderid=" + t
        });
    },
    bindlose: function(e) {
        var t = this.data.orderid;
        wx.navigateTo({
            url: "/pages/ordering/lost-powerback/lost-powerback?orderid=" + t
        });
    },
    bindhelp: function() {
        var e = this.data.orderid;
        wx.navigateTo({
            url: "/pages/helpCenter/helpCenter?orderid=" + e + "&csEntryType=2"
        });
    },
    returnone: function() {
        wx.reLaunch({
            url: "/pages/index/index"
        });
    },
    copyID: function(e) {
        wx.setClipboardData({
            data: this.data.orderid,
            success: function(e) {
                wx.showToast({
                    title: "复制成功",
                    icon: "success",
                    duration: 1500,
                    complete: function() {}
                });
            }
        });
    },
    bluetoothBlackout: function() {
        var e = this, t = Math.ceil(e.data.timer / 60), o = e.data.bluetoothMac, a = e.data.orderid;
        getApp().http_post({
            bhv_type: "click",
            obj_type: "Control",
            title: "订单详情",
            other: {
                orderid: a
            },
            control_name: "订单详情_无故断电",
            act_obj: 10064
        }), wx.redirectTo({
            url: "/packageB/Bluetooth/openbluetoothNotice/openbluetoothNotice?states=2&timer=" + t + "&bluetoothMac=" + o + "&orderid=" + a
        });
    },
    breakSure: function() {
        var e = this, t = Math.ceil(e.data.timer / 60), o = e.data.bluetoothMac;
        wx.redirectTo({
            url: "/packageB/Bluetooth/progress/progress?states=2&timer=" + t + "&bluetoothMac=" + o
        });
    },
    time: function() {
        var e = this;
        clearInterval(e.timesclear), e.timesclear = setInterval(function() {
            e.countDown();
        }, 1e3), e.countDown();
    },
    countDown: function() {
        var e = this, t = new Date().getTime(), o = e.data.orderInfo.borrow_time.replace(/-/g, "/"), a = Date.parse(new Date(o)), i = Math.floor((t - a) / 1e3), r = e.data.Stime - i;
        if (e.setData({
            timer: r,
            goingtime: i
        }), r <= 0) e.setData({
            hour: "00",
            minute: "00",
            second: "00"
        }), clearInterval(e.timesclear), getApp().bluetoothRefund(e.data.orderid, e.getRentedRecords); else {
            e.setData({
                timer: e.data.timer - 1
            });
            var n = Math.floor(e.data.timer / 3600), s = Math.floor(e.data.timer % 3600 / 60), d = Math.floor(e.data.timer % 60);
            n = n < 10 ? "0" + n : n, s = s < 10 ? "0" + s : s, d = d < 10 ? "0" + d : d, e.setData({
                hour: n,
                minute: s,
                second: d
            });
        }
    },
    statusMember: function() {
        var e = this;
        wx.request({
            url: t.configObj.memberStatus,
            data: {
                session: t.globalData.session
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(o) {
                if (0 == o.data.code) {
                    var a = o.data.data;
                    t.userMemberStatus = a, "01" == a && e.setData({
                        memberShow: !0
                    });
                }
            }
        });
    },
    memberViewTouch: function() {
        wx.navigateTo({
            url: "/pages/index/member/member?backRoot=true&referrer_title=订单详情"
        });
    },
    hereto: function(e) {
        var t = this.data.shops[e.currentTarget.dataset.index];
        wx.openLocation({
            latitude: Number(t.latitude),
            longitude: Number(t.longitude),
            name: t.name,
            address: t.address,
            scale: 18
        });
    },
    toShopInfo: function(e) {
        var t = e.currentTarget.dataset.ind, o = this.data.shops[t];
        wx.navigateTo({
            url: "/packagenearby/nearby/details/details?dis=" + o.dis + "&ss_id=" + o.ss_id + "&urladd=1&referrer_title=订单详情"
        });
    }
});