var e = getApp();

Page({
    adv_objStr: {},
    data: {},
    onLoad: function(e) {
        var t = this;
        wx.showLoading({
            title: "正在加载"
        }), t.setData({
            orderid: e.orderid,
            last_time: e.last_time,
            ticket_usefee: Number(e.ticket_usefee),
            usefee: Number(e.usefee),
            fee_strategy: e.fee_strategy
        }), wx.hideLoading();
    },
    onShow: function() {
        var t = this, a = wx.getStorageSync("adv_obj");
        a && (t.adv_objStr = JSON.parse(a), t.adv_objStr.wechat_gdb && (e.advExposure(t.adv_objStr.wechat_gdb, "300018"), 
        t.setData({
            checkUrl_wechat_gdb: t.adv_objStr.wechat_gdb.checkUrl,
            materialUrl_wechat_gdb: e.configObj.advImgAdd + t.adv_objStr.wechat_gdb.materialUrl
        })));
    },
    returnone: function() {
        wx.reLaunch({
            url: "/pages/index/index"
        });
    },
    catchAd: function() {
        e.pushAdv(this.adv_objStr.wechat_gdb, "300018");
    }
});