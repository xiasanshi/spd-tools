Page({
    data: {},
    onLoad: function(n) {
        var o = decodeURIComponent(n.advurl);
        this.setData({
            advurl: o
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});