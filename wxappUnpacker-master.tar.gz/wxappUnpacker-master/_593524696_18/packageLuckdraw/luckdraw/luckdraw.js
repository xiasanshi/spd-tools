var a = getApp();

Page({
    data: {
        showboxhide: !1,
        showmodalhide: !1,
        showpopupboxhide: !1,
        canPrizeNumhide: !1,
        carWidth: "",
        number: 8,
        cardData: []
    },
    onLoad: function(a) {
        wx.showLoading({
            title: "正在加载"
        });
        var e = 0;
        wx.getSystemInfo({
            success: function(a) {
                e = parseInt((a.windowWidth - 180) / 3);
            }
        }), this.setData({
            routeid: a.routeid,
            carWidth: e
        });
    },
    onShow: function() {
        var e = this, t = setInterval(function() {
            a.globalData.session && (e.getPrizeAwardsluck(), getApp().userLoginSuccessCallback = function() {
                e.getPrizeAwardsluck();
            }, clearInterval(t));
        }, 500);
    },
    onPullDownRefresh: function() {
        wx.showLoading({
            title: "正在加载"
        }), this.getPrizeAwardsluck(), wx.stopPullDownRefresh();
    },
    getPrizeAwardsluck: function() {
        var e = this;
        wx.request({
            url: a.configObj.getPrizeAwards,
            data: {
                session: a.globalData.session
            },
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            method: "POST",
            success: function(a) {
                if (5 == a.data.code) getApp().globalData.session = null, getApp().login(); else if (0 == a.data.code) {
                    for (var t = [], i = a.data.awards, o = 0; o < i.length; o++) {
                        var n = 100;
                        o % 3 == 0 && (n = o + 200), t.push({
                            front: "../images/img2_03.png",
                            id: i[o].id,
                            imgurl: i[o].imgurl,
                            advurl: i[o].advurl,
                            name: i[o].name,
                            disabled: !1,
                            animationData: {},
                            idnum: o + 1,
                            showClass: !1,
                            zIndex: n
                        });
                    }
                    if (a.data.canPrizeNum <= 0) r = 0; else var r = a.data.canPrizeNum;
                    e.setData({
                        cardData: t,
                        canPrizeNum: r
                    }), e.addPosition();
                } else wx.showModal({
                    content: a.data.msg,
                    confirmText: "确定",
                    showCancel: !1,
                    success: function(a) {
                        a.confirm && wx.reLaunch({
                            url: "/pages/index/index"
                        });
                    }
                });
            },
            fail: function() {
                wx.showToast({
                    title: "请求失败",
                    duration: 1500,
                    complete: function() {}
                });
            },
            complete: function() {
                wx.hideLoading();
            }
        });
    },
    handleCurClick: function(e) {
        var t = this, i = e.currentTarget.dataset.idnum;
        t.setData({
            curId: i,
            showClass: !0,
            showboxhide: !0
        });
        var o = e.currentTarget.dataset.imgurl, n = e.currentTarget.dataset.advurl, r = e.currentTarget.dataset.id, s = e.currentTarget.dataset.name, d = t.data.canPrizeNum;
        t.allMove(), setTimeout(function() {
            d > 0 ? (t.setData({
                name: s,
                pid: r,
                imgurl: o,
                advurl: n,
                showmodalhide: !0,
                showpopupboxhide: !0,
                showboxhide: !1
            }), wx.request({
                url: a.configObj.savePrizeLog,
                data: {
                    session: a.globalData.session,
                    pid: r,
                    name: s
                },
                header: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                method: "POST",
                success: function(a) {
                    0 == a.data.code && t.getPrizeAwardsluck();
                },
                fail: function() {},
                complete: function() {}
            })) : t.setData({
                showmodalhide: !0,
                canPrizeNumhide: !0,
                showboxhide: !1
            });
        }, 1500);
    },
    hidepopuh: function() {
        this.setData({
            showmodalhide: !1,
            showpopupboxhide: !1,
            showboxhide: !1
        });
    },
    determine: function() {
        this.setData({
            showmodalhide: !1,
            canPrizeNumhide: !1,
            showboxhide: !1
        });
    },
    bindhome: function() {
        var a = this.data.routeid;
        1 == a ? wx.navigateBack({}) : 2 == a && wx.reLaunch({
            url: "/pages/index/index"
        });
    },
    receive: function() {
        var e = this, t = e.data.advurl, i = (e.data.name, e.data.pid);
        if (e.setData({
            showmodalhide: !1,
            showpopupboxhide: !1
        }), "爱奇艺" == t) wx.navigateTo({
            url: "/packageaiqiyi/aiqiyi/aiqiyi?videoHY=aqyhy"
        }); else if ("优酷" == t) wx.navigateTo({
            url: "/packageaiqiyi/aiqiyi/aiqiyi?videoHY=ykhy"
        }); else if ("喜马拉雅" == t) wx.navigateTo({
            url: "/packageaiqiyi/aiqiyi/aiqiyi?videoHY=xmly"
        }); else if ("腾讯" == t) wx.navigateTo({
            url: "/packageaiqiyi/aiqiyi/aiqiyi?videoHY=tengxu"
        }); else if ("芒果" == t) wx.navigateTo({
            url: "/packageaiqiyi/aiqiyi/aiqiyi?videoHY=mangguo"
        }); else {
            var o = a.configObj.host + "/a/" + i;
            wx.navigateTo({
                url: "/pages/advertising-h5/advertising-h5?advurl=" + encodeURIComponent(o)
            });
        }
    },
    addPosition: function() {
        var a = this.data.cardData;
        a.map(function(a, e) {
            var t = e % 3, i = parseInt((e + 3) / 3);
            a.twoArry = {
                x: t,
                y: i
            }, a.zindex = 0, a.disabled = !1;
        }), this.setData({
            cardData: a
        });
    },
    allMove: function() {
        var a = this;
        console.log("hahahahah");
        var e = this.data, t = e.carWidth;
        e.cardData;
        this.shuffle(t);
        var i = setTimeout(function() {
            clearTimeout(i), a.shuffle2(0);
        }, 1e3);
    },
    shuffle: function(a) {
        a = a;
        console.log("translateUnit" + a);
        var e = this.data.cardData, t = this.data.curId - 1;
        if (3 == t || 4 == t || 5 == t) a = a + 10;
        if (6 == t || 7 == t || 8 == t) var a = a + 20;
        console.log(e);
        var i = wx.createAnimation({
            duration: 500,
            timingFunction: "ease"
        });
        if (i.export(), 0 == t) o = -(a * (e[t].twoArry.x - 1) - 30); else if (3 == t || 6 == t) o = -(a * (e[t].twoArry.x - 1) - 30); else if (2 == t || 5 == t || 8 == t) o = -(a * (e[t].twoArry.x - 1) + 30); else var o = -a * (e[t].twoArry.x - 1);
        var n = a * e[t].twoArry.y;
        i.translate(o, -n).scale(1.5, 1.5).step({
            duration: 500
        }).rotate(-30).step({
            duration: 50
        }).rotate(30).step({
            duration: 100
        }).rotate(-30).step({
            duration: 100
        }).rotate(0).step({
            duration: 50
        }), e[t].animationData = i.export(), this.setData({
            cardData: e
        });
    },
    shuffle2: function(a) {
        var a = a;
        console.log("translateUnit" + a);
        var e = this.data.cardData, t = this.data.curId - 1;
        console.log(e);
        var i = wx.createAnimation({
            duration: 500,
            timingFunction: "ease"
        });
        i.export();
        var o = a * (1 - e[t].twoArry.x), n = a * (1 - e[t].twoArry.y);
        i.translate(o, n).scale(1, 1).step(), e[t].animationData = i.export(), this.setData({
            cardData: e
        });
    }
});