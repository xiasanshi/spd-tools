// packageA/Lottery/Lottery.js
Page({data: {}})